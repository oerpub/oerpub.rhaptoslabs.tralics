/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ANY = 258,
     SET = 259,
     END = 260,
     DVIY = 261,
     PAR = 262,
     FontChange = 263,
     SPACE = 264,
     CR = 265,
     BLeft = 266,
     ELeft = 267,
     BRight = 268,
     ERight = 269,
     LeftNull = 270,
     RightNull = 271,
     BTBOX = 272,
     ETBOX = 273,
     BMBOX = 274,
     EMBOX = 275,
     BFBOX = 276,
     EFBOX = 277,
     BPUBLISHED = 278,
     EPUBLISHED = 279,
     BMATHICS = 280,
     EMATHICS = 281,
     BICSIDX = 282,
     EICSIDX = 283,
     BICSDESC = 284,
     EICSDESC = 285,
     BMATVERW = 286,
     EMATVERW = 287,
     BMATHICSSUB = 288,
     EMATHICSSUB = 289,
     BackgroundColor = 290,
     POST_POST = 291,
     BENTRY = 292,
     EENTRY = 293,
     BTITLE = 294,
     ETITLE = 295,
     BAUTHOR = 296,
     EAUTHOR = 297,
     BName = 298,
     EName = 299,
     BDATE = 300,
     EDATE = 301,
     BTHANKS = 302,
     ETHANKS = 303,
     MAKETITLE = 304,
     BComment = 305,
     EComment = 306,
     BCAuthor = 307,
     ECAuthor = 308,
     BSubjectClass = 309,
     ESubjectClass = 310,
     BDedicatory = 311,
     EDedicatory = 312,
     BURL = 313,
     EURL = 314,
     BEMAIL = 315,
     EEMAIL = 316,
     BAffiliation = 317,
     EAffiliation = 318,
     BAddress = 319,
     EAddress = 320,
     BCAddress = 321,
     ECAddress = 322,
     BKeywords = 323,
     EKeywords = 324,
     BPACS = 325,
     EPACS = 326,
     BIdLine = 327,
     EIdLine = 328,
     BDOI = 329,
     EDOI = 330,
     BCopyright = 331,
     ECopyright = 332,
     BLocation = 333,
     ELocation = 334,
     BJournal = 335,
     EJournal = 336,
     BLogo = 337,
     ELogo = 338,
     BBranch = 339,
     EBranch = 340,
     BEQTAG = 341,
     EEQTAG = 342,
     BBINOM = 343,
     EBINOM = 344,
     BBINOMUP = 345,
     EBINOMUP = 346,
     BBINOMDOWN = 347,
     EBINOMDOWN = 348,
     BHEADLINE = 349,
     EHEADLINE = 350,
     BFOOTLINE = 351,
     EFOOTLINE = 352,
     BEnv = 353,
     EEnv = 354,
     BAbstract = 355,
     EAbstract = 356,
     AbsLang = 357,
     Item = 358,
     BList = 359,
     EList = 360,
     BLabel = 361,
     ELabel = 362,
     BBibliography = 363,
     EBibliography = 364,
     BBibLabel = 365,
     EBibLabel = 366,
     BSectMark = 367,
     ESectMark = 368,
     SectType = 369,
     BSectLabel = 370,
     ESectLabel = 371,
     BSectTitle = 372,
     ESectTitle = 373,
     BCaption = 374,
     ECaption = 375,
     BFigureTag = 376,
     EFigureTag = 377,
     FigureFileName = 378,
     EPSFigureFileName = 379,
     Id = 380,
     BRef = 381,
     Ref = 382,
     ERef = 383,
     BCite = 384,
     ECite = 385,
     BCiteLabel = 386,
     ECiteLabel = 387,
     CiteSRef = 388,
     BFootnoteMark = 389,
     EFootnoteMark = 390,
     BFootnote = 391,
     EFootnote = 392,
     BFloat = 393,
     EFloat = 394,
     FType = 395,
     BTabular = 396,
     ETabular = 397,
     BTabularx = 398,
     ETabularx = 399,
     FOption = 400,
     AOption = 401,
     BLTable = 402,
     ELTable = 403,
     BLTBody = 404,
     ELTBody = 405,
     BLTCaption = 406,
     ELTCaption = 407,
     TABCR = 408,
     HLINE = 409,
     SPAN = 410,
     BMultiColumn = 411,
     EMultiColumn = 412,
     MultiColumnNumber = 413,
     MultiColumnFormat = 414,
     TACCENT = 415,
     TACCENTU = 416,
     MACCENT = 417,
     BIGSQCUP = 418,
     BIGSQCAP = 419,
     IMATHB = 420,
     IMATHE = 421,
     DMATHB = 422,
     DMATHE = 423,
     Bfile = 424,
     Efile = 425,
     EQNO = 426,
     LEQNO = 427,
     REQNO = 428,
     BEqNum = 429,
     EEqNum = 430,
     BFoot = 431,
     EFoot = 432,
     BHead = 433,
     EHead = 434,
     BPage = 435,
     EPage = 436,
     ALIGN = 437,
     BMTABLE = 438,
     EMTABLE = 439,
     BARRAY = 440,
     EARRAY = 441,
     BEqnArray = 442,
     EEqnArray = 443,
     BAligned = 444,
     EAligned = 445,
     BAlign = 446,
     EAlign = 447,
     BEQALIGN = 448,
     EEQALIGN = 449,
     BSplit = 450,
     ESplit = 451,
     BSP = 452,
     ESP = 453,
     BPower = 454,
     Power = 455,
     EPower = 456,
     BSB = 457,
     ESB = 458,
     SBCHAR = 459,
     LT = 460,
     GT = 461,
     NEQ = 462,
     ARCCOS = 463,
     ARCSIN = 464,
     ARCTAN = 465,
     ARG = 466,
     COS = 467,
     COSH = 468,
     COT = 469,
     COTH = 470,
     CSC = 471,
     DEG = 472,
     DET = 473,
     DIM = 474,
     EXP = 475,
     GCD = 476,
     HOM = 477,
     INF = 478,
     KER = 479,
     LG = 480,
     LIM = 481,
     LIMINF = 482,
     LIMSUP = 483,
     LN = 484,
     LOG = 485,
     MAX = 486,
     MIN = 487,
     PR = 488,
     SEC = 489,
     SIN = 490,
     SINH = 491,
     SUP = 492,
     TAN = 493,
     TANH = 494,
     CDOTS = 495,
     DDOTS = 496,
     LDOTS = 497,
     VDOTS = 498,
     BFRAC = 499,
     FRACN = 500,
     FRACD = 501,
     EFRAC = 502,
     OVER = 503,
     CHOOSE = 504,
     ATOP = 505,
     BBUILDREL = 506,
     BUILDREL = 507,
     EBUILDREL = 508,
     MAPSTO = 509,
     LMAPSTO = 510,
     MODELS = 511,
     HLARROW = 512,
     HRARROW = 513,
     lLARROW = 514,
     LLARROW = 515,
     lRARROW = 516,
     LRARROW = 517,
     lLRARROW = 518,
     LLRARROW = 519,
     BOWTIE = 520,
     BOVERLARROW = 521,
     EOVERLARROW = 522,
     BOVERRARROW = 523,
     EOVERRARROW = 524,
     BUNDERLARROW = 525,
     EUNDERLARROW = 526,
     BUNDERRARROW = 527,
     EUNDERRARROW = 528,
     BOVERBRACE = 529,
     EOVERBRACE = 530,
     BUNDERBRACE = 531,
     EUNDERBRACE = 532,
     BWIDEHAT = 533,
     EWIDEHAT = 534,
     BWIDETILDE = 535,
     EWIDETILDE = 536,
     BDOT = 537,
     EDOT = 538,
     BOVERLINE = 539,
     EOVERLINE = 540,
     BUNDERLINE = 541,
     EUNDERLINE = 542,
     BMO = 543,
     EMO = 544,
     BSQRT = 545,
     SQRT = 546,
     ESQRT = 547,
     BROOT = 548,
     ROOT = 549,
     EROOT = 550,
     BRoot = 551,
     Root = 552,
     ERoot = 553,
     BSqrt = 554,
     ESqrt = 555,
     Bfunc = 556,
     Bfarg = 557,
     Efarg = 558,
     Efunc = 559,
     BInterval = 560,
     Interval = 561,
     EInterval = 562,
     BCompose = 563,
     Compose = 564,
     ECompose = 565,
     BInverse = 566,
     Inverse = 567,
     EInverse = 568,
     Ident = 569,
     BDomain = 570,
     EDomain = 571,
     BCodomain = 572,
     ECodomain = 573,
     BImage = 574,
     EImage = 575,
     BAmsCases = 576,
     EAmsCases = 577,
     BCases = 578,
     ECases = 579,
     BCasesRow = 580,
     ECasesRow = 581,
     BBra = 582,
     EBra = 583,
     BKet = 584,
     EKet = 585,
     NOTIN = 586,
     BPlus = 587,
     Plus = 588,
     EPlus = 589,
     BMinus = 590,
     Minus = 591,
     EMinus = 592,
     BTimes = 593,
     Times = 594,
     ETimes = 595,
     BQuotient = 596,
     Quotient = 597,
     EQuotient = 598,
     BFactorial = 599,
     Factorial = 600,
     EFactorial = 601,
     BFrac = 602,
     Fracn = 603,
     Fracd = 604,
     EFrac = 605,
     BMaxl = 606,
     BMaxc = 607,
     EMaxl = 608,
     EMaxc = 609,
     BVar = 610,
     EVar = 611,
     BCond = 612,
     ECond = 613,
     BExpr = 614,
     EExpr = 615,
     BMinl = 616,
     BMinc = 617,
     EMinl = 618,
     EMinc = 619,
     BRem = 620,
     Rem = 621,
     ERem = 622,
     REM = 623,
     BPMOD = 624,
     EPMOD = 625,
     BGcd = 626,
     EGcd = 627,
     BLcm = 628,
     ELcm = 629,
     LCM = 630,
     BRe = 631,
     ERe = 632,
     BIm = 633,
     EIm = 634,
     AND = 635,
     BLand = 636,
     Land = 637,
     ELand = 638,
     OR = 639,
     BLor = 640,
     Lor = 641,
     ELor = 642,
     XOR = 643,
     BXor = 644,
     Xor = 645,
     EXor = 646,
     BNot = 647,
     ENot = 648,
     BImplies = 649,
     Implies = 650,
     EImplies = 651,
     BForall = 652,
     EForall = 653,
     BAssert = 654,
     EAssert = 655,
     BExists = 656,
     EExists = 657,
     Babs = 658,
     Eabs = 659,
     Bconjugate = 660,
     Econjugate = 661,
     BArg = 662,
     EArg = 663,
     Bfloor = 664,
     Efloor = 665,
     Bceil = 666,
     Eceil = 667,
     BFactor = 668,
     Factor = 669,
     EFactor = 670,
     BEqual = 671,
     Equal = 672,
     EEqual = 673,
     BNequal = 674,
     Nequal = 675,
     ENequal = 676,
     BLequal = 677,
     Lequal = 678,
     ELequal = 679,
     BGequal = 680,
     Gequal = 681,
     EGequal = 682,
     BEquiv = 683,
     Equiv = 684,
     EEquiv = 685,
     BApprox = 686,
     Approx = 687,
     EApprox = 688,
     BGthan = 689,
     Gthan = 690,
     EGthan = 691,
     BLthan = 692,
     Lthan = 693,
     ELthan = 694,
     BInt = 695,
     EInt = 696,
     BIntll = 697,
     EIntll = 698,
     BIntul = 699,
     EIntul = 700,
     BIntarg = 701,
     EIntarg = 702,
     BIntbe = 703,
     EIntbe = 704,
     BDiff = 705,
     EDiff = 706,
     BDiffbe = 707,
     EDiffbe = 708,
     BDiffdeg = 709,
     EDiffdeg = 710,
     BDiffarg = 711,
     EDiffarg = 712,
     BDivs = 713,
     BDivt = 714,
     EDiv = 715,
     BGradt = 716,
     BGrads = 717,
     EGrad = 718,
     BCurlt = 719,
     BCurls = 720,
     ECurl = 721,
     BLaplacian = 722,
     ELaplacian = 723,
     BSum = 724,
     ESum = 725,
     BSumll = 726,
     ESumll = 727,
     BSumul = 728,
     ESumul = 729,
     BSumarg = 730,
     ESumarg = 731,
     BProd = 732,
     EProd = 733,
     BProdll = 734,
     EProdll = 735,
     BProdul = 736,
     EProdul = 737,
     BProdarg = 738,
     EProdarg = 739,
     BLimit = 740,
     ELimit = 741,
     BLimitarg = 742,
     ELimitarg = 743,
     BTendsto = 744,
     Tendsto = 745,
     ETendsto = 746,
     BSetl = 747,
     ESetl = 748,
     BSetc = 749,
     ESetc = 750,
     BSubset = 751,
     Subset = 752,
     ESubset = 753,
     BSubseteq = 754,
     Subseteq = 755,
     ESubseteq = 756,
     BNotsubset = 757,
     Notsubset = 758,
     ENotsubset = 759,
     BNotsubseteq = 760,
     Notsubseteq = 761,
     ENotsubseteq = 762,
     BListl = 763,
     EListl = 764,
     BListcarg = 765,
     EListcarg = 766,
     BListc = 767,
     EListc = 768,
     BUnion = 769,
     Union = 770,
     EUnion = 771,
     BIntersect = 772,
     Intersect = 773,
     EIntersect = 774,
     BIn = 775,
     In = 776,
     EIn = 777,
     BNotin = 778,
     Notin = 779,
     ENotin = 780,
     BSetdiff = 781,
     Setdiff = 782,
     ESetdiff = 783,
     BCard = 784,
     ECard = 785,
     BCartesian = 786,
     Cartesian = 787,
     ECartesian = 788,
     BSin = 789,
     ESin = 790,
     BCos = 791,
     ECos = 792,
     BTan = 793,
     ETan = 794,
     BSec = 795,
     ESec = 796,
     BCsc = 797,
     ECsc = 798,
     BCot = 799,
     ECot = 800,
     BSinh = 801,
     ESinh = 802,
     BCosh = 803,
     ECosh = 804,
     BTanh = 805,
     ETanh = 806,
     BSech = 807,
     Sech = 808,
     ESech = 809,
     BCsch = 810,
     Csch = 811,
     ECsch = 812,
     BCoth = 813,
     ECoth = 814,
     BArccos = 815,
     EArccos = 816,
     BArccosh = 817,
     Arccosh = 818,
     EArccosh = 819,
     BArcsin = 820,
     EArcsin = 821,
     BArctan = 822,
     EArctan = 823,
     BArccot = 824,
     Arccot = 825,
     EArccot = 826,
     BArccoth = 827,
     Arccoth = 828,
     EArccoth = 829,
     BArccsc = 830,
     Arccsc = 831,
     EArccsc = 832,
     BArccsch = 833,
     Arccsch = 834,
     EArccsch = 835,
     BArcsec = 836,
     Arcsec = 837,
     EArcsec = 838,
     BArcsech = 839,
     Arcsech = 840,
     EArcsech = 841,
     BArcsinh = 842,
     Arcsinh = 843,
     EArcsinh = 844,
     BArctanh = 845,
     Arctanh = 846,
     EArctanh = 847,
     BLn = 848,
     ELn = 849,
     BLog = 850,
     ELog = 851,
     BLg = 852,
     ELg = 853,
     BExp = 854,
     EExp = 855,
     BMean = 856,
     EMean = 857,
     BSDev = 858,
     ESDev = 859,
     BVariance = 860,
     Variance = 861,
     EVariance = 862,
     BMedian = 863,
     Median = 864,
     EMedian = 865,
     BMode = 866,
     Mode = 867,
     EMode = 868,
     BMoment = 869,
     EMoment = 870,
     BMomentDeg = 871,
     EMomentDeg = 872,
     BMomentArg = 873,
     EMomentArg = 874,
     BMomenta = 875,
     EMomenta = 876,
     BMabout = 877,
     EMabout = 878,
     BMATRIX = 879,
     EMATRIX = 880,
     BVector = 881,
     EVector = 882,
     BMatrix = 883,
     EMatrix = 884,
     BTranspose = 885,
     ETranspose = 886,
     BDet = 887,
     EDet = 888,
     BSelector = 889,
     SelectorMatrix = 890,
     ESelector = 891,
     BVectorProduct = 892,
     VectorProduct = 893,
     EVectorProduct = 894,
     BScalarProduct = 895,
     ScalarProduct = 896,
     EScalarProduct = 897,
     BOuterProduct = 898,
     OuterProduct = 899,
     EOuterProduct = 900,
     Integers = 901,
     Naturals = 902,
     Rationals = 903,
     Reals = 904,
     Complexes = 905,
     Primes = 906,
     EPrimes = 907,
     ExponentialE = 908,
     ImaginaryI = 909,
     NotANumber = 910,
     True = 911,
     False = 912,
     Emptyset = 913,
     PiCst = 914,
     EulerGamma = 915,
     Infty = 916,
     HBar = 917,
     Trace = 918
   };
#endif
/* Tokens.  */
#define ANY 258
#define SET 259
#define END 260
#define DVIY 261
#define PAR 262
#define FontChange 263
#define SPACE 264
#define CR 265
#define BLeft 266
#define ELeft 267
#define BRight 268
#define ERight 269
#define LeftNull 270
#define RightNull 271
#define BTBOX 272
#define ETBOX 273
#define BMBOX 274
#define EMBOX 275
#define BFBOX 276
#define EFBOX 277
#define BPUBLISHED 278
#define EPUBLISHED 279
#define BMATHICS 280
#define EMATHICS 281
#define BICSIDX 282
#define EICSIDX 283
#define BICSDESC 284
#define EICSDESC 285
#define BMATVERW 286
#define EMATVERW 287
#define BMATHICSSUB 288
#define EMATHICSSUB 289
#define BackgroundColor 290
#define POST_POST 291
#define BENTRY 292
#define EENTRY 293
#define BTITLE 294
#define ETITLE 295
#define BAUTHOR 296
#define EAUTHOR 297
#define BName 298
#define EName 299
#define BDATE 300
#define EDATE 301
#define BTHANKS 302
#define ETHANKS 303
#define MAKETITLE 304
#define BComment 305
#define EComment 306
#define BCAuthor 307
#define ECAuthor 308
#define BSubjectClass 309
#define ESubjectClass 310
#define BDedicatory 311
#define EDedicatory 312
#define BURL 313
#define EURL 314
#define BEMAIL 315
#define EEMAIL 316
#define BAffiliation 317
#define EAffiliation 318
#define BAddress 319
#define EAddress 320
#define BCAddress 321
#define ECAddress 322
#define BKeywords 323
#define EKeywords 324
#define BPACS 325
#define EPACS 326
#define BIdLine 327
#define EIdLine 328
#define BDOI 329
#define EDOI 330
#define BCopyright 331
#define ECopyright 332
#define BLocation 333
#define ELocation 334
#define BJournal 335
#define EJournal 336
#define BLogo 337
#define ELogo 338
#define BBranch 339
#define EBranch 340
#define BEQTAG 341
#define EEQTAG 342
#define BBINOM 343
#define EBINOM 344
#define BBINOMUP 345
#define EBINOMUP 346
#define BBINOMDOWN 347
#define EBINOMDOWN 348
#define BHEADLINE 349
#define EHEADLINE 350
#define BFOOTLINE 351
#define EFOOTLINE 352
#define BEnv 353
#define EEnv 354
#define BAbstract 355
#define EAbstract 356
#define AbsLang 357
#define Item 358
#define BList 359
#define EList 360
#define BLabel 361
#define ELabel 362
#define BBibliography 363
#define EBibliography 364
#define BBibLabel 365
#define EBibLabel 366
#define BSectMark 367
#define ESectMark 368
#define SectType 369
#define BSectLabel 370
#define ESectLabel 371
#define BSectTitle 372
#define ESectTitle 373
#define BCaption 374
#define ECaption 375
#define BFigureTag 376
#define EFigureTag 377
#define FigureFileName 378
#define EPSFigureFileName 379
#define Id 380
#define BRef 381
#define Ref 382
#define ERef 383
#define BCite 384
#define ECite 385
#define BCiteLabel 386
#define ECiteLabel 387
#define CiteSRef 388
#define BFootnoteMark 389
#define EFootnoteMark 390
#define BFootnote 391
#define EFootnote 392
#define BFloat 393
#define EFloat 394
#define FType 395
#define BTabular 396
#define ETabular 397
#define BTabularx 398
#define ETabularx 399
#define FOption 400
#define AOption 401
#define BLTable 402
#define ELTable 403
#define BLTBody 404
#define ELTBody 405
#define BLTCaption 406
#define ELTCaption 407
#define TABCR 408
#define HLINE 409
#define SPAN 410
#define BMultiColumn 411
#define EMultiColumn 412
#define MultiColumnNumber 413
#define MultiColumnFormat 414
#define TACCENT 415
#define TACCENTU 416
#define MACCENT 417
#define BIGSQCUP 418
#define BIGSQCAP 419
#define IMATHB 420
#define IMATHE 421
#define DMATHB 422
#define DMATHE 423
#define Bfile 424
#define Efile 425
#define EQNO 426
#define LEQNO 427
#define REQNO 428
#define BEqNum 429
#define EEqNum 430
#define BFoot 431
#define EFoot 432
#define BHead 433
#define EHead 434
#define BPage 435
#define EPage 436
#define ALIGN 437
#define BMTABLE 438
#define EMTABLE 439
#define BARRAY 440
#define EARRAY 441
#define BEqnArray 442
#define EEqnArray 443
#define BAligned 444
#define EAligned 445
#define BAlign 446
#define EAlign 447
#define BEQALIGN 448
#define EEQALIGN 449
#define BSplit 450
#define ESplit 451
#define BSP 452
#define ESP 453
#define BPower 454
#define Power 455
#define EPower 456
#define BSB 457
#define ESB 458
#define SBCHAR 459
#define LT 460
#define GT 461
#define NEQ 462
#define ARCCOS 463
#define ARCSIN 464
#define ARCTAN 465
#define ARG 466
#define COS 467
#define COSH 468
#define COT 469
#define COTH 470
#define CSC 471
#define DEG 472
#define DET 473
#define DIM 474
#define EXP 475
#define GCD 476
#define HOM 477
#define INF 478
#define KER 479
#define LG 480
#define LIM 481
#define LIMINF 482
#define LIMSUP 483
#define LN 484
#define LOG 485
#define MAX 486
#define MIN 487
#define PR 488
#define SEC 489
#define SIN 490
#define SINH 491
#define SUP 492
#define TAN 493
#define TANH 494
#define CDOTS 495
#define DDOTS 496
#define LDOTS 497
#define VDOTS 498
#define BFRAC 499
#define FRACN 500
#define FRACD 501
#define EFRAC 502
#define OVER 503
#define CHOOSE 504
#define ATOP 505
#define BBUILDREL 506
#define BUILDREL 507
#define EBUILDREL 508
#define MAPSTO 509
#define LMAPSTO 510
#define MODELS 511
#define HLARROW 512
#define HRARROW 513
#define lLARROW 514
#define LLARROW 515
#define lRARROW 516
#define LRARROW 517
#define lLRARROW 518
#define LLRARROW 519
#define BOWTIE 520
#define BOVERLARROW 521
#define EOVERLARROW 522
#define BOVERRARROW 523
#define EOVERRARROW 524
#define BUNDERLARROW 525
#define EUNDERLARROW 526
#define BUNDERRARROW 527
#define EUNDERRARROW 528
#define BOVERBRACE 529
#define EOVERBRACE 530
#define BUNDERBRACE 531
#define EUNDERBRACE 532
#define BWIDEHAT 533
#define EWIDEHAT 534
#define BWIDETILDE 535
#define EWIDETILDE 536
#define BDOT 537
#define EDOT 538
#define BOVERLINE 539
#define EOVERLINE 540
#define BUNDERLINE 541
#define EUNDERLINE 542
#define BMO 543
#define EMO 544
#define BSQRT 545
#define SQRT 546
#define ESQRT 547
#define BROOT 548
#define ROOT 549
#define EROOT 550
#define BRoot 551
#define Root 552
#define ERoot 553
#define BSqrt 554
#define ESqrt 555
#define Bfunc 556
#define Bfarg 557
#define Efarg 558
#define Efunc 559
#define BInterval 560
#define Interval 561
#define EInterval 562
#define BCompose 563
#define Compose 564
#define ECompose 565
#define BInverse 566
#define Inverse 567
#define EInverse 568
#define Ident 569
#define BDomain 570
#define EDomain 571
#define BCodomain 572
#define ECodomain 573
#define BImage 574
#define EImage 575
#define BAmsCases 576
#define EAmsCases 577
#define BCases 578
#define ECases 579
#define BCasesRow 580
#define ECasesRow 581
#define BBra 582
#define EBra 583
#define BKet 584
#define EKet 585
#define NOTIN 586
#define BPlus 587
#define Plus 588
#define EPlus 589
#define BMinus 590
#define Minus 591
#define EMinus 592
#define BTimes 593
#define Times 594
#define ETimes 595
#define BQuotient 596
#define Quotient 597
#define EQuotient 598
#define BFactorial 599
#define Factorial 600
#define EFactorial 601
#define BFrac 602
#define Fracn 603
#define Fracd 604
#define EFrac 605
#define BMaxl 606
#define BMaxc 607
#define EMaxl 608
#define EMaxc 609
#define BVar 610
#define EVar 611
#define BCond 612
#define ECond 613
#define BExpr 614
#define EExpr 615
#define BMinl 616
#define BMinc 617
#define EMinl 618
#define EMinc 619
#define BRem 620
#define Rem 621
#define ERem 622
#define REM 623
#define BPMOD 624
#define EPMOD 625
#define BGcd 626
#define EGcd 627
#define BLcm 628
#define ELcm 629
#define LCM 630
#define BRe 631
#define ERe 632
#define BIm 633
#define EIm 634
#define AND 635
#define BLand 636
#define Land 637
#define ELand 638
#define OR 639
#define BLor 640
#define Lor 641
#define ELor 642
#define XOR 643
#define BXor 644
#define Xor 645
#define EXor 646
#define BNot 647
#define ENot 648
#define BImplies 649
#define Implies 650
#define EImplies 651
#define BForall 652
#define EForall 653
#define BAssert 654
#define EAssert 655
#define BExists 656
#define EExists 657
#define Babs 658
#define Eabs 659
#define Bconjugate 660
#define Econjugate 661
#define BArg 662
#define EArg 663
#define Bfloor 664
#define Efloor 665
#define Bceil 666
#define Eceil 667
#define BFactor 668
#define Factor 669
#define EFactor 670
#define BEqual 671
#define Equal 672
#define EEqual 673
#define BNequal 674
#define Nequal 675
#define ENequal 676
#define BLequal 677
#define Lequal 678
#define ELequal 679
#define BGequal 680
#define Gequal 681
#define EGequal 682
#define BEquiv 683
#define Equiv 684
#define EEquiv 685
#define BApprox 686
#define Approx 687
#define EApprox 688
#define BGthan 689
#define Gthan 690
#define EGthan 691
#define BLthan 692
#define Lthan 693
#define ELthan 694
#define BInt 695
#define EInt 696
#define BIntll 697
#define EIntll 698
#define BIntul 699
#define EIntul 700
#define BIntarg 701
#define EIntarg 702
#define BIntbe 703
#define EIntbe 704
#define BDiff 705
#define EDiff 706
#define BDiffbe 707
#define EDiffbe 708
#define BDiffdeg 709
#define EDiffdeg 710
#define BDiffarg 711
#define EDiffarg 712
#define BDivs 713
#define BDivt 714
#define EDiv 715
#define BGradt 716
#define BGrads 717
#define EGrad 718
#define BCurlt 719
#define BCurls 720
#define ECurl 721
#define BLaplacian 722
#define ELaplacian 723
#define BSum 724
#define ESum 725
#define BSumll 726
#define ESumll 727
#define BSumul 728
#define ESumul 729
#define BSumarg 730
#define ESumarg 731
#define BProd 732
#define EProd 733
#define BProdll 734
#define EProdll 735
#define BProdul 736
#define EProdul 737
#define BProdarg 738
#define EProdarg 739
#define BLimit 740
#define ELimit 741
#define BLimitarg 742
#define ELimitarg 743
#define BTendsto 744
#define Tendsto 745
#define ETendsto 746
#define BSetl 747
#define ESetl 748
#define BSetc 749
#define ESetc 750
#define BSubset 751
#define Subset 752
#define ESubset 753
#define BSubseteq 754
#define Subseteq 755
#define ESubseteq 756
#define BNotsubset 757
#define Notsubset 758
#define ENotsubset 759
#define BNotsubseteq 760
#define Notsubseteq 761
#define ENotsubseteq 762
#define BListl 763
#define EListl 764
#define BListcarg 765
#define EListcarg 766
#define BListc 767
#define EListc 768
#define BUnion 769
#define Union 770
#define EUnion 771
#define BIntersect 772
#define Intersect 773
#define EIntersect 774
#define BIn 775
#define In 776
#define EIn 777
#define BNotin 778
#define Notin 779
#define ENotin 780
#define BSetdiff 781
#define Setdiff 782
#define ESetdiff 783
#define BCard 784
#define ECard 785
#define BCartesian 786
#define Cartesian 787
#define ECartesian 788
#define BSin 789
#define ESin 790
#define BCos 791
#define ECos 792
#define BTan 793
#define ETan 794
#define BSec 795
#define ESec 796
#define BCsc 797
#define ECsc 798
#define BCot 799
#define ECot 800
#define BSinh 801
#define ESinh 802
#define BCosh 803
#define ECosh 804
#define BTanh 805
#define ETanh 806
#define BSech 807
#define Sech 808
#define ESech 809
#define BCsch 810
#define Csch 811
#define ECsch 812
#define BCoth 813
#define ECoth 814
#define BArccos 815
#define EArccos 816
#define BArccosh 817
#define Arccosh 818
#define EArccosh 819
#define BArcsin 820
#define EArcsin 821
#define BArctan 822
#define EArctan 823
#define BArccot 824
#define Arccot 825
#define EArccot 826
#define BArccoth 827
#define Arccoth 828
#define EArccoth 829
#define BArccsc 830
#define Arccsc 831
#define EArccsc 832
#define BArccsch 833
#define Arccsch 834
#define EArccsch 835
#define BArcsec 836
#define Arcsec 837
#define EArcsec 838
#define BArcsech 839
#define Arcsech 840
#define EArcsech 841
#define BArcsinh 842
#define Arcsinh 843
#define EArcsinh 844
#define BArctanh 845
#define Arctanh 846
#define EArctanh 847
#define BLn 848
#define ELn 849
#define BLog 850
#define ELog 851
#define BLg 852
#define ELg 853
#define BExp 854
#define EExp 855
#define BMean 856
#define EMean 857
#define BSDev 858
#define ESDev 859
#define BVariance 860
#define Variance 861
#define EVariance 862
#define BMedian 863
#define Median 864
#define EMedian 865
#define BMode 866
#define Mode 867
#define EMode 868
#define BMoment 869
#define EMoment 870
#define BMomentDeg 871
#define EMomentDeg 872
#define BMomentArg 873
#define EMomentArg 874
#define BMomenta 875
#define EMomenta 876
#define BMabout 877
#define EMabout 878
#define BMATRIX 879
#define EMATRIX 880
#define BVector 881
#define EVector 882
#define BMatrix 883
#define EMatrix 884
#define BTranspose 885
#define ETranspose 886
#define BDet 887
#define EDet 888
#define BSelector 889
#define SelectorMatrix 890
#define ESelector 891
#define BVectorProduct 892
#define VectorProduct 893
#define EVectorProduct 894
#define BScalarProduct 895
#define ScalarProduct 896
#define EScalarProduct 897
#define BOuterProduct 898
#define OuterProduct 899
#define EOuterProduct 900
#define Integers 901
#define Naturals 902
#define Rationals 903
#define Reals 904
#define Complexes 905
#define Primes 906
#define EPrimes 907
#define ExponentialE 908
#define ImaginaryI 909
#define NotANumber 910
#define True 911
#define False 912
#define Emptyset 913
#define PiCst 914
#define EulerGamma 915
#define Infty 916
#define HBar 917
#define Trace 918




/* Copy the first part of user declarations.  */
#line 7 "hermes.y"


#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
const char * VERSION="0.9.12";
const char * DATE="2006-10-06";
const char * DESCRIPTION="http://hermes.roua.org/";
extern char* yytext;
extern FILE* yyin;
extern FILE* yyout;
extern int yylex();
int yyerror(char*msg);
void showcontext();
int BigEndian=0; 
#define LIMIT 100000
#ifdef WIN32
#pragma warning(disable : 4996)
#define _CRT_SECURE_NO_DEPRECATE
#endif
void p(char*s);
struct{
	unsigned int mag;
	unsigned int num;
	unsigned int den;
}scale;

int DEBUG=0;
int INFER_CONTENT=0;
int maxFontNr=0;
int fakesp=1;
int inhibitspace=0;
char *doc_math;
char *doc_text;
int mathText=0;
int mathOp=0;
int pHints=1;//switch for presentation hints (welformedness-glue)
int pHint=0;//set if a pHint is opened
extern int spacing;	//choose modifier/combining version
int hasSections=0;
int inBibliography=0;
int inCitation=0;
int length=0;
char fname[512];
extern char lastToken[512];//last token received before an error happens
extern void clearStack();
extern int inputlines;
int mathmode=0;		//if in text it's 0
int mathblock=0;	//'display mode' flag
int mathBox=0;		//set if inside a math box
int infhp=0;			//inside footer or header
int mDelimiter=0;	//a manual left or right, e.g. \left] 
#define DEPTH 10 //max depth level of a (m)table cell containing parenthesized math
signed int Wraps[DEPTH];	//number of parentheses currently open at the current depth level
unsigned int depth=0;	//depth level of a mtable cell containing parenthesized math
void wrap(int open);	//pop phantom parentheses to keep the math cell well-formed

int decorated=0;	//set if an operator is sup/sub'ed
unsigned int blockthis=0xFFFF;//use this to stop TeX construction of big delimiters
int canbreak=1;
int noDVIY=0;
int inTable=0;
char id[512]="";
char label[512]="";
char* content(char*from,char*what, char*bas, char*eas);
void InferContent();
void printFigureFileName();
void printEPSFigureFileName();
void printEnvType();
void printId();
void printOption();
void printFType();
void printAbsLang();
void printBkgColor();
void printRef();
void printSectType();
void printCiteSRef();

char* Insert(char*at,char*what);
char* MatchTagLeft(char*from, char*what);
char* MatchTagRight(char*from);
char* SkipBracketsLeft(char*from);
char* SkipBracketsRight(char*from);
char* MoveLeft(char*where,char*temp);
char* IndentContainer(char*pos,int* spaces,int start);
int IsMMLContainerEnd(char*at);
int IsMMLContainerStart(char*at);
int IsMMLConstant(char*at);
void flushMath();
void flushText();
void AddPHint(int StartOrEnd);
void Clean(char*from,char*what,int how);
void pretty(char*s,int eraseBrackets);
void die(char* text);
void fixIds();
void fixLabels();
void fixBackParsedPrimitive(const char* what);

//font mapping
int fontsMissing=0;

//encodings from ftp://tug.ctan.org/pub/tex-archive/info/fontname/fontname.html
void mapFonts(int check);
void fontMap7t();	//OT1+
void fontMap7tp();	//OT1+ (pound for dollar)
void fontMap7tt();	//OT1+
void fontMap7ttp();	//OT1+ (pound for dollar)
void fontMap8a();//standard
void fontMapDvips();
void fontMap8r();//TeXBase1
void fontMap8t();//Cork
void fontMap8c();//TS1
void fontMap8q();
void fontMap8y();//TeXnANSI
void fontMap8z();//OT1+ISO Latin2, XL2
void fontMap8u();//OT1+ISO Latin2 typewriter, XT2
void fontMapMathExt();
void fontMapMathExtA();
void fontMapMathSymbol();//msy
void fontMapMathSymbolC();
void fontMapCmTeX();
void fontMapMathItalic();//mi
void fontMapMathItalicA();
void fontMapMsam();//AMSa
void fontMapMsbm();//AMSb
void fontMapLasy();
void fontMapWasy();
void fontMap7c();//fraktur

struct _Font{
	void (*map)();
	unsigned int number;
	char name[10];
	char size[3];
	
	enum{
		serif,
		sans,
		monospace,
		cursive,
		fantasy,
		fraktur,
		doubleStruck, 
	}family;
	
	enum{
		normal,
		smallCaps
	}variant;
	
	enum{
		upright,
		italic, 
		oblique
	}style;
	
	enum{
		hairline, 				//a
		extraLight, 			//j
		light, 						//l
		book, 						//k
		normalWeight, 		//r
		medium,						//m
		demiBold, 				//d
		semiBold, 				//s
		bold, 						//b
		extraBold, 				//x
		heavy, 						//h
		black, 						//c
		ultraBlack, 			//u
		poster						//p
	}weight;
	
	enum{
		ultraCompressed,	//u
		ultraCondensed, 	//o
		extraCondensed, 	//q
		compressed, 			//p
		condensed,				//c
		thin, 						//t
		narrow, 					//n
		regularWidth, 		//r
		extended, 				//x
		expanded, 				//e
		extraExpanded, 		//v
		wide 							//w
	}width;

}theFont;

struct _Font (*pFont)[];
void selectFont(unsigned int fnum);

unsigned int combiningUnicode=0;
void saveAccent(char accent);
void saveAccentUnder(char accent);
char* ul2utf8(unsigned int unicode);
void pmt(unsigned int unicode);
void precomposedNegative(unsigned int single, unsigned int composed);
enum{
	mi, //presentation math identifier -> <mi> default variant
	mo,			////presentation math operatorr -> <mo> normal variant
	mn,			//<mn>
	ld,			//left delimiter
	rd,			//right delimiter
	ld_b,		//left delimiter begin (bigg  delimiters)
	rd_b,
	ld_x,		//left delimiter extend (bigg)
	rd_x,
	ld_e,		//left delimiter end	(bigg)
	rd_e
}pMathType;





void beginSuperScript();
void beginSubScript();
void endSubScript();
void endSuperScript();
void endover();
void endMAccent();
void fixDigits();
void contractTextAccent();
int hbrace=0;


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 1662 "hermes.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   19255

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  664
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  580
/* YYNRULES -- Number of rules.  */
#define YYNRULES  1007
/* YYNRULES -- Number of states.  */
#define YYNSTATES  2113

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   918

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint16 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,   237,   238,   239,   240,   241,   242,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417,   418,   419,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,   492,   493,   494,
     495,   496,   497,   498,   499,   500,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,   511,   512,   513,   514,
     515,   516,   517,   518,   519,   520,   521,   522,   523,   524,
     525,   526,   527,   528,   529,   530,   531,   532,   533,   534,
     535,   536,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   550,   551,   552,   553,   554,
     555,   556,   557,   558,   559,   560,   561,   562,   563,   564,
     565,   566,   567,   568,   569,   570,   571,   572,   573,   574,
     575,   576,   577,   578,   579,   580,   581,   582,   583,   584,
     585,   586,   587,   588,   589,   590,   591,   592,   593,   594,
     595,   596,   597,   598,   599,   600,   601,   602,   603,   604,
     605,   606,   607,   608,   609,   610,   611,   612,   613,   614,
     615,   616,   617,   618,   619,   620,   621,   622,   623,   624,
     625,   626,   627,   628,   629,   630,   631,   632,   633,   634,
     635,   636,   637,   638,   639,   640,   641,   642,   643,   644,
     645,   646,   647,   648,   649,   650,   651,   652,   653,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,     7,    10,    12,    13,    14,    20,
      22,    23,    24,    31,    32,    37,    38,    39,    46,    47,
      52,    54,    56,    57,    62,    64,    65,    66,    74,    75,
      80,    81,    82,    88,    90,    92,    94,    96,    97,   101,
     102,   107,   108,   113,   115,   117,   123,   125,   127,   129,
     131,   133,   135,   136,   137,   138,   147,   148,   150,   151,
     156,   157,   158,   169,   170,   171,   175,   176,   181,   182,
     188,   189,   194,   198,   202,   203,   209,   210,   217,   218,
     223,   224,   234,   235,   236,   247,   248,   250,   251,   253,
     255,   258,   262,   265,   266,   269,   271,   274,   276,   279,
     282,   285,   291,   293,   295,   297,   299,   301,   304,   306,
     307,   308,   314,   315,   316,   322,   323,   324,   330,   331,
     332,   338,   339,   340,   346,   347,   348,   354,   355,   356,
     362,   363,   364,   370,   371,   372,   378,   380,   381,   382,
     388,   389,   390,   396,   397,   398,   404,   405,   406,   412,
     413,   414,   420,   421,   422,   428,   429,   430,   436,   437,
     438,   444,   445,   446,   452,   453,   454,   460,   461,   462,
     470,   471,   472,   478,   480,   481,   482,   488,   489,   490,
     496,   497,   498,   504,   505,   506,   512,   513,   514,   520,
     521,   522,   528,   529,   530,   536,   537,   538,   544,   545,
     546,   552,   553,   554,   560,   561,   562,   568,   569,   570,
     576,   577,   582,   583,   588,   589,   594,   595,   598,   599,
     600,   607,   608,   609,   610,   617,   618,   621,   622,   628,
     633,   637,   638,   644,   645,   646,   647,   653,   655,   656,
     657,   658,   666,   667,   668,   677,   679,   681,   683,   685,
     687,   688,   690,   691,   692,   693,   706,   707,   712,   714,
     715,   721,   728,   735,   736,   738,   740,   741,   744,   745,
     746,   752,   753,   755,   758,   761,   764,   765,   766,   773,
     778,   781,   784,   787,   788,   789,   796,   797,   798,   805,
     806,   807,   814,   817,   820,   823,   828,   833,   834,   835,
     842,   843,   844,   851,   854,   857,   860,   863,   866,   869,
     873,   877,   878,   882,   883,   887,   888,   892,   893,   897,
     900,   902,   903,   909,   910,   914,   915,   916,   917,   929,
     930,   937,   938,   945,   946,   951,   955,   956,   957,   965,
     970,   976,   977,   978,   986,   987,   992,   993,  1000,  1001,
    1004,  1005,  1006,  1007,  1008,  1009,  1010,  1030,  1031,  1033,
    1034,  1040,  1042,  1046,  1048,  1051,  1052,  1058,  1063,  1068,
    1076,  1082,  1083,  1085,  1086,  1092,  1093,  1095,  1096,  1100,
    1106,  1107,  1110,  1115,  1116,  1123,  1125,  1127,  1129,  1131,
    1134,  1136,  1138,  1140,  1142,  1143,  1144,  1150,  1151,  1152,
    1158,  1166,  1168,  1170,  1171,  1172,  1173,  1183,  1184,  1185,
    1186,  1196,  1197,  1198,  1204,  1205,  1210,  1211,  1216,  1217,
    1222,  1223,  1228,  1229,  1234,  1235,  1240,  1241,  1246,  1247,
    1252,  1253,  1258,  1259,  1264,  1265,  1270,  1271,  1277,  1279,
    1283,  1285,  1286,  1287,  1288,  1291,  1292,  1295,  1297,  1299,
    1301,  1303,  1305,  1307,  1309,  1311,  1313,  1315,  1317,  1319,
    1321,  1323,  1324,  1325,  1327,  1328,  1331,  1333,  1334,  1335,
    1342,  1343,  1344,  1352,  1353,  1354,  1360,  1361,  1362,  1370,
    1371,  1376,  1381,  1385,  1386,  1387,  1393,  1394,  1395,  1401,
    1403,  1405,  1407,  1409,  1411,  1413,  1415,  1417,  1419,  1421,
    1422,  1423,  1434,  1435,  1447,  1448,  1449,  1458,  1459,  1466,
    1467,  1474,  1475,  1482,  1492,  1493,  1494,  1506,  1508,  1511,
    1512,  1513,  1514,  1525,  1526,  1528,  1534,  1535,  1542,  1543,
    1546,  1547,  1555,  1557,  1559,  1560,  1567,  1568,  1571,  1576,
    1581,  1582,  1583,  1592,  1594,  1600,  1602,  1605,  1606,  1607,
    1608,  1609,  1610,  1623,  1624,  1633,  1634,  1635,  1642,  1643,
    1651,  1652,  1665,  1666,  1674,  1675,  1688,  1689,  1690,  1700,
    1701,  1702,  1711,  1712,  1713,  1721,  1722,  1723,  1731,  1732,
    1733,  1741,  1742,  1743,  1757,  1758,  1759,  1767,  1768,  1769,
    1776,  1777,  1778,  1787,  1788,  1789,  1798,  1799,  1800,  1809,
    1810,  1811,  1817,  1818,  1819,  1820,  1830,  1831,  1842,  1843,
    1854,  1855,  1862,  1863,  1870,  1871,  1877,  1878,  1884,  1885,
    1891,  1892,  1893,  1900,  1901,  1902,  1910,  1911,  1912,  1920,
    1925,  1929,  1932,  1935,  1936,  1937,  1944,  1945,  1946,  1947,
    1953,  1954,  1959,  1960,  1962,  1963,  1967,  1968,  1969,  1970,
    1971,  1980,  1981,  1982,  1992,  1993,  1994,  2003,  2004,  2005,
    2014,  2015,  2016,  2025,  2026,  2027,  2036,  2037,  2038,  2047,
    2048,  2049,  2058,  2059,  2060,  2069,  2070,  2077,  2078,  2087,
    2088,  2095,  2096,  2105,  2106,  2107,  2116,  2117,  2118,  2127,
    2128,  2129,  2138,  2139,  2140,  2149,  2150,  2151,  2160,  2161,
    2162,  2171,  2172,  2173,  2182,  2183,  2184,  2192,  2193,  2194,
    2203,  2204,  2211,  2212,  2213,  2222,  2223,  2224,  2231,  2232,
    2233,  2240,  2241,  2242,  2249,  2250,  2251,  2258,  2259,  2260,
    2267,  2268,  2269,  2276,  2277,  2278,  2285,  2286,  2287,  2294,
    2295,  2296,  2303,  2304,  2305,  2312,  2313,  2314,  2321,  2322,
    2323,  2330,  2331,  2332,  2339,  2340,  2341,  2348,  2349,  2350,
    2357,  2358,  2359,  2366,  2367,  2368,  2375,  2376,  2377,  2384,
    2385,  2386,  2393,  2394,  2395,  2402,  2403,  2404,  2411,  2412,
    2413,  2420,  2421,  2422,  2429,  2430,  2431,  2438,  2439,  2440,
    2447,  2448,  2449,  2456,  2457,  2458,  2465,  2466,  2467,  2474,
    2475,  2480,  2481,  2489,  2490,  2502,  2503,  2511,  2512,  2520,
    2521,  2522,  2530,  2531,  2532,  2542,  2547,  2548,  2549,  2555,
    2556,  2557,  2558,  2559,  2568,  2569,  2571,  2573,  2574,  2580,
    2581,  2589,  2590,  2591,  2601,  2602,  2603,  2613,  2614,  2615,
    2625,  2626,  2627,  2637,  2638,  2648,  2654,  2658,  2659,  2668,
    2670,  2672,  2679,  2680,  2683,  2688,  2693,  2694,  2697,  2698,
    2702,  2704,  2707,  2709,  2710,  2713,  2714,  2715,  2717,  2719,
    2721,  2723,  2725,  2727,  2729,  2731,  2733,  2735,  2737,  2739,
    2741,  2743,  2745,  2747,  2749,  2751,  2753,  2755,  2757,  2759,
    2761,  2763,  2765,  2767,  2769,  2771,  2773,  2775,  2777,  2779,
    2781,  2783,  2785,  2787,  2789,  2791,  2793,  2795,  2797,  2799,
    2801,  2803,  2805,  2807,  2809,  2811,  2813,  2815,  2817,  2819,
    2821,  2823,  2825,  2827,  2829,  2831,  2833,  2835,  2837,  2839,
    2841,  2842,  2844,  2845,  2846,  2847,  2848,  2864,  2865,  2866,
    2867,  2868,  2869,  2892,  2893,  2898,  2899,  2904,  2905,  2910,
    2911,  2916,  2917,  2922,  2923,  2928,  2929,  2937,  2938,  2939,
    2945,  2946,  2947,  2948,  2956,  2957,  2958,  2967,  2968,  2969,
    2978,  2979,  2980,  2995,  2996,  2997,  3005,  3006,  3022,  3038,
    3047,  3056,  3065,  3074,  3075,  3091,  3107,  3116,  3125,  3134,
    3135,  3151,  3167,  3176,  3185,  3194,  3195,  3196,  3197,  3198,
    3199,  3200,  3201,  3203,  3205,  3207,  3209,  3210
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     665,     0,    -1,   666,     5,    -1,    -1,   666,   667,    -1,
     690,    -1,    -1,    -1,   100,   668,   666,   669,   101,    -1,
     102,    -1,    -1,    -1,   126,   670,   127,   671,   666,   128,
      -1,    -1,   174,   672,   666,   175,    -1,    -1,    -1,   129,
     673,   133,   674,   798,   130,    -1,    -1,   112,   675,   692,
     113,    -1,   125,    -1,    35,    -1,    -1,   108,   676,   666,
     109,    -1,   103,    -1,    -1,    -1,   104,   677,   689,   103,
     678,   666,   105,    -1,    -1,   106,   679,   666,   107,    -1,
      -1,    -1,    19,   680,   666,   681,    20,    -1,   791,    -1,
     723,    -1,   810,    -1,   700,    -1,    -1,   165,   682,   166,
      -1,    -1,   169,   683,   666,   170,    -1,    -1,   286,   684,
     666,   287,    -1,   703,    -1,   709,    -1,   165,   809,   709,
     666,   166,    -1,   697,    -1,   702,    -1,   123,    -1,   124,
      -1,   685,    -1,   722,    -1,    -1,    -1,    -1,   138,   686,
     140,   687,   713,   688,   666,   139,    -1,    -1,   125,    -1,
      -1,    98,   691,   666,    99,    -1,    -1,    -1,   114,   693,
     689,   115,   695,   116,   117,   694,   666,   118,    -1,    -1,
      -1,   696,   666,   667,    -1,    -1,   134,   698,   666,   135,
      -1,    -1,   136,   809,   699,   666,   137,    -1,    -1,   119,
     701,   666,   120,    -1,   121,   666,   122,    -1,   147,   704,
     148,    -1,    -1,   707,   689,    10,   705,   715,    -1,    -1,
     704,   707,   689,    10,   706,   715,    -1,    -1,   151,   708,
     666,   152,    -1,    -1,   141,   710,   165,   185,   714,   715,
     186,   166,   142,    -1,    -1,    -1,   143,   711,   165,   809,
     714,   715,   712,   166,   144,   809,    -1,    -1,   145,    -1,
      -1,   146,    -1,   716,    -1,   715,   716,    -1,   154,    10,
      10,    -1,   154,    10,    -1,    -1,   717,   718,    -1,   721,
      -1,   719,   721,    -1,   720,    -1,   719,   720,    -1,   666,
     182,    -1,   666,    10,    -1,   156,   158,   159,   666,   157,
      -1,   802,    -1,     3,    -1,   204,    -1,     6,    -1,   786,
      -1,     4,     3,    -1,     9,    -1,    -1,    -1,    25,   724,
     666,   725,    26,    -1,    -1,    -1,    31,   726,   666,   727,
      32,    -1,    -1,    -1,    33,   728,   666,   729,    34,    -1,
      -1,    -1,    41,   730,   666,   731,    42,    -1,    -1,    -1,
      52,   732,   666,   733,    53,    -1,    -1,    -1,    37,   734,
     666,   735,    38,    -1,    -1,    -1,    17,   736,   666,   737,
      18,    -1,    -1,    -1,    23,   738,   666,   739,    24,    -1,
      -1,    -1,    50,   740,   666,   741,    51,    -1,     7,    -1,
      -1,    -1,    39,   742,   666,   743,    40,    -1,    -1,    -1,
      45,   744,   666,   745,    46,    -1,    -1,    -1,    54,   746,
     666,   747,    55,    -1,    -1,    -1,    56,   748,   666,   749,
      57,    -1,    -1,    -1,    47,   750,   666,   751,    48,    -1,
      -1,    -1,    58,   752,   666,   753,    59,    -1,    -1,    -1,
      60,   754,   666,   755,    61,    -1,    -1,    -1,    62,   756,
     666,   757,    63,    -1,    -1,    -1,    64,   758,   666,   759,
      65,    -1,    -1,    -1,    66,   760,   666,   761,    67,    -1,
      -1,    -1,   165,    41,   762,   666,   763,    42,   166,    -1,
      -1,    -1,    43,   764,   666,   765,    44,    -1,     8,    -1,
      -1,    -1,    68,   766,   666,   767,    69,    -1,    -1,    -1,
      70,   768,   666,   769,    71,    -1,    -1,    -1,    72,   770,
     666,   771,    73,    -1,    -1,    -1,    74,   772,   666,   773,
      75,    -1,    -1,    -1,    76,   774,   666,   775,    77,    -1,
      -1,    -1,    78,   776,   666,   777,    79,    -1,    -1,    -1,
      80,   778,   666,   779,    81,    -1,    -1,    -1,    82,   780,
     666,   781,    83,    -1,    -1,    -1,    84,   782,   666,   783,
      85,    -1,    -1,    -1,    21,   784,   666,   785,    22,    -1,
      -1,    -1,    94,   787,   666,   788,    95,    -1,    -1,    -1,
      96,   789,   666,   790,    97,    -1,    -1,   176,   792,   795,
     177,    -1,    -1,   178,   793,   795,   179,    -1,    -1,   180,
     794,   666,   181,    -1,    -1,   723,   795,    -1,    -1,    -1,
     180,   796,   666,   797,   181,   795,    -1,    -1,    -1,    -1,
     131,   799,   666,   132,   800,   798,    -1,    -1,   801,     6,
      -1,    -1,   160,   805,     3,   803,   723,    -1,   160,   805,
       4,     3,    -1,   161,   723,     3,    -1,    -1,   162,   805,
       3,   804,   723,    -1,    -1,    -1,    -1,   106,   806,   666,
     807,   107,    -1,     8,    -1,    -1,    -1,    -1,   165,   808,
     811,   814,   829,   166,   809,    -1,    -1,    -1,   167,   808,
     812,   814,   829,   168,   813,   809,    -1,   815,    -1,   883,
      -1,   866,    -1,   877,    -1,   861,    -1,    -1,     8,    -1,
      -1,    -1,    -1,   167,   808,   816,    10,   817,   819,   820,
      10,   819,   168,   818,   809,    -1,    -1,   809,   786,   808,
     819,    -1,   822,    -1,    -1,   820,    10,   819,   821,   820,
      -1,   824,   165,   828,   823,   166,   824,    -1,   822,   165,
     828,   823,   166,   824,    -1,    -1,   182,    -1,    10,    -1,
      -1,   814,   825,    -1,    -1,    -1,   174,   826,   666,   827,
     175,    -1,    -1,   829,    -1,   895,   828,    -1,   930,   828,
      -1,   924,   828,    -1,    -1,    -1,   165,   830,   828,   166,
     831,   828,    -1,   167,   828,   168,   828,    -1,   825,   828,
      -1,   894,   828,    -1,   947,   828,    -1,    -1,    -1,   176,
     832,   795,   177,   833,   828,    -1,    -1,    -1,   178,   834,
     795,   179,   835,   828,    -1,    -1,    -1,   180,   836,   666,
     181,   837,   828,    -1,   883,   828,    -1,   856,   828,    -1,
     849,   828,    -1,   809,   786,   808,   828,    -1,   809,   697,
     808,   828,    -1,    -1,    -1,    11,   838,   828,    12,   839,
     828,    -1,    -1,    -1,    13,   840,   828,    14,   841,   828,
      -1,   866,   828,    -1,   861,   828,    -1,   864,   828,    -1,
     877,   828,    -1,  1182,   828,    -1,   846,   828,    -1,   197,
     198,   828,    -1,   202,   203,   828,    -1,    -1,   125,   842,
     828,    -1,    -1,   248,   843,   828,    -1,    -1,   249,   844,
     828,    -1,    -1,   250,   845,   828,    -1,     6,   828,    -1,
     722,    -1,    -1,   195,   848,   847,   879,   196,    -1,    -1,
     182,   166,   165,    -1,    -1,    -1,    -1,    88,    90,   850,
     829,    91,   851,    92,   829,    93,   852,    89,    -1,    -1,
     327,     3,   853,   829,   328,     3,    -1,    -1,   329,     3,
     854,   829,   330,     3,    -1,    -1,   369,   855,   829,   370,
      -1,   857,   891,   860,    -1,    -1,    -1,   193,   858,   165,
     859,   828,   888,   166,    -1,   165,   828,   166,   194,    -1,
     165,   828,    10,   166,   194,    -1,    -1,    -1,   191,   862,
     167,   863,   879,   168,   192,    -1,    -1,   189,   865,   879,
     190,    -1,    -1,   187,   867,   167,   868,   168,   188,    -1,
      -1,   868,   869,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     165,   870,   828,   876,   166,   871,   165,   872,   828,   876,
     166,   873,   165,   874,   828,   876,   166,   875,   824,    -1,
      -1,   182,    -1,    -1,   185,   714,   878,   879,   186,    -1,
     880,    -1,   167,   880,   168,    -1,   881,    -1,   880,   881,
      -1,    -1,   165,   882,   828,   876,   166,    -1,   165,    10,
     166,   824,    -1,   183,   808,   884,   184,    -1,   165,   166,
     886,   891,   890,   165,   166,    -1,   167,   886,   891,   890,
     168,    -1,    -1,   791,    -1,    -1,   165,   887,   828,   888,
     166,    -1,    -1,   182,    -1,    -1,    10,   889,   824,    -1,
     165,   828,   166,   824,   885,    -1,    -1,   891,   892,    -1,
     165,   828,   182,   166,    -1,    -1,   165,   828,    10,   166,
     893,   824,    -1,   171,    -1,   172,    -1,   173,    -1,     3,
      -1,     4,     3,    -1,   906,    -1,   662,    -1,   204,    -1,
       9,    -1,    -1,    -1,    19,   896,   666,   897,    20,    -1,
      -1,    -1,    21,   898,   666,   899,    22,    -1,   331,   165,
       3,   166,   165,     3,   166,    -1,    15,    -1,    16,    -1,
      -1,    -1,    -1,   129,   809,   900,   133,   901,   798,   130,
     902,   808,    -1,    -1,    -1,    -1,   126,   809,   903,   127,
     904,   666,   128,   905,   808,    -1,    -1,    -1,   162,   907,
     895,   908,   921,    -1,    -1,   266,   909,   829,   267,    -1,
      -1,   270,   910,   829,   271,    -1,    -1,   268,   911,   829,
     269,    -1,    -1,   272,   912,   829,   273,    -1,    -1,   274,
     913,   829,   275,    -1,    -1,   282,   914,   828,   283,    -1,
      -1,   276,   915,   829,   277,    -1,    -1,   278,   916,   829,
     279,    -1,    -1,   280,   917,   829,   281,    -1,    -1,   284,
     918,   829,   285,    -1,    -1,   286,   919,   829,   287,    -1,
      -1,   160,   801,     3,   920,   723,    -1,   895,    -1,   165,
     895,   166,    -1,   930,    -1,    -1,    -1,    -1,   925,  1198,
      -1,    -1,   926,  1197,    -1,   164,    -1,   163,    -1,   254,
      -1,   255,    -1,   256,    -1,   257,    -1,   258,    -1,   259,
      -1,   260,    -1,   261,    -1,   262,    -1,   263,    -1,   264,
      -1,   265,    -1,    -1,    -1,     3,    -1,    -1,   931,  1241,
      -1,   942,    -1,    -1,    -1,   244,   932,   828,   245,   933,
     941,    -1,    -1,    -1,   293,   934,   828,   294,   935,   828,
     295,    -1,    -1,    -1,   290,   936,   829,   937,   292,    -1,
      -1,    -1,   251,   938,   828,   252,   939,   828,   253,    -1,
      -1,   288,   940,   829,   289,    -1,   248,   246,   828,   247,
      -1,   246,   828,   247,    -1,    -1,    -1,   197,   943,   829,
     944,   198,    -1,    -1,    -1,   202,   945,   829,   946,   203,
      -1,   948,    -1,  1048,    -1,   982,    -1,  1200,    -1,  1222,
      -1,  1067,    -1,  1093,    -1,  1150,    -1,  1168,    -1,  1196,
      -1,    -1,    -1,   305,   980,   949,   829,   306,   929,   950,
     829,   307,   981,    -1,    -1,   311,   951,   829,   312,   197,
     929,   929,   929,   929,   198,   313,    -1,    -1,    -1,   308,
     952,   829,   309,   929,   953,   829,   310,    -1,    -1,   315,
     954,   929,   829,   316,   929,    -1,    -1,   317,   955,   929,
     829,   318,   929,    -1,    -1,   319,   956,   929,   829,   320,
     929,    -1,   321,    11,   964,    12,   965,    13,   964,    14,
     322,    -1,    -1,    -1,   323,    11,   964,    12,   957,   959,
     958,    13,   964,    14,   324,    -1,   960,    -1,   959,   960,
      -1,    -1,    -1,    -1,   325,   165,   961,   829,   182,   962,
     166,   666,   963,   326,    -1,    -1,   979,    -1,   183,   968,
     973,   971,   184,    -1,    -1,   185,   714,   966,   978,   967,
     186,    -1,    -1,   165,   166,    -1,    -1,   165,   166,   969,
     165,   828,   970,   166,    -1,   182,    -1,    10,    -1,    -1,
     165,   828,   166,   972,   165,   166,    -1,    -1,   973,   974,
      -1,   165,   828,   182,   166,    -1,   165,   828,    10,   166,
      -1,    -1,    -1,   165,   976,   828,   182,   977,   166,   810,
     808,    -1,   975,    -1,   978,   165,    10,   166,   975,    -1,
     929,    -1,   979,   929,    -1,    -1,    -1,    -1,    -1,    -1,
     341,   983,   929,   829,   342,   929,   984,   342,   829,   985,
     343,   929,    -1,    -1,   344,   986,   927,   829,   928,   345,
     929,   346,    -1,    -1,    -1,   347,   987,   829,   348,   988,
    1033,    -1,    -1,   351,   231,   989,   929,  1044,   353,   929,
      -1,    -1,   352,   231,   990,   202,  1035,   203,   929,  1038,
    1193,  1041,   929,   354,    -1,    -1,   361,   232,   991,   929,
    1044,   363,   929,    -1,    -1,   362,   232,   992,   202,  1035,
     203,   929,  1038,  1193,  1041,   929,   364,    -1,    -1,    -1,
     199,   993,   829,   200,   994,   197,   829,   198,   201,    -1,
      -1,    -1,   365,   995,   829,   996,   366,   368,   829,   367,
      -1,    -1,    -1,   332,   997,   829,   333,   998,   829,   334,
      -1,    -1,    -1,   335,   999,   829,   336,  1000,   829,   337,
      -1,    -1,    -1,   338,  1001,   829,   339,  1002,   829,   340,
      -1,    -1,    -1,   296,   165,  1003,   922,   829,   923,   297,
    1004,   166,   165,   929,   829,  1034,    -1,    -1,    -1,   299,
    1005,   927,   829,   928,  1006,   300,    -1,    -1,    -1,   371,
     221,  1007,   829,  1008,   372,    -1,    -1,    -1,   381,  1009,
     829,   382,   929,  1010,   829,   383,    -1,    -1,    -1,   385,
    1011,   829,   386,   929,  1012,   829,   387,    -1,    -1,    -1,
     389,  1013,   829,   390,   388,  1014,   829,   391,    -1,    -1,
      -1,   392,  1015,   829,  1016,   393,    -1,    -1,    -1,    -1,
     394,  1017,   829,  1018,   395,   929,   829,  1019,   396,    -1,
      -1,   397,  1020,  1035,  1193,  1043,   399,   929,   829,   400,
     398,    -1,    -1,   401,  1021,  1035,  1193,  1043,   399,   929,
     829,   400,   402,    -1,    -1,   403,  1022,   929,   829,   404,
     929,    -1,    -1,   405,  1023,   284,   829,   285,   406,    -1,
      -1,   407,   211,  1024,   829,   408,    -1,    -1,   376,   929,
    1025,   829,   377,    -1,    -1,   378,   929,  1026,   829,   379,
      -1,    -1,    -1,   373,   375,  1027,   829,  1028,   374,    -1,
      -1,    -1,   409,   929,  1029,   829,  1030,   410,   929,    -1,
      -1,    -1,   411,   929,  1031,   829,  1032,   412,   929,    -1,
     248,   349,   829,   350,    -1,   349,   829,   350,    -1,   298,
     166,    -1,   166,   298,    -1,    -1,    -1,   355,  1036,  1044,
    1037,   356,  1047,    -1,    -1,    -1,    -1,   359,  1039,   829,
    1040,   360,    -1,    -1,   357,  1042,   829,   358,    -1,    -1,
    1041,    -1,    -1,  1045,   829,  1046,    -1,    -1,    -1,    -1,
      -1,   416,  1049,   829,   417,   929,  1050,   829,   418,    -1,
      -1,    -1,   419,  1051,   829,   420,   929,   929,  1052,   829,
     421,    -1,    -1,    -1,   422,  1053,   829,   423,   929,  1054,
     829,   424,    -1,    -1,    -1,   425,  1055,   829,   426,   929,
    1056,   829,   427,    -1,    -1,    -1,   428,  1057,   829,   429,
     929,  1058,   829,   430,    -1,    -1,    -1,   431,  1059,   829,
     432,   929,  1060,   829,   433,    -1,    -1,    -1,   434,  1061,
     829,   435,   929,  1062,   829,   436,    -1,    -1,    -1,   437,
    1063,   829,   438,   929,  1064,   829,   439,    -1,    -1,    -1,
     413,  1065,   829,   414,   929,  1066,   829,   415,    -1,    -1,
     492,   929,  1068,  1044,   493,   929,    -1,    -1,   494,   929,
    1069,  1035,   929,  1041,   929,   495,    -1,    -1,   508,   929,
    1070,  1044,   509,   929,    -1,    -1,   512,   929,  1071,  1035,
     929,  1041,   929,   513,    -1,    -1,    -1,   496,  1072,   829,
     497,   929,  1073,   829,   498,    -1,    -1,    -1,   499,  1074,
     829,   500,   929,  1075,   829,   501,    -1,    -1,    -1,   502,
    1076,   829,   503,   929,  1077,   829,   504,    -1,    -1,    -1,
     505,  1078,   829,   506,   929,  1079,   829,   507,    -1,    -1,
      -1,   514,  1080,   829,   515,   929,  1081,   829,   516,    -1,
      -1,    -1,   517,  1082,   829,   518,   929,  1083,   829,   519,
      -1,    -1,    -1,   520,  1084,   829,   521,   929,  1085,   829,
     522,    -1,    -1,    -1,   523,  1086,   829,   524,  1087,   829,
     525,    -1,    -1,    -1,   526,  1088,   829,   527,   929,  1089,
     829,   528,    -1,    -1,   529,  1090,   929,   829,   530,   929,
      -1,    -1,    -1,   531,  1091,   829,   532,   929,  1092,   829,
     533,    -1,    -1,    -1,   560,   208,  1094,   829,  1095,   561,
      -1,    -1,    -1,   562,   563,  1096,   829,  1097,   564,    -1,
      -1,    -1,   565,   209,  1098,   829,  1099,   566,    -1,    -1,
      -1,   587,   588,  1100,   829,  1101,   589,    -1,    -1,    -1,
     567,   210,  1102,   829,  1103,   568,    -1,    -1,    -1,   590,
     591,  1104,   829,  1105,   592,    -1,    -1,    -1,   536,   212,
    1106,   829,  1107,   537,    -1,    -1,    -1,   548,   213,  1108,
     829,  1109,   549,    -1,    -1,    -1,   544,   214,  1110,   829,
    1111,   545,    -1,    -1,    -1,   569,   570,  1112,   829,  1113,
     571,    -1,    -1,    -1,   558,   215,  1114,   829,  1115,   559,
      -1,    -1,    -1,   572,   573,  1116,   829,  1117,   574,    -1,
      -1,    -1,   542,   216,  1118,   829,  1119,   543,    -1,    -1,
      -1,   575,   576,  1120,   829,  1121,   577,    -1,    -1,    -1,
     555,   556,  1122,   829,  1123,   557,    -1,    -1,    -1,   578,
     579,  1124,   829,  1125,   580,    -1,    -1,    -1,   599,   220,
    1126,   829,  1127,   600,    -1,    -1,    -1,   597,   225,  1128,
     829,  1129,   596,    -1,    -1,    -1,   593,   229,  1130,   829,
    1131,   594,    -1,    -1,    -1,   595,   230,  1132,   829,  1133,
     596,    -1,    -1,    -1,   540,   234,  1134,   829,  1135,   541,
      -1,    -1,    -1,   581,   582,  1136,   829,  1137,   583,    -1,
      -1,    -1,   552,   553,  1138,   829,  1139,   554,    -1,    -1,
      -1,   584,   585,  1140,   829,  1141,   586,    -1,    -1,    -1,
     534,   235,  1142,   829,  1143,   535,    -1,    -1,    -1,   546,
     236,  1144,   829,  1145,   547,    -1,    -1,    -1,   538,   238,
    1146,   829,  1147,   539,    -1,    -1,    -1,   550,   239,  1148,
     829,  1149,   551,    -1,    -1,   601,  1151,   829,   602,    -1,
      -1,   603,   929,   929,  1152,   829,   604,   929,    -1,    -1,
     605,   929,   929,  1153,   829,   606,   929,   197,   929,   198,
     607,    -1,    -1,   608,  1154,   609,   929,   829,   610,   929,
      -1,    -1,   611,  1155,   612,   929,   829,   613,   929,    -1,
      -1,    -1,   614,  1156,   829,  1157,  1163,   615,  1167,    -1,
      -1,    -1,   620,  1158,  1160,  1159,  1193,  1161,  1163,   621,
    1167,    -1,  1193,   618,   829,   619,    -1,    -1,    -1,   622,
    1162,   829,   623,  1193,    -1,    -1,    -1,    -1,    -1,   616,
    1164,   197,  1165,   895,  1166,   617,   198,    -1,    -1,  1179,
      -1,  1181,    -1,    -1,   632,   218,  1169,   829,   633,    -1,
      -1,   630,  1170,   723,   197,   929,   198,   631,    -1,    -1,
      -1,   634,  1171,  1189,  1172,   202,  1192,   203,   636,  1195,
      -1,    -1,    -1,   637,  1242,  1173,   829,   638,   929,  1174,
     829,   639,    -1,    -1,    -1,   640,  1243,  1175,   829,   641,
     929,  1176,   829,   642,    -1,    -1,    -1,   643,  1242,  1177,
     829,   644,   929,  1178,   829,   645,    -1,    -1,   626,  1180,
    1193,   624,   829,   625,  1193,  1194,   627,    -1,   628,  1193,
    1182,  1193,   629,    -1,  1183,  1187,  1186,    -1,    -1,   624,
    1184,   165,   166,   165,   828,  1185,   166,    -1,   182,    -1,
      10,    -1,   165,   828,   166,   165,   166,   625,    -1,    -1,
    1187,  1188,    -1,   165,   828,   182,   166,    -1,   165,   828,
      10,   166,    -1,    -1,  1190,   723,    -1,    -1,   635,  1191,
     723,    -1,  1179,    -1,   635,  1182,    -1,   829,    -1,    -1,
     929,  1193,    -1,    -1,    -1,   646,    -1,   647,    -1,   648,
      -1,   649,    -1,   650,    -1,   651,    -1,   653,    -1,   654,
      -1,   655,    -1,   658,    -1,   656,    -1,   657,    -1,   659,
      -1,   660,    -1,   661,    -1,   314,    -1,   663,    -1,   208,
      -1,   563,    -1,   209,    -1,   588,    -1,   210,    -1,   591,
      -1,   211,    -1,   212,    -1,   213,    -1,   214,    -1,   570,
      -1,   215,    -1,   573,    -1,   216,    -1,   576,    -1,   556,
      -1,   579,    -1,   217,    -1,   218,    -1,   219,    -1,   220,
      -1,   221,    -1,   375,    -1,   222,    -1,   223,    -1,   224,
      -1,   225,    -1,   226,    -1,   227,    -1,   228,    -1,   229,
      -1,   230,    -1,   231,    -1,   232,    -1,   233,    -1,   234,
      -1,   582,    -1,   553,    -1,   585,    -1,   235,    -1,   236,
      -1,   237,    -1,   238,    -1,   239,    -1,   368,    -1,   388,
      -1,    -1,   248,    -1,    -1,    -1,    -1,    -1,   440,  1201,
    1231,   446,  1202,   829,   447,  1203,   448,   929,   829,   449,
    1204,  1217,   441,    -1,    -1,    -1,    -1,    -1,    -1,   450,
    1205,   244,   929,  1218,   456,  1206,   829,   457,   245,  1199,
     246,   929,  1207,   452,   829,   453,  1208,  1219,  1209,   247,
     451,    -1,    -1,   459,  1210,   829,   460,    -1,    -1,   458,
    1211,   829,   460,    -1,    -1,   461,  1212,   829,   463,    -1,
      -1,   462,  1213,   829,   463,    -1,    -1,   464,  1214,   829,
     466,    -1,    -1,   465,  1215,   829,   466,    -1,    -1,   467,
    1216,   197,   929,   198,   829,   468,    -1,    -1,    -1,   454,
     197,   929,   198,   455,    -1,    -1,    -1,    -1,   454,   197,
    1220,   895,  1221,   198,   455,    -1,    -1,    -1,   469,  1223,
    1232,  1224,   475,   829,   476,   470,    -1,    -1,    -1,   477,
    1225,  1233,  1226,   483,   829,   484,   478,    -1,    -1,    -1,
     485,  1227,   226,  1234,   202,   829,   203,  1236,  1235,  1228,
     487,   829,   488,   486,    -1,    -1,    -1,   489,  1229,   829,
    1230,   490,   828,   491,    -1,    -1,   197,  1238,   444,   829,
     445,   198,   929,  1240,   202,  1237,   442,   829,   443,   203,
    1239,    -1,   929,   197,  1238,   444,   829,   445,   198,  1240,
     202,  1237,   442,   829,   443,   203,  1239,    -1,   202,  1237,
     442,   829,   443,   203,   929,  1239,    -1,   929,   202,  1237,
     442,   829,   443,   203,  1239,    -1,   197,  1238,   444,   829,
     445,   198,   929,  1240,    -1,   929,   197,  1238,   444,   829,
     445,   198,  1240,    -1,    -1,   197,  1238,   473,   829,   474,
     198,   929,  1240,   202,  1237,   471,   829,   472,   203,  1239,
      -1,   929,   197,  1238,   473,   829,   474,   198,  1240,   202,
    1237,   471,   829,   472,   203,  1239,    -1,   929,   202,  1237,
     471,   829,   472,   203,  1239,    -1,   197,  1238,   473,   829,
     474,   198,   929,  1240,    -1,   929,   197,  1238,   473,   829,
     474,   198,  1240,    -1,    -1,   197,  1238,   481,   829,   482,
     198,   929,  1240,   202,  1237,   479,   829,   480,   203,  1239,
      -1,   929,   197,  1238,   481,   829,   482,   198,  1240,   202,
    1237,   479,   829,   480,   203,  1239,    -1,   929,   202,  1237,
     479,   829,   480,   203,  1239,    -1,   197,  1238,   481,   829,
     482,   198,   929,  1240,    -1,   929,   197,  1238,   481,   829,
     482,   198,  1240,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   240,    -1,   241,    -1,   242,    -1,   243,    -1,    -1,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   381,   381,   383,   383,   387,   389,   394,   389,   401,
     405,   406,   405,   410,   410,   415,   416,   414,   421,   420,
     430,   432,   435,   434,   449,   451,   452,   451,   458,   457,
     464,   466,   463,   469,   470,   471,   472,   473,   473,   474,
     474,   476,   475,   480,   481,   482,   483,   484,   485,   486,
     487,   488,   492,   493,   494,   492,   500,   501,   513,   512,
     520,   525,   520,   530,   531,   531,   538,   537,   544,   543,
     553,   552,   560,   566,   573,   572,   578,   577,   585,   584,
     594,   593,   599,   602,   599,   607,   607,   610,   610,   615,
     617,   621,   623,   625,   625,   629,   631,   634,   634,   636,
     639,   643,   647,   648,   649,   650,   651,   652,   653,   656,
     658,   655,   662,   664,   661,   668,   670,   667,   673,   678,
     673,   685,   690,   685,   698,   700,   697,   704,   706,   703,
     710,   712,   709,   716,   718,   715,   721,   725,   727,   724,
     730,   733,   730,   737,   739,   736,   743,   745,   742,   749,
     751,   748,   755,   757,   754,   761,   763,   760,   767,   769,
     766,   773,   775,   772,   779,   781,   778,   785,   790,   784,
     797,   802,   796,   808,   811,   813,   810,   817,   819,   816,
     823,   825,   822,   829,   831,   828,   835,   837,   834,   841,
     843,   840,   847,   849,   846,   853,   855,   852,   859,   861,
     858,   864,   864,   864,   869,   871,   868,   875,   877,   874,
     882,   882,   889,   889,   896,   896,   905,   906,   909,   911,
     908,   916,   916,   916,   916,   920,   920,   924,   924,   925,
     926,   927,   927,   930,   933,   935,   932,   937,   940,   945,
     951,   951,   955,   957,   955,   958,   959,   960,   961,   962,
     966,   966,   968,   968,   970,   968,   974,   974,   975,   976,
     976,   979,   981,   983,   983,   983,   986,   986,   989,   989,
     989,   992,   992,   994,   995,   996,   998,  1000,   998,  1002,
    1003,  1004,  1005,  1006,  1006,  1006,  1007,  1007,  1007,  1008,
    1008,  1008,  1009,  1010,  1011,  1012,  1013,  1014,  1016,  1014,
    1018,  1020,  1018,  1022,  1023,  1024,  1025,  1026,  1027,  1028,
    1029,  1030,  1030,  1031,  1031,  1032,  1032,  1033,  1033,  1034,
    1035,  1040,  1039,  1045,  1045,  1049,  1049,  1049,  1049,  1050,
    1050,  1051,  1051,  1052,  1052,  1055,  1057,  1057,  1057,  1059,
    1060,  1064,  1064,  1064,  1070,  1070,  1077,  1077,  1084,  1084,
    1088,  1088,  1089,  1089,  1090,  1090,  1088,  1095,  1095,  1101,
    1100,  1107,  1109,  1113,  1115,  1119,  1119,  1121,  1125,  1127,
    1128,  1131,  1131,  1133,  1133,  1134,  1134,  1134,  1134,  1135,
    1137,  1137,  1139,  1140,  1140,  1143,  1143,  1143,  1147,  1148,
    1149,  1150,  1151,  1152,  1155,  1157,  1154,  1159,  1159,  1159,
    1160,  1161,  1162,  1166,  1167,  1170,  1165,  1172,  1173,  1175,
    1172,  1179,  1179,  1179,  1180,  1180,  1182,  1182,  1184,  1184,
    1186,  1186,  1188,  1188,  1190,  1190,  1192,  1192,  1194,  1194,
    1196,  1196,  1198,  1198,  1200,  1200,  1202,  1202,  1205,  1205,
    1205,  1207,  1208,  1211,  1211,  1212,  1212,  1213,  1214,  1215,
    1216,  1217,  1218,  1219,  1220,  1221,  1222,  1223,  1224,  1225,
    1226,  1229,  1230,  1232,  1234,  1234,  1235,  1236,  1236,  1236,
    1238,  1239,  1238,  1241,  1241,  1241,  1242,  1243,  1242,  1245,
    1245,  1249,  1250,  1255,  1262,  1254,  1269,  1276,  1268,  1285,
    1286,  1287,  1288,  1289,  1290,  1291,  1292,  1293,  1294,  1298,
    1298,  1298,  1299,  1299,  1300,  1300,  1300,  1301,  1301,  1302,
    1302,  1303,  1303,  1304,  1305,  1305,  1305,  1309,  1311,  1316,
    1317,  1318,  1315,  1322,  1322,  1324,  1326,  1326,  1329,  1329,
    1332,  1332,  1333,  1333,  1335,  1335,  1337,  1337,  1339,  1340,
    1343,  1343,  1343,  1349,  1351,  1355,  1355,  1361,  1362,  1387,
    1387,  1387,  1387,  1388,  1388,  1389,  1389,  1389,  1390,  1390,
    1391,  1391,  1392,  1392,  1393,  1393,  1394,  1394,  1394,  1395,
    1395,  1395,  1396,  1396,  1396,  1397,  1397,  1397,  1398,  1398,
    1398,  1399,  1399,  1399,  1400,  1400,  1400,  1401,  1401,  1401,
    1402,  1402,  1402,  1403,  1403,  1403,  1404,  1404,  1404,  1405,
    1405,  1405,  1406,  1406,  1406,  1406,  1407,  1407,  1408,  1408,
    1409,  1409,  1410,  1410,  1411,  1411,  1412,  1412,  1413,  1413,
    1414,  1414,  1414,  1415,  1415,  1415,  1416,  1416,  1416,  1420,
    1421,  1425,  1427,  1430,  1430,  1430,  1432,  1432,  1432,  1432,
    1433,  1433,  1435,  1435,  1439,  1439,  1441,  1462,  1481,  1481,
    1481,  1482,  1482,  1482,  1483,  1483,  1483,  1484,  1484,  1484,
    1485,  1485,  1485,  1486,  1486,  1486,  1487,  1487,  1487,  1488,
    1488,  1488,  1489,  1489,  1489,  1493,  1493,  1494,  1494,  1495,
    1495,  1496,  1496,  1497,  1497,  1497,  1498,  1498,  1498,  1499,
    1499,  1499,  1500,  1500,  1500,  1501,  1501,  1501,  1502,  1502,
    1502,  1503,  1503,  1503,  1504,  1504,  1504,  1505,  1505,  1505,
    1506,  1506,  1507,  1507,  1507,  1511,  1511,  1511,  1512,  1512,
    1512,  1513,  1513,  1513,  1514,  1514,  1514,  1515,  1515,  1515,
    1516,  1516,  1516,  1517,  1517,  1517,  1518,  1518,  1518,  1519,
    1519,  1519,  1520,  1520,  1520,  1521,  1521,  1521,  1522,  1522,
    1522,  1523,  1523,  1523,  1524,  1524,  1524,  1525,  1525,  1525,
    1526,  1526,  1526,  1527,  1527,  1527,  1528,  1528,  1528,  1529,
    1529,  1529,  1530,  1530,  1530,  1531,  1531,  1531,  1532,  1532,
    1532,  1533,  1533,  1533,  1534,  1534,  1534,  1535,  1535,  1535,
    1536,  1536,  1536,  1537,  1537,  1537,  1538,  1538,  1538,  1542,
    1542,  1543,  1543,  1544,  1544,  1545,  1545,  1546,  1546,  1547,
    1547,  1547,  1548,  1548,  1548,  1551,  1552,  1552,  1552,  1553,
    1553,  1553,  1553,  1553,  1554,  1571,  1572,  1573,  1573,  1574,
    1574,  1575,  1575,  1575,  1576,  1576,  1576,  1577,  1577,  1577,
    1578,  1578,  1578,  1581,  1581,  1583,  1585,  1587,  1587,  1588,
    1588,  1590,  1592,  1592,  1594,  1595,  1598,  1598,  1599,  1599,
    1600,  1601,  1603,  1605,  1605,  1607,  1631,  1648,  1649,  1650,
    1651,  1652,  1653,  1654,  1655,  1656,  1657,  1658,  1659,  1660,
    1661,  1662,  1663,  1668,  1672,  1673,  1674,  1675,  1676,  1677,
    1678,  1679,  1680,  1681,  1682,  1683,  1684,  1685,  1686,  1687,
    1688,  1689,  1690,  1691,  1692,  1693,  1694,  1695,  1696,  1697,
    1698,  1699,  1700,  1701,  1702,  1703,  1704,  1705,  1706,  1707,
    1708,  1709,  1710,  1711,  1712,  1713,  1714,  1715,  1717,  1718,
    1723,  1723,  1727,  1727,  1727,  1727,  1727,  1728,  1728,  1730,
    1730,  1730,  1728,  1731,  1731,  1732,  1732,  1733,  1733,  1734,
    1734,  1735,  1735,  1736,  1736,  1737,  1737,  1741,  1755,  1756,
    1758,  1759,  1759,  1759,  1762,  1762,  1762,  1763,  1763,  1763,
    1764,  1764,  1764,  1765,  1765,  1765,  1768,  1769,  1770,  1771,
    1772,  1773,  1774,  1777,  1778,  1779,  1780,  1781,  1782,  1785,
    1786,  1787,  1788,  1789,  1790,  1796,  1797,  1798,  1819,  1820,
    1821,  1822,  1826,  1827,  1828,  1829,  1832,  1834
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ANY", "SET", "END", "DVIY", "PAR",
  "FontChange", "SPACE", "CR", "BLeft", "ELeft", "BRight", "ERight",
  "LeftNull", "RightNull", "BTBOX", "ETBOX", "BMBOX", "EMBOX", "BFBOX",
  "EFBOX", "BPUBLISHED", "EPUBLISHED", "BMATHICS", "EMATHICS", "BICSIDX",
  "EICSIDX", "BICSDESC", "EICSDESC", "BMATVERW", "EMATVERW", "BMATHICSSUB",
  "EMATHICSSUB", "BackgroundColor", "POST_POST", "BENTRY", "EENTRY",
  "BTITLE", "ETITLE", "BAUTHOR", "EAUTHOR", "BName", "EName", "BDATE",
  "EDATE", "BTHANKS", "ETHANKS", "MAKETITLE", "BComment", "EComment",
  "BCAuthor", "ECAuthor", "BSubjectClass", "ESubjectClass", "BDedicatory",
  "EDedicatory", "BURL", "EURL", "BEMAIL", "EEMAIL", "BAffiliation",
  "EAffiliation", "BAddress", "EAddress", "BCAddress", "ECAddress",
  "BKeywords", "EKeywords", "BPACS", "EPACS", "BIdLine", "EIdLine", "BDOI",
  "EDOI", "BCopyright", "ECopyright", "BLocation", "ELocation", "BJournal",
  "EJournal", "BLogo", "ELogo", "BBranch", "EBranch", "BEQTAG", "EEQTAG",
  "BBINOM", "EBINOM", "BBINOMUP", "EBINOMUP", "BBINOMDOWN", "EBINOMDOWN",
  "BHEADLINE", "EHEADLINE", "BFOOTLINE", "EFOOTLINE", "BEnv", "EEnv",
  "BAbstract", "EAbstract", "AbsLang", "Item", "BList", "EList", "BLabel",
  "ELabel", "BBibliography", "EBibliography", "BBibLabel", "EBibLabel",
  "BSectMark", "ESectMark", "SectType", "BSectLabel", "ESectLabel",
  "BSectTitle", "ESectTitle", "BCaption", "ECaption", "BFigureTag",
  "EFigureTag", "FigureFileName", "EPSFigureFileName", "Id", "BRef", "Ref",
  "ERef", "BCite", "ECite", "BCiteLabel", "ECiteLabel", "CiteSRef",
  "BFootnoteMark", "EFootnoteMark", "BFootnote", "EFootnote", "BFloat",
  "EFloat", "FType", "BTabular", "ETabular", "BTabularx", "ETabularx",
  "FOption", "AOption", "BLTable", "ELTable", "BLTBody", "ELTBody",
  "BLTCaption", "ELTCaption", "TABCR", "HLINE", "SPAN", "BMultiColumn",
  "EMultiColumn", "MultiColumnNumber", "MultiColumnFormat", "TACCENT",
  "TACCENTU", "MACCENT", "BIGSQCUP", "BIGSQCAP", "IMATHB", "IMATHE",
  "DMATHB", "DMATHE", "Bfile", "Efile", "EQNO", "LEQNO", "REQNO", "BEqNum",
  "EEqNum", "BFoot", "EFoot", "BHead", "EHead", "BPage", "EPage", "ALIGN",
  "BMTABLE", "EMTABLE", "BARRAY", "EARRAY", "BEqnArray", "EEqnArray",
  "BAligned", "EAligned", "BAlign", "EAlign", "BEQALIGN", "EEQALIGN",
  "BSplit", "ESplit", "BSP", "ESP", "BPower", "Power", "EPower", "BSB",
  "ESB", "SBCHAR", "LT", "GT", "NEQ", "ARCCOS", "ARCSIN", "ARCTAN", "ARG",
  "COS", "COSH", "COT", "COTH", "CSC", "DEG", "DET", "DIM", "EXP", "GCD",
  "HOM", "INF", "KER", "LG", "LIM", "LIMINF", "LIMSUP", "LN", "LOG", "MAX",
  "MIN", "PR", "SEC", "SIN", "SINH", "SUP", "TAN", "TANH", "CDOTS",
  "DDOTS", "LDOTS", "VDOTS", "BFRAC", "FRACN", "FRACD", "EFRAC", "OVER",
  "CHOOSE", "ATOP", "BBUILDREL", "BUILDREL", "EBUILDREL", "MAPSTO",
  "LMAPSTO", "MODELS", "HLARROW", "HRARROW", "lLARROW", "LLARROW",
  "lRARROW", "LRARROW", "lLRARROW", "LLRARROW", "BOWTIE", "BOVERLARROW",
  "EOVERLARROW", "BOVERRARROW", "EOVERRARROW", "BUNDERLARROW",
  "EUNDERLARROW", "BUNDERRARROW", "EUNDERRARROW", "BOVERBRACE",
  "EOVERBRACE", "BUNDERBRACE", "EUNDERBRACE", "BWIDEHAT", "EWIDEHAT",
  "BWIDETILDE", "EWIDETILDE", "BDOT", "EDOT", "BOVERLINE", "EOVERLINE",
  "BUNDERLINE", "EUNDERLINE", "BMO", "EMO", "BSQRT", "SQRT", "ESQRT",
  "BROOT", "ROOT", "EROOT", "BRoot", "Root", "ERoot", "BSqrt", "ESqrt",
  "Bfunc", "Bfarg", "Efarg", "Efunc", "BInterval", "Interval", "EInterval",
  "BCompose", "Compose", "ECompose", "BInverse", "Inverse", "EInverse",
  "Ident", "BDomain", "EDomain", "BCodomain", "ECodomain", "BImage",
  "EImage", "BAmsCases", "EAmsCases", "BCases", "ECases", "BCasesRow",
  "ECasesRow", "BBra", "EBra", "BKet", "EKet", "NOTIN", "BPlus", "Plus",
  "EPlus", "BMinus", "Minus", "EMinus", "BTimes", "Times", "ETimes",
  "BQuotient", "Quotient", "EQuotient", "BFactorial", "Factorial",
  "EFactorial", "BFrac", "Fracn", "Fracd", "EFrac", "BMaxl", "BMaxc",
  "EMaxl", "EMaxc", "BVar", "EVar", "BCond", "ECond", "BExpr", "EExpr",
  "BMinl", "BMinc", "EMinl", "EMinc", "BRem", "Rem", "ERem", "REM",
  "BPMOD", "EPMOD", "BGcd", "EGcd", "BLcm", "ELcm", "LCM", "BRe", "ERe",
  "BIm", "EIm", "AND", "BLand", "Land", "ELand", "OR", "BLor", "Lor",
  "ELor", "XOR", "BXor", "Xor", "EXor", "BNot", "ENot", "BImplies",
  "Implies", "EImplies", "BForall", "EForall", "BAssert", "EAssert",
  "BExists", "EExists", "Babs", "Eabs", "Bconjugate", "Econjugate", "BArg",
  "EArg", "Bfloor", "Efloor", "Bceil", "Eceil", "BFactor", "Factor",
  "EFactor", "BEqual", "Equal", "EEqual", "BNequal", "Nequal", "ENequal",
  "BLequal", "Lequal", "ELequal", "BGequal", "Gequal", "EGequal", "BEquiv",
  "Equiv", "EEquiv", "BApprox", "Approx", "EApprox", "BGthan", "Gthan",
  "EGthan", "BLthan", "Lthan", "ELthan", "BInt", "EInt", "BIntll",
  "EIntll", "BIntul", "EIntul", "BIntarg", "EIntarg", "BIntbe", "EIntbe",
  "BDiff", "EDiff", "BDiffbe", "EDiffbe", "BDiffdeg", "EDiffdeg",
  "BDiffarg", "EDiffarg", "BDivs", "BDivt", "EDiv", "BGradt", "BGrads",
  "EGrad", "BCurlt", "BCurls", "ECurl", "BLaplacian", "ELaplacian", "BSum",
  "ESum", "BSumll", "ESumll", "BSumul", "ESumul", "BSumarg", "ESumarg",
  "BProd", "EProd", "BProdll", "EProdll", "BProdul", "EProdul", "BProdarg",
  "EProdarg", "BLimit", "ELimit", "BLimitarg", "ELimitarg", "BTendsto",
  "Tendsto", "ETendsto", "BSetl", "ESetl", "BSetc", "ESetc", "BSubset",
  "Subset", "ESubset", "BSubseteq", "Subseteq", "ESubseteq", "BNotsubset",
  "Notsubset", "ENotsubset", "BNotsubseteq", "Notsubseteq", "ENotsubseteq",
  "BListl", "EListl", "BListcarg", "EListcarg", "BListc", "EListc",
  "BUnion", "Union", "EUnion", "BIntersect", "Intersect", "EIntersect",
  "BIn", "In", "EIn", "BNotin", "Notin", "ENotin", "BSetdiff", "Setdiff",
  "ESetdiff", "BCard", "ECard", "BCartesian", "Cartesian", "ECartesian",
  "BSin", "ESin", "BCos", "ECos", "BTan", "ETan", "BSec", "ESec", "BCsc",
  "ECsc", "BCot", "ECot", "BSinh", "ESinh", "BCosh", "ECosh", "BTanh",
  "ETanh", "BSech", "Sech", "ESech", "BCsch", "Csch", "ECsch", "BCoth",
  "ECoth", "BArccos", "EArccos", "BArccosh", "Arccosh", "EArccosh",
  "BArcsin", "EArcsin", "BArctan", "EArctan", "BArccot", "Arccot",
  "EArccot", "BArccoth", "Arccoth", "EArccoth", "BArccsc", "Arccsc",
  "EArccsc", "BArccsch", "Arccsch", "EArccsch", "BArcsec", "Arcsec",
  "EArcsec", "BArcsech", "Arcsech", "EArcsech", "BArcsinh", "Arcsinh",
  "EArcsinh", "BArctanh", "Arctanh", "EArctanh", "BLn", "ELn", "BLog",
  "ELog", "BLg", "ELg", "BExp", "EExp", "BMean", "EMean", "BSDev", "ESDev",
  "BVariance", "Variance", "EVariance", "BMedian", "Median", "EMedian",
  "BMode", "Mode", "EMode", "BMoment", "EMoment", "BMomentDeg",
  "EMomentDeg", "BMomentArg", "EMomentArg", "BMomenta", "EMomenta",
  "BMabout", "EMabout", "BMATRIX", "EMATRIX", "BVector", "EVector",
  "BMatrix", "EMatrix", "BTranspose", "ETranspose", "BDet", "EDet",
  "BSelector", "SelectorMatrix", "ESelector", "BVectorProduct",
  "VectorProduct", "EVectorProduct", "BScalarProduct", "ScalarProduct",
  "EScalarProduct", "BOuterProduct", "OuterProduct", "EOuterProduct",
  "Integers", "Naturals", "Rationals", "Reals", "Complexes", "Primes",
  "EPrimes", "ExponentialE", "ImaginaryI", "NotANumber", "True", "False",
  "Emptyset", "PiCst", "EulerGamma", "Infty", "HBar", "Trace", "$accept",
  "Document", "document", "input", "@1", "@2", "@3", "@4", "@5", "@6",
  "@7", "@8", "@9", "@10", "@11", "@12", "@13", "@14", "@15", "@16", "@17",
  "float", "@18", "@19", "@20", "optId", "environment", "@21",
  "sectionmark", "@22", "@23", "label", "@24", "footnote", "@25", "@26",
  "caption", "@27", "figureTag", "ltable", "ltcore", "@28", "@29",
  "ltcaption", "@30", "tabular", "@31", "@32", "@33", "optFOption",
  "optAOption", "tcore", "xrow", "@34", "row", "cells", "cell", "ecell",
  "mcol", "text", "@35", "@36", "@37", "@38", "@39", "@40", "@41", "@42",
  "@43", "@44", "@45", "@46", "@47", "@48", "@49", "@50", "@51", "@52",
  "@53", "@54", "@55", "@56", "@57", "@58", "@59", "@60", "@61", "@62",
  "@63", "@64", "@65", "@66", "@67", "@68", "@69", "@70", "@71", "@72",
  "@73", "@74", "@75", "@76", "@77", "@78", "@79", "@80", "@81", "@82",
  "@83", "@84", "@85", "@86", "@87", "@88", "@89", "@90", "@91", "@92",
  "@93", "@94", "@95", "@96", "headline", "@97", "@98", "@99", "@100",
  "fhp", "@101", "@102", "@103", "headerfooter", "@104", "@105",
  "citelabels", "@106", "@107", "dvi", "accent", "@108", "@109",
  "happenings", "@110", "@111", "mathmode_on", "mathmode_off", "math",
  "@112", "@113", "@114", "phints", "ams_align", "@115", "@116", "@117",
  "optheadline", "cams_align", "@118", "amscells", "optalign", "optEqno",
  "eqno", "@119", "@120", "expression", "formula", "@121", "@122", "@123",
  "@124", "@125", "@126", "@127", "@128", "@129", "@130", "@131", "@132",
  "@133", "@134", "@135", "@136", "split", "@137", "split_in_align",
  "extensions", "@138", "@139", "@140", "@141", "@142", "@143", "eqalign",
  "beqalign", "@144", "@145", "eeqalign", "align", "@146", "@147",
  "aligned", "@148", "eqnarray", "@149", "eqnarrayrows", "eqnarrayrow",
  "@150", "@151", "@152", "@153", "@154", "@155", "opt_ignored_align",
  "mathArray", "@156", "almtcore", "trows", "tcell", "@157", "mtable",
  "mtable_core", "optfhp", "bmtable", "@158", "mtablecolumns", "@159",
  "emtable", "cmtable", "mtcell", "@160", "eqtags", "mtext", "@161",
  "@162", "@163", "@164", "@165", "@166", "@167", "@168", "@169", "@170",
  "math_accent", "@171", "@172", "@173", "@174", "@175", "@176", "@177",
  "@178", "@179", "@180", "@181", "@182", "@183", "@184", "omtext",
  "mml_bdegree", "mml_edegree", "function", "@185", "@186", "ld", "rd",
  "junk", "ops", "@187", "@188", "@189", "@190", "@191", "@192", "@193",
  "@194", "@195", "@196", "endfrac", "tex_sup_op", "@197", "@198", "@199",
  "@200", "mathML_content", "mathML_basic", "@201", "@202", "@203", "@204",
  "@205", "@206", "@207", "@208", "@209", "@210", "cases", "casesrow",
  "@211", "@212", "@213", "optjunks", "amscases", "@214", "opt_tail",
  "bcases", "@215", "casescolumns", "ecases", "@216", "ccases", "amsccell",
  "arrcase", "@217", "@218", "arrcases", "junks", "mml_binterval",
  "mml_einterval", "mathML_arithmetic_logic", "@219", "@220", "@221",
  "@222", "@223", "@224", "@225", "@226", "@227", "@228", "@229", "@230",
  "@231", "@232", "@233", "@234", "@235", "@236", "@237", "@238", "@239",
  "@240", "@241", "@242", "@243", "@244", "@245", "@246", "@247", "@248",
  "@249", "@250", "@251", "@252", "@253", "@254", "@255", "@256", "@257",
  "@258", "@259", "@260", "@261", "@262", "@263", "@264", "@265", "@266",
  "@267", "@268", "EndFrac", "stupid_root", "bvar", "@269", "@270",
  "opt_Expression", "@271", "@272", "condition", "@273", "opt_condition",
  "clist", "@274", "fix_list", "fix_bvar", "mathML_relations", "@275",
  "@276", "@277", "@278", "@279", "@280", "@281", "@282", "@283", "@284",
  "@285", "@286", "@287", "@288", "@289", "@290", "@291", "@292",
  "mathML_set_theory", "@293", "@294", "@295", "@296", "@297", "@298",
  "@299", "@300", "@301", "@302", "@303", "@304", "@305", "@306", "@307",
  "@308", "@309", "@310", "@311", "@312", "@313", "@314", "@315", "@316",
  "@317", "mathML_elementary", "@318", "@319", "@320", "@321", "@322",
  "@323", "@324", "@325", "@326", "@327", "@328", "@329", "@330", "@331",
  "@332", "@333", "@334", "@335", "@336", "@337", "@338", "@339", "@340",
  "@341", "@342", "@343", "@344", "@345", "@346", "@347", "@348", "@349",
  "@350", "@351", "@352", "@353", "@354", "@355", "@356", "@357", "@358",
  "@359", "@360", "@361", "@362", "@363", "@364", "@365", "@366", "@367",
  "@368", "@369", "@370", "@371", "@372", "@373", "mathML_statistics",
  "@374", "@375", "@376", "@377", "@378", "@379", "@380", "@381", "@382",
  "mml_moment_arg", "mml_moment_about", "@383", "mml_moment_degree",
  "@384", "@385", "@386", "mml_emoment", "mathML_linear_algebra", "@387",
  "@388", "@389", "@390", "@391", "@392", "@393", "@394", "@395", "@396",
  "vector", "@397", "Matrix", "matrix", "bmatrix", "@398", "matrixcolumns",
  "ematrix", "cmatrix", "matrixcell", "selector_content", "@399", "@400",
  "selector", "optjunk", "mml_evector", "mml_eselector",
  "mathML_constants_symbols", "extras", "tex_func", "opt_over",
  "mathML_calculus_vector", "@401", "@402", "@403", "@404", "@405", "@406",
  "@407", "@408", "@409", "@410", "@411", "@412", "@413", "@414", "@415",
  "@416", "flipIntegrand", "mml_diff_degree0", "mml_diff_degree", "@417",
  "@418", "mathML_sequences_series", "@419", "@420", "@421", "@422",
  "@423", "@424", "@425", "@426", "mml_Ilimits", "mml_Slimits",
  "mml_Plimits", "mml_bcondition", "mml_econdition", "mml_elimit",
  "mml_bllimit", "mml_buplimit", "mml_ellimit", "mml_euplimit", "symbol",
  "mml_bapply", "mml_bapplyi", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417,   418,   419,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,   492,   493,   494,
     495,   496,   497,   498,   499,   500,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,   511,   512,   513,   514,
     515,   516,   517,   518,   519,   520,   521,   522,   523,   524,
     525,   526,   527,   528,   529,   530,   531,   532,   533,   534,
     535,   536,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   550,   551,   552,   553,   554,
     555,   556,   557,   558,   559,   560,   561,   562,   563,   564,
     565,   566,   567,   568,   569,   570,   571,   572,   573,   574,
     575,   576,   577,   578,   579,   580,   581,   582,   583,   584,
     585,   586,   587,   588,   589,   590,   591,   592,   593,   594,
     595,   596,   597,   598,   599,   600,   601,   602,   603,   604,
     605,   606,   607,   608,   609,   610,   611,   612,   613,   614,
     615,   616,   617,   618,   619,   620,   621,   622,   623,   624,
     625,   626,   627,   628,   629,   630,   631,   632,   633,   634,
     635,   636,   637,   638,   639,   640,   641,   642,   643,   644,
     645,   646,   647,   648,   649,   650,   651,   652,   653,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,   664,
     665,   666,   667,   668,   669,   670,   671,   672,   673,   674,
     675,   676,   677,   678,   679,   680,   681,   682,   683,   684,
     685,   686,   687,   688,   689,   690,   691,   692,   693,   694,
     695,   696,   697,   698,   699,   700,   701,   702,   703,   704,
     705,   706,   707,   708,   709,   710,   711,   712,   713,   714,
     715,   716,   717,   718,   719,   720,   721,   722,   723,   724,
     725,   726,   727,   728,   729,   730,   731,   732,   733,   734,
     735,   736,   737,   738,   739,   740,   741,   742,   743,   744,
     745,   746,   747,   748,   749,   750,   751,   752,   753,   754,
     755,   756,   757,   758,   759,   760,   761,   762,   763,   764,
     765,   766,   767,   768,   769,   770,   771,   772,   773,   774,
     775,   776,   777,   778,   779,   780,   781,   782,   783,   784,
     785,   786,   787,   788,   789,   790,   791,   792,   793,   794,
     795,   796,   797,   798,   799,   800,   801,   802,   803,   804,
     805,   806,   807,   808,   809,   810,   811,   812,   813,   814,
     815,   816,   817,   818,   819,   820,   821,   822,   823,   824,
     825,   826,   827,   828,   829,   830,   831,   832,   833,   834,
     835,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,   846,   847,   848,   849,   850,   851,   852,   853,   854,
     855,   856,   857,   858,   859,   860,   861,   862,   863,   864,
     865,   866,   867,   868,   869,   870,   871,   872,   873,   874,
     875,   876,   877,   878,   879,   880,   881,   882,   883,   884,
     885,   886,   887,   888,   889,   890,   891,   892,   893,   894,
     895,   896,   897,   898,   899,   900,   901,   902,   903,   904,
     905,   906,   907,   908,   909,   910,   911,   912,   913,   914,
     915,   916,   917,   918
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   664,   665,   666,   666,   667,   668,   669,   667,   667,
     670,   671,   667,   672,   667,   673,   674,   667,   675,   667,
     667,   667,   676,   667,   667,   677,   678,   667,   679,   667,
     680,   681,   667,   667,   667,   667,   667,   682,   667,   683,
     667,   684,   667,   667,   667,   667,   667,   667,   667,   667,
     667,   667,   686,   687,   688,   685,   689,   689,   691,   690,
     693,   694,   692,   695,   696,   695,   698,   697,   699,   697,
     701,   700,   702,   703,   705,   704,   706,   704,   708,   707,
     710,   709,   711,   712,   709,   713,   713,   714,   714,   715,
     715,   716,   716,   717,   716,   718,   718,   719,   719,   720,
     721,   722,   723,   723,   723,   723,   723,   723,   723,   724,
     725,   723,   726,   727,   723,   728,   729,   723,   730,   731,
     723,   732,   733,   723,   734,   735,   723,   736,   737,   723,
     738,   739,   723,   740,   741,   723,   723,   742,   743,   723,
     744,   745,   723,   746,   747,   723,   748,   749,   723,   750,
     751,   723,   752,   753,   723,   754,   755,   723,   756,   757,
     723,   758,   759,   723,   760,   761,   723,   762,   763,   723,
     764,   765,   723,   723,   766,   767,   723,   768,   769,   723,
     770,   771,   723,   772,   773,   723,   774,   775,   723,   776,
     777,   723,   778,   779,   723,   780,   781,   723,   782,   783,
     723,   784,   785,   723,   787,   788,   786,   789,   790,   786,
     792,   791,   793,   791,   794,   791,   795,   795,   796,   797,
     795,   798,   799,   800,   798,   801,   801,   803,   802,   802,
     802,   804,   802,   805,   806,   807,   805,   805,   808,   809,
     811,   810,   812,   813,   810,   810,   810,   810,   810,   810,
     814,   814,   816,   817,   818,   815,   819,   819,   820,   821,
     820,   822,   822,   823,   823,   823,   824,   824,   826,   827,
     825,   828,   828,   829,   829,   829,   830,   831,   829,   829,
     829,   829,   829,   832,   833,   829,   834,   835,   829,   836,
     837,   829,   829,   829,   829,   829,   829,   838,   839,   829,
     840,   841,   829,   829,   829,   829,   829,   829,   829,   829,
     829,   842,   829,   843,   829,   844,   829,   845,   829,   829,
     829,   847,   846,   848,   848,   850,   851,   852,   849,   853,
     849,   854,   849,   855,   849,   856,   858,   859,   857,   860,
     860,   862,   863,   861,   865,   864,   867,   866,   868,   868,
     870,   871,   872,   873,   874,   875,   869,   876,   876,   878,
     877,   879,   879,   880,   880,   882,   881,   881,   883,   884,
     884,   885,   885,   887,   886,   888,   888,   889,   888,   890,
     891,   891,   892,   893,   892,   894,   894,   894,   895,   895,
     895,   895,   895,   895,   896,   897,   895,   898,   899,   895,
     895,   895,   895,   900,   901,   902,   895,   903,   904,   905,
     895,   907,   908,   906,   909,   906,   910,   906,   911,   906,
     912,   906,   913,   906,   914,   906,   915,   906,   916,   906,
     917,   906,   918,   906,   919,   906,   920,   906,   921,   921,
     921,   922,   923,   925,   924,   926,   924,   924,   924,   924,
     924,   924,   924,   924,   924,   924,   924,   924,   924,   924,
     924,   927,   928,   929,   931,   930,   930,   932,   933,   930,
     934,   935,   930,   936,   937,   930,   938,   939,   930,   940,
     930,   941,   941,   943,   944,   942,   945,   946,   942,   947,
     947,   947,   947,   947,   947,   947,   947,   947,   947,   949,
     950,   948,   951,   948,   952,   953,   948,   954,   948,   955,
     948,   956,   948,   948,   957,   958,   948,   959,   959,   961,
     962,   963,   960,   964,   964,   965,   966,   965,   967,   967,
     969,   968,   970,   970,   972,   971,   973,   973,   974,   974,
     976,   977,   975,   978,   978,   979,   979,   980,   981,   983,
     984,   985,   982,   986,   982,   987,   988,   982,   989,   982,
     990,   982,   991,   982,   992,   982,   993,   994,   982,   995,
     996,   982,   997,   998,   982,   999,  1000,   982,  1001,  1002,
     982,  1003,  1004,   982,  1005,  1006,   982,  1007,  1008,   982,
    1009,  1010,   982,  1011,  1012,   982,  1013,  1014,   982,  1015,
    1016,   982,  1017,  1018,  1019,   982,  1020,   982,  1021,   982,
    1022,   982,  1023,   982,  1024,   982,  1025,   982,  1026,   982,
    1027,  1028,   982,  1029,  1030,   982,  1031,  1032,   982,  1033,
    1033,  1034,  1034,  1036,  1037,  1035,  1038,  1039,  1040,  1038,
    1042,  1041,  1043,  1043,  1045,  1044,  1046,  1047,  1049,  1050,
    1048,  1051,  1052,  1048,  1053,  1054,  1048,  1055,  1056,  1048,
    1057,  1058,  1048,  1059,  1060,  1048,  1061,  1062,  1048,  1063,
    1064,  1048,  1065,  1066,  1048,  1068,  1067,  1069,  1067,  1070,
    1067,  1071,  1067,  1072,  1073,  1067,  1074,  1075,  1067,  1076,
    1077,  1067,  1078,  1079,  1067,  1080,  1081,  1067,  1082,  1083,
    1067,  1084,  1085,  1067,  1086,  1087,  1067,  1088,  1089,  1067,
    1090,  1067,  1091,  1092,  1067,  1094,  1095,  1093,  1096,  1097,
    1093,  1098,  1099,  1093,  1100,  1101,  1093,  1102,  1103,  1093,
    1104,  1105,  1093,  1106,  1107,  1093,  1108,  1109,  1093,  1110,
    1111,  1093,  1112,  1113,  1093,  1114,  1115,  1093,  1116,  1117,
    1093,  1118,  1119,  1093,  1120,  1121,  1093,  1122,  1123,  1093,
    1124,  1125,  1093,  1126,  1127,  1093,  1128,  1129,  1093,  1130,
    1131,  1093,  1132,  1133,  1093,  1134,  1135,  1093,  1136,  1137,
    1093,  1138,  1139,  1093,  1140,  1141,  1093,  1142,  1143,  1093,
    1144,  1145,  1093,  1146,  1147,  1093,  1148,  1149,  1093,  1151,
    1150,  1152,  1150,  1153,  1150,  1154,  1150,  1155,  1150,  1156,
    1157,  1150,  1158,  1159,  1150,  1160,  1161,  1162,  1161,  1163,
    1164,  1165,  1166,  1163,  1167,  1168,  1168,  1169,  1168,  1170,
    1168,  1171,  1172,  1168,  1173,  1174,  1168,  1175,  1176,  1168,
    1177,  1178,  1168,  1180,  1179,  1181,  1182,  1184,  1183,  1185,
    1185,  1186,  1187,  1187,  1188,  1188,  1190,  1189,  1191,  1189,
    1189,  1189,  1192,  1193,  1193,  1194,  1195,  1196,  1196,  1196,
    1196,  1196,  1196,  1196,  1196,  1196,  1196,  1196,  1196,  1196,
    1196,  1196,  1196,  1197,  1198,  1198,  1198,  1198,  1198,  1198,
    1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,
    1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,
    1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,
    1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,  1198,
    1199,  1199,  1201,  1202,  1203,  1204,  1200,  1205,  1206,  1207,
    1208,  1209,  1200,  1210,  1200,  1211,  1200,  1212,  1200,  1213,
    1200,  1214,  1200,  1215,  1200,  1216,  1200,  1217,  1218,  1218,
    1219,  1220,  1221,  1219,  1223,  1224,  1222,  1225,  1226,  1222,
    1227,  1228,  1222,  1229,  1230,  1222,  1231,  1231,  1231,  1231,
    1231,  1231,  1231,  1232,  1232,  1232,  1232,  1232,  1232,  1233,
    1233,  1233,  1233,  1233,  1233,  1234,  1235,  1236,  1237,  1238,
    1239,  1240,  1241,  1241,  1241,  1241,  1242,  1243
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     0,     2,     1,     0,     0,     5,     1,
       0,     0,     6,     0,     4,     0,     0,     6,     0,     4,
       1,     1,     0,     4,     1,     0,     0,     7,     0,     4,
       0,     0,     5,     1,     1,     1,     1,     0,     3,     0,
       4,     0,     4,     1,     1,     5,     1,     1,     1,     1,
       1,     1,     0,     0,     0,     8,     0,     1,     0,     4,
       0,     0,    10,     0,     0,     3,     0,     4,     0,     5,
       0,     4,     3,     3,     0,     5,     0,     6,     0,     4,
       0,     9,     0,     0,    10,     0,     1,     0,     1,     1,
       2,     3,     2,     0,     2,     1,     2,     1,     2,     2,
       2,     5,     1,     1,     1,     1,     1,     2,     1,     0,
       0,     5,     0,     0,     5,     0,     0,     5,     0,     0,
       5,     0,     0,     5,     0,     0,     5,     0,     0,     5,
       0,     0,     5,     0,     0,     5,     1,     0,     0,     5,
       0,     0,     5,     0,     0,     5,     0,     0,     5,     0,
       0,     5,     0,     0,     5,     0,     0,     5,     0,     0,
       5,     0,     0,     5,     0,     0,     5,     0,     0,     7,
       0,     0,     5,     1,     0,     0,     5,     0,     0,     5,
       0,     0,     5,     0,     0,     5,     0,     0,     5,     0,
       0,     5,     0,     0,     5,     0,     0,     5,     0,     0,
       5,     0,     0,     5,     0,     0,     5,     0,     0,     5,
       0,     4,     0,     4,     0,     4,     0,     2,     0,     0,
       6,     0,     0,     0,     6,     0,     2,     0,     5,     4,
       3,     0,     5,     0,     0,     0,     5,     1,     0,     0,
       0,     7,     0,     0,     8,     1,     1,     1,     1,     1,
       0,     1,     0,     0,     0,    12,     0,     4,     1,     0,
       5,     6,     6,     0,     1,     1,     0,     2,     0,     0,
       5,     0,     1,     2,     2,     2,     0,     0,     6,     4,
       2,     2,     2,     0,     0,     6,     0,     0,     6,     0,
       0,     6,     2,     2,     2,     4,     4,     0,     0,     6,
       0,     0,     6,     2,     2,     2,     2,     2,     2,     3,
       3,     0,     3,     0,     3,     0,     3,     0,     3,     2,
       1,     0,     5,     0,     3,     0,     0,     0,    11,     0,
       6,     0,     6,     0,     4,     3,     0,     0,     7,     4,
       5,     0,     0,     7,     0,     4,     0,     6,     0,     2,
       0,     0,     0,     0,     0,     0,    19,     0,     1,     0,
       5,     1,     3,     1,     2,     0,     5,     4,     4,     7,
       5,     0,     1,     0,     5,     0,     1,     0,     3,     5,
       0,     2,     4,     0,     6,     1,     1,     1,     1,     2,
       1,     1,     1,     1,     0,     0,     5,     0,     0,     5,
       7,     1,     1,     0,     0,     0,     9,     0,     0,     0,
       9,     0,     0,     5,     0,     4,     0,     4,     0,     4,
       0,     4,     0,     4,     0,     4,     0,     4,     0,     4,
       0,     4,     0,     4,     0,     4,     0,     5,     1,     3,
       1,     0,     0,     0,     2,     0,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     0,     0,     1,     0,     2,     1,     0,     0,     6,
       0,     0,     7,     0,     0,     5,     0,     0,     7,     0,
       4,     4,     3,     0,     0,     5,     0,     0,     5,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
       0,    10,     0,    11,     0,     0,     8,     0,     6,     0,
       6,     0,     6,     9,     0,     0,    11,     1,     2,     0,
       0,     0,    10,     0,     1,     5,     0,     6,     0,     2,
       0,     7,     1,     1,     0,     6,     0,     2,     4,     4,
       0,     0,     8,     1,     5,     1,     2,     0,     0,     0,
       0,     0,    12,     0,     8,     0,     0,     6,     0,     7,
       0,    12,     0,     7,     0,    12,     0,     0,     9,     0,
       0,     8,     0,     0,     7,     0,     0,     7,     0,     0,
       7,     0,     0,    13,     0,     0,     7,     0,     0,     6,
       0,     0,     8,     0,     0,     8,     0,     0,     8,     0,
       0,     5,     0,     0,     0,     9,     0,    10,     0,    10,
       0,     6,     0,     6,     0,     5,     0,     5,     0,     5,
       0,     0,     6,     0,     0,     7,     0,     0,     7,     4,
       3,     2,     2,     0,     0,     6,     0,     0,     0,     5,
       0,     4,     0,     1,     0,     3,     0,     0,     0,     0,
       8,     0,     0,     9,     0,     0,     8,     0,     0,     8,
       0,     0,     8,     0,     0,     8,     0,     0,     8,     0,
       0,     8,     0,     0,     8,     0,     6,     0,     8,     0,
       6,     0,     8,     0,     0,     8,     0,     0,     8,     0,
       0,     8,     0,     0,     8,     0,     0,     8,     0,     0,
       8,     0,     0,     8,     0,     0,     7,     0,     0,     8,
       0,     6,     0,     0,     8,     0,     0,     6,     0,     0,
       6,     0,     0,     6,     0,     0,     6,     0,     0,     6,
       0,     0,     6,     0,     0,     6,     0,     0,     6,     0,
       0,     6,     0,     0,     6,     0,     0,     6,     0,     0,
       6,     0,     0,     6,     0,     0,     6,     0,     0,     6,
       0,     0,     6,     0,     0,     6,     0,     0,     6,     0,
       0,     6,     0,     0,     6,     0,     0,     6,     0,     0,
       6,     0,     0,     6,     0,     0,     6,     0,     0,     6,
       0,     0,     6,     0,     0,     6,     0,     0,     6,     0,
       4,     0,     7,     0,    11,     0,     7,     0,     7,     0,
       0,     7,     0,     0,     9,     4,     0,     0,     5,     0,
       0,     0,     0,     8,     0,     1,     1,     0,     5,     0,
       7,     0,     0,     9,     0,     0,     9,     0,     0,     9,
       0,     0,     9,     0,     9,     5,     3,     0,     8,     1,
       1,     6,     0,     2,     4,     4,     0,     2,     0,     3,
       1,     2,     1,     0,     2,     0,     0,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     1,     0,     0,     0,     0,    15,     0,     0,     0,
       0,     0,    22,     0,     4,     0,     4,     0,     4,     0,
       4,     0,     4,     0,     4,     0,     7,     0,     0,     5,
       0,     0,     0,     7,     0,     0,     8,     0,     0,     8,
       0,     0,    14,     0,     0,     7,     0,    15,    15,     8,
       8,     8,     8,     0,    15,    15,     8,     8,     8,     0,
      15,    15,     8,     8,     8,     0,     0,     0,     0,     0,
       0,     0,     1,     1,     1,     1,     0,     0
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       3,     0,     0,     1,   103,     0,     2,   105,   136,   173,
     108,   127,    30,   201,   130,   109,   112,   115,    21,   124,
     137,   118,   170,   140,   149,   133,   121,   143,   146,   152,
     155,   158,   161,   164,   174,   177,   180,   183,   186,   189,
     192,   195,   198,   204,   207,    58,     6,     9,    24,    25,
      28,    22,    18,    70,     3,    48,    49,    20,    10,    15,
      66,   239,    52,    80,    82,     0,     0,   233,     0,   233,
     238,   238,    39,    13,   210,   212,   214,   238,    87,   346,
     341,   104,    41,     4,    50,     5,    46,    36,    47,    43,
      44,    51,    34,   106,    33,   102,    35,   245,   249,   247,
     248,   246,   107,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,    56,     3,
       3,     0,     3,     0,     0,     0,     3,    68,     0,     0,
       0,    78,     0,    56,     0,   237,   234,     0,     0,     0,
       0,   167,     0,   240,     0,   242,     3,     3,   216,   216,
       3,     0,    88,   359,     0,     0,     3,   128,    31,   202,
     131,   110,   113,   116,   125,   138,   119,   171,   141,   150,
     134,   122,   144,   147,   153,   156,   159,   162,   165,   175,
     178,   181,   184,   187,   190,   193,   196,   199,   205,   208,
       0,     7,    57,     0,     0,     0,    60,     0,     0,    72,
      11,    16,     0,     3,    53,     0,   239,     3,    73,    56,
       0,     3,     3,   227,     0,   230,   231,     3,    38,   250,
       3,   250,     0,     0,     0,   218,   216,     0,     0,     0,
       0,     0,     0,     0,   348,   342,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      59,     0,    26,    29,    23,    56,    19,    71,     3,   221,
      67,     0,    85,    87,    87,     0,     0,    74,     0,   235,
       0,   229,     0,   168,   251,   443,     0,   443,   253,    40,
      14,     3,   217,   211,   213,   215,     0,   373,   380,   368,
     365,     0,     0,   361,   363,     0,     0,    42,   129,    32,
     203,   132,   111,   114,   117,   126,   139,   120,   172,   142,
     151,   135,   123,   145,   148,   154,   157,   160,   163,   166,
     176,   179,   182,   185,   188,   191,   194,   197,   200,   206,
     209,     8,     3,     0,     0,   222,     0,    69,    86,    54,
      93,    93,    79,    76,    93,   101,     0,   228,   232,     0,
     388,     0,   271,   393,   297,   300,   401,   402,   394,   397,
       0,   311,   239,   239,   225,   411,   448,   447,   276,   443,
     385,   386,   387,   268,   283,   286,   289,   344,   336,   323,
     483,   566,   486,   392,   467,   313,   315,   317,   476,   449,
     450,   451,   452,   453,   454,   455,   456,   457,   458,   459,
     460,   414,   418,   416,   420,   422,   426,   428,   430,   424,
     432,   434,   479,   473,   470,     0,   584,   547,   504,   502,
     882,   507,   509,   511,     0,     0,     0,     0,     0,   572,
     575,   578,   549,   553,   555,     0,     0,     0,     0,   569,
     333,     0,     0,     0,     0,   590,   593,   596,   599,   602,
     606,   608,   610,   612,     0,     0,     0,   672,   648,   651,
     654,   657,   660,   663,   666,   669,   932,   937,   945,   943,
     947,   949,   951,   953,   955,   964,   967,   970,   973,     0,
       0,   683,   686,   689,   692,     0,     0,   695,   698,   701,
     704,   707,   710,   712,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   799,     0,     0,   805,   807,   809,   812,   847,
     843,   863,   829,     0,   831,  1006,  1007,  1006,   867,   868,
     869,   870,   871,   872,   873,   874,   875,   877,   878,   876,
     879,   880,   881,   391,   320,     0,   271,     0,   271,   271,
     271,   380,   271,   271,   271,   271,   271,   271,   271,   390,
     271,     0,     0,   271,     0,   466,   271,   489,   491,   490,
     494,   495,   496,   497,   825,   826,   271,   852,   498,   492,
     493,    45,     0,   256,   219,   380,   443,     0,     0,   443,
       0,   360,   364,   350,     0,   349,     0,     0,    64,    12,
       3,    17,     3,     0,    93,    89,     3,    93,    93,    93,
     236,     0,   389,   319,   272,   443,   443,     3,     3,   325,
     271,   407,   403,     0,     0,   443,     0,     3,   216,   216,
       3,     0,     0,     0,   321,   271,   443,   443,   271,   443,
     443,   271,   271,   271,   443,   443,   443,   443,   443,   443,
     443,   443,   443,   443,   443,   443,   443,   443,   443,   581,
     461,   499,   443,   443,     0,     0,     0,   523,   523,   329,
     331,     0,   443,   443,   443,     0,   461,   443,   558,   560,
     562,   564,   443,   443,   587,   620,   463,   616,   618,   443,
     443,   443,   443,   443,     0,     0,     0,     0,   614,   623,
     626,   443,   443,   443,   443,   443,   443,   443,   443,   443,
     976,     0,   443,   443,   443,   443,   443,   443,     0,   983,
     989,     0,   443,   675,   677,   443,   443,   443,   443,   679,
     681,   443,   443,   443,   443,   443,     0,   443,   787,   733,
     793,   775,   751,   739,   790,   736,   796,   781,   757,   745,
     715,   718,   721,   727,   742,   748,   754,   760,   778,   784,
     724,   730,   769,   772,   766,   763,   443,     0,     0,     0,
       0,   443,   863,     0,   863,   863,     0,     0,   827,   856,
     834,   837,   840,   238,   238,   280,   239,   308,   294,   293,
       0,   304,   305,   303,   306,   292,   281,   273,   275,   884,
     886,   888,   890,   891,   892,   893,   895,   897,   901,   902,
     903,   904,   905,   907,   908,   909,   910,   911,   912,   913,
     914,   915,   916,   917,   918,   919,   923,   924,   925,   926,
     927,   928,   906,   929,   921,   899,   885,   894,   896,   898,
     900,   920,   922,   887,   889,   444,   883,   446,   274,  1002,
    1003,  1004,  1005,   465,   282,   307,     0,   243,     0,   250,
       0,     0,   375,   443,     0,   381,   266,   357,   362,   443,
     347,     0,    27,     0,     3,     0,     0,    92,     0,    90,
       0,    94,     3,    97,    95,     0,    93,   169,     0,     0,
     395,   398,   443,   312,     0,     0,   436,   226,   412,     0,
     271,   269,     0,     0,     0,     0,   337,     0,     0,   309,
     484,     0,   310,   487,     0,   314,   316,   318,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   474,     0,   441,   443,   443,     0,     0,   443,   443,
     443,   545,     0,   524,     0,   443,   443,     0,     0,     0,
       0,   443,   443,     0,     0,     0,     0,     0,   570,     0,
     443,   443,   443,   443,     0,     0,     0,   600,   603,   633,
     863,   863,   443,   443,   443,   443,   443,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   999,   998,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   999,     0,
     965,   999,     0,   968,   995,   974,   644,     0,     0,     0,
       0,     0,   644,     0,     0,     0,     0,     0,     0,   443,
       0,   443,   443,   443,   443,   443,   443,   443,   443,   443,
     443,   443,   443,   443,   443,   443,   443,   443,   443,   443,
     443,   443,   443,   443,   443,   443,   443,   443,   443,     0,
     801,   803,     0,     0,   810,   813,     0,     0,     0,   864,
     863,     0,   443,   858,   860,   832,     0,   443,   443,   443,
     271,   271,   241,   443,   335,   443,   846,   853,   239,   238,
       0,     0,   258,     0,   216,     0,   377,   376,     0,     0,
     370,   367,   358,     0,   357,   343,     0,     0,   223,    55,
      91,     0,   100,    99,    98,    96,     0,   298,   301,     0,
       0,     0,   408,   404,     0,   464,   277,   279,     0,   284,
     287,   290,   345,   443,   324,     0,     0,   567,     0,   468,
     477,   415,   419,   417,   421,   423,   427,   429,   431,   425,
     433,   435,   480,     0,   471,   443,   462,     0,     0,     0,
       0,     0,     0,     0,   546,   514,     0,     0,     0,   573,
     576,   579,     0,   462,   556,   644,     0,   644,     0,     0,
     334,   588,   621,     0,     0,     0,     0,     0,     0,     0,
     644,   642,   642,     0,     0,     0,   624,   627,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   999,
     998,   933,   958,   946,   944,   948,   950,   952,   954,     0,
       0,   999,   998,     0,     0,   999,   998,     0,     0,     0,
       0,   443,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   705,     0,     0,     0,   788,   734,   794,   776,
     752,   740,   791,   737,   797,   782,   758,   746,   716,   719,
     722,   728,   743,   749,   755,   761,   779,   785,   725,   731,
     770,   773,   767,   764,   800,   443,   443,   443,   443,   819,
     863,   443,     0,   443,     0,     0,     0,   861,     0,     0,
     857,     0,     0,     0,   296,   295,     0,     0,   244,   256,
     267,   256,   443,   443,   220,     0,   250,   374,     0,   266,
       0,   366,     0,    61,     4,   221,    81,   239,   271,   271,
     396,   399,   326,     3,   221,   437,     0,   483,   486,   438,
     413,   440,   271,   270,   271,   271,   271,   375,   322,   485,
       0,   488,     0,   443,   475,   443,   442,   585,     0,   505,
       0,     0,     0,     0,     0,    87,     0,     0,     0,     0,
       0,   443,   443,   443,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   617,   619,   591,   594,   597,   601,
       0,   634,   640,   643,     0,     0,     0,     0,   615,     0,
       0,   673,   649,     0,   655,   658,   661,   664,   667,   670,
     443,   443,     0,     0,   443,     0,     0,   443,   443,     0,
       0,   443,   443,     0,     0,   443,   443,   443,     0,   646,
       0,   684,   687,   690,   693,     0,     0,   696,   699,   702,
     443,   708,     0,   713,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   820,     0,   816,     0,
     443,     0,   845,     0,   828,   859,   443,     0,     0,     0,
       0,     0,     0,     0,     0,   257,   259,   263,   263,   369,
     378,   383,   371,   382,   351,     3,   224,    84,   299,   302,
       0,     0,     0,     0,   278,   285,   288,   291,     0,   443,
     443,     0,   469,     0,     0,     0,     0,   500,   443,     0,
     508,   510,   512,     0,   536,   526,   523,     0,   515,   517,
     330,   332,     0,     0,     0,     0,   550,     0,     0,   443,
     557,     0,     0,     0,     0,   443,   589,   622,   443,   443,
     443,   443,     0,   443,     0,     0,   611,   613,     0,     0,
     443,   443,   652,   443,   443,   443,   443,   443,   443,     0,
       0,   443,   443,     0,     0,   938,     0,     0,   443,   443,
       0,     0,   443,   443,     0,     0,     0,   676,   645,     0,
     443,   443,   443,   443,   680,     0,   443,   443,   443,     0,
     443,   711,   443,   789,   735,   795,   777,   753,   741,   792,
     738,   798,   783,   759,   747,   717,   720,   723,   729,   744,
     750,   756,   762,   780,   786,   726,   732,   771,   774,   768,
     765,     0,     0,     0,     0,     0,   824,   817,   819,   815,
       0,   863,     0,   862,     0,   835,   838,   841,   383,   339,
     855,     0,   854,   254,   250,   265,   264,     0,     0,   250,
     372,   379,     0,     0,   443,   409,   405,   439,   338,     0,
       0,   443,   478,   472,   582,   586,   443,     0,     0,   530,
       0,     0,     0,   519,     0,   518,   400,   574,   577,   580,
       0,     0,   443,     0,   559,   636,   563,   636,     0,     0,
       0,     0,   604,   647,     0,   443,   443,   625,   628,     0,
       0,   443,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   934,     0,   443,   956,     0,     0,     0,     0,
       0,     0,     0,     0,   997,   975,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   706,     0,     0,   802,     0,
     806,   808,   821,   811,   443,     0,   850,   849,     0,   865,
     830,     0,   443,   443,   443,   340,     0,   239,   260,   266,
     266,   384,   352,    62,     0,   238,   238,     0,   482,     0,
       0,     0,   506,     0,     0,   443,     0,   537,   540,   543,
     528,     0,   443,   523,   443,   554,     0,   630,   637,   863,
     863,   571,   592,   595,   598,     0,   635,   641,     0,     0,
     674,   650,     0,   656,   659,   662,   665,   668,   671,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   966,
       0,     0,     0,   969,   996,   678,   685,   688,   691,   694,
     682,   697,   700,   703,   709,   714,     0,     0,     0,   824,
     848,     0,   866,     0,     0,     0,   851,   255,   256,   262,
     261,   443,   327,   410,   406,   568,   481,     0,   548,     0,
     443,     0,   525,   443,     0,     0,   513,     0,     0,   551,
     629,   443,     0,     0,   605,     0,     0,   653,  1001,  1000,
    1001,  1000,     0,   959,     0,  1001,  1001,  1000,  1001,  1001,
    1000,   971,     0,   822,   863,   814,   844,   833,   836,   839,
     842,   259,   357,     0,     0,   501,     0,     0,     0,   534,
       0,     0,     0,   529,   527,   520,     0,     0,   638,     0,
       0,   607,   609,   981,   979,   982,   980,   443,   930,   987,
     988,   986,   993,   994,   992,     0,     0,     0,   818,     0,
     328,   443,   503,   533,   532,     0,   539,     0,   538,   541,
       0,     0,   516,     0,     0,     0,     0,   998,   998,     0,
     931,     0,   998,   998,   998,   998,   443,   804,     0,   353,
       0,   531,     0,     0,   544,     3,   552,   639,   561,   565,
       0,     0,   935,     0,     0,     0,     0,     0,     0,   823,
       0,     0,     0,   583,   535,     0,   521,   443,   443,   957,
     939,   443,   443,   443,   443,     0,   354,   632,   631,   238,
     238,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     972,   443,   542,   522,     0,     0,   936,   443,     0,     0,
       0,     0,   357,  1000,  1000,     0,  1000,  1000,  1000,  1000,
       0,   977,   978,   940,   984,   985,   990,   991,   355,   960,
     266,     0,   941,   356,   961,     0,     0,     0,   962,   942,
       0,     0,   963
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,   930,    83,   137,   291,   144,   298,   167,   145,
     299,   141,   140,   138,   372,   139,   104,   258,   162,   166,
     176,    84,   148,   302,   652,   213,    85,   136,   217,   295,
    1535,   923,   924,    86,   146,   223,    87,   142,    88,    89,
     152,   384,   658,   153,   227,    90,   149,   150,   935,   379,
     173,   654,   655,   656,   931,   932,   933,   934,   594,    92,
     107,   261,   108,   262,   109,   263,   112,   266,   117,   271,
     110,   264,   103,   257,   106,   260,   116,   270,   111,   265,
     114,   268,   118,   272,   119,   273,   115,   269,   120,   274,
     121,   275,   122,   276,   123,   277,   124,   278,   237,   389,
     113,   267,   125,   279,   126,   280,   127,   281,   128,   282,
     129,   283,   130,   284,   131,   285,   132,   286,   133,   287,
     105,   259,    93,   134,   288,   135,   289,    94,   168,   169,
     170,   247,   321,   910,   376,   650,  1355,   673,    95,   310,
     312,   157,   232,   386,   163,   595,    96,   239,   241,  1128,
    1130,    97,   242,   633,  1807,   909,  1131,  1694,  1132,  1697,
    1133,   596,   677,  1168,   663,   664,   675,  1372,   678,  1374,
     679,  1375,   680,  1376,   665,  1358,   666,  1359,   670,   691,
     692,   693,   598,   958,   684,   599,   942,  1540,  1953,   995,
     996,   733,   600,   601,   682,  1173,  1124,   602,   175,   336,
     603,   681,   604,   174,   335,   645,   919,  1702,  1901,  2040,
    2071,  2100,  1143,   605,   253,   332,   333,   334,   639,   606,
     252,  1701,   328,   636,  1138,  1346,   914,   637,   915,  1699,
     607,   608,   667,  1159,   668,  1160,   945,  1364,  1816,   944,
    1363,  1815,   609,   674,  1165,   695,   697,   696,   698,   699,
     703,   700,   701,   702,   704,   705,  1164,  1370,  1195,  1555,
     610,   611,   612,   984,  1387,   825,   613,   614,   690,  1382,
     708,  1385,   707,  1193,   694,  1383,   706,  1552,   615,   686,
    1176,   689,  1178,   616,   617,   985,  1716,   713,   712,  1558,
     714,   715,   716,  1397,  1724,  1568,  1569,  1832,  2001,  2061,
     992,  1396,  1721,  1915,  1564,  1824,  1995,  1826,  1997,  1720,
    1827,  1829,  1913,  2023,  1830,   993,   711,  1955,   618,   725,
    1730,  1967,   726,   727,  1406,  1004,  1005,  1006,  1007,   687,
    1380,   732,  1219,   722,  1401,   723,  1402,   724,  1403,   983,
    1820,   710,  1556,  1010,  1412,   739,  1588,   740,  1589,   741,
    1590,   742,  1228,   743,  1229,  1845,   744,   745,   746,   747,
    1024,  1012,  1013,  1011,  1413,  1025,  1429,  1026,  1430,  1580,
    2043,  1020,  1230,  1592,  1839,  1921,  2004,  1423,  1593,  1424,
    1270,  1271,  1628,  1846,   619,   752,  1601,   753,  1751,   754,
    1603,   755,  1604,   756,  1605,   757,  1606,   758,  1607,   759,
    1608,   751,  1600,   620,  1056,  1057,  1062,  1063,   775,  1630,
     776,  1631,   777,  1632,   778,  1633,   781,  1636,   782,  1637,
     783,  1638,   784,  1470,   785,  1640,   786,   787,  1642,   621,
    1083,  1486,  1084,  1487,  1085,  1488,  1093,  1496,  1086,  1489,
    1094,  1497,  1072,  1475,  1078,  1481,  1076,  1479,  1087,  1490,
    1082,  1485,  1088,  1491,  1075,  1478,  1089,  1492,  1081,  1484,
    1090,  1493,  1098,  1501,  1097,  1500,  1095,  1498,  1096,  1499,
    1074,  1477,  1091,  1494,  1080,  1483,  1092,  1495,  1071,  1474,
    1077,  1480,  1073,  1476,  1079,  1482,   622,   816,  1315,  1316,
     819,   820,   821,  1319,   822,  1320,  1105,  1678,  1794,  1507,
    1675,  1887,  1987,  1793,   623,  1112,   827,   829,  1329,  1117,
    1802,  1118,  1803,  1119,  1804,   624,   824,   625,   626,   627,
     823,  1798,  1126,   906,  1127,  1115,  1116,  1328,  1684,   826,
    1891,  1947,   628,   897,   895,  2011,   629,   760,  1444,  1863,
    2049,   761,  1764,  2065,  2099,  2105,   763,   762,   764,   765,
     766,   767,   768,  2064,  1446,  2102,  2106,  2110,   630,   769,
    1263,   770,  1267,   771,  1985,   772,  1269,  1039,  1050,  1053,
    1268,  1941,  1874,  1248,  1247,  1974,  1973,   903,   830,   831
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1847
static const yytype_int16 yypact[] =
{
   -1847,    69, 15000, -1847, -1847,    74, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847,   -69,   -63,    36,  3413,    36,
     -12, -1847, -1847, -1847, -1847, -1847, -1847, -1847,   -13, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,    10, -1847,
   -1847,    20, -1847, 15189,    13,     3, -1847, -1847,    -3,   -22,
     -21, -1847,   -47,    10,   -14, -1847, -1847,   124,   105,   144,
     145, -1847,   -17, -1847,   -90,   140, -1847, -1847,  3051,  3051,
   -1847,   -50, -1847, -1847,   -15,   -11, -1847, 18969, 18969, 18969,
   18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969,
   18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969,
   18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969, 18969,
   15378, 18969, -1847,    50, 15567, 15756, -1847,    45, 15945, -1847,
   -1847, -1847, 16134, -1847, -1847,   -28, -1847, -1847, -1847,    10,
     149, -1847, -1847, -1847,   157, -1847, -1847, -1847, -1847,   154,
   -1847,   154,   153, 16323, 16512, -1847,  3051,   -10,    -9, 16701,
      -1,     1,   -16,   -49, -1847, -1847, 14612,   151,   152,   209,
     147,   148,   204,   206,   205,   208,   210,   202,   244,   203,
     199,   238,   239,   247,   242,   248,   249,   252,   253,   250,
     255,   256,   257,   251,   254,   290,   292,   245,   236,   281,
   -1847,   234, -1847, -1847, -1847,    10, -1847, -1847, -1847,   261,
   -1847, 16890,   240,   -13,   -13, 17079,   378, -1847, 17268, 18969,
    3413, -1847,  3413, 18969, -1847, 13951, 17457, 13951, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847,     1, -1847, -1847, -1847,
     385,   231,   211,   231, -1847,   -56,   -49, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847,   283, 17646, -1847,   269, -1847, -1847, -1847,
     246,   246, -1847, -1847,   246, -1847,   294, -1847, -1847,   362,
   -1847,   402,  3594, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
     316, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,  6018,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,   225,
     212, -1847,   213, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847,   258, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847,   398,   403,   410,   414,   259, -1847,
   -1847, -1847, -1847, -1847, -1847,   187,   188,   189,   190, -1847,
   -1847,   207,    51,   417,   417, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847,   214,   417,   417, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,   417,
     417, -1847, -1847, -1847, -1847,   417,   417, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847,   192,   217,   193,   196,   216,   219,
     198,   223,   200,  -116,  -115,   227,   232,  -120,   235,   237,
    -125,  -124,  -128,  -129,  -127,  -134,  -132,  -137,   224,   228,
     241,   243, -1847,   417,   417, -1847, -1847, -1847, -1847, -1847,
   -1847,   417, -1847,   260, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847,   -48,  3594,   291,  3594,  3594,
    3594, -1847,  3594,  3594,  3594,  3594,  3594,  3594,  3594, -1847,
    3594,  2167,  -204,  3594,  -135, -1847,  3594, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847,  3594, -1847, -1847, -1847,
   -1847, -1847,   293,    25, 18969, -1847,  4200,   297,   299,  4806,
     -55, -1847, -1847, -1847,   282, -1847,   301, 17835,   355, -1847,
   -1847, -1847, -1847,   463,  -111, -1847, -1847,  -114,   246,   -52,
   -1847,   308, -1847, -1847, -1847,  6624,  7285, -1847, -1847, -1847,
    3594, -1847, -1847,   108,   780,  7891,   348, -1847,  3051,  3051,
   -1847,   -49,   311,   356, -1847,  3594, 13951, 13951,  3594, 13951,
    8497,  3594,  3594,  3594,  9103, 13951, 13951, 13951, 13951, 13951,
   13951, 13951, 13951,  9709, 13951, 13951, 13951, 13951, 10315, -1847,
   -1847, -1847, 13951, 13951,   417,   417,   417,   417,   417, -1847,
   -1847,   521, 13951, 13951, 13951,   417, -1847, 13951, -1847, -1847,
   -1847, -1847, 13951, 13951, -1847, -1847, -1847, -1847, -1847, 13951,
   13951, 13951, 13951, 13951,   173,   173,   417,   264, -1847, -1847,
   -1847, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951,
      30,   285, 13951, 13951, 13951, 13951, 13951, 13951,   334,    18,
      33,   306, 13951, -1847, -1847, 13951, 13951, 13951, 13951, -1847,
   -1847, 13951, 13951, 13951, 13951, 13951,   417, 13951, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, 13951,   417,   417,   -75,
     -77, 13951,   417,   373,   417,   417,   -81,  3413, -1847,  -585,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
     379, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847,   380, -1847,    26,    60,
     368,   297,    29,  4200,   382, -1847,    48,   369, -1847,  4806,
   -1847,   361, -1847,   438, -1847, 18024, 18213, -1847,   389, -1847,
   14811, -1847, -1847, -1847, -1847,   390,   -51, -1847,   545,   544,
   18969, 18969, 13951, -1847,   433,   429, -1847, -1847, -1847,   397,
    3594, 18969,   422,   421, 18402,   413, -1847,   441,   -49, -1847,
   -1847,   407, -1847, -1847,   365, -1847, -1847, -1847,   363,   346,
     345,   347,   344,   349,   343,   342,   341,   340,   350,   338,
     337, -1847,   333, -1847, 13951, 13951,   319,   317, 13951, 13951,
   13951, -1847,   621,   417,   622, 13951, 13951,   471,   305,   304,
     300, 13951, 13951,   296,   417,   439,   417,   444, -1847,   277,
   13951, 13951, 13951, 13951,   266,   263,   262, -1847, -1847, -1847,
     417,   417, 13951, 13951, 13951, 13951, 13951,   265,   233,   267,
     268,   229,   222,   226,   221,   230, -1847, -1847,  -142,   215,
     417,   194,   197,   201,   218,   220,   270,   417, -1847,  -138,
   -1847, -1847,  -136, -1847, -1847, -1847, -1847,   173,   162,   160,
     163,   156, -1847,   173,   150,   155,   142,   143,   158, 13951,
     137, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951,
   13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951,
   13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951, 13951,    68,
   -1847, -1847,   417,   417, -1847, -1847,    53,   506,    54, -1847,
     417,   477, 13951,   -81, -1847, -1847,  3413, 13951, 13951, 13951,
    3594,  3594, -1847,  4200, -1847,  4200, -1847, -1847, -1847, -1847,
     501,   666,   515,   517,  3051,   518, -1847, -1847,   523,    44,
   -1847, -1847, -1847,   524,   369, -1847,   567, 18969, -1847, -1847,
   -1847,   551, -1847, -1847, -1847, -1847,   550, -1847, -1847,   677,
     676,   608, -1847, -1847,  3413,  1135, -1847, -1847,   526, -1847,
   -1847, -1847, -1847,  4200, -1847,   509,   504, -1847,   503, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847,   415, -1847, 13951, -1847,   404,   417,   511,
     393,   395,   391,   -60, -1847, -1847,   386,   388,   552, -1847,
   -1847, -1847,   377, -1847, -1847, -1847,   173, -1847,   173,   354,
   -1847, -1847, -1847,   351,   336,   417,   417,   335,   328,   327,
   -1847,   367,   367,   322,   442,   321, -1847, -1847,   417,   417,
     417,   417,   417,   417,   417,   417,   417,   286,   289, -1847,
   -1847, -1847,   278, -1847, -1847, -1847, -1847, -1847, -1847,   535,
     271, -1847, -1847,   272,   273, -1847, -1847,   274,   532,   275,
     276, 13951,   417,   417,   417,   417,   417,   288,   417,   417,
     417,   417, -1847,   417,   318,   417, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, 13951, 13951, 13951, 13951,   119,
     417, 13951,   572, 13951,   109,   417,   106, -1847,  3413,   538,
   -1847,   103,   101,    99, -1847, -1847,    52,    62, -1847,    25,
   -1847,    25,  4200,  4200, -1847,   579,     7, -1847,   580,    48,
     584, -1847,   585, -1847,   636,   261, -1847, -1847,  3594,  3594,
   -1847, -1847, -1847, -1847,   261, -1847,   780, -1847, -1847, -1847,
   -1847, -1847,  3594, -1847,  3594,  3594,  3594,    29, -1847, -1847,
     556, -1847,  -122, 10921, -1847, 11527, -1847, -1847,   417, -1847,
     417,   417,   417,   417,   590,   -13,   743,   434,   757,   759,
     763, 13951, 13951, 13951,   417,   423,  -210,   420,   564,   411,
     577,   418,   409,   396, -1847, -1847, -1847, -1847, -1847, -1847,
     417, -1847, -1847, -1847,   376,   383,   417,   381, -1847,   375,
     392, -1847, -1847,   417, -1847, -1847, -1847, -1847, -1847, -1847,
   13951, 13951,   358,   352, 13951,   593,   399, 13951, 13951,   325,
     320, 13951, 13951,   324,   313, 13951, 13951, 12133,   417, -1847,
     367, -1847, -1847, -1847, -1847,   417,   367, -1847, -1847, -1847,
   13951, -1847,   417, -1847,   312,   315,   310,   323,   314,   309,
     326,   307,   302,   329,   330,   331,   298,   332,   295,   339,
     287,   359,   353,   280,   279,   357,   364,   284,   360,   366,
     370,   371,   372,   374,   384,   394, -1847,   185,   181,   401,
    5412,   405, -1847,   665, -1847, -1847, 13951,   417,   417,   417,
     699,   672,   701,   703,   706, -1847,   707,    32,    32, -1847,
   -1847, -1847,  -102, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
     777, 18591,   747,   712, -1847, -1847, -1847, -1847,   713, 13951,
   12739,   635, -1847,   629,   591,   588,   589, -1847, 13951,   417,
   -1847, -1847, -1847,   722, -1847, -1847,   417,   726,   434, -1847,
   -1847, -1847,   727,   558,   557,   555, -1847,   417,   553, 13951,
   -1847,   417,   417,   417,   417, 13951, -1847, -1847, 13951, 13951,
   13951, 13951,   547, 13951,   417,   417, -1847, -1847,   417,   417,
   13951, 13951, -1847, 13951, 13951, 13951, 13951, 13951, 13951,   455,
     458, 13951, 13951,   457,   417, -1847,   437,   436, 13951, 13951,
     432,   430, 13951, 13951,   427,   710,   424, -1847, -1847,   417,
   13951, 13951, 13951, 13951, -1847,   417, 13951, 13951, 13951,   400,
   13951, -1847, 13951, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847,   417,   417,   417,   417,   717, -1847, -1847,   119, -1847,
      35,   417,   406, -1847,   714, -1847, -1847, -1847,   724, -1847,
   -1847,   750, -1847, -1847,    60, -1847, -1847,   753,   754,    60,
   -1847, -1847,   756, 18780, 13951, -1847, -1847, -1847, -1847,   728,
     675, 12739, -1847, -1847, -1847, -1847, 13951,   619,   417, -1847,
     767,   769,   931, -1847,   933, -1847, -1847, -1847, -1847, -1847,
     605,   602, 13951,   601, -1847,   596, -1847,   596,   592,   573,
     570,   569, -1847, -1847,   600, 13951, 13951, -1847, -1847,   546,
     549, 13951,   539,   537,   540,   536,   529,   534,   770,   771,
     530,   542, -1847,   779, 13951, -1847,   781,   507,   514,   508,
     785,   505,   510,   513, -1847, -1847,   493,   491,   492,   488,
     489,   482,   481,   479,   478, -1847,   473,   466, -1847,   808,
   -1847, -1847, -1847, -1847, 13951,   412, -1847, -1847,   840, -1847,
   -1847,   408, 13951, 13951, 13951, -1847,   416, -1847, -1847,    48,
      48, -1847, -1847, -1847,   916, -1847, -1847,   809, -1847,   764,
     846,   708, -1847,   417,   848,  4200,   830, -1847, -1847, -1847,
     851,   695, 13951,   417, 13951, -1847,   673, -1847, -1847,   417,
     417, -1847, -1847, -1847, -1847,   626, -1847, -1847,   624,   627,
   -1847, -1847,   607, -1847, -1847, -1847, -1847, -1847, -1847,   417,
     417,   828,   832,   583,   581,   582,   417,   842,   835, -1847,
     417,   847,   844, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847,   417,   780,   426, -1847,
   -1847,   428, -1847,   431,   419,   435, -1847, -1847,    25, -1847,
   -1847,  4806, -1847, -1847, -1847, -1847, -1847,   886, -1847,   855,
    5412,    71, -1847, 13345,    63,   871, -1847,   881,  1051, -1847,
   -1847, 13951,   367,   367, -1847,   669,   667, -1847, -1847, -1847,
   -1847, -1847,   417, -1847,   823, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847,   873, -1847,   417, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847,   369,   983,   417, -1847,   760,    37,   908, -1847,
     909,   895,   912, -1847, -1847, -1847,   755,   738, -1847,   417,
     417, -1847, -1847,   880, -1847,   884, -1847, 13951,   839,   888,
     889, -1847,   890,   891, -1847,   609,   476,   480, -1847,   922,
   -1847, 13951, -1847, -1847, -1847,   928, -1847,   930, -1847, -1847,
     769,   932, -1847,   417,   742,   749,   740, -1847, -1847,   656,
   -1847,   860, -1847, -1847, -1847, -1847, 13951, -1847,   910, -1847,
    -147, -1847,   941,   943, -1847, -1847, -1847, -1847, -1847, -1847,
     670,   674, -1847,   417,   643,   644,   638,   640,   632, -1847,
     956,   824,   957, -1847, -1847,  -100, 18969, 13951, 13951, -1847,
   -1847, 13951, 13951, 13951, 13951,   639, -1847, -1847, -1847, -1847,
   -1847,   798,   683,   684,   687,   678,   657,   659,   652,   653,
   -1847,  4806, -1847, -1847,   937,   938, -1847, 13951,   939,   940,
     945,   946,   369, -1847, -1847,   681, -1847, -1847, -1847, -1847,
     969, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,   682,
      48,   949, -1847, -1847, -1847,   905,   780,   702, -1847, -1847,
     959,   700, -1847
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
   -1847, -1847,   704,    11, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847,  -131, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847,   565, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847,  1007, -1847,   997, -1847, -1847, -1847, -1847,
    -294,  -361,  -641, -1847, -1847, -1847,   425,   443,   387,    70,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847,  -583, -1847, -1847, -1847, -1847,  -370, -1847, -1847,
   -1847,  -152, -1847, -1847, -1306, -1847, -1847, -1847, -1847, -1847,
   -1847,  1094, -1847, -1847,   -70,     9,  -881, -1847, -1847, -1847,
    -109, -1847, -1847, -1847, -1847, -1337,  -529, -1847, -1847,  -362,
    -911,    38, -1847, -1847,  1411,   858, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847,    -2, -1847, -1847,
   -1847, -1847,    78, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1110,   159, -1847,  -305,   836,  -325, -1847,   303,
   -1847, -1847,   843, -1847,  -207, -1847,   440,  -564, -1847, -1847,
   -1847,  -650, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847,   445,   -41,  1768,    12, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847,  -394, -1847, -1847, -1847,
    -715, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847,  -824, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847,  -739, -1847, -1847,  -559, -1847, -1847, -1403, -1847,   -53,
    -907, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,  -498,
   -1847, -1847, -1847,  -708, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847,   446, -1847, -1847,  -815, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,  -797,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847, -1847,
   -1847, -1847, -1847, -1236, -1016, -1547, -1846, -1847,   606, -1847
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -465
static const yytype_int16 yytable[] =
{
      98,   165,  1525,   994,  1526,  1141,  1021,   171,   642,   380,
     381,  1110,   834,   929,  1443,   314,   929,   248,   929,  2041,
     657,   736,   230,   659,   948,  1106,  1450,  1108,  1109,   161,
    1454,   646,  1260,   736,  1352,  1264,   736,   840,  1578,  1136,
     653,   570,  1695,   653,   155,  1796,    43,  1993,    44,  1536,
    1113,    63,   -83,    64,  1348,  1249,   314,  1629,  1542,  1261,
    1250,  1265,  1520,  1635,  1262,  2059,  1266,    71,   314,     3,
     147,   911,  1522,  1962,    74,   928,    75,   102,    76,   164,
      99,  1958,   151,    77,  1975,    78,    60,    79,    61,  1979,
    1980,    80,  1982,  1983,   322,   154,   -75,   -77,   306,   -75,
     -77,   228,   653,   653,   151,   899,   900,   901,   902,   643,
     330,   946,   644,   918,   947,   250,   330,   251,   331,  -239,
      43,  -239,    44,  1394,  1550,  1395,  1551,   233,   234,  -239,
     315,  -239,   317,   172,   216,   212,   221,   224,   159,  1579,
     220,    98,   156,   225,   226,   231,   161,   235,   236,   238,
    -252,  2042,   254,   292,   -37,  1277,   255,   303,   296,   307,
     311,   100,   314,   318,   373,   326,   327,   323,   329,   338,
     324,   341,   339,  -266,   342,    98,    98,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    98,    98,
    1349,  1137,    98,    98,  1696,  1048,    98,  1797,  1521,  1994,
      98,    99,  -250,  1231,  1232,  -266,  1350,  1036,  1523,  1963,
    1051,   340,  1037,  1442,  1350,   304,   343,  1959,   246,   246,
     344,    98,    98,   345,  1524,  1449,   348,    98,   346,  1453,
     351,   350,   347,  1960,    98,    99,    99,    99,    99,    99,
      99,    99,    99,    99,    99,    99,    99,    99,    99,    99,
      99,    99,    99,    99,    99,    99,    99,    99,    99,    99,
      99,    99,    99,    99,    99,    99,    99,    99,    99,    99,
     349,   352,    99,    99,   353,   929,    99,   936,  1327,    98,
      99,   355,   100,    98,   354,   101,    98,    98,  1407,   356,
    1409,    98,   357,  1324,    98,   642,   246,   358,  1272,   360,
     359,    99,    99,  1421,  1278,  1129,   361,    99,   364,   362,
     368,   369,   363,   365,    99,   371,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
     100,   366,    98,   100,   100,   367,   955,   100,   370,    99,
     387,   100,   388,    99,  1976,   378,    99,    99,   383,    91,
    1981,    99,   375,  1984,    99,   638,   330,   641,   648,   651,
     653,   660,   100,   100,   661,   662,   669,   683,   100,   717,
     685,   671,   672,   719,   718,   100,   688,   720,   728,   729,
     736,   730,   731,   709,   721,   748,   735,   788,   734,   789,
     791,   790,   792,   793,   794,  1530,   795,   797,  1532,   796,
     800,   798,   799,   801,   802,   804,   101,   803,   806,   805,
     807,   809,    99,   812,   811,   808,   810,   836,   813,   896,
     100,   907,   913,   815,   100,   916,   814,   100,   100,   921,
     920,   -63,   100,   927,   937,   100,   956,  1408,   828,  1410,
     101,   101,   101,   101,   101,   101,   101,   101,   101,   101,
     101,   101,   101,   101,   101,   101,   101,   101,   101,   101,
     101,   101,   101,   101,   101,   101,   101,   101,   101,   101,
     101,   101,   101,   101,   101,  1369,   950,   101,   101,  1969,
    1970,   101,   957,  1508,   997,   101,   952,   953,  1019,  1040,
      91,  1047,  1054,   100,  1102,  1103,  2091,  2092,  1107,  2094,
    2095,  2096,  2097,   569,  1123,  1125,   101,   101,  1023,  1134,
    1140,  1142,   101,  1145,  1146,  1151,  1156,  1157,  1158,   101,
    1162,  1951,  1163,  1166,    91,    91,    91,    91,    91,    91,
      91,    91,    91,    91,    91,    91,    91,    91,    91,    91,
      91,    91,    91,    91,    91,    91,    91,    91,    91,    91,
      91,    91,    91,    91,    91,    91,    91,    91,    91,  1169,
    1170,    91,    91,  1172,   101,    91,  1174,  1177,   101,    91,
    1179,   101,   101,  1181,  1182,  1180,   101,  1184,  1183,   101,
    1186,  1187,  1188,  1189,  1185,  1191,  1192,  1194,  1198,  1199,
      91,    91,    98,  1203,  1205,  1190,    91,  1208,  1209,  1211,
    1210,  1216,   908,    91,  1214,    98,  1218,  1220,  1225,  1226,
    1239,  1243,  1227,  1175,  1253,  1242,  1245,  1254,  1244,  1273,
    1274,  1251,  1276,  1281,  1255,  1279,  1275,  1282,  1246,  1285,
    1314,  1321,  1322,  1280,  1325,   413,  1341,   101,  1323,  1238,
    1342,  1256,  1343,  1345,  1353,  1283,  1257,  1240,    91,  1347,
    1351,  1241,    91,  1356,  1357,    91,    91,  1360,  1361,  1362,
      91,  1373,  1379,    91,     2,  1378,  1381,  1384,  1390,  1391,
    1388,  1393,    99,  1392,  1398,  1415,  1543,  1400,  1399,  1404,
    1411,  1419,  1420,  1418,  1422,    99,  1426,  1427,  1414,  1428,
    1440,  1441,  1445,  1447,  1456,  1506,  1258,  1510,  1512,  1514,
    1516,  1517,  1518,  1519,  1448,  1529,  1531,  1451,   246,   246,
    1533,  1534,   -65,  1549,  1452,  1563,  1566,  1455,   143,  1567,
    1570,    91,  1571,  1120,  1121,  1457,  1572,  1582,  1577,  1458,
    1587,  2030,  2031,  1581,  1583,  1594,  2034,  2035,  2036,  2037,
    1584,  1586,  1595,   390,   391,  1598,  1585,  1597,  1811,   393,
    1614,  1619,  1623,   100,  1612,   396,   397,  1465,  1618,   398,
    1676,   399,  1611,  1677,  1599,  1622,   100,   177,   178,   179,
     180,   181,   182,   183,   184,   185,   186,   187,   188,   189,
     190,   191,   192,   193,   194,   195,   196,   197,   198,   199,
     200,   201,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   211,  1989,   214,   215,  1122,   218,  1643,  1472,  1645,
     222,  1722,  1644,  1651,  1648,  1615,  1650,  1647,  1659,  1655,
    1662,  1657,  1663,  1682,  1646,  1688,  1689,  1690,  1691,  1704,
     243,   244,  1692,  1649,   249,  1693,  1666,  1706,  1707,  1708,
     256,  1711,  1712,  1652,  1799,  1714,  1713,  1653,  1719,  1715,
    1654,  1723,  1727,  1726,  1728,  1729,  1656,  1111,  1899,  1900,
    1758,  1759,  1732,  1743,  1762,  1765,   402,  1658,  1769,   403,
    1766,  1773,  1770,  1774,  1792,  1775,  1806,  1801,  1805,  1809,
    1810,  1812,  1818,    98,    98,  1785,  1817,   301,    98,  1822,
    1661,   305,  1825,  1660,  1828,   308,   309,   101,    98,    98,
     404,   313,   405,  1664,   316,  1831,  1833,  1834,  1835,    98,
     101,  1837,    98,  1665,  1667,  1838,  1842,  1843,  1847,  1841,
    1844,  1850,  1668,  1853,  1854,  1857,  1669,  1851,  1859,  1856,
    1855,  1670,  2090,  1858,  1860,  1861,  1671,  1864,  1869,  1866,
    1672,  1867,  1344,  1870,   423,  1862,  1868,  1871,  1875,  1876,
    1872,  1873,  1878,  1877,  1673,  1880,  1879,  1881,  1882,  1885,
    1883,  1884,   374,    99,    99,  1886,  1890,  1674,    99,  1902,
    1905,  1906,  1907,  1910,  1912,  1908,  1914,  1916,    99,    99,
    1679,    91,  1924,  1920,  1925,   634,  1930,  1926,  1927,    99,
    1681,  1932,    99,  1889,    91,  1931,  1933,  1800,  1937,  1934,
    1936,  1896,  1922,  1923,  1892,  1939,   441,  1940,   442,  1944,
     443,  1954,   444,  1956,   445,  1946,   446,  1964,   447,  1339,
     448,  1949,   449,  1965,   450,  1966,   451,  1971,  1978,  1972,
    1948,  1986,  1990,  1992,  1996,  1998,   647,  1999,  2000,  2002,
    1950,  2003,  2007,  2017,   100,   100,  2008,  2010,  2019,   100,
    2012,  2013,  2014,  2015,  2021,  2022,  2016,  2018,  2025,   100,
     100,  1565,  2027,  2028,  2029,  2032,  2033,  2044,  2039,  2045,
     100,   468,  2047,   100,  2051,  2052,  2048,  2053,  1918,  2054,
    2055,  2056,  2057,  2058,  2073,  2070,  2074,  2075,  2076,  2078,
    2077,  2079,  2080,  2081,  2093,  2098,  2101,  1338,   390,   391,
    2083,  2084,  2086,  2087,   393,    98,  2104,  1988,  2088,  2089,
     396,   397,  2107,  2109,   398,  2112,   399,  2111,  1354,   229,
     833,   240,  1700,   160,  2060,  1808,  1698,   640,  1340,   635,
    1548,  1002,  1405,   597,  1725,   632,  2024,  1371,  1840,  1425,
    1795,  1945,     0,   832,     0,     0,  1330,     0,     0,  2103,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   246,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    99,     0,     0,   101,   101,
       0,     0,     0,   101,  1365,     0,     0,  1943,     0,     0,
       0,     0,     0,   101,   101,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   101,     0,     0,   101,     0,     0,
       0,   402,     0,     0,   403,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1114,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   404,     0,   405,     0,     0,
    1366,     0,     0,     0,     0,     0,   100,     0,     0,     0,
       0,     0,    91,    91,     0,     0,     0,    91,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    91,    91,     0,
       0,     0,  1367,     0,     0,     0,     0,  1368,    91,   423,
       0,    91,     0,     0,     0,     0,     0,     0,   908,     0,
     908,  1135,     0,     0,   925,     0,   926,  1154,     0,     0,
       0,     0,     0,     0,     0,     0,  1537,     0,     0,     0,
       0,   940,   941,     0,     0,  1155,     0,     0,     0,   424,
       0,   951,     0,     0,   954,     0,   428,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1515,     0,
       0,   441,     0,   442,     0,   443,     0,   444,     0,   445,
       0,   446,     0,   447,     0,   448,     0,   449,     0,   450,
       0,   451,     0,   452,     0,   453,     0,     0,   454,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   593,     0,     0,     0,     0,     0,     0,     0,
     101,     0,     0,     0,     0,     0,  2108,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   468,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    91,     0,     0,     0,     0,    98,
       0,     0,     0,     0,   960,   961,     0,   963,     0,     0,
       0,     0,     0,   969,   970,   971,   972,   973,   974,   975,
     976,     0,   978,   979,   980,   981,     0,     0,     0,     0,
     986,   987,     0,     0,     0,     0,     0,     0,     0,     0,
     998,   999,  1000,     0,     0,  1003,     0,     0,     0,     0,
    1008,  1009,     0,     0,     0,     0,     0,  1014,  1015,  1016,
    1017,  1018,     0,     0,     0,     0,     0,     0,     0,  1027,
    1028,  1029,  1030,  1031,  1032,  1033,  1034,  1035,     0,    99,
    1041,  1042,  1043,  1044,  1045,  1046,     0,     0,  1147,     0,
    1055,     0,     0,  1058,  1059,  1060,  1061,     0,     0,  1064,
    1065,  1066,  1067,  1068,     0,  1070,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1099,     0,     0,     0,     0,  1104,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     100,    98,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1903,  1904,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    99,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   593,     0,     0,
    1161,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1897,     0,     0,     0,
     676,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1196,  1197,   101,     0,  1200,  1201,  1202,     0,
       0,     0,     0,  1206,  1207,     0,     0,     0,     0,  1212,
    1213,     0,   100,     0,     0,     0,     0,     0,  1221,  1222,
    1223,  1224,     0,     0,     0,     0,     0,     0,     0,     0,
    1233,  1234,  1235,  1236,  1237,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   908,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1284,    91,  1286,
    1287,  1288,  1289,  1290,  1291,  1292,  1293,  1294,  1295,  1296,
    1297,  1298,  1299,  1300,  1301,  1302,  1303,  1304,  1305,  1306,
    1307,  1308,  1309,  1310,  1311,  1312,  1313,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1326,     0,     0,     0,     0,  1331,  1332,  1333,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    2072,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   101,   835,     0,   837,
     838,   839,     0,   841,   842,   843,   844,   845,   846,   847,
       0,   848,     0,     0,   898,     0,     0,   904,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   905,     0,     0,
       0,     0,     0,    98,    98,     0,     0,   912,     0,     0,
     917,     0,     0,  1386,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1541,     0,     0,
       0,     0,     0,     0,     0,     0,   938,   939,     0,     0,
       0,   943,     0,     0,     0,     0,   949,     0,     0,     0,
      91,     0,     0,     0,     0,     0,   959,     0,     0,   962,
       0,   964,   965,   966,   967,   968,     0,     0,     0,     0,
       0,     0,     0,     0,   977,     0,     0,     0,     0,   982,
       0,     0,     0,    99,    99,     0,     0,     0,     0,  1459,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1502,  1503,  1504,  1505,     0,     0,  1509,
       0,  1511,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   100,   100,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  1703,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   737,   738,     0,     0,     0,     0,     0,     0,  1573,
    1574,  1575,     0,   749,   750,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   773,   774,     0,
       0,     0,     0,   779,   780,     0,     0,     0,  1609,  1610,
       0,     0,  1613,     0,     0,  1616,  1617,     0,     0,  1620,
    1621,     0,     0,  1624,  1625,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1139,     0,     0,     0,  1639,     0,
    1144,   817,   818,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   101,   101,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1167,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1683,   849,   850,   851,   852,   853,
     854,   855,   856,   857,   858,   859,   860,   861,   862,   863,
     864,   865,   866,   867,   868,   869,   870,   871,   872,   873,
     874,   875,   876,   877,   878,   879,   880,  1709,     0,     0,
       0,     0,     0,     0,     0,     0,  1717,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    91,     0,     0,     0,  1733,     0,     0,
       0,     0,     0,  1738,     0,     0,  1739,  1740,  1741,  1742,
       0,  1744,     0,     0,     0,     0,     0,     0,  1749,  1750,
       0,  1752,  1753,  1754,  1755,  1756,  1757,     0,     0,  1760,
    1761,     0,     0,     0,     0,     0,  1767,  1768,     0,     0,
    1771,  1772,   988,   989,   990,   991,   991,     0,  1777,  1778,
    1779,  1780,     0,  1001,  1782,  1783,  1784,     0,  1786,     0,
    1787,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1022,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1038,     0,
       0,  1334,  1335,     0,  1336,   881,  1337,  1049,  1052,     0,
       0,     0,   882,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1069,   883,     0,     0,     0,     0,
       0,     0,  1814,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1821,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1377,  1100,  1101,     0,     0,     0,
    1836,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1848,  1849,     0,     0,     0,     0,  1852,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1865,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1888,     0,     0,     0,     0,     0,     0,     0,
    1893,  1894,  1895,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1917,     0,  1919,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     884,     0,     0,   885,     0,     0,     0,     0,     0,  2046,
     886,     0,     0,     0,     0,     0,     0,   887,     0,     0,
     888,     0,     0,   889,     0,     0,   890,     0,     0,   891,
       0,     0,   892,  1527,  1528,   893,     0,     0,   894,     0,
       0,  1204,     0,     0,     0,     0,     0,     0,     0,  1538,
    1539,     0,  1215,     0,  1217,     0,     0,     0,     0,  1968,
       0,     0,     0,  1544,     0,  1545,  1546,  1547,     0,     0,
       0,     0,     0,     0,  1553,     0,  1554,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1252,     0,
       0,     0,     0,     0,     0,  1259,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  2009,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  2020,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1626,     0,
    1317,  1318,     0,     0,  2038,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  2062,  2063,     0,     0,  2066,
    2067,  2068,  2069,     0,     0,     0,     0,     0,     0,     0,
       0,  1680,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  2085,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1710,     0,     0,     0,     0,  1389,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1416,  1417,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1431,  1432,  1433,  1434,
    1435,  1436,  1437,  1438,  1439,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1460,  1461,  1462,  1463,  1464,     0,  1466,  1467,  1468,  1469,
       0,  1471,     0,  1473,     4,     5,     0,     7,     8,     9,
      10,     0,     0,     0,     0,     0,     0,     0,    11,     0,
       0,     0,    13,     0,    14,     0,    15,     0,     0,     0,
       0,     0,    16,     0,    17,     0,     0,     0,    19,     0,
      20,     0,    21,  1513,    22,     0,    23,     0,    24,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
       0,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,  1819,    36,     0,    37,     0,    38,     0,    39,
       0,    40,     0,    41,     0,    42,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    43,     0,    44,     0,     0,
       0,     0,     0,     0,     0,     0,  1557,     0,  1559,  1560,
    1561,  1562,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1576,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1591,     0,
       0,     0,     0,     0,  1596,     0,     0,     0,     0,     0,
       0,  1602,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    67,    68,    69,     0,     0,   158,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1627,     0,     0,     0,
       0,   245,     0,  1634,     0,     0,  1911,     0,     0,     0,
    1641,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    81,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1685,  1686,  1687,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1952,     0,     0,     0,     0,     0,     0,     0,
       0,  1957,     0,     0,  1961,     0,     0,  1718,     0,     0,
       0,     0,     0,     0,   991,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1731,     0,     0,     0,  1734,
    1735,  1736,  1737,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1745,  1746,     0,     0,  1747,  1748,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1763,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1776,     0,     0,
       0,     0,     0,  1781,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     4,     5,     0,     7,
       8,     9,    10,     0,     0,     0,     0,     0,     0,     0,
      11,     0,     0,     0,    13,     0,    14,     0,    15,  1788,
    1789,  1790,  1791,     0,    16,     0,    17,     0,     0,     0,
      19,     0,    20,     0,    21,     0,    22,     0,    23,     0,
      24,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,     0,    30,     0,    31,     0,    32,     0,    33,
       0,    34,  2082,    35,     0,    36,  1823,    37,     0,    38,
       0,    39,     0,    40,     0,    41,     0,    42,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    43,     0,    44,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    67,    68,    69,     0,     0,   158,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1909,     0,     0,     0,     0,     0,   390,   391,     0,
     392,   991,     0,   393,     0,   394,     0,   395,     0,   396,
     397,     0,     0,   398,     0,   399,     0,    81,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1928,  1929,     0,
       0,     0,     0,     0,  1935,     0,     0,     0,  1938,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1942,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   400,     0,     0,     0,     0,     0,  -239,     0,
    -239,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1977,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   401,
     402,     0,  1991,   403,     0,     0,     0,     0,  -239,     0,
    -239,     0,     0,     0,     0,     0,     0,  2005,  2006,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      66,     0,     0,     0,   404,     0,   405,   406,   407,   408,
       0,   409,     0,     0,     0,   410,   411,   412,   413,     0,
     414,  2026,   415,     0,   416,     0,     0,    77,     0,    78,
       0,    79,     0,   417,     0,    80,     0,   418,     0,   419,
       0,   420,     0,   421,     0,     0,   422,     0,   423,     0,
       0,  2050,  -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,
    -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,
    -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,  -443,
    -443,  -443,  -443,  -443,  -464,  -464,  -464,  -464,   424,     0,
       0,     0,   425,   426,   427,   428,     0,     0,   429,   430,
     431,   432,   433,   434,   435,   436,   437,   438,   439,   440,
     441,     0,   442,     0,   443,     0,   444,     0,   445,     0,
     446,     0,   447,     0,   448,     0,   449,     0,   450,     0,
     451,     0,   452,     0,   453,     0,     0,   454,     0,     0,
     455,     0,     0,   456,     0,     0,     0,     0,     0,   457,
       0,     0,   458,     0,     0,   459,     0,     0,   460,   461,
       0,   462,     0,   463,     0,   464,     0,   465,     0,     0,
       0,   466,     0,   467,     0,   468,   469,     0,     0,   470,
       0,     0,   471,     0,     0,   472,     0,     0,   473,     0,
       0,   474,     0,     0,     0,   475,   476,     0,     0,     0,
       0,     0,     0,     0,     0,   477,   478,     0,     0,   479,
       0,     0,  -443,   480,     0,   481,     0,   482,     0,  -443,
     483,     0,   484,     0,     0,   485,     0,     0,     0,   486,
       0,     0,  -443,   487,     0,     0,   488,     0,   489,     0,
       0,   490,     0,     0,     0,   491,     0,   492,     0,   493,
       0,   494,     0,   495,     0,   496,     0,   497,     0,     0,
     498,     0,     0,   499,     0,     0,   500,     0,     0,   501,
       0,     0,   502,     0,     0,   503,     0,     0,   504,     0,
       0,   505,     0,     0,   506,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   507,     0,     0,     0,     0,     0,
       0,     0,   508,   509,     0,   510,   511,     0,   512,   513,
       0,   514,     0,   515,     0,     0,     0,     0,     0,     0,
       0,   516,     0,     0,     0,     0,     0,     0,     0,   517,
       0,     0,     0,   518,     0,     0,   519,     0,   520,     0,
     521,     0,     0,   522,     0,     0,   523,     0,     0,   524,
       0,     0,   525,     0,     0,     0,   526,     0,   527,     0,
       0,   528,     0,     0,   529,     0,     0,   530,     0,     0,
     531,     0,     0,   532,     0,   533,     0,     0,   534,     0,
     535,     0,   536,     0,   537,     0,   538,     0,   539,     0,
     540,     0,   541,     0,   542,     0,   543,  -443,     0,   544,
    -443,     0,   545,     0,   546,     0,   547,  -443,     0,   548,
       0,   549,     0,   550,  -443,     0,   551,  -443,     0,   552,
    -443,     0,   553,  -443,     0,   554,  -443,     0,   555,  -443,
       0,   556,  -443,     0,   557,  -443,     0,   558,     0,   559,
       0,   560,     0,   561,     0,   562,     0,   563,     0,   564,
       0,     0,   565,   390,   391,   566,   392,     0,   567,   393,
    -271,   394,     0,   395,   568,   396,   397,     0,   569,   398,
     570,   399,   571,     0,   572,     0,   573,     0,   574,     0,
       0,   575,     0,     0,   576,     0,     0,   577,     0,     0,
     578,   579,   580,   581,   582,   583,     0,   584,   585,   586,
     587,   588,   589,   590,   591,   592,   593,  -445,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   400,     0,
       0,     0,     0,     0,  -239,     0,  -239,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   401,   402,     0,     0,   403,
       0,     0,     0,     0,  -239,     0,  -239,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    66,     0,     0,     0,
     404,     0,   405,   406,   407,   408,  -271,   409,     0,     0,
       0,   410,   411,   412,   413,     0,   414,     0,   415,     0,
     416,     0,  -271,    77,     0,    78,     0,    79,     0,   417,
       0,    80,     0,   418,     0,   419,     0,   420,     0,   421,
       0,     0,   422,     0,   423,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    -464,  -464,  -464,  -464,   424,     0,     0,     0,   425,   426,
     427,   428,     0,     0,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,     0,   442,     0,
     443,     0,   444,     0,   445,     0,   446,     0,   447,     0,
     448,     0,   449,     0,   450,     0,   451,     0,   452,     0,
     453,     0,     0,   454,     0,     0,   455,     0,     0,   456,
       0,     0,     0,     0,     0,   457,     0,     0,   458,     0,
       0,   459,     0,     0,   460,   461,     0,   462,     0,   463,
       0,   464,     0,   465,     0,     0,     0,   466,     0,   467,
       0,   468,   469,     0,     0,   470,     0,     0,   471,     0,
       0,   472,     0,     0,   473,     0,     0,   474,     0,     0,
       0,   475,   476,     0,     0,     0,     0,     0,     0,     0,
       0,   477,   478,     0,     0,   479,     0,     0,     0,   480,
       0,   481,     0,   482,     0,     0,   483,     0,   484,     0,
       0,   485,     0,     0,     0,   486,     0,     0,     0,   487,
       0,     0,   488,     0,   489,     0,     0,   490,     0,     0,
       0,   491,     0,   492,     0,   493,     0,   494,     0,   495,
       0,   496,     0,   497,     0,     0,   498,     0,     0,   499,
       0,     0,   500,     0,     0,   501,     0,     0,   502,     0,
       0,   503,     0,     0,   504,     0,     0,   505,     0,     0,
     506,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     507,     0,     0,     0,     0,     0,     0,     0,   508,   509,
       0,   510,   511,     0,   512,   513,     0,   514,     0,   515,
       0,     0,     0,     0,     0,     0,     0,   516,     0,     0,
       0,     0,     0,     0,     0,   517,     0,     0,     0,   518,
       0,     0,   519,     0,   520,     0,   521,     0,     0,   522,
       0,     0,   523,     0,     0,   524,     0,     0,   525,     0,
       0,     0,   526,     0,   527,     0,     0,   528,     0,     0,
     529,     0,     0,   530,     0,     0,   531,     0,     0,   532,
       0,   533,     0,     0,   534,     0,   535,     0,   536,     0,
     537,     0,   538,     0,   539,     0,   540,     0,   541,     0,
     542,     0,   543,     0,     0,   544,     0,     0,   545,     0,
     546,     0,   547,     0,     0,   548,     0,   549,     0,   550,
       0,     0,   551,     0,     0,   552,     0,     0,   553,     0,
       0,   554,     0,     0,   555,     0,     0,   556,     0,     0,
     557,     0,     0,   558,     0,   559,     0,   560,     0,   561,
       0,   562,     0,   563,     0,   564,     0,     0,   565,   390,
     391,   566,   392,     0,   567,   393,     0,   394,     0,   395,
     568,   396,   397,     0,   569,   398,   570,   399,   571,     0,
     572,     0,   573,     0,   574,     0,     0,   575,     0,     0,
     576,     0,     0,   577,     0,     0,   578,   579,   580,   581,
     582,   583,     0,   584,   585,   586,   587,   588,   589,   590,
     591,   592,   593,  -445,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   400,     0,     0,     0,     0,     0,
    -239,     0,  -239,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   401,   402,     0,     0,   403,     0,     0,     0,     0,
    -239,     0,  -239,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    66,     0,     0,     0,   404,     0,   405,   406,
     407,   408,  -271,   409,     0,     0,     0,   410,   411,   412,
     413,     0,   414,     0,   415,     0,   416,     0,  -271,    77,
       0,    78,     0,    79,     0,   417,     0,    80,     0,   418,
       0,   419,     0,   420,     0,   421,     0,     0,   422,     0,
     423,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  -464,  -464,  -464,  -464,
     424,     0,     0,     0,   425,   426,   427,   428,     0,     0,
     429,   430,   431,   432,   433,   434,   435,   436,   437,   438,
     439,   440,   441,     0,   442,     0,   443,     0,   444,     0,
     445,     0,   446,     0,   447,     0,   448,     0,   449,     0,
     450,     0,   451,     0,   452,     0,   453,     0,     0,   454,
       0,     0,   455,     0,     0,   456,     0,     0,     0,     0,
       0,   457,     0,     0,   458,     0,     0,   459,     0,     0,
     460,   461,     0,   462,     0,   463,     0,   464,     0,   465,
       0,     0,     0,   466,     0,   467,     0,   468,   469,     0,
       0,   470,     0,     0,   471,     0,     0,   472,     0,     0,
     473,     0,     0,   474,     0,     0,     0,   475,   476,     0,
       0,     0,     0,     0,     0,     0,     0,   477,   478,     0,
       0,   479,     0,     0,     0,   480,     0,   481,     0,   482,
       0,     0,   483,     0,   484,     0,     0,   485,     0,     0,
       0,   486,     0,     0,     0,   487,     0,     0,   488,     0,
     489,     0,     0,   490,     0,     0,     0,   491,     0,   492,
       0,   493,     0,   494,     0,   495,     0,   496,     0,   497,
       0,     0,   498,     0,     0,   499,     0,     0,   500,     0,
       0,   501,     0,     0,   502,     0,     0,   503,     0,     0,
     504,     0,     0,   505,     0,     0,   506,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   507,     0,     0,     0,
       0,     0,     0,     0,   508,   509,     0,   510,   511,     0,
     512,   513,     0,   514,     0,   515,     0,     0,     0,     0,
       0,     0,     0,   516,     0,     0,     0,     0,     0,     0,
       0,   517,     0,     0,     0,   518,     0,     0,   519,     0,
     520,     0,   521,     0,     0,   522,     0,     0,   523,     0,
       0,   524,     0,     0,   525,     0,     0,     0,   526,     0,
     527,     0,     0,   528,     0,     0,   529,     0,     0,   530,
       0,     0,   531,     0,     0,   532,     0,   533,     0,     0,
     534,     0,   535,     0,   536,     0,   537,     0,   538,     0,
     539,     0,   540,     0,   541,     0,   542,     0,   543,     0,
       0,   544,     0,     0,   545,     0,   546,     0,   547,     0,
       0,   548,     0,   549,     0,   550,     0,     0,   551,     0,
       0,   552,     0,     0,   553,     0,     0,   554,     0,     0,
     555,     0,     0,   556,     0,     0,   557,     0,     0,   558,
       0,   559,     0,   560,     0,   561,     0,   562,     0,   563,
       0,   564,     0,     0,   565,   390,   391,   566,   392,     0,
     567,   393,  -271,   394,     0,   395,   568,   396,   397,     0,
     569,   398,   570,   399,   571,     0,   572,     0,   573,     0,
     574,     0,     0,   575,     0,     0,   576,     0,     0,   577,
       0,     0,   578,   579,   580,   581,   582,   583,     0,   584,
     585,   586,   587,   588,   589,   590,   591,   592,   593,  -445,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     400,     0,     0,     0,     0,     0,  -239,     0,  -239,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   401,   402,     0,
       0,   403,     0,     0,     0,     0,  -239,     0,  -239,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    66,     0,
       0,     0,   404,     0,   405,   406,   407,   408,     0,   409,
       0,     0,     0,   410,   411,   412,   413,     0,   414,     0,
     415,     0,   416,     0,  -271,    77,     0,    78,     0,    79,
       0,   417,     0,    80,     0,   418,     0,   419,     0,   420,
       0,   421,     0,     0,   422,     0,   423,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  -464,  -464,  -464,  -464,   424,     0,     0,     0,
     425,   426,   427,   428,     0,     0,   429,   430,   431,   432,
     433,   434,   435,   436,   437,   438,   439,   440,   441,     0,
     442,     0,   443,     0,   444,     0,   445,     0,   446,     0,
     447,     0,   448,     0,   449,     0,   450,     0,   451,     0,
     452,     0,   453,     0,     0,   454,     0,     0,   455,     0,
       0,   456,     0,     0,     0,     0,     0,   457,     0,     0,
     458,     0,     0,   459,     0,     0,   460,   461,     0,   462,
       0,   463,     0,   464,     0,   465,     0,     0,     0,   466,
       0,   467,     0,   468,   469,     0,     0,   470,     0,     0,
     471,     0,     0,   472,     0,     0,   473,     0,     0,   474,
       0,     0,     0,   475,   476,     0,     0,     0,     0,     0,
       0,     0,     0,   477,   478,     0,     0,   479,     0,     0,
       0,   480,     0,   481,     0,   482,     0,     0,   483,     0,
     484,     0,     0,   485,     0,     0,     0,   486,     0,     0,
       0,   487,     0,     0,   488,     0,   489,     0,     0,   490,
       0,     0,     0,   491,     0,   492,     0,   493,     0,   494,
       0,   495,     0,   496,     0,   497,     0,     0,   498,     0,
       0,   499,     0,     0,   500,     0,     0,   501,     0,     0,
     502,     0,     0,   503,     0,     0,   504,     0,     0,   505,
       0,     0,   506,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   507,     0,     0,     0,     0,     0,     0,     0,
     508,   509,     0,   510,   511,     0,   512,   513,     0,   514,
       0,   515,     0,     0,     0,     0,     0,     0,     0,   516,
       0,     0,     0,     0,     0,     0,     0,   517,     0,     0,
       0,   518,     0,     0,   519,     0,   520,     0,   521,     0,
       0,   522,     0,     0,   523,     0,     0,   524,     0,     0,
     525,     0,     0,     0,   526,     0,   527,     0,     0,   528,
       0,     0,   529,     0,     0,   530,     0,     0,   531,     0,
       0,   532,     0,   533,     0,     0,   534,     0,   535,     0,
     536,     0,   537,     0,   538,     0,   539,     0,   540,     0,
     541,     0,   542,     0,   543,     0,     0,   544,     0,     0,
     545,     0,   546,     0,   547,     0,     0,   548,     0,   549,
       0,   550,     0,     0,   551,     0,     0,   552,     0,     0,
     553,     0,     0,   554,     0,     0,   555,     0,     0,   556,
       0,     0,   557,     0,     0,   558,     0,   559,     0,   560,
       0,   561,     0,   562,     0,   563,     0,   564,     0,     0,
     565,   390,   391,   566,   392,     0,   567,   393,     0,   394,
       0,   395,   568,   396,   397,     0,   569,   398,   570,   399,
     571,     0,   572,     0,   573,     0,   574,     0,     0,   575,
       0,     0,   576,     0,     0,   577,     0,     0,   578,   579,
     580,   581,   582,   583,     0,   584,   585,   586,   587,   588,
     589,   590,   591,   592,   593,  -445,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   400,     0,     0,     0,
       0,     0,  -239,     0,  -239,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   401,   402,     0,     0,   403,     0,     0,
       0,     0,  -239,     0,  -239,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    66,     0,     0,     0,   404,     0,
     405,   406,   407,   408,     0,   409,  -271,     0,     0,   410,
     411,   412,   413,     0,   414,     0,   415,     0,   416,     0,
       0,    77,     0,    78,     0,    79,     0,   417,     0,    80,
       0,   418,     0,   419,     0,   420,     0,   421,     0,     0,
     422,     0,   423,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  -464,  -464,
    -464,  -464,   424,     0,     0,     0,   425,   426,   427,   428,
       0,     0,   429,   430,   431,   432,   433,   434,   435,   436,
     437,   438,   439,   440,   441,     0,   442,     0,   443,     0,
     444,     0,   445,     0,   446,     0,   447,     0,   448,     0,
     449,     0,   450,     0,   451,     0,   452,     0,   453,     0,
       0,   454,     0,     0,   455,     0,     0,   456,     0,     0,
       0,     0,     0,   457,     0,     0,   458,     0,     0,   459,
       0,     0,   460,   461,     0,   462,     0,   463,     0,   464,
       0,   465,     0,     0,     0,   466,     0,   467,     0,   468,
     469,     0,     0,   470,     0,     0,   471,     0,     0,   472,
       0,     0,   473,     0,     0,   474,     0,     0,     0,   475,
     476,     0,     0,     0,     0,     0,     0,     0,     0,   477,
     478,     0,     0,   479,     0,     0,     0,   480,     0,   481,
       0,   482,     0,     0,   483,     0,   484,     0,     0,   485,
       0,     0,     0,   486,     0,     0,     0,   487,     0,     0,
     488,     0,   489,     0,     0,   490,     0,     0,     0,   491,
       0,   492,     0,   493,     0,   494,     0,   495,     0,   496,
       0,   497,     0,     0,   498,     0,     0,   499,     0,     0,
     500,     0,     0,   501,     0,     0,   502,     0,     0,   503,
       0,     0,   504,     0,     0,   505,     0,     0,   506,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   507,     0,
       0,     0,     0,     0,     0,     0,   508,   509,     0,   510,
     511,     0,   512,   513,     0,   514,     0,   515,     0,     0,
       0,     0,     0,     0,     0,   516,     0,     0,     0,     0,
       0,     0,     0,   517,     0,     0,     0,   518,     0,     0,
     519,     0,   520,     0,   521,     0,     0,   522,     0,     0,
     523,     0,     0,   524,     0,     0,   525,     0,     0,     0,
     526,     0,   527,     0,     0,   528,     0,     0,   529,     0,
       0,   530,     0,     0,   531,     0,     0,   532,     0,   533,
       0,     0,   534,     0,   535,     0,   536,     0,   537,     0,
     538,     0,   539,     0,   540,     0,   541,     0,   542,     0,
     543,     0,     0,   544,     0,     0,   545,     0,   546,     0,
     547,     0,     0,   548,     0,   549,     0,   550,     0,     0,
     551,     0,     0,   552,     0,     0,   553,     0,     0,   554,
       0,     0,   555,     0,     0,   556,     0,     0,   557,     0,
       0,   558,     0,   559,     0,   560,     0,   561,     0,   562,
       0,   563,     0,   564,     0,     0,   565,   390,   391,   566,
     392,     0,   567,   393,     0,   394,  -271,   395,   568,   396,
     397,     0,   569,   398,   570,   399,   571,     0,   572,     0,
     573,     0,   574,     0,     0,   575,     0,     0,   576,     0,
       0,   577,     0,     0,   578,   579,   580,   581,   582,   583,
       0,   584,   585,   586,   587,   588,   589,   590,   591,   592,
     593,  -445,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   400,     0,     0,     0,     0,     0,  -239,     0,
    -239,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   401,
     402,     0,     0,   403,     0,     0,     0,     0,  -239,     0,
    -239,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      66,     0,     0,     0,   404,     0,   405,   406,   407,   408,
       0,   409,     0,     0,     0,   410,   411,   412,   413,     0,
     414,     0,   415,     0,   416,     0,     0,    77,     0,    78,
       0,    79,     0,   417,     0,    80,     0,   418,     0,   419,
       0,   420,     0,   421,     0,     0,   422,     0,   423,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  -464,  -464,  -464,  -464,   424,     0,
       0,     0,   425,   426,   427,   428,     0,     0,   429,   430,
     431,   432,   433,   434,   435,   436,   437,   438,   439,   440,
     441,     0,   442,     0,   443,     0,   444,     0,   445,     0,
     446,     0,   447,     0,   448,     0,   449,     0,   450,     0,
     451,     0,   452,     0,   453,     0,     0,   454,     0,     0,
     455,     0,     0,   456,     0,     0,     0,     0,     0,   457,
       0,     0,   458,     0,     0,   459,     0,     0,   460,   461,
       0,   462,     0,   463,     0,   464,     0,   465,     0,     0,
       0,   466,     0,   467,     0,   468,   469,     0,     0,   470,
       0,     0,   471,     0,     0,   472,     0,     0,   473,     0,
       0,   474,     0,     0,     0,   475,   476,     0,     0,     0,
       0,     0,     0,     0,     0,   477,   478,     0,     0,   479,
       0,     0,     0,   480,     0,   481,     0,   482,     0,     0,
     483,     0,   484,     0,     0,   485,     0,     0,     0,   486,
       0,     0,     0,   487,     0,     0,   488,     0,   489,     0,
       0,   490,     0,     0,     0,   491,     0,   492,     0,   493,
       0,   494,     0,   495,     0,   496,     0,   497,     0,     0,
     498,     0,     0,   499,     0,     0,   500,     0,     0,   501,
       0,     0,   502,     0,     0,   503,     0,     0,   504,     0,
       0,   505,     0,     0,   506,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   507,     0,     0,     0,     0,     0,
       0,     0,   508,   509,     0,   510,   511,     0,   512,   513,
       0,   514,     0,   515,     0,     0,     0,     0,     0,     0,
       0,   516,     0,     0,     0,     0,     0,     0,     0,   517,
       0,     0,     0,   518,     0,     0,   519,     0,   520,     0,
     521,     0,     0,   522,     0,     0,   523,     0,     0,   524,
       0,     0,   525,     0,     0,     0,   526,     0,   527,     0,
       0,   528,     0,     0,   529,     0,     0,   530,     0,     0,
     531,     0,     0,   532,     0,   533,     0,     0,   534,     0,
     535,     0,   536,     0,   537,     0,   538,     0,   539,     0,
     540,     0,   541,     0,   542,     0,   543,     0,     0,   544,
       0,     0,   545,     0,   546,     0,   547,     0,     0,   548,
       0,   549,     0,   550,     0,     0,   551,     0,     0,   552,
       0,     0,   553,     0,     0,   554,     0,     0,   555,     0,
       0,   556,     0,     0,   557,     0,     0,   558,     0,   559,
       0,   560,     0,   561,     0,   562,     0,   563,     0,   564,
       0,     0,   565,     0,     0,   566,     0,     0,   567,     0,
       0,     0,     0,     0,   568,     0,     0,     0,   569,     0,
     570,     0,   571,     0,   572,     0,   573,     0,   574,     0,
       0,   575,     0,     0,   576,     0,     0,   577,     0,     0,
     578,   579,   580,   581,   582,   583,     0,   584,   585,   586,
     587,   588,   589,   590,   591,   592,   593,  -445,   390,   391,
       0,   392,     0,     0,   393,     0,   394,     0,   395,  -271,
     396,   397,     0,     0,   398,     0,   399,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   400,     0,     0,     0,     0,     0,  -239,
       0,  -239,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     401,   402,     0,     0,   403,     0,     0,     0,     0,  -239,
       0,  -239,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    66,     0,     0,     0,   404,     0,   405,   406,   407,
     408,     0,   409,     0,     0,     0,   410,   411,   412,   413,
       0,   414,     0,   415,     0,   416,     0,     0,    77,     0,
      78,     0,    79,     0,   417,     0,    80,     0,   418,     0,
     419,     0,   420,     0,   421,     0,     0,   422,     0,   423,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -464,  -464,  -464,  -464,   424,
       0,     0,     0,   425,   426,   427,   428,     0,     0,   429,
     430,   431,   432,   433,   434,   435,   436,   437,   438,   439,
     440,   441,     0,   442,     0,   443,     0,   444,     0,   445,
       0,   446,     0,   447,     0,   448,     0,   449,     0,   450,
       0,   451,     0,   452,     0,   453,     0,     0,   454,     0,
       0,   455,     0,     0,   456,     0,     0,     0,     0,     0,
     457,     0,     0,   458,     0,     0,   459,     0,     0,   460,
     461,     0,   462,     0,   463,     0,   464,     0,   465,     0,
       0,     0,   466,     0,   467,     0,   468,   469,     0,     0,
     470,     0,     0,   471,     0,     0,   472,     0,     0,   473,
       0,     0,   474,     0,     0,     0,   475,   476,     0,     0,
       0,     0,     0,     0,     0,     0,   477,   478,     0,     0,
     479,     0,     0,     0,   480,     0,   481,     0,   482,     0,
       0,   483,     0,   484,     0,     0,   485,     0,     0,     0,
     486,     0,     0,     0,   487,     0,     0,   488,     0,   489,
       0,     0,   490,     0,     0,     0,   491,     0,   492,     0,
     493,     0,   494,     0,   495,     0,   496,     0,   497,     0,
       0,   498,     0,     0,   499,     0,     0,   500,     0,     0,
     501,     0,     0,   502,     0,     0,   503,     0,     0,   504,
       0,     0,   505,     0,     0,   506,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   507,     0,     0,     0,     0,
       0,     0,     0,   508,   509,     0,   510,   511,     0,   512,
     513,     0,   514,     0,   515,     0,     0,     0,     0,     0,
       0,     0,   516,     0,     0,     0,     0,     0,     0,     0,
     517,     0,     0,     0,   518,     0,     0,   519,     0,   520,
       0,   521,     0,     0,   522,     0,     0,   523,     0,     0,
     524,     0,     0,   525,     0,     0,     0,   526,     0,   527,
       0,     0,   528,     0,     0,   529,     0,     0,   530,     0,
       0,   531,     0,     0,   532,     0,   533,     0,     0,   534,
       0,   535,     0,   536,     0,   537,     0,   538,     0,   539,
       0,   540,     0,   541,     0,   542,     0,   543,     0,     0,
     544,     0,     0,   545,     0,   546,     0,   547,     0,     0,
     548,     0,   549,     0,   550,     0,     0,   551,     0,     0,
     552,     0,     0,   553,     0,     0,   554,     0,     0,   555,
       0,     0,   556,     0,     0,   557,     0,     0,   558,     0,
     559,     0,   560,     0,   561,     0,   562,     0,   563,     0,
     564,     0,     0,   565,   390,   391,   566,   392,     0,   567,
     393,     0,   394,     0,   395,   568,   396,   397,     0,   569,
     398,   570,   399,   571,     0,   572,     0,   573,     0,   574,
       0,     0,   575,     0,     0,   576,     0,     0,   577,     0,
       0,   578,   579,   580,   581,   582,   583,     0,   584,   585,
     586,   587,   588,   589,   590,   591,   592,   593,  -445,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   400,
       0,     0,     0,     0,     0,  -239,     0,  -239,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   401,   402,     0,     0,
     403,     0,     0,     0,     0,  -239,     0,  -239,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,   404,     0,   405,   406,   407,   408,  -271,   409,     0,
       0,     0,   410,   411,   412,   413,     0,   414,     0,   415,
       0,   416,     0,     0,    77,     0,    78,     0,    79,     0,
     417,     0,    80,     0,   418,     0,   419,     0,   420,     0,
     421,     0,     0,   422,     0,   423,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  -464,  -464,  -464,  -464,   424,     0,     0,     0,   425,
     426,   427,   428,     0,     0,   429,   430,   431,   432,   433,
     434,   435,   436,   437,   438,   439,   440,   441,     0,   442,
       0,   443,     0,   444,     0,   445,     0,   446,     0,   447,
       0,   448,     0,   449,     0,   450,     0,   451,     0,   452,
       0,   453,     0,     0,   454,     0,     0,   455,     0,     0,
     456,     0,     0,     0,     0,     0,   457,     0,     0,   458,
       0,     0,   459,     0,     0,   460,   461,     0,   462,     0,
     463,     0,   464,     0,   465,     0,     0,     0,   466,     0,
     467,     0,   468,   469,     0,     0,   470,     0,     0,   471,
       0,     0,   472,     0,     0,   473,     0,     0,   474,     0,
       0,     0,   475,   476,     0,     0,     0,     0,     0,     0,
       0,     0,   477,   478,     0,     0,   479,     0,     0,     0,
     480,     0,   481,     0,   482,     0,     0,   483,     0,   484,
       0,     0,   485,     0,     0,     0,   486,     0,     0,     0,
     487,     0,     0,   488,     0,   489,     0,     0,   490,     0,
       0,     0,   491,     0,   492,     0,   493,     0,   494,     0,
     495,     0,   496,     0,   497,     0,     0,   498,     0,     0,
     499,     0,     0,   500,     0,     0,   501,     0,     0,   502,
       0,     0,   503,     0,     0,   504,     0,     0,   505,     0,
       0,   506,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   507,     0,     0,     0,     0,     0,     0,     0,   508,
     509,     0,   510,   511,     0,   512,   513,     0,   514,     0,
     515,     0,     0,     0,     0,     0,     0,     0,   516,     0,
       0,     0,     0,     0,     0,     0,   517,     0,     0,     0,
     518,     0,     0,   519,     0,   520,     0,   521,     0,     0,
     522,     0,     0,   523,     0,     0,   524,     0,     0,   525,
       0,     0,     0,   526,     0,   527,     0,     0,   528,     0,
       0,   529,     0,     0,   530,     0,     0,   531,     0,     0,
     532,     0,   533,     0,     0,   534,     0,   535,     0,   536,
       0,   537,     0,   538,     0,   539,     0,   540,     0,   541,
       0,   542,     0,   543,     0,     0,   544,     0,     0,   545,
       0,   546,     0,   547,     0,     0,   548,     0,   549,     0,
     550,     0,     0,   551,     0,     0,   552,     0,     0,   553,
       0,     0,   554,     0,     0,   555,     0,     0,   556,     0,
       0,   557,     0,     0,   558,     0,   559,     0,   560,     0,
     561,     0,   562,     0,   563,     0,   564,     0,     0,   565,
     390,   391,   566,   392,     0,   567,   393,     0,   394,     0,
     395,   568,   396,   397,     0,   569,   398,   570,   399,   571,
       0,   572,     0,   573,     0,   574,     0,     0,   575,     0,
       0,   576,     0,     0,   577,     0,     0,   578,   579,   580,
     581,   582,   583,     0,   584,   585,   586,   587,   588,   589,
     590,   591,   592,   593,  -445,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   400,     0,     0,     0,     0,
       0,  -239,     0,  -239,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   401,   402,     0,     0,   403,     0,     0,     0,
       0,  -239,     0,  -239,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    66,     0,     0,     0,   404,     0,   405,
     406,   407,   408,     0,   409,     0,     0,     0,   410,   411,
     412,   413,     0,   414,     0,   415,     0,   416,     0,     0,
      77,     0,    78,     0,    79,     0,   417,     0,    80,     0,
     418,     0,   419,     0,   420,     0,   421,     0,     0,   422,
       0,   423,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  -464,  -464,  -464,
    -464,   424,  -271,     0,     0,   425,   426,   427,   428,     0,
       0,   429,   430,   431,   432,   433,   434,   435,   436,   437,
     438,   439,   440,   441,     0,   442,     0,   443,     0,   444,
       0,   445,     0,   446,     0,   447,     0,   448,     0,   449,
       0,   450,     0,   451,     0,   452,     0,   453,     0,     0,
     454,     0,     0,   455,     0,     0,   456,     0,     0,     0,
       0,     0,   457,     0,     0,   458,     0,     0,   459,     0,
       0,   460,   461,     0,   462,     0,   463,     0,   464,     0,
     465,     0,     0,     0,   466,     0,   467,     0,   468,   469,
       0,     0,   470,     0,     0,   471,     0,     0,   472,     0,
       0,   473,     0,     0,   474,     0,     0,     0,   475,   476,
       0,     0,     0,     0,     0,     0,     0,     0,   477,   478,
       0,     0,   479,     0,     0,     0,   480,     0,   481,     0,
     482,     0,     0,   483,     0,   484,     0,     0,   485,     0,
       0,     0,   486,     0,     0,     0,   487,     0,     0,   488,
       0,   489,     0,     0,   490,     0,     0,     0,   491,     0,
     492,     0,   493,     0,   494,     0,   495,     0,   496,     0,
     497,     0,     0,   498,     0,     0,   499,     0,     0,   500,
       0,     0,   501,     0,     0,   502,     0,     0,   503,     0,
       0,   504,     0,     0,   505,     0,     0,   506,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   507,     0,     0,
       0,     0,     0,     0,     0,   508,   509,     0,   510,   511,
       0,   512,   513,     0,   514,     0,   515,     0,     0,     0,
       0,     0,     0,     0,   516,     0,     0,     0,     0,     0,
       0,     0,   517,     0,     0,     0,   518,     0,     0,   519,
       0,   520,     0,   521,     0,     0,   522,     0,     0,   523,
       0,     0,   524,     0,     0,   525,     0,     0,     0,   526,
       0,   527,     0,     0,   528,     0,     0,   529,     0,     0,
     530,     0,     0,   531,     0,     0,   532,     0,   533,     0,
       0,   534,     0,   535,     0,   536,     0,   537,     0,   538,
       0,   539,     0,   540,     0,   541,     0,   542,     0,   543,
       0,     0,   544,     0,     0,   545,     0,   546,     0,   547,
       0,     0,   548,     0,   549,     0,   550,     0,     0,   551,
       0,     0,   552,     0,     0,   553,     0,     0,   554,     0,
       0,   555,     0,     0,   556,     0,     0,   557,     0,     0,
     558,     0,   559,     0,   560,     0,   561,     0,   562,     0,
     563,     0,   564,     0,     0,   565,   390,   391,   566,   392,
       0,   567,   393,     0,   394,     0,   395,   568,   396,   397,
       0,   569,   398,   570,   399,   571,     0,   572,     0,   573,
       0,   574,     0,     0,   575,     0,     0,   576,     0,     0,
     577,     0,     0,   578,   579,   580,   581,   582,   583,     0,
     584,   585,   586,   587,   588,   589,   590,   591,   592,   593,
    -445,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   400,     0,     0,     0,     0,     0,  -239,     0,  -239,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   401,   402,
       0,     0,   403,     0,     0,     0,     0,  -239,     0,  -239,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    66,
       0,     0,     0,   404,     0,   405,   406,   407,   408,     0,
     409,     0,     0,     0,   410,   411,   412,   413,     0,   414,
       0,   415,     0,   416,     0,     0,    77,     0,    78,     0,
      79,     0,   417,     0,    80,     0,   418,     0,   419,     0,
     420,     0,   421,     0,     0,   422,     0,   423,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  -464,  -464,  -464,  -464,   424,     0,     0,
       0,   425,   426,   427,   428,  -271,     0,   429,   430,   431,
     432,   433,   434,   435,   436,   437,   438,   439,   440,   441,
       0,   442,     0,   443,     0,   444,     0,   445,     0,   446,
       0,   447,     0,   448,     0,   449,     0,   450,     0,   451,
       0,   452,     0,   453,     0,     0,   454,     0,     0,   455,
       0,     0,   456,     0,     0,     0,     0,     0,   457,     0,
       0,   458,     0,     0,   459,     0,     0,   460,   461,     0,
     462,     0,   463,     0,   464,     0,   465,     0,     0,     0,
     466,     0,   467,     0,   468,   469,     0,     0,   470,     0,
       0,   471,     0,     0,   472,     0,     0,   473,     0,     0,
     474,     0,     0,     0,   475,   476,     0,     0,     0,     0,
       0,     0,     0,     0,   477,   478,     0,     0,   479,     0,
       0,     0,   480,     0,   481,     0,   482,     0,     0,   483,
       0,   484,     0,     0,   485,     0,     0,     0,   486,     0,
       0,     0,   487,     0,     0,   488,     0,   489,     0,     0,
     490,     0,     0,     0,   491,     0,   492,     0,   493,     0,
     494,     0,   495,     0,   496,     0,   497,     0,     0,   498,
       0,     0,   499,     0,     0,   500,     0,     0,   501,     0,
       0,   502,     0,     0,   503,     0,     0,   504,     0,     0,
     505,     0,     0,   506,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   507,     0,     0,     0,     0,     0,     0,
       0,   508,   509,     0,   510,   511,     0,   512,   513,     0,
     514,     0,   515,     0,     0,     0,     0,     0,     0,     0,
     516,     0,     0,     0,     0,     0,     0,     0,   517,     0,
       0,     0,   518,     0,     0,   519,     0,   520,     0,   521,
       0,     0,   522,     0,     0,   523,     0,     0,   524,     0,
       0,   525,     0,     0,     0,   526,     0,   527,     0,     0,
     528,     0,     0,   529,     0,     0,   530,     0,     0,   531,
       0,     0,   532,     0,   533,     0,     0,   534,     0,   535,
       0,   536,     0,   537,     0,   538,     0,   539,     0,   540,
       0,   541,     0,   542,     0,   543,     0,     0,   544,     0,
       0,   545,     0,   546,     0,   547,     0,     0,   548,     0,
     549,     0,   550,     0,     0,   551,     0,     0,   552,     0,
       0,   553,     0,     0,   554,     0,     0,   555,     0,     0,
     556,     0,     0,   557,     0,     0,   558,     0,   559,     0,
     560,     0,   561,     0,   562,     0,   563,     0,   564,     0,
       0,   565,   390,   391,   566,   392,     0,   567,   393,     0,
     394,     0,   395,   568,   396,   397,     0,   569,   398,   570,
     399,   571,     0,   572,     0,   573,     0,   574,     0,     0,
     575,     0,     0,   576,     0,     0,   577,     0,     0,   578,
     579,   580,   581,   582,   583,     0,   584,   585,   586,   587,
     588,   589,   590,   591,   592,   593,  -445,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   400,     0,     0,
       0,     0,     0,  -239,     0,  -239,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   401,   402,     0,     0,   403,     0,
       0,     0,     0,  -239,     0,  -239,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    66,     0,     0,     0,   404,
       0,   405,   406,   407,   408,     0,   409,     0,     0,     0,
     410,   411,   412,   413,     0,   414,     0,   415,     0,   416,
       0,     0,    77,     0,    78,     0,    79,     0,   417,     0,
      80,     0,   418,     0,   419,     0,   420,     0,   421,     0,
       0,   422,     0,   423,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  -464,
    -464,  -464,  -464,   424,     0,     0,     0,   425,   426,   427,
     428,     0,     0,   429,   430,   431,   432,   433,   434,   435,
     436,   437,   438,   439,   440,   441,     0,   442,     0,   443,
       0,   444,     0,   445,     0,   446,     0,   447,     0,   448,
       0,   449,  -271,   450,     0,   451,     0,   452,     0,   453,
       0,     0,   454,     0,     0,   455,     0,     0,   456,     0,
       0,     0,     0,     0,   457,     0,     0,   458,     0,     0,
     459,     0,     0,   460,   461,     0,   462,     0,   463,     0,
     464,     0,   465,     0,     0,     0,   466,     0,   467,     0,
     468,   469,     0,     0,   470,     0,     0,   471,     0,     0,
     472,     0,     0,   473,     0,     0,   474,     0,     0,     0,
     475,   476,     0,     0,     0,     0,     0,     0,     0,     0,
     477,   478,     0,     0,   479,     0,     0,     0,   480,     0,
     481,     0,   482,     0,     0,   483,     0,   484,     0,     0,
     485,     0,     0,     0,   486,     0,     0,     0,   487,     0,
       0,   488,     0,   489,     0,     0,   490,     0,     0,     0,
     491,     0,   492,     0,   493,     0,   494,     0,   495,     0,
     496,     0,   497,     0,     0,   498,     0,     0,   499,     0,
       0,   500,     0,     0,   501,     0,     0,   502,     0,     0,
     503,     0,     0,   504,     0,     0,   505,     0,     0,   506,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   507,
       0,     0,     0,     0,     0,     0,     0,   508,   509,     0,
     510,   511,     0,   512,   513,     0,   514,     0,   515,     0,
       0,     0,     0,     0,     0,     0,   516,     0,     0,     0,
       0,     0,     0,     0,   517,     0,     0,     0,   518,     0,
       0,   519,     0,   520,     0,   521,     0,     0,   522,     0,
       0,   523,     0,     0,   524,     0,     0,   525,     0,     0,
       0,   526,     0,   527,     0,     0,   528,     0,     0,   529,
       0,     0,   530,     0,     0,   531,     0,     0,   532,     0,
     533,     0,     0,   534,     0,   535,     0,   536,     0,   537,
       0,   538,     0,   539,     0,   540,     0,   541,     0,   542,
       0,   543,     0,     0,   544,     0,     0,   545,     0,   546,
       0,   547,     0,     0,   548,     0,   549,     0,   550,     0,
       0,   551,     0,     0,   552,     0,     0,   553,     0,     0,
     554,     0,     0,   555,     0,     0,   556,     0,     0,   557,
       0,     0,   558,     0,   559,     0,   560,     0,   561,     0,
     562,     0,   563,     0,   564,     0,     0,   565,   390,   391,
     566,   392,     0,   567,   393,     0,   394,     0,   395,   568,
     396,   397,     0,   569,   398,   570,   399,   571,     0,   572,
       0,   573,     0,   574,     0,     0,   575,     0,     0,   576,
       0,     0,   577,     0,     0,   578,   579,   580,   581,   582,
     583,     0,   584,   585,   586,   587,   588,   589,   590,   591,
     592,   593,  -445,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   400,     0,     0,     0,     0,     0,  -239,
       0,  -239,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     401,   402,     0,     0,   403,     0,     0,     0,     0,  -239,
       0,  -239,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    66,     0,     0,     0,   404,     0,   405,   406,   407,
     408,     0,   409,     0,     0,     0,   410,   411,   412,   413,
       0,   414,     0,   415,     0,   416,     0,     0,    77,     0,
      78,     0,    79,     0,   417,     0,    80,     0,   418,     0,
     419,     0,   420,     0,   421,     0,     0,   422,     0,   423,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -464,  -464,  -464,  -464,   424,
       0,     0,     0,   425,   426,   427,   428,     0,     0,   429,
     430,   431,   432,   433,   434,   435,   436,   437,   438,   439,
     440,   441,     0,   442,     0,   443,     0,   444,     0,   445,
       0,   446,     0,   447,     0,   448,     0,   449,     0,   450,
       0,   451,     0,   452,     0,   453,     0,     0,   454,  -271,
       0,   455,     0,     0,   456,     0,     0,     0,     0,     0,
     457,     0,     0,   458,     0,     0,   459,     0,     0,   460,
     461,     0,   462,     0,   463,     0,   464,     0,   465,     0,
       0,     0,   466,     0,   467,     0,   468,   469,     0,     0,
     470,     0,     0,   471,     0,     0,   472,     0,     0,   473,
       0,     0,   474,     0,     0,     0,   475,   476,     0,     0,
       0,     0,     0,     0,     0,     0,   477,   478,     0,     0,
     479,     0,     0,     0,   480,     0,   481,     0,   482,     0,
       0,   483,     0,   484,     0,     0,   485,     0,     0,     0,
     486,     0,     0,     0,   487,     0,     0,   488,     0,   489,
       0,     0,   490,     0,     0,     0,   491,     0,   492,     0,
     493,     0,   494,     0,   495,     0,   496,     0,   497,     0,
       0,   498,     0,     0,   499,     0,     0,   500,     0,     0,
     501,     0,     0,   502,     0,     0,   503,     0,     0,   504,
       0,     0,   505,     0,     0,   506,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   507,     0,     0,     0,     0,
       0,     0,     0,   508,   509,     0,   510,   511,     0,   512,
     513,     0,   514,     0,   515,     0,     0,     0,     0,     0,
       0,     0,   516,     0,     0,     0,     0,     0,     0,     0,
     517,     0,     0,     0,   518,     0,     0,   519,     0,   520,
       0,   521,     0,     0,   522,     0,     0,   523,     0,     0,
     524,     0,     0,   525,     0,     0,     0,   526,     0,   527,
       0,     0,   528,     0,     0,   529,     0,     0,   530,     0,
       0,   531,     0,     0,   532,     0,   533,     0,     0,   534,
       0,   535,     0,   536,     0,   537,     0,   538,     0,   539,
       0,   540,     0,   541,     0,   542,     0,   543,     0,     0,
     544,     0,     0,   545,     0,   546,     0,   547,     0,     0,
     548,     0,   549,     0,   550,     0,     0,   551,     0,     0,
     552,     0,     0,   553,     0,     0,   554,     0,     0,   555,
       0,     0,   556,     0,     0,   557,     0,     0,   558,     0,
     559,     0,   560,     0,   561,     0,   562,     0,   563,     0,
     564,     0,     0,   565,   390,   391,   566,   392,     0,   567,
     393,     0,   394,     0,   395,   568,   396,   397,     0,   569,
     398,   570,   399,   571,     0,   572,     0,   573,     0,   574,
       0,     0,   575,     0,     0,   576,     0,     0,   577,     0,
       0,   578,   579,   580,   581,   582,   583,     0,   584,   585,
     586,   587,   588,   589,   590,   591,   592,   593,  -445,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   400,
       0,     0,     0,     0,     0,  -239,     0,  -239,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   401,   402,     0,     0,
     403,     0,     0,     0,     0,  -239,     0,  -239,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,   404,     0,   405,   406,   407,   408,     0,   409,     0,
       0,     0,   410,   411,   412,   413,     0,   414,     0,   415,
       0,   416,     0,     0,    77,     0,    78,     0,    79,     0,
     417,     0,    80,     0,   418,     0,   419,     0,   420,     0,
     421,     0,     0,   422,     0,   423,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  -464,  -464,  -464,  -464,   424,     0,     0,     0,   425,
     426,   427,   428,     0,  -271,   429,   430,   431,   432,   433,
     434,   435,   436,   437,   438,   439,   440,   441,     0,   442,
       0,   443,     0,   444,     0,   445,     0,   446,     0,   447,
       0,   448,     0,   449,     0,   450,     0,   451,     0,   452,
       0,   453,     0,     0,   454,     0,     0,   455,     0,     0,
     456,     0,     0,     0,     0,     0,   457,     0,     0,   458,
       0,     0,   459,     0,     0,   460,   461,     0,   462,     0,
     463,     0,   464,     0,   465,     0,     0,     0,   466,     0,
     467,     0,   468,   469,     0,     0,   470,     0,     0,   471,
       0,     0,   472,     0,     0,   473,     0,     0,   474,     0,
       0,     0,   475,   476,     0,     0,     0,     0,     0,     0,
       0,     0,   477,   478,     0,     0,   479,     0,     0,     0,
     480,     0,   481,     0,   482,     0,     0,   483,     0,   484,
       0,     0,   485,     0,     0,     0,   486,     0,     0,     0,
     487,     0,     0,   488,     0,   489,     0,     0,   490,     0,
       0,     0,   491,     0,   492,     0,   493,     0,   494,     0,
     495,     0,   496,     0,   497,     0,     0,   498,     0,     0,
     499,     0,     0,   500,     0,     0,   501,     0,     0,   502,
       0,     0,   503,     0,     0,   504,     0,     0,   505,     0,
       0,   506,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   507,     0,     0,     0,     0,     0,     0,     0,   508,
     509,     0,   510,   511,     0,   512,   513,     0,   514,     0,
     515,     0,     0,     0,     0,     0,     0,     0,   516,     0,
       0,     0,     0,     0,     0,     0,   517,     0,     0,     0,
     518,     0,     0,   519,     0,   520,     0,   521,     0,     0,
     522,     0,     0,   523,     0,     0,   524,     0,     0,   525,
       0,     0,     0,   526,     0,   527,     0,     0,   528,     0,
       0,   529,     0,     0,   530,     0,     0,   531,     0,     0,
     532,     0,   533,     0,     0,   534,     0,   535,     0,   536,
       0,   537,     0,   538,     0,   539,     0,   540,     0,   541,
       0,   542,     0,   543,     0,     0,   544,     0,     0,   545,
       0,   546,     0,   547,     0,     0,   548,     0,   549,     0,
     550,     0,     0,   551,     0,     0,   552,     0,     0,   553,
       0,     0,   554,     0,     0,   555,     0,     0,   556,     0,
       0,   557,     0,     0,   558,     0,   559,     0,   560,     0,
     561,     0,   562,     0,   563,     0,   564,     0,     0,   565,
     390,   391,   566,   392,     0,   567,   393,     0,   394,     0,
     395,   568,   396,   397,     0,   569,   398,   570,   399,   571,
       0,   572,     0,   573,     0,   574,     0,     0,   575,     0,
       0,   576,     0,     0,   577,     0,     0,   578,   579,   580,
     581,   582,   583,     0,   584,   585,   586,   587,   588,   589,
     590,   591,   592,   593,  -445,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   400,     0,     0,     0,     0,
       0,  -239,     0,  -239,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   401,   402,     0,     0,   403,     0,     0,     0,
       0,  -239,     0,  -239,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    66,     0,     0,     0,   404,     0,   405,
     406,   407,   408,     0,   409,     0,     0,     0,   410,   411,
     412,   413,     0,   414,     0,   415,     0,   416,     0,     0,
      77,     0,    78,     0,    79,     0,   417,     0,    80,     0,
     418,     0,   419,     0,   420,     0,   421,     0,     0,   422,
       0,   423,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  -464,  -464,  -464,
    -464,   424,     0,     0,     0,   425,   426,   427,   428,     0,
       0,   429,   430,   431,   432,   433,   434,   435,   436,   437,
     438,   439,   440,   441,     0,   442,     0,   443,     0,   444,
       0,   445,     0,   446,     0,   447,     0,   448,     0,   449,
       0,   450,     0,   451,     0,   452,     0,   453,     0,     0,
     454,     0,  -271,   455,     0,     0,   456,     0,     0,     0,
       0,     0,   457,     0,     0,   458,     0,     0,   459,     0,
       0,   460,   461,     0,   462,     0,   463,     0,   464,     0,
     465,     0,     0,     0,   466,     0,   467,     0,   468,   469,
       0,     0,   470,     0,     0,   471,     0,     0,   472,     0,
       0,   473,     0,     0,   474,     0,     0,     0,   475,   476,
       0,     0,     0,     0,     0,     0,     0,     0,   477,   478,
       0,     0,   479,     0,     0,     0,   480,     0,   481,     0,
     482,     0,     0,   483,     0,   484,     0,     0,   485,     0,
       0,     0,   486,     0,     0,     0,   487,     0,     0,   488,
       0,   489,     0,     0,   490,     0,     0,     0,   491,     0,
     492,     0,   493,     0,   494,     0,   495,     0,   496,     0,
     497,     0,     0,   498,     0,     0,   499,     0,     0,   500,
       0,     0,   501,     0,     0,   502,     0,     0,   503,     0,
       0,   504,     0,     0,   505,     0,     0,   506,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   507,     0,     0,
       0,     0,     0,     0,     0,   508,   509,     0,   510,   511,
       0,   512,   513,     0,   514,     0,   515,     0,     0,     0,
       0,     0,     0,     0,   516,     0,     0,     0,     0,     0,
       0,     0,   517,     0,     0,     0,   518,     0,     0,   519,
       0,   520,     0,   521,     0,     0,   522,     0,     0,   523,
       0,     0,   524,     0,     0,   525,     0,     0,     0,   526,
       0,   527,     0,     0,   528,     0,     0,   529,     0,     0,
     530,     0,     0,   531,     0,     0,   532,     0,   533,     0,
       0,   534,     0,   535,     0,   536,     0,   537,     0,   538,
       0,   539,     0,   540,     0,   541,     0,   542,     0,   543,
       0,     0,   544,     0,     0,   545,     0,   546,     0,   547,
       0,     0,   548,     0,   549,     0,   550,     0,     0,   551,
       0,     0,   552,     0,     0,   553,     0,     0,   554,     0,
       0,   555,     0,     0,   556,     0,     0,   557,     0,     0,
     558,     0,   559,     0,   560,     0,   561,     0,   562,     0,
     563,     0,   564,     0,     0,   565,   390,   391,   566,   392,
       0,   567,   393,     0,   394,     0,   395,   568,   396,   397,
       0,   569,   398,   570,   399,   571,     0,   572,     0,   573,
       0,   574,     0,     0,   575,     0,     0,   576,     0,     0,
     577,     0,     0,   578,   579,   580,   581,   582,   583,     0,
     584,   585,   586,   587,   588,   589,   590,   591,   592,   593,
    -445,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   400,     0,     0,     0,     0,     0,  -239,     0,  -239,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   401,   402,
       0,     0,   403,     0,     0,     0,     0,  -239,     0,  -239,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    66,
       0,     0,     0,   404,     0,   405,   406,   407,   408,     0,
     409,     0,     0,     0,   410,   411,   412,   413,     0,   414,
       0,   415,     0,   416,     0,     0,    77,     0,    78,     0,
      79,     0,   417,     0,    80,     0,   418,     0,   419,     0,
     420,     0,   421,     0,     0,   422,     0,   423,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  -464,  -464,  -464,  -464,   424,     0,     0,
       0,   425,   426,   427,   428,     0,     0,   429,   430,   431,
     432,   433,   434,   435,   436,   437,   438,   439,   440,   441,
       0,   442,     0,   443,     0,   444,     0,   445,     0,   446,
       0,   447,     0,   448,     0,   449,     0,   450,     0,   451,
       0,   452,     0,   453,     0,     0,   454,     0,     0,   455,
       0,     0,   456,     0,     0,     0,     0,     0,   457,     0,
       0,   458,     0,     0,   459,     0,     0,   460,   461,     0,
     462,     0,   463,     0,   464,     0,   465,     0,     0,     0,
     466,     0,   467,     0,   468,   469,     0,     0,   470,     0,
       0,   471,     0,     0,   472,     0,     0,   473,     0,     0,
     474,     0,     0,     0,   475,   476,     0,     0,     0,     0,
       0,     0,     0,     0,   477,   478,     0,     0,   479,     0,
       0,     0,   480,     0,   481,     0,   482,     0,     0,   483,
       0,   484,     0,     0,   485,     0,     0,     0,   486,     0,
       0,     0,   487,     0,     0,   488,     0,   489,     0,     0,
     490,     0,     0,     0,   491,     0,   492,     0,   493,     0,
     494,     0,   495,     0,   496,     0,   497,     0,     0,   498,
       0,     0,   499,     0,     0,   500,     0,     0,   501,     0,
       0,   502,     0,     0,   503,     0,     0,   504,     0,     0,
     505,     0,     0,   506,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   507,     0,     0,     0,     0,     0,     0,
       0,   508,   509,     0,   510,   511,     0,   512,   513,     0,
     514,     0,   515,     0,     0,     0,     0,     0,     0,     0,
     516,     0,     0,     0,     0,     0,     0,     0,   517,     0,
       0,     0,   518,     0,  -271,   519,     0,   520,     0,   521,
       0,     0,   522,     0,     0,   523,     0,     0,   524,     0,
       0,   525,     0,     0,     0,   526,     0,   527,     0,     0,
     528,     0,     0,   529,     0,     0,   530,     0,     0,   531,
       0,     0,   532,     0,   533,     0,     0,   534,     0,   535,
       0,   536,     0,   537,     0,   538,     0,   539,     0,   540,
       0,   541,     0,   542,     0,   543,     0,     0,   544,     0,
       0,   545,     0,   546,     0,   547,     0,     0,   548,     0,
     549,     0,   550,     0,     0,   551,     0,     0,   552,     0,
       0,   553,     0,     0,   554,     0,     0,   555,     0,     0,
     556,     0,     0,   557,     0,     0,   558,     0,   559,     0,
     560,     0,   561,     0,   562,     0,   563,     0,   564,     0,
       0,   565,   390,   391,   566,   392,     0,   567,   393,     0,
     394,     0,   395,   568,   396,   397,     0,   569,   398,   570,
     399,   571,     0,   572,     0,   573,     0,   574,     0,     0,
     575,     0,     0,   576,     0,     0,   577,     0,     0,   578,
     579,   580,   581,   582,   583,     0,   584,   585,   586,   587,
     588,   589,   590,   591,   592,   593,  -445,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   400,     0,     0,
       0,     0,     0,  -239,     0,  -239,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   401,   402,     0,     0,   403,     0,
       0,     0,     0,  -239,     0,  -239,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    66,     0,     0,     0,   404,
       0,   405,   406,   407,   408,     0,   409,     0,     0,     0,
     410,   411,   412,   413,     0,   414,     0,   415,     0,   416,
       0,     0,    77,     0,    78,     0,    79,     0,   417,     0,
      80,     0,   418,     0,   419,     0,   420,     0,   421,     0,
       0,   422,     0,   423,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  -464,
    -464,  -464,  -464,   424,     0,     0,  -271,   425,   426,   427,
     428,     0,     0,   429,   430,   431,   432,   433,   434,   435,
     436,   437,   438,   439,   440,   441,     0,   442,     0,   443,
       0,   444,     0,   445,     0,   446,     0,   447,     0,   448,
       0,   449,     0,   450,     0,   451,     0,   452,     0,   453,
       0,     0,   454,     0,     0,   455,     0,     0,   456,     0,
       0,     0,     0,     0,   457,     0,     0,   458,     0,     0,
     459,     0,     0,   460,   461,     0,   462,     0,   463,     0,
     464,     0,   465,     0,     0,     0,   466,     0,   467,     0,
     468,   469,     0,     0,   470,     0,     0,   471,     0,     0,
     472,     0,     0,   473,     0,     0,   474,     0,     0,     0,
     475,   476,     0,     0,     0,     0,     0,     0,     0,     0,
     477,   478,     0,     0,   479,     0,     0,     0,   480,     0,
     481,     0,   482,     0,     0,   483,     0,   484,     0,     0,
     485,     0,     0,     0,   486,     0,     0,     0,   487,     0,
       0,   488,     0,   489,     0,     0,   490,     0,     0,     0,
     491,     0,   492,     0,   493,     0,   494,     0,   495,     0,
     496,     0,   497,     0,     0,   498,     0,     0,   499,     0,
       0,   500,     0,     0,   501,     0,     0,   502,     0,     0,
     503,     0,     0,   504,     0,     0,   505,     0,     0,   506,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   507,
       0,     0,     0,     0,     0,     0,     0,   508,   509,     0,
     510,   511,     0,   512,   513,     0,   514,     0,   515,     0,
       0,     0,     0,     0,     0,     0,   516,     0,     0,     0,
       0,     0,     0,     0,   517,     0,     0,     0,   518,     0,
       0,   519,     0,   520,     0,   521,     0,     0,   522,     0,
       0,   523,     0,     0,   524,     0,     0,   525,     0,     0,
       0,   526,     0,   527,     0,     0,   528,     0,     0,   529,
       0,     0,   530,     0,     0,   531,     0,     0,   532,     0,
     533,     0,     0,   534,     0,   535,     0,   536,     0,   537,
       0,   538,     0,   539,     0,   540,     0,   541,     0,   542,
       0,   543,     0,     0,   544,     0,     0,   545,     0,   546,
       0,   547,     0,     0,   548,     0,   549,     0,   550,     0,
       0,   551,     0,     0,   552,     0,     0,   553,     0,     0,
     554,     0,     0,   555,     0,     0,   556,     0,     0,   557,
       0,     0,   558,     0,   559,     0,   560,     0,   561,     0,
     562,     0,   563,     0,   564,     0,     0,   565,   390,   391,
     566,   392,     0,   567,   393,     0,   394,     0,   395,   568,
     396,   397,     0,   569,   398,   570,   399,   571,     0,   572,
       0,   573,     0,   574,     0,     0,   575,     0,     0,   576,
       0,     0,   577,     0,     0,   578,   579,   580,   581,   582,
     583,     0,   584,   585,   586,   587,   588,   589,   590,   591,
     592,   593,  -445,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   400,     0,     0,     0,     0,     0,  -239,
       0,  -239,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     401,   402,     0,     0,   403,     0,     0,     0,     0,  -239,
       0,  -239,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    66,     0,     0,     0,   404,     0,   405,   406,   407,
     408,     0,   409,     0,     0,     0,   410,   411,   412,   413,
       0,   414,     0,   415,     0,   416,     0,  -271,    77,     0,
      78,     0,    79,     0,   417,     0,    80,     0,   418,     0,
     419,     0,   420,     0,   421,     0,     0,   422,     0,   423,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -464,  -464,  -464,  -464,   424,
       0,     0,     0,   425,   426,   427,   428,     0,     0,   429,
     430,   431,   432,   433,   434,   435,   436,   437,   438,   439,
     440,   441,     0,   442,     0,   443,     0,   444,     0,   445,
       0,   446,     0,   447,     0,   448,     0,   449,     0,   450,
       0,   451,     0,   452,     0,   453,     0,     0,   454,     0,
       0,   455,     0,     0,   456,     0,     0,     0,     0,     0,
     457,     0,     0,   458,     0,     0,   459,     0,     0,   460,
     461,     0,   462,     0,   463,     0,   464,     0,   465,     0,
       0,     0,   466,     0,   467,     0,   468,   469,     0,     0,
     470,     0,     0,   471,     0,     0,   472,     0,     0,   473,
       0,     0,   474,     0,     0,     0,   475,   476,     0,     0,
       0,     0,     0,     0,     0,     0,   477,   478,     0,     0,
     479,     0,     0,     0,   480,     0,   481,     0,   482,     0,
       0,   483,     0,   484,     0,     0,   485,     0,     0,     0,
     486,     0,     0,     0,   487,     0,     0,   488,     0,   489,
       0,     0,   490,     0,     0,     0,   491,     0,   492,     0,
     493,     0,   494,     0,   495,     0,   496,     0,   497,     0,
       0,   498,     0,     0,   499,     0,     0,   500,     0,     0,
     501,     0,     0,   502,     0,     0,   503,     0,     0,   504,
       0,     0,   505,     0,     0,   506,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   507,     0,     0,     0,     0,
       0,     0,     0,   508,   509,     0,   510,   511,     0,   512,
     513,     0,   514,     0,   515,     0,     0,     0,     0,     0,
       0,     0,   516,     0,     0,     0,     0,     0,     0,     0,
     517,     0,     0,     0,   518,     0,     0,   519,     0,   520,
       0,   521,     0,     0,   522,     0,     0,   523,     0,     0,
     524,     0,     0,   525,     0,     0,     0,   526,     0,   527,
       0,     0,   528,     0,     0,   529,     0,     0,   530,     0,
       0,   531,     0,     0,   532,     0,   533,     0,     0,   534,
       0,   535,     0,   536,     0,   537,     0,   538,     0,   539,
       0,   540,     0,   541,     0,   542,     0,   543,     0,     0,
     544,     0,     0,   545,     0,   546,     0,   547,     0,     0,
     548,     0,   549,     0,   550,     0,     0,   551,     0,     0,
     552,     0,     0,   553,     0,     0,   554,     0,     0,   555,
       0,     0,   556,     0,     0,   557,     0,     0,   558,     0,
     559,     0,   560,     0,   561,     0,   562,     0,   563,     0,
     564,     0,     0,   565,   390,   391,   566,   392,     0,   567,
     393,     0,   394,     0,   395,   568,   396,   397,     0,   569,
     398,   570,   399,   571,     0,   572,     0,   573,     0,   574,
       0,     0,   575,     0,     0,   576,     0,     0,   577,     0,
       0,   578,   579,   580,   581,   582,   583,     0,   584,   585,
     586,   587,   588,   589,   590,   591,   592,   593,  -445,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   400,
       0,     0,     0,     0,     0,  -239,     0,  -239,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   401,   402,     0,     0,
     403,     0,     0,     0,     0,  -239,     0,  -239,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,   404,     0,   405,   406,   407,   408,     0,   409,     0,
       0,     0,   410,   411,   412,   413,     0,   414,     0,   415,
       0,   416,     0,     0,    77,     0,    78,     0,    79,     0,
     417,     0,    80,     0,   418,     0,   419,     0,   420,     0,
     421,     0,     0,   422,     0,   423,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  -464,  -464,  -464,  -464,   424,     0,     0,     0,   425,
     426,   427,   428,     0,     0,   429,   430,   431,   432,   433,
     434,   435,   436,   437,   438,   439,   440,   441,     0,   442,
       0,   443,     0,   444,     0,   445,     0,   446,     0,   447,
       0,   448,     0,   449,     0,   450,     0,   451,     0,   452,
       0,   453,     0,     0,   454,     0,     0,   455,     0,     0,
     456,     0,     0,     0,     0,     0,   457,     0,     0,   458,
       0,     0,   459,     0,     0,   460,   461,     0,   462,     0,
     463,     0,   464,     0,   465,     0,     0,     0,   466,     0,
     467,     0,   468,   469,     0,     0,   470,     0,     0,   471,
       0,     0,   472,     0,     0,   473,     0,     0,   474,     0,
       0,     0,   475,   476,     0,     0,     0,     0,     0,     0,
       0,     0,   477,   478,     0,     0,   479,     0,     0,     0,
     480,     0,   481,     0,   482,     0,     0,   483,     0,   484,
       0,     0,   485,     0,     0,     0,   486,     0,     0,     0,
     487,     0,     0,   488,     0,   489,     0,     0,   490,     0,
       0,     0,   491,     0,   492,     0,   493,     0,   494,     0,
     495,     0,   496,     0,   497,     0,     0,   498,     0,     0,
     499,     0,     0,   500,     0,     0,   501,     0,     0,   502,
       0,     0,   503,     0,     0,   504,     0,     0,   505,     0,
       0,   506,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   507,     0,     0,     0,     0,     0,     0,     0,   508,
     509,     0,   510,   511,     0,   512,   513,     0,   514,     0,
     515,     0,     0,     0,     0,     0,     0,     0,   516,     0,
       0,     0,     0,     0,     0,     0,   517,     0,     0,     0,
     518,     0,     0,   519,     0,   520,     0,   521,     0,     0,
     522,     0,     0,   523,     0,     0,   524,     0,     0,   525,
       0,     0,     0,   526,     0,   527,     0,     0,   528,     0,
       0,   529,     0,     0,   530,     0,     0,   531,     0,     0,
     532,     0,   533,     0,     0,   534,     0,   535,     0,   536,
       0,   537,     0,   538,     0,   539,     0,   540,     0,   541,
       0,   542,     0,   543,     0,     0,   544,     0,     0,   545,
       0,   546,     0,   547,     0,     0,   548,     0,   549,     0,
     550,     0,     0,   551,     0,     0,   552,     0,     0,   553,
       0,     0,   554,     0,     0,   555,     0,     0,   556,     0,
       0,   557,     0,     0,   558,     0,   559,     0,   560,     0,
     561,     0,   562,     0,   563,     0,   564,     0,     0,   565,
       0,     0,   566,     0,     0,   567,     0,     0,     0,     0,
       0,   568,     0,     0,     0,   569,     0,   570,     0,   571,
       0,   572,     0,   573,     0,   574,     0,     0,   575,     0,
       0,   576,     0,     0,   577,     0,     0,   578,   579,   580,
     581,   582,   583,     0,   584,   585,   586,   587,   588,   589,
     590,   591,   592,   593,  -445,     4,     5,     0,     7,     8,
       9,    10,     0,     0,     0,     0,     0,     0,     0,    11,
       0,    12,     0,    13,     0,    14,     0,    15,     0,     0,
       0,     0,     0,    16,     0,    17,     0,    18,     0,    19,
       0,    20,     0,    21,     0,    22,     0,    23,     0,    24,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,     0,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,     0,    37,     0,    38,     0,
      39,     0,    40,     0,    41,     0,    42,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    43,     0,    44,     0,
      45,     0,    46,     0,    47,    48,    49,     0,    50,     0,
      51,     0,     0,     0,    52,     0,     0,     0,     0,     0,
       0,    53,     0,    54,     0,    55,    56,    57,    58,     0,
       0,    59,     0,     0,     0,     0,    60,     0,    61,     0,
      62,     0,     0,    63,     0,    64,     0,     0,     0,    65,
       0,     0,     0,     0,     0,     0,     0,     0,    66,     0,
       0,     0,    67,    68,    69,     0,     0,    70,     0,    71,
       0,    72,     0,     0,     0,     0,    73,     0,    74,     0,
      75,     0,    76,     0,     0,    77,     0,    78,     0,    79,
       0,     0,     0,    80,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     4,     5,    81,     7,     8,     9,
      10,  1152,     0,     0,     0,     0,     0,     0,    11,     0,
      12,     0,    13,     0,    14,     0,    15,     0,     0,     0,
       0,     0,    16,     0,    17,     0,    18,     0,    19,     0,
      20,     0,    21,     0,    22,     0,    23,     0,    24,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
       0,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,     0,    37,     0,    38,     0,    39,
       0,    40,     0,    41,     0,    42,     0,     0,    82,   337,
       0,     0,     0,     0,     0,    43,     0,    44,     0,    45,
       0,    46,     0,    47,    48,    49,     0,    50,     0,    51,
       0,     0,     0,    52,     0,     0,     0,     0,     0,     0,
      53,     0,    54,     0,    55,    56,    57,    58,     0,     0,
      59,     0,     0,     0,     0,    60,     0,    61,     0,    62,
       0,     0,    63,     0,    64,     0,     0,     0,    65,     0,
       0,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,    67,    68,    69,     0,     0,    70,     0,    71,     0,
      72,     0,     0,     0,     0,    73,     0,    74,     0,    75,
       0,    76,     0,  1153,    77,     0,    78,     0,    79,     0,
       0,     0,    80,     4,     5,     6,     7,     8,     9,    10,
       0,     0,     0,     0,     0,    81,     0,    11,     0,    12,
       0,    13,     0,    14,     0,    15,     0,     0,     0,     0,
       0,    16,     0,    17,     0,    18,     0,    19,     0,    20,
       0,    21,     0,    22,     0,    23,     0,    24,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,     0,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,     0,    37,     0,    38,     0,    39,     0,
      40,     0,    41,     0,    42,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    43,     0,    44,    82,    45,     0,
      46,     0,    47,    48,    49,     0,    50,     0,    51,     0,
       0,     0,    52,     0,     0,     0,     0,     0,     0,    53,
       0,    54,     0,    55,    56,    57,    58,     0,     0,    59,
       0,     0,     0,     0,    60,     0,    61,     0,    62,     0,
       0,    63,     0,    64,     0,     0,     0,    65,     0,     0,
       0,     0,     0,     0,     0,     0,    66,     0,     0,     0,
      67,    68,    69,     0,     0,    70,     0,    71,     0,    72,
       0,     0,     0,     0,    73,     0,    74,     0,    75,     0,
      76,     0,     0,    77,     0,    78,     0,    79,     0,     0,
       0,    80,     4,     5,     0,     7,     8,     9,    10,     0,
       0,     0,     0,     0,    81,     0,    11,     0,    12,     0,
      13,     0,    14,     0,    15,     0,     0,     0,     0,     0,
      16,     0,    17,     0,    18,     0,    19,     0,    20,     0,
      21,     0,    22,     0,    23,     0,    24,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,     0,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,     0,    37,     0,    38,     0,    39,     0,    40,
       0,    41,     0,    42,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    43,     0,    44,    82,    45,     0,    46,
       0,    47,    48,    49,     0,    50,     0,    51,     0,     0,
       0,    52,     0,     0,     0,     0,     0,     0,    53,     0,
      54,   219,    55,    56,    57,    58,     0,     0,    59,     0,
       0,     0,     0,    60,     0,    61,     0,    62,     0,     0,
      63,     0,    64,     0,     0,     0,    65,     0,     0,     0,
       0,     0,     0,     0,     0,    66,     0,     0,     0,    67,
      68,    69,     0,     0,    70,     0,    71,     0,    72,     0,
       0,     0,     0,    73,     0,    74,     0,    75,     0,    76,
       0,     0,    77,     0,    78,     0,    79,     0,     0,     0,
      80,     4,     5,     0,     7,     8,     9,    10,     0,     0,
       0,     0,     0,    81,     0,    11,     0,    12,     0,    13,
       0,    14,     0,    15,     0,     0,     0,     0,     0,    16,
       0,    17,     0,    18,     0,    19,     0,    20,     0,    21,
       0,    22,     0,    23,     0,    24,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,     0,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,     0,    37,     0,    38,     0,    39,     0,    40,     0,
      41,     0,    42,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    43,     0,    44,    82,    45,   290,    46,     0,
      47,    48,    49,     0,    50,     0,    51,     0,     0,     0,
      52,     0,     0,     0,     0,     0,     0,    53,     0,    54,
       0,    55,    56,    57,    58,     0,     0,    59,     0,     0,
       0,     0,    60,     0,    61,     0,    62,     0,     0,    63,
       0,    64,     0,     0,     0,    65,     0,     0,     0,     0,
       0,     0,     0,     0,    66,     0,     0,     0,    67,    68,
      69,     0,     0,    70,     0,    71,     0,    72,     0,     0,
       0,     0,    73,     0,    74,     0,    75,     0,    76,     0,
       0,    77,     0,    78,     0,    79,     0,     0,     0,    80,
       4,     5,     0,     7,     8,     9,    10,     0,     0,     0,
       0,     0,    81,     0,    11,     0,    12,     0,    13,     0,
      14,     0,    15,     0,     0,     0,     0,     0,    16,     0,
      17,     0,    18,     0,    19,     0,    20,     0,    21,     0,
      22,     0,    23,     0,    24,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,     0,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
       0,    37,     0,    38,     0,    39,     0,    40,     0,    41,
       0,    42,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    43,     0,    44,    82,    45,     0,    46,     0,    47,
      48,    49,     0,    50,   293,    51,     0,     0,     0,    52,
       0,     0,     0,     0,     0,     0,    53,     0,    54,     0,
      55,    56,    57,    58,     0,     0,    59,     0,     0,     0,
       0,    60,     0,    61,     0,    62,     0,     0,    63,     0,
      64,     0,     0,     0,    65,     0,     0,     0,     0,     0,
       0,     0,     0,    66,     0,     0,     0,    67,    68,    69,
       0,     0,    70,     0,    71,     0,    72,     0,     0,     0,
       0,    73,     0,    74,     0,    75,     0,    76,     0,     0,
      77,     0,    78,     0,    79,     0,     0,     0,    80,     4,
       5,     0,     7,     8,     9,    10,     0,     0,     0,     0,
       0,    81,     0,    11,     0,    12,     0,    13,     0,    14,
       0,    15,     0,     0,     0,     0,     0,    16,     0,    17,
       0,    18,     0,    19,     0,    20,     0,    21,     0,    22,
       0,    23,     0,    24,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,     0,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,     0,
      37,     0,    38,     0,    39,     0,    40,     0,    41,     0,
      42,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      43,     0,    44,    82,    45,     0,    46,     0,    47,    48,
      49,     0,    50,     0,    51,   294,     0,     0,    52,     0,
       0,     0,     0,     0,     0,    53,     0,    54,     0,    55,
      56,    57,    58,     0,     0,    59,     0,     0,     0,     0,
      60,     0,    61,     0,    62,     0,     0,    63,     0,    64,
       0,     0,     0,    65,     0,     0,     0,     0,     0,     0,
       0,     0,    66,     0,     0,     0,    67,    68,    69,     0,
       0,    70,     0,    71,     0,    72,     0,     0,     0,     0,
      73,     0,    74,     0,    75,     0,    76,     0,     0,    77,
       0,    78,     0,    79,     0,     0,     0,    80,     4,     5,
       0,     7,     8,     9,    10,     0,     0,     0,     0,     0,
      81,     0,    11,     0,    12,     0,    13,     0,    14,     0,
      15,     0,     0,     0,     0,     0,    16,     0,    17,     0,
      18,     0,    19,     0,    20,     0,    21,     0,    22,     0,
      23,     0,    24,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,     0,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,     0,    37,
       0,    38,     0,    39,     0,    40,     0,    41,     0,    42,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    43,
       0,    44,    82,    45,     0,    46,     0,    47,    48,    49,
       0,    50,     0,    51,     0,     0,     0,    52,     0,     0,
       0,     0,     0,     0,    53,   297,    54,     0,    55,    56,
      57,    58,     0,     0,    59,     0,     0,     0,     0,    60,
       0,    61,     0,    62,     0,     0,    63,     0,    64,     0,
       0,     0,    65,     0,     0,     0,     0,     0,     0,     0,
       0,    66,     0,     0,     0,    67,    68,    69,     0,     0,
      70,     0,    71,     0,    72,     0,     0,     0,     0,    73,
       0,    74,     0,    75,     0,    76,     0,     0,    77,     0,
      78,     0,    79,     0,     0,     0,    80,     4,     5,     0,
       7,     8,     9,    10,     0,     0,     0,     0,     0,    81,
       0,    11,     0,    12,     0,    13,     0,    14,     0,    15,
       0,     0,     0,     0,     0,    16,     0,    17,     0,    18,
       0,    19,     0,    20,     0,    21,     0,    22,     0,    23,
       0,    24,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,     0,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,     0,    37,     0,
      38,     0,    39,     0,    40,     0,    41,     0,    42,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    43,     0,
      44,    82,    45,     0,    46,     0,    47,    48,    49,     0,
      50,     0,    51,     0,     0,     0,    52,     0,     0,     0,
       0,     0,     0,    53,     0,    54,     0,    55,    56,    57,
      58,     0,     0,    59,     0,     0,     0,     0,    60,   300,
      61,     0,    62,     0,     0,    63,     0,    64,     0,     0,
       0,    65,     0,     0,     0,     0,     0,     0,     0,     0,
      66,     0,     0,     0,    67,    68,    69,     0,     0,    70,
       0,    71,     0,    72,     0,     0,     0,     0,    73,     0,
      74,     0,    75,     0,    76,     0,     0,    77,     0,    78,
       0,    79,     0,     0,     0,    80,     4,     5,     0,     7,
       8,     9,    10,     0,     0,     0,     0,     0,    81,     0,
      11,     0,    12,     0,    13,     0,    14,     0,    15,     0,
       0,     0,     0,     0,    16,     0,    17,     0,    18,     0,
      19,     0,    20,     0,    21,     0,    22,     0,    23,     0,
      24,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,     0,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,     0,    37,     0,    38,
       0,    39,     0,    40,     0,    41,     0,    42,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    43,     0,    44,
      82,    45,     0,    46,     0,    47,    48,    49,     0,    50,
       0,    51,     0,     0,     0,    52,     0,     0,     0,     0,
       0,     0,    53,     0,    54,     0,    55,    56,    57,    58,
       0,     0,    59,     0,     0,     0,     0,    60,     0,    61,
       0,    62,     0,     0,    63,     0,    64,     0,     0,     0,
      65,     0,     0,     0,     0,     0,     0,     0,     0,    66,
       0,     0,     0,    67,    68,    69,     0,     0,    70,     0,
      71,     0,    72,   319,     0,     0,     0,    73,     0,    74,
       0,    75,     0,    76,     0,     0,    77,     0,    78,     0,
      79,     0,     0,     0,    80,     4,     5,     0,     7,     8,
       9,    10,     0,     0,     0,     0,     0,    81,     0,    11,
       0,    12,     0,    13,     0,    14,     0,    15,     0,     0,
       0,     0,     0,    16,     0,    17,     0,    18,     0,    19,
       0,    20,     0,    21,     0,    22,     0,    23,     0,    24,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,     0,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,     0,    37,     0,    38,     0,
      39,     0,    40,     0,    41,     0,    42,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    43,     0,    44,    82,
      45,     0,    46,     0,    47,    48,    49,     0,    50,     0,
      51,     0,     0,     0,    52,     0,     0,     0,     0,     0,
       0,    53,     0,    54,     0,    55,    56,    57,    58,     0,
       0,    59,     0,     0,     0,     0,    60,     0,    61,     0,
      62,     0,     0,    63,     0,    64,     0,     0,     0,    65,
       0,     0,     0,     0,     0,     0,     0,     0,    66,     0,
       0,     0,    67,    68,    69,     0,     0,    70,     0,    71,
       0,    72,     0,     0,     0,     0,    73,   320,    74,     0,
      75,     0,    76,     0,     0,    77,     0,    78,     0,    79,
       0,     0,     0,    80,     4,     5,     0,     7,     8,     9,
      10,     0,     0,     0,     0,     0,    81,     0,    11,     0,
      12,     0,    13,     0,    14,     0,    15,     0,     0,     0,
       0,     0,    16,     0,    17,     0,    18,     0,    19,     0,
      20,     0,    21,     0,    22,     0,    23,     0,    24,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
       0,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,     0,    37,     0,    38,     0,    39,
       0,    40,     0,    41,     0,    42,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    43,     0,    44,    82,    45,
       0,    46,     0,    47,    48,    49,     0,    50,     0,    51,
       0,     0,     0,    52,     0,     0,     0,     0,     0,     0,
      53,     0,    54,     0,    55,    56,    57,    58,     0,     0,
      59,     0,     0,     0,     0,    60,     0,    61,     0,    62,
       0,     0,    63,     0,    64,     0,     0,     0,    65,     0,
       0,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,    67,    68,    69,     0,     0,    70,     0,    71,     0,
      72,     0,     0,     0,     0,    73,     0,    74,     0,    75,
       0,    76,   325,     0,    77,     0,    78,     0,    79,     0,
       0,     0,    80,     4,     5,     0,     7,     8,     9,    10,
       0,     0,     0,     0,     0,    81,     0,    11,     0,    12,
       0,    13,     0,    14,     0,    15,     0,     0,     0,     0,
       0,    16,     0,    17,     0,    18,     0,    19,     0,    20,
       0,    21,     0,    22,     0,    23,     0,    24,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,     0,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,     0,    37,     0,    38,     0,    39,     0,
      40,     0,    41,     0,    42,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    43,     0,    44,    82,    45,     0,
      46,     0,    47,    48,    49,     0,    50,     0,    51,     0,
       0,     0,    52,     0,     0,     0,     0,     0,     0,    53,
       0,    54,     0,    55,    56,    57,    58,     0,     0,    59,
       0,     0,     0,     0,    60,     0,    61,   377,    62,     0,
       0,    63,     0,    64,     0,     0,     0,    65,     0,     0,
       0,     0,     0,     0,     0,     0,    66,     0,     0,     0,
      67,    68,    69,     0,     0,    70,     0,    71,     0,    72,
       0,     0,     0,     0,    73,     0,    74,     0,    75,     0,
      76,     0,     0,    77,     0,    78,     0,    79,     0,     0,
       0,    80,     4,     5,     0,     7,     8,     9,    10,     0,
       0,     0,     0,     0,    81,     0,    11,     0,    12,     0,
      13,     0,    14,     0,    15,     0,     0,     0,     0,     0,
      16,     0,    17,     0,    18,     0,    19,     0,    20,     0,
      21,     0,    22,     0,    23,     0,    24,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,     0,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,     0,    37,     0,    38,     0,    39,     0,    40,
       0,    41,     0,    42,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    43,     0,    44,    82,    45,     0,    46,
       0,    47,    48,    49,     0,    50,     0,    51,     0,     0,
       0,    52,     0,     0,     0,     0,     0,     0,    53,     0,
      54,     0,    55,    56,    57,    58,     0,     0,    59,     0,
       0,     0,     0,    60,     0,    61,     0,    62,     0,     0,
      63,     0,    64,     0,     0,     0,    65,     0,     0,     0,
       0,   382,     0,     0,     0,    66,     0,     0,     0,    67,
      68,    69,     0,     0,    70,     0,    71,     0,    72,     0,
       0,     0,     0,    73,     0,    74,     0,    75,     0,    76,
       0,     0,    77,     0,    78,     0,    79,     0,     0,     0,
      80,     4,     5,     0,     7,     8,     9,    10,     0,     0,
       0,     0,     0,    81,     0,    11,     0,    12,     0,    13,
       0,    14,     0,    15,     0,     0,     0,     0,     0,    16,
       0,    17,     0,    18,     0,    19,     0,    20,     0,    21,
       0,    22,     0,    23,     0,    24,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,     0,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,     0,    37,     0,    38,     0,    39,     0,    40,     0,
      41,     0,    42,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    43,     0,    44,    82,    45,     0,    46,     0,
      47,    48,    49,     0,    50,     0,    51,     0,     0,     0,
      52,     0,     0,     0,     0,     0,     0,    53,     0,    54,
       0,    55,    56,    57,    58,     0,     0,    59,     0,     0,
       0,     0,    60,     0,    61,     0,    62,     0,     0,    63,
       0,    64,     0,     0,     0,    65,     0,     0,     0,     0,
       0,     0,     0,     0,    66,   385,     0,     0,    67,    68,
      69,     0,     0,    70,     0,    71,     0,    72,     0,     0,
       0,     0,    73,     0,    74,     0,    75,     0,    76,     0,
       0,    77,     0,    78,     0,    79,     0,     0,     0,    80,
       4,     5,     0,     7,     8,     9,    10,     0,     0,     0,
       0,     0,    81,     0,    11,     0,    12,     0,    13,     0,
      14,     0,    15,     0,     0,     0,     0,     0,    16,     0,
      17,     0,    18,     0,    19,     0,    20,     0,    21,     0,
      22,     0,    23,     0,    24,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,     0,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
       0,    37,     0,    38,     0,    39,     0,    40,     0,    41,
       0,    42,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    43,     0,    44,    82,    45,     0,    46,     0,    47,
      48,    49,     0,    50,     0,    51,     0,     0,     0,    52,
       0,     0,     0,     0,     0,     0,    53,     0,    54,     0,
      55,    56,    57,    58,     0,     0,    59,     0,     0,     0,
       0,    60,     0,    61,     0,    62,     0,     0,    63,     0,
      64,     0,     0,     0,    65,     0,     0,     0,     0,     0,
       0,     0,     0,    66,     0,     0,     0,    67,    68,    69,
       0,     0,    70,   631,    71,     0,    72,     0,     0,     0,
       0,    73,     0,    74,     0,    75,     0,    76,     0,     0,
      77,     0,    78,     0,    79,     0,     0,     0,    80,     4,
       5,     0,     7,     8,     9,    10,     0,     0,     0,     0,
       0,    81,     0,    11,     0,    12,     0,    13,     0,    14,
       0,    15,     0,     0,     0,     0,     0,    16,     0,    17,
       0,    18,     0,    19,     0,    20,     0,    21,     0,    22,
       0,    23,     0,    24,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,     0,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,     0,
      37,     0,    38,     0,    39,     0,    40,     0,    41,     0,
      42,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      43,     0,    44,    82,    45,     0,    46,     0,    47,    48,
      49,     0,    50,     0,    51,     0,     0,     0,    52,     0,
       0,     0,     0,     0,     0,    53,     0,    54,     0,    55,
      56,    57,    58,     0,   649,    59,     0,     0,     0,     0,
      60,     0,    61,     0,    62,     0,     0,    63,     0,    64,
       0,     0,     0,    65,     0,     0,     0,     0,     0,     0,
       0,     0,    66,     0,     0,     0,    67,    68,    69,     0,
       0,    70,     0,    71,     0,    72,     0,     0,     0,     0,
      73,     0,    74,     0,    75,     0,    76,     0,     0,    77,
       0,    78,     0,    79,     0,     0,     0,    80,     4,     5,
       0,     7,     8,     9,    10,     0,     0,     0,     0,     0,
      81,     0,    11,     0,    12,     0,    13,     0,    14,     0,
      15,     0,     0,     0,     0,     0,    16,     0,    17,     0,
      18,     0,    19,     0,    20,     0,    21,     0,    22,     0,
      23,     0,    24,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,     0,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,     0,    37,
       0,    38,     0,    39,     0,    40,     0,    41,     0,    42,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    43,
       0,    44,    82,    45,     0,    46,     0,    47,    48,    49,
     922,    50,     0,    51,     0,     0,     0,    52,     0,     0,
       0,     0,     0,     0,    53,     0,    54,     0,    55,    56,
      57,    58,     0,     0,    59,     0,     0,     0,     0,    60,
       0,    61,     0,    62,     0,     0,    63,     0,    64,     0,
       0,     0,    65,     0,     0,     0,     0,     0,     0,     0,
       0,    66,     0,     0,     0,    67,    68,    69,     0,     0,
      70,     0,    71,     0,    72,     0,     0,     0,     0,    73,
       0,    74,     0,    75,     0,    76,     0,     0,    77,     0,
      78,     0,    79,     0,     0,     0,    80,     4,     5,     0,
       7,     8,     9,    10,     0,     0,     0,     0,     0,    81,
       0,    11,     0,    12,     0,    13,     0,    14,     0,    15,
       0,     0,     0,     0,     0,    16,     0,    17,     0,    18,
       0,    19,     0,    20,     0,    21,     0,    22,     0,    23,
       0,    24,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,     0,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,     0,    37,     0,
      38,     0,    39,     0,    40,     0,    41,     0,    42,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    43,     0,
      44,    82,    45,     0,    46,     0,    47,    48,    49,     0,
      50,     0,    51,     0,     0,     0,    52,     0,     0,     0,
       0,     0,     0,    53,     0,    54,     0,    55,    56,    57,
      58,     0,     0,    59,     0,     0,  1148,     0,    60,     0,
      61,     0,    62,     0,     0,    63,     0,    64,     0,     0,
       0,    65,     0,     0,     0,     0,     0,     0,     0,     0,
      66,     0,     0,     0,    67,    68,    69,     0,     0,    70,
       0,    71,     0,    72,     0,     0,     0,     0,    73,     0,
      74,     0,    75,     0,    76,     0,     0,    77,     0,    78,
       0,    79,     0,     0,     0,    80,     4,     5,     0,     7,
       8,     9,    10,     0,     0,     0,     0,     0,    81,     0,
      11,     0,    12,     0,    13,     0,    14,     0,    15,     0,
       0,     0,     0,     0,    16,     0,    17,     0,    18,     0,
      19,     0,    20,     0,    21,     0,    22,     0,    23,     0,
      24,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,     0,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,     0,    37,     0,    38,
       0,    39,     0,    40,     0,    41,     0,    42,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    43,     0,    44,
      82,    45,     0,    46,     0,    47,    48,    49,     0,    50,
       0,    51,     0,     0,     0,    52,     0,     0,     0,     0,
       0,     0,    53,     0,    54,     0,    55,    56,    57,    58,
       0,     0,    59,     0,     0,     0,     0,    60,     0,    61,
       0,    62,  1149,     0,    63,     0,    64,     0,     0,     0,
      65,     0,     0,     0,     0,     0,     0,     0,     0,    66,
       0,     0,     0,    67,    68,    69,     0,     0,    70,     0,
      71,     0,    72,     0,     0,     0,     0,    73,     0,    74,
       0,    75,     0,    76,     0,     0,    77,     0,    78,     0,
      79,     0,     0,     0,    80,     4,     5,     0,     7,     8,
       9,    10,     0,     0,     0,     0,     0,    81,     0,    11,
       0,    12,     0,    13,     0,    14,     0,    15,     0,     0,
       0,     0,     0,    16,     0,    17,     0,    18,     0,    19,
       0,    20,     0,    21,     0,    22,     0,    23,     0,    24,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,     0,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,     0,    37,     0,    38,     0,
      39,     0,    40,     0,    41,     0,    42,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    43,     0,    44,    82,
      45,     0,    46,     0,    47,    48,    49,     0,    50,     0,
      51,     0,     0,     0,    52,     0,     0,     0,     0,     0,
       0,    53,     0,    54,     0,    55,    56,    57,    58,     0,
       0,    59,     0,     0,     0,     0,    60,     0,    61,     0,
      62,     0,     0,    63,     0,    64,     0,     0,     0,    65,
       0,     0,     0,     0,     0,     0,     0,     0,    66,     0,
       0,     0,    67,    68,    69,     0,     0,    70,     0,    71,
       0,    72,     0,     0,     0,     0,    73,     0,    74,     0,
      75,     0,    76,  1171,     0,    77,     0,    78,     0,    79,
       0,     0,     0,    80,     4,     5,     0,     7,     8,     9,
      10,     0,     0,     0,     0,     0,    81,     0,    11,     0,
      12,     0,    13,     0,    14,     0,    15,     0,     0,     0,
       0,     0,    16,     0,    17,     0,    18,     0,    19,     0,
      20,     0,    21,     0,    22,     0,    23,     0,    24,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
       0,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,     0,    37,     0,    38,     0,    39,
       0,    40,     0,    41,     0,    42,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    43,     0,    44,    82,    45,
       0,    46,     0,    47,    48,    49,     0,    50,     0,    51,
       0,     0,     0,    52,     0,     0,     0,     0,     0,     0,
      53,     0,    54,     0,    55,    56,    57,    58,     0,  1705,
      59,     0,     0,     0,     0,    60,     0,    61,     0,    62,
       0,     0,    63,     0,    64,     0,     0,     0,    65,     0,
       0,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,    67,    68,    69,     0,     0,    70,     0,    71,     0,
      72,     0,     0,     0,     0,    73,     0,    74,     0,    75,
       0,    76,     0,     0,    77,     0,    78,     0,    79,     0,
       0,     0,    80,     4,     5,     0,     7,     8,     9,    10,
       0,     0,     0,     0,     0,    81,     0,    11,     0,    12,
       0,    13,     0,    14,     0,    15,     0,     0,     0,     0,
       0,    16,     0,    17,     0,    18,     0,    19,     0,    20,
       0,    21,     0,    22,     0,    23,     0,    24,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,     0,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,     0,    37,     0,    38,     0,    39,     0,
      40,     0,    41,     0,    42,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    43,     0,    44,    82,    45,     0,
      46,     0,    47,    48,    49,     0,    50,     0,    51,     0,
       0,     0,    52,     0,     0,     0,     0,     0,  1813,    53,
       0,    54,     0,    55,    56,    57,    58,     0,     0,    59,
       0,     0,     0,     0,    60,     0,    61,     0,    62,     0,
       0,    63,     0,    64,     0,     0,     0,    65,     0,     0,
       0,     0,     0,     0,     0,     0,    66,     0,     0,     0,
      67,    68,    69,     0,     0,    70,     0,    71,     0,    72,
       0,     0,     0,     0,    73,     0,    74,     0,    75,     0,
      76,     0,     0,    77,     0,    78,     0,    79,     0,     0,
       0,    80,     4,     5,     0,     7,     8,     9,    10,     0,
       0,     0,     0,     0,    81,     0,    11,     0,    12,     0,
      13,     0,    14,     0,    15,     0,     0,     0,     0,     0,
      16,     0,    17,     0,    18,     0,    19,     0,    20,     0,
      21,     0,    22,     0,    23,     0,    24,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,     0,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,     0,    37,     0,    38,     0,    39,     0,    40,
       0,    41,     0,    42,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    43,     0,    44,    82,    45,     0,    46,
       0,    47,    48,    49,     0,    50,     0,    51,     0,     0,
       0,    52,     0,     0,     0,     0,     0,     0,    53,     0,
      54,     0,    55,    56,    57,    58,     0,     0,    59,     0,
       0,     0,     0,    60,     0,    61,     0,    62,     0,     0,
      63,     0,    64,     0,     0,     0,    65,     0,     0,     0,
       0,     0,     0,     0,     0,    66,     0,     0,     0,    67,
      68,    69,     0,     0,    70,     0,    71,     0,    72,     0,
       0,     0,     0,    73,     0,    74,     0,    75,     0,    76,
       0,     0,    77,     0,    78,     0,    79,     0,     0,     0,
      80,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    81,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    82
};

static const yytype_int16 yycheck[] =
{
       2,    71,  1339,   718,  1341,   916,   745,    77,   333,   303,
     304,   826,   595,   654,  1250,     8,   657,   169,   659,   166,
     381,     3,   153,   384,   674,   822,  1262,   824,   825,    41,
    1266,   336,  1048,     3,  1144,  1051,     3,   601,   248,    10,
     154,   626,    10,   154,     8,    10,    94,    10,    96,  1355,
     635,   141,   166,   143,    10,   197,     8,  1460,  1364,   197,
     202,   197,    10,  1466,   202,   165,   202,   167,     8,     0,
      61,   635,    10,    10,   176,   186,   178,     3,   180,    70,
       2,    10,   151,   183,  1930,   185,   134,   187,   136,  1935,
    1936,   191,  1938,  1939,   246,   158,   148,   148,   229,   151,
     151,   148,   154,   154,   151,   240,   241,   242,   243,   165,
     165,     3,   168,   168,     6,   165,   165,   167,   167,    94,
      94,    96,    96,   183,   246,   185,   248,     3,     4,   141,
     239,   143,   241,   146,   114,   125,   133,   140,    68,   349,
     127,   143,   106,   165,   165,   159,    41,     3,     3,   166,
      10,   298,   167,   103,   166,  1062,   167,   185,   113,    10,
       3,     2,     8,    10,   295,   166,   165,   177,   184,    18,
     179,    24,    20,   166,    26,   177,   178,   179,   180,   181,
     182,   183,   184,   185,   186,   187,   188,   189,   190,   191,
     192,   193,   194,   195,   196,   197,   198,   199,   200,   201,
     202,   203,   204,   205,   206,   207,   208,   209,   210,   211,
     166,   182,   214,   215,   182,   197,   218,   182,   166,   182,
     222,   143,   174,  1020,  1021,   165,   182,   197,   166,   166,
     197,    22,   202,  1249,   182,   226,    32,   166,   168,   169,
      34,   243,   244,    38,   182,  1261,    44,   249,    40,  1265,
      51,    48,    42,   182,   256,   177,   178,   179,   180,   181,
     182,   183,   184,   185,   186,   187,   188,   189,   190,   191,
     192,   193,   194,   195,   196,   197,   198,   199,   200,   201,
     202,   203,   204,   205,   206,   207,   208,   209,   210,   211,
      46,    53,   214,   215,    55,   936,   218,   658,  1113,   301,
     222,    59,   143,   305,    57,     2,   308,   309,  1215,    61,
    1217,   313,    63,  1110,   316,   640,   246,    65,  1057,    69,
      67,   243,   244,  1230,  1063,   908,    71,   249,    77,    73,
      85,    95,    75,    79,   256,   101,   177,   178,   179,   180,
     181,   182,   183,   184,   185,   186,   187,   188,   189,   190,
     191,   192,   193,   194,   195,   196,   197,   198,   199,   200,
     201,   202,   203,   204,   205,   206,   207,   208,   209,   210,
     211,    81,   374,   214,   215,    83,   681,   218,    97,   301,
     310,   222,   312,   305,  1931,   145,   308,   309,    10,     2,
    1937,   313,   131,  1940,   316,    10,   165,   186,   115,   130,
     154,   107,   243,   244,    42,     3,    90,   182,   249,    11,
     198,   402,   403,     3,    11,   256,   203,     3,   231,   231,
       3,   232,   232,   165,   165,   211,   375,   235,   221,   212,
     234,   238,   216,   214,   236,  1346,   213,   553,  1349,   239,
     208,   556,   215,   563,   209,   570,   143,   210,   576,   573,
     579,   585,   374,   229,   591,   582,   588,   166,   230,   663,
     301,   168,   165,   220,   305,   166,   225,   308,   309,   168,
     188,   116,   313,    10,   166,   316,   165,  1216,   218,  1218,
     177,   178,   179,   180,   181,   182,   183,   184,   185,   186,
     187,   188,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,   199,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   211,  1165,   168,   214,   215,  1922,
    1923,   218,   166,  1320,     3,   222,   678,   679,   355,   244,
     143,   197,   226,   374,   609,   612,  2083,  2084,   165,  2086,
    2087,  2088,  2089,   624,   165,   165,   243,   244,   284,   181,
     168,   182,   249,   192,   116,   166,   166,    12,    14,   256,
     127,  1898,   133,   166,   177,   178,   179,   180,   181,   182,
     183,   184,   185,   186,   187,   188,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     203,   204,   205,   206,   207,   208,   209,   210,   211,   177,
     179,   214,   215,   190,   301,   218,   165,   200,   305,   222,
     245,   308,   309,   267,   269,   252,   313,   273,   271,   316,
     277,   279,   281,   283,   275,   287,   289,   294,   309,   312,
     243,   244,   634,    12,    12,   285,   249,   166,   333,   339,
     336,   202,   633,   256,   348,   647,   202,   370,   382,   386,
     417,   429,   390,   958,   460,   426,   435,   460,   432,   497,
     500,   446,   506,   521,   463,   515,   503,   524,   438,   532,
     602,   618,   166,   518,   197,   174,    10,   374,   624,   414,
     165,   463,   165,   165,   117,   527,   466,   420,   301,   166,
     166,   423,   305,   142,   144,   308,   309,    20,    22,    91,
     313,   175,   198,   316,     0,   196,   203,   292,   197,   316,
     306,   320,   634,   318,   328,   379,  1366,   165,   330,   342,
     366,   393,   395,   388,   357,   647,   404,   285,   377,   408,
     444,   442,   454,   198,   202,   616,   466,   165,   629,   633,
     202,   638,   641,   644,   473,   166,   166,   475,   678,   679,
     166,   166,   116,   197,   481,   165,    13,   483,    54,   325,
       3,   374,     3,   833,   834,   490,     3,   203,   345,   493,
     374,  2007,  2008,   353,   363,   399,  2012,  2013,  2014,  2015,
     203,   372,   399,     3,     4,   410,   368,   406,  1699,     9,
     197,   471,   479,   634,   442,    15,    16,   509,   473,    19,
     615,    21,   444,   622,   412,   481,   647,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   137,  1952,   139,   140,   836,   142,   535,   530,   539,
     146,  1566,   537,   551,   545,   456,   549,   543,   571,   561,
     580,   566,   583,   198,   541,   166,   194,   166,   165,    92,
     166,   167,   166,   547,   170,   168,   592,   130,   166,   166,
     176,   246,   253,   554,  1681,   297,   295,   557,   166,   300,
     559,   165,   334,   166,   337,   340,   564,   827,  1809,  1810,
     445,   443,   349,   356,   447,   468,   126,   568,   476,   129,
     474,   484,   482,   203,   197,   491,   166,   203,   194,   166,
     166,   165,   247,   925,   926,   525,   198,   223,   930,   310,
     577,   227,   165,   574,   165,   231,   232,   634,   940,   941,
     160,   237,   162,   586,   240,    14,    13,   342,   346,   951,
     647,   350,   954,   589,   594,   359,   383,   387,   358,   367,
     391,   415,   596,   424,   427,   436,   596,   418,   198,   433,
     430,   600,  2082,   439,   203,   445,   604,   198,   470,   198,
     606,   474,  1134,   198,   204,   443,   472,   482,   495,   498,
     480,   478,   504,   501,   610,   513,   507,   516,   519,   533,
     522,   528,   298,   925,   926,   197,   166,   613,   930,    93,
     201,   247,   166,   165,   184,   307,   165,   322,   940,   941,
     619,   634,   396,   350,   400,   321,   198,   400,   421,   951,
     625,   448,   954,   621,   647,   203,   455,   631,   203,   457,
     198,   625,  1839,  1840,   636,   198,   266,   203,   268,   623,
     270,   165,   272,   198,   274,   627,   276,   186,   278,  1129,
     280,   642,   282,   182,   284,    14,   286,   398,   245,   402,
     639,   198,    89,   313,   166,   166,   372,   182,   166,   324,
     645,   343,   202,   607,   925,   926,   202,   248,   166,   930,
     202,   202,   202,   202,   166,   165,   487,   617,   166,   940,
     941,  1395,   360,   354,   364,   449,   246,   166,   198,   166,
     951,   331,   442,   954,   471,   471,   442,   479,  1833,   479,
     488,   165,   298,   166,   326,   486,   443,   443,   441,   472,
     452,   472,   480,   480,   453,   166,   454,  1128,     3,     4,
     203,   203,   203,   203,     9,  1147,   197,  1944,   203,   203,
      15,    16,   247,   451,    19,   455,    21,   198,  1147,   152,
     595,   164,  1532,    69,  2045,  1694,  1528,   331,  1130,   326,
    1377,   726,  1213,   315,  1568,   317,  2000,  1165,  1737,  1232,
    1678,  1889,    -1,   577,    -1,    -1,  1116,    -1,    -1,  2100,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1134,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1147,    -1,    -1,   925,   926,
      -1,    -1,    -1,   930,  1164,    -1,    -1,  1887,    -1,    -1,
      -1,    -1,    -1,   940,   941,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   951,    -1,    -1,   954,    -1,    -1,
      -1,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   829,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   160,    -1,   162,    -1,    -1,
     165,    -1,    -1,    -1,    -1,    -1,  1147,    -1,    -1,    -1,
      -1,    -1,   925,   926,    -1,    -1,    -1,   930,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   940,   941,    -1,
      -1,    -1,   197,    -1,    -1,    -1,    -1,   202,   951,   204,
      -1,   954,    -1,    -1,    -1,    -1,    -1,    -1,  1339,    -1,
    1341,   911,    -1,    -1,   650,    -1,   652,   932,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1357,    -1,    -1,    -1,
      -1,   667,   668,    -1,    -1,   932,    -1,    -1,    -1,   244,
      -1,   677,    -1,    -1,   680,    -1,   251,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1328,    -1,
      -1,   266,    -1,   268,    -1,   270,    -1,   272,    -1,   274,
      -1,   276,    -1,   278,    -1,   280,    -1,   282,    -1,   284,
      -1,   286,    -1,   288,    -1,   290,    -1,    -1,   293,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   662,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1147,    -1,    -1,    -1,    -1,    -1,  2106,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   331,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1147,    -1,    -1,    -1,    -1,  1541,
      -1,    -1,    -1,    -1,   686,   687,    -1,   689,    -1,    -1,
      -1,    -1,    -1,   695,   696,   697,   698,   699,   700,   701,
     702,    -1,   704,   705,   706,   707,    -1,    -1,    -1,    -1,
     712,   713,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     722,   723,   724,    -1,    -1,   727,    -1,    -1,    -1,    -1,
     732,   733,    -1,    -1,    -1,    -1,    -1,   739,   740,   741,
     742,   743,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   751,
     752,   753,   754,   755,   756,   757,   758,   759,    -1,  1541,
     762,   763,   764,   765,   766,   767,    -1,    -1,   924,    -1,
     772,    -1,    -1,   775,   776,   777,   778,    -1,    -1,   781,
     782,   783,   784,   785,    -1,   787,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   816,    -1,    -1,    -1,    -1,   821,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1541,  1703,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1815,  1816,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1703,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   662,    -1,    -1,
     942,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1807,    -1,    -1,    -1,
     409,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   984,   985,  1541,    -1,   988,   989,   990,    -1,
      -1,    -1,    -1,   995,   996,    -1,    -1,    -1,    -1,  1001,
    1002,    -1,  1703,    -1,    -1,    -1,    -1,    -1,  1010,  1011,
    1012,  1013,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1022,  1023,  1024,  1025,  1026,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1898,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1069,  1541,  1071,
    1072,  1073,  1074,  1075,  1076,  1077,  1078,  1079,  1080,  1081,
    1082,  1083,  1084,  1085,  1086,  1087,  1088,  1089,  1090,  1091,
    1092,  1093,  1094,  1095,  1096,  1097,  1098,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1112,    -1,    -1,    -1,    -1,  1117,  1118,  1119,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    2060,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1703,   596,    -1,   598,
     599,   600,    -1,   602,   603,   604,   605,   606,   607,   608,
      -1,   610,    -1,    -1,   613,    -1,    -1,   616,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   626,    -1,    -1,
      -1,    -1,    -1,  2045,  2046,    -1,    -1,   636,    -1,    -1,
     639,    -1,    -1,  1195,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1363,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   665,   666,    -1,    -1,
      -1,   670,    -1,    -1,    -1,    -1,   675,    -1,    -1,    -1,
    1703,    -1,    -1,    -1,    -1,    -1,   685,    -1,    -1,   688,
      -1,   690,   691,   692,   693,   694,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   703,    -1,    -1,    -1,    -1,   708,
      -1,    -1,    -1,  2045,  2046,    -1,    -1,    -1,    -1,  1271,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1315,  1316,  1317,  1318,    -1,    -1,  1321,
      -1,  1323,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  2045,  2046,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1535,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   483,   484,    -1,    -1,    -1,    -1,    -1,    -1,  1401,
    1402,  1403,    -1,   495,   496,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   519,   520,    -1,
      -1,    -1,    -1,   525,   526,    -1,    -1,    -1,  1440,  1441,
      -1,    -1,  1444,    -1,    -1,  1447,  1448,    -1,    -1,  1451,
    1452,    -1,    -1,  1455,  1456,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   913,    -1,    -1,    -1,  1470,    -1,
     919,   563,   564,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  2045,  2046,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   950,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1516,   208,   209,   210,   211,   212,
     213,   214,   215,   216,   217,   218,   219,   220,   221,   222,
     223,   224,   225,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,   237,   238,   239,  1549,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1558,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  2046,    -1,    -1,    -1,  1579,    -1,    -1,
      -1,    -1,    -1,  1585,    -1,    -1,  1588,  1589,  1590,  1591,
      -1,  1593,    -1,    -1,    -1,    -1,    -1,    -1,  1600,  1601,
      -1,  1603,  1604,  1605,  1606,  1607,  1608,    -1,    -1,  1611,
    1612,    -1,    -1,    -1,    -1,    -1,  1618,  1619,    -1,    -1,
    1622,  1623,   714,   715,   716,   717,   718,    -1,  1630,  1631,
    1632,  1633,    -1,   725,  1636,  1637,  1638,    -1,  1640,    -1,
    1642,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   746,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   760,    -1,
      -1,  1120,  1121,    -1,  1123,   368,  1125,   769,   770,    -1,
      -1,    -1,   375,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   786,   388,    -1,    -1,    -1,    -1,
      -1,    -1,  1704,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1716,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1173,   817,   818,    -1,    -1,    -1,
    1732,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1745,  1746,    -1,    -1,    -1,    -1,  1751,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1764,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1794,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1802,  1803,  1804,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1832,    -1,  1834,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     553,    -1,    -1,   556,    -1,    -1,    -1,    -1,    -1,  2025,
     563,    -1,    -1,    -1,    -1,    -1,    -1,   570,    -1,    -1,
     573,    -1,    -1,   576,    -1,    -1,   579,    -1,    -1,   582,
      -1,    -1,   585,  1342,  1343,   588,    -1,    -1,   591,    -1,
      -1,   993,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1358,
    1359,    -1,  1004,    -1,  1006,    -1,    -1,    -1,    -1,  1921,
      -1,    -1,    -1,  1372,    -1,  1374,  1375,  1376,    -1,    -1,
      -1,    -1,    -1,    -1,  1383,    -1,  1385,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1040,    -1,
      -1,    -1,    -1,    -1,    -1,  1047,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1977,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1991,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1457,    -1,
    1102,  1103,    -1,    -1,  2016,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  2047,  2048,    -1,    -1,  2051,
    2052,  2053,  2054,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1510,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  2077,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1550,    -1,    -1,    -1,    -1,  1198,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1225,  1226,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1238,  1239,  1240,  1241,
    1242,  1243,  1244,  1245,  1246,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1272,  1273,  1274,  1275,  1276,    -1,  1278,  1279,  1280,  1281,
      -1,  1283,    -1,  1285,     3,     4,    -1,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    -1,
      -1,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,
      -1,    -1,    31,    -1,    33,    -1,    -1,    -1,    37,    -1,
      39,    -1,    41,  1325,    43,    -1,    45,    -1,    47,    -1,
      -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,
      -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,
      -1,    70,  1711,    72,    -1,    74,    -1,    76,    -1,    78,
      -1,    80,    -1,    82,    -1,    84,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1388,    -1,  1390,  1391,
    1392,  1393,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1404,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1420,    -1,
      -1,    -1,    -1,    -1,  1426,    -1,    -1,    -1,    -1,    -1,
      -1,  1433,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   160,   161,   162,    -1,    -1,   165,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1458,    -1,    -1,    -1,
      -1,   180,    -1,  1465,    -1,    -1,  1825,    -1,    -1,    -1,
    1472,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   204,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1517,  1518,  1519,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1901,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1910,    -1,    -1,  1913,    -1,    -1,  1559,    -1,    -1,
      -1,    -1,    -1,    -1,  1566,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1577,    -1,    -1,    -1,  1581,
    1582,  1583,  1584,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1594,  1595,    -1,    -1,  1598,  1599,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1614,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1629,    -1,    -1,
      -1,    -1,    -1,  1635,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     3,     4,    -1,     6,
       7,     8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      17,    -1,    -1,    -1,    21,    -1,    23,    -1,    25,  1671,
    1672,  1673,  1674,    -1,    31,    -1,    33,    -1,    -1,    -1,
      37,    -1,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    -1,    50,    -1,    52,    -1,    54,    -1,    56,
      -1,    58,    -1,    60,    -1,    62,    -1,    64,    -1,    66,
      -1,    68,  2071,    70,    -1,    72,  1718,    74,    -1,    76,
      -1,    78,    -1,    80,    -1,    82,    -1,    84,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   160,   161,   162,    -1,    -1,   165,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1823,    -1,    -1,    -1,    -1,    -1,     3,     4,    -1,
       6,  1833,    -1,     9,    -1,    11,    -1,    13,    -1,    15,
      16,    -1,    -1,    19,    -1,    21,    -1,   204,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1859,  1860,    -1,
      -1,    -1,    -1,    -1,  1866,    -1,    -1,    -1,  1870,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1886,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    88,    -1,    -1,    -1,    -1,    -1,    94,    -1,
      96,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1932,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   125,
     126,    -1,  1954,   129,    -1,    -1,    -1,    -1,   134,    -1,
     136,    -1,    -1,    -1,    -1,    -1,    -1,  1969,  1970,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     156,    -1,    -1,    -1,   160,    -1,   162,   163,   164,   165,
      -1,   167,    -1,    -1,    -1,   171,   172,   173,   174,    -1,
     176,  2003,   178,    -1,   180,    -1,    -1,   183,    -1,   185,
      -1,   187,    -1,   189,    -1,   191,    -1,   193,    -1,   195,
      -1,   197,    -1,   199,    -1,    -1,   202,    -1,   204,    -1,
      -1,  2033,   208,   209,   210,   211,   212,   213,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   241,   242,   243,   244,    -1,
      -1,    -1,   248,   249,   250,   251,    -1,    -1,   254,   255,
     256,   257,   258,   259,   260,   261,   262,   263,   264,   265,
     266,    -1,   268,    -1,   270,    -1,   272,    -1,   274,    -1,
     276,    -1,   278,    -1,   280,    -1,   282,    -1,   284,    -1,
     286,    -1,   288,    -1,   290,    -1,    -1,   293,    -1,    -1,
     296,    -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,   305,
      -1,    -1,   308,    -1,    -1,   311,    -1,    -1,   314,   315,
      -1,   317,    -1,   319,    -1,   321,    -1,   323,    -1,    -1,
      -1,   327,    -1,   329,    -1,   331,   332,    -1,    -1,   335,
      -1,    -1,   338,    -1,    -1,   341,    -1,    -1,   344,    -1,
      -1,   347,    -1,    -1,    -1,   351,   352,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   361,   362,    -1,    -1,   365,
      -1,    -1,   368,   369,    -1,   371,    -1,   373,    -1,   375,
     376,    -1,   378,    -1,    -1,   381,    -1,    -1,    -1,   385,
      -1,    -1,   388,   389,    -1,    -1,   392,    -1,   394,    -1,
      -1,   397,    -1,    -1,    -1,   401,    -1,   403,    -1,   405,
      -1,   407,    -1,   409,    -1,   411,    -1,   413,    -1,    -1,
     416,    -1,    -1,   419,    -1,    -1,   422,    -1,    -1,   425,
      -1,    -1,   428,    -1,    -1,   431,    -1,    -1,   434,    -1,
      -1,   437,    -1,    -1,   440,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   458,   459,    -1,   461,   462,    -1,   464,   465,
      -1,   467,    -1,   469,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   485,
      -1,    -1,    -1,   489,    -1,    -1,   492,    -1,   494,    -1,
     496,    -1,    -1,   499,    -1,    -1,   502,    -1,    -1,   505,
      -1,    -1,   508,    -1,    -1,    -1,   512,    -1,   514,    -1,
      -1,   517,    -1,    -1,   520,    -1,    -1,   523,    -1,    -1,
     526,    -1,    -1,   529,    -1,   531,    -1,    -1,   534,    -1,
     536,    -1,   538,    -1,   540,    -1,   542,    -1,   544,    -1,
     546,    -1,   548,    -1,   550,    -1,   552,   553,    -1,   555,
     556,    -1,   558,    -1,   560,    -1,   562,   563,    -1,   565,
      -1,   567,    -1,   569,   570,    -1,   572,   573,    -1,   575,
     576,    -1,   578,   579,    -1,   581,   582,    -1,   584,   585,
      -1,   587,   588,    -1,   590,   591,    -1,   593,    -1,   595,
      -1,   597,    -1,   599,    -1,   601,    -1,   603,    -1,   605,
      -1,    -1,   608,     3,     4,   611,     6,    -1,   614,     9,
      10,    11,    -1,    13,   620,    15,    16,    -1,   624,    19,
     626,    21,   628,    -1,   630,    -1,   632,    -1,   634,    -1,
      -1,   637,    -1,    -1,   640,    -1,    -1,   643,    -1,    -1,
     646,   647,   648,   649,   650,   651,    -1,   653,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,
      -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   125,   126,    -1,    -1,   129,
      -1,    -1,    -1,    -1,   134,    -1,   136,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,
     160,    -1,   162,   163,   164,   165,   166,   167,    -1,    -1,
      -1,   171,   172,   173,   174,    -1,   176,    -1,   178,    -1,
     180,    -1,   182,   183,    -1,   185,    -1,   187,    -1,   189,
      -1,   191,    -1,   193,    -1,   195,    -1,   197,    -1,   199,
      -1,    -1,   202,    -1,   204,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     240,   241,   242,   243,   244,    -1,    -1,    -1,   248,   249,
     250,   251,    -1,    -1,   254,   255,   256,   257,   258,   259,
     260,   261,   262,   263,   264,   265,   266,    -1,   268,    -1,
     270,    -1,   272,    -1,   274,    -1,   276,    -1,   278,    -1,
     280,    -1,   282,    -1,   284,    -1,   286,    -1,   288,    -1,
     290,    -1,    -1,   293,    -1,    -1,   296,    -1,    -1,   299,
      -1,    -1,    -1,    -1,    -1,   305,    -1,    -1,   308,    -1,
      -1,   311,    -1,    -1,   314,   315,    -1,   317,    -1,   319,
      -1,   321,    -1,   323,    -1,    -1,    -1,   327,    -1,   329,
      -1,   331,   332,    -1,    -1,   335,    -1,    -1,   338,    -1,
      -1,   341,    -1,    -1,   344,    -1,    -1,   347,    -1,    -1,
      -1,   351,   352,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   361,   362,    -1,    -1,   365,    -1,    -1,    -1,   369,
      -1,   371,    -1,   373,    -1,    -1,   376,    -1,   378,    -1,
      -1,   381,    -1,    -1,    -1,   385,    -1,    -1,    -1,   389,
      -1,    -1,   392,    -1,   394,    -1,    -1,   397,    -1,    -1,
      -1,   401,    -1,   403,    -1,   405,    -1,   407,    -1,   409,
      -1,   411,    -1,   413,    -1,    -1,   416,    -1,    -1,   419,
      -1,    -1,   422,    -1,    -1,   425,    -1,    -1,   428,    -1,
      -1,   431,    -1,    -1,   434,    -1,    -1,   437,    -1,    -1,
     440,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     450,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   458,   459,
      -1,   461,   462,    -1,   464,   465,    -1,   467,    -1,   469,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   477,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   485,    -1,    -1,    -1,   489,
      -1,    -1,   492,    -1,   494,    -1,   496,    -1,    -1,   499,
      -1,    -1,   502,    -1,    -1,   505,    -1,    -1,   508,    -1,
      -1,    -1,   512,    -1,   514,    -1,    -1,   517,    -1,    -1,
     520,    -1,    -1,   523,    -1,    -1,   526,    -1,    -1,   529,
      -1,   531,    -1,    -1,   534,    -1,   536,    -1,   538,    -1,
     540,    -1,   542,    -1,   544,    -1,   546,    -1,   548,    -1,
     550,    -1,   552,    -1,    -1,   555,    -1,    -1,   558,    -1,
     560,    -1,   562,    -1,    -1,   565,    -1,   567,    -1,   569,
      -1,    -1,   572,    -1,    -1,   575,    -1,    -1,   578,    -1,
      -1,   581,    -1,    -1,   584,    -1,    -1,   587,    -1,    -1,
     590,    -1,    -1,   593,    -1,   595,    -1,   597,    -1,   599,
      -1,   601,    -1,   603,    -1,   605,    -1,    -1,   608,     3,
       4,   611,     6,    -1,   614,     9,    -1,    11,    -1,    13,
     620,    15,    16,    -1,   624,    19,   626,    21,   628,    -1,
     630,    -1,   632,    -1,   634,    -1,    -1,   637,    -1,    -1,
     640,    -1,    -1,   643,    -1,    -1,   646,   647,   648,   649,
     650,   651,    -1,   653,   654,   655,   656,   657,   658,   659,
     660,   661,   662,   663,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    88,    -1,    -1,    -1,    -1,    -1,
      94,    -1,    96,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,
     134,    -1,   136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   156,    -1,    -1,    -1,   160,    -1,   162,   163,
     164,   165,   166,   167,    -1,    -1,    -1,   171,   172,   173,
     174,    -1,   176,    -1,   178,    -1,   180,    -1,   182,   183,
      -1,   185,    -1,   187,    -1,   189,    -1,   191,    -1,   193,
      -1,   195,    -1,   197,    -1,   199,    -1,    -1,   202,    -1,
     204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   240,   241,   242,   243,
     244,    -1,    -1,    -1,   248,   249,   250,   251,    -1,    -1,
     254,   255,   256,   257,   258,   259,   260,   261,   262,   263,
     264,   265,   266,    -1,   268,    -1,   270,    -1,   272,    -1,
     274,    -1,   276,    -1,   278,    -1,   280,    -1,   282,    -1,
     284,    -1,   286,    -1,   288,    -1,   290,    -1,    -1,   293,
      -1,    -1,   296,    -1,    -1,   299,    -1,    -1,    -1,    -1,
      -1,   305,    -1,    -1,   308,    -1,    -1,   311,    -1,    -1,
     314,   315,    -1,   317,    -1,   319,    -1,   321,    -1,   323,
      -1,    -1,    -1,   327,    -1,   329,    -1,   331,   332,    -1,
      -1,   335,    -1,    -1,   338,    -1,    -1,   341,    -1,    -1,
     344,    -1,    -1,   347,    -1,    -1,    -1,   351,   352,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   361,   362,    -1,
      -1,   365,    -1,    -1,    -1,   369,    -1,   371,    -1,   373,
      -1,    -1,   376,    -1,   378,    -1,    -1,   381,    -1,    -1,
      -1,   385,    -1,    -1,    -1,   389,    -1,    -1,   392,    -1,
     394,    -1,    -1,   397,    -1,    -1,    -1,   401,    -1,   403,
      -1,   405,    -1,   407,    -1,   409,    -1,   411,    -1,   413,
      -1,    -1,   416,    -1,    -1,   419,    -1,    -1,   422,    -1,
      -1,   425,    -1,    -1,   428,    -1,    -1,   431,    -1,    -1,
     434,    -1,    -1,   437,    -1,    -1,   440,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   450,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   458,   459,    -1,   461,   462,    -1,
     464,   465,    -1,   467,    -1,   469,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   477,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   485,    -1,    -1,    -1,   489,    -1,    -1,   492,    -1,
     494,    -1,   496,    -1,    -1,   499,    -1,    -1,   502,    -1,
      -1,   505,    -1,    -1,   508,    -1,    -1,    -1,   512,    -1,
     514,    -1,    -1,   517,    -1,    -1,   520,    -1,    -1,   523,
      -1,    -1,   526,    -1,    -1,   529,    -1,   531,    -1,    -1,
     534,    -1,   536,    -1,   538,    -1,   540,    -1,   542,    -1,
     544,    -1,   546,    -1,   548,    -1,   550,    -1,   552,    -1,
      -1,   555,    -1,    -1,   558,    -1,   560,    -1,   562,    -1,
      -1,   565,    -1,   567,    -1,   569,    -1,    -1,   572,    -1,
      -1,   575,    -1,    -1,   578,    -1,    -1,   581,    -1,    -1,
     584,    -1,    -1,   587,    -1,    -1,   590,    -1,    -1,   593,
      -1,   595,    -1,   597,    -1,   599,    -1,   601,    -1,   603,
      -1,   605,    -1,    -1,   608,     3,     4,   611,     6,    -1,
     614,     9,    10,    11,    -1,    13,   620,    15,    16,    -1,
     624,    19,   626,    21,   628,    -1,   630,    -1,   632,    -1,
     634,    -1,    -1,   637,    -1,    -1,   640,    -1,    -1,   643,
      -1,    -1,   646,   647,   648,   649,   650,   651,    -1,   653,
     654,   655,   656,   657,   658,   659,   660,   661,   662,   663,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      88,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   125,   126,    -1,
      -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,
      -1,    -1,   160,    -1,   162,   163,   164,   165,    -1,   167,
      -1,    -1,    -1,   171,   172,   173,   174,    -1,   176,    -1,
     178,    -1,   180,    -1,   182,   183,    -1,   185,    -1,   187,
      -1,   189,    -1,   191,    -1,   193,    -1,   195,    -1,   197,
      -1,   199,    -1,    -1,   202,    -1,   204,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   240,   241,   242,   243,   244,    -1,    -1,    -1,
     248,   249,   250,   251,    -1,    -1,   254,   255,   256,   257,
     258,   259,   260,   261,   262,   263,   264,   265,   266,    -1,
     268,    -1,   270,    -1,   272,    -1,   274,    -1,   276,    -1,
     278,    -1,   280,    -1,   282,    -1,   284,    -1,   286,    -1,
     288,    -1,   290,    -1,    -1,   293,    -1,    -1,   296,    -1,
      -1,   299,    -1,    -1,    -1,    -1,    -1,   305,    -1,    -1,
     308,    -1,    -1,   311,    -1,    -1,   314,   315,    -1,   317,
      -1,   319,    -1,   321,    -1,   323,    -1,    -1,    -1,   327,
      -1,   329,    -1,   331,   332,    -1,    -1,   335,    -1,    -1,
     338,    -1,    -1,   341,    -1,    -1,   344,    -1,    -1,   347,
      -1,    -1,    -1,   351,   352,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   361,   362,    -1,    -1,   365,    -1,    -1,
      -1,   369,    -1,   371,    -1,   373,    -1,    -1,   376,    -1,
     378,    -1,    -1,   381,    -1,    -1,    -1,   385,    -1,    -1,
      -1,   389,    -1,    -1,   392,    -1,   394,    -1,    -1,   397,
      -1,    -1,    -1,   401,    -1,   403,    -1,   405,    -1,   407,
      -1,   409,    -1,   411,    -1,   413,    -1,    -1,   416,    -1,
      -1,   419,    -1,    -1,   422,    -1,    -1,   425,    -1,    -1,
     428,    -1,    -1,   431,    -1,    -1,   434,    -1,    -1,   437,
      -1,    -1,   440,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   450,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     458,   459,    -1,   461,   462,    -1,   464,   465,    -1,   467,
      -1,   469,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   477,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   485,    -1,    -1,
      -1,   489,    -1,    -1,   492,    -1,   494,    -1,   496,    -1,
      -1,   499,    -1,    -1,   502,    -1,    -1,   505,    -1,    -1,
     508,    -1,    -1,    -1,   512,    -1,   514,    -1,    -1,   517,
      -1,    -1,   520,    -1,    -1,   523,    -1,    -1,   526,    -1,
      -1,   529,    -1,   531,    -1,    -1,   534,    -1,   536,    -1,
     538,    -1,   540,    -1,   542,    -1,   544,    -1,   546,    -1,
     548,    -1,   550,    -1,   552,    -1,    -1,   555,    -1,    -1,
     558,    -1,   560,    -1,   562,    -1,    -1,   565,    -1,   567,
      -1,   569,    -1,    -1,   572,    -1,    -1,   575,    -1,    -1,
     578,    -1,    -1,   581,    -1,    -1,   584,    -1,    -1,   587,
      -1,    -1,   590,    -1,    -1,   593,    -1,   595,    -1,   597,
      -1,   599,    -1,   601,    -1,   603,    -1,   605,    -1,    -1,
     608,     3,     4,   611,     6,    -1,   614,     9,    -1,    11,
      -1,    13,   620,    15,    16,    -1,   624,    19,   626,    21,
     628,    -1,   630,    -1,   632,    -1,   634,    -1,    -1,   637,
      -1,    -1,   640,    -1,    -1,   643,    -1,    -1,   646,   647,
     648,   649,   650,   651,    -1,   653,   654,   655,   656,   657,
     658,   659,   660,   661,   662,   663,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,    -1,    -1,
      -1,    -1,    94,    -1,    96,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   125,   126,    -1,    -1,   129,    -1,    -1,
      -1,    -1,   134,    -1,   136,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,    -1,
     162,   163,   164,   165,    -1,   167,   168,    -1,    -1,   171,
     172,   173,   174,    -1,   176,    -1,   178,    -1,   180,    -1,
      -1,   183,    -1,   185,    -1,   187,    -1,   189,    -1,   191,
      -1,   193,    -1,   195,    -1,   197,    -1,   199,    -1,    -1,
     202,    -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   240,   241,
     242,   243,   244,    -1,    -1,    -1,   248,   249,   250,   251,
      -1,    -1,   254,   255,   256,   257,   258,   259,   260,   261,
     262,   263,   264,   265,   266,    -1,   268,    -1,   270,    -1,
     272,    -1,   274,    -1,   276,    -1,   278,    -1,   280,    -1,
     282,    -1,   284,    -1,   286,    -1,   288,    -1,   290,    -1,
      -1,   293,    -1,    -1,   296,    -1,    -1,   299,    -1,    -1,
      -1,    -1,    -1,   305,    -1,    -1,   308,    -1,    -1,   311,
      -1,    -1,   314,   315,    -1,   317,    -1,   319,    -1,   321,
      -1,   323,    -1,    -1,    -1,   327,    -1,   329,    -1,   331,
     332,    -1,    -1,   335,    -1,    -1,   338,    -1,    -1,   341,
      -1,    -1,   344,    -1,    -1,   347,    -1,    -1,    -1,   351,
     352,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   361,
     362,    -1,    -1,   365,    -1,    -1,    -1,   369,    -1,   371,
      -1,   373,    -1,    -1,   376,    -1,   378,    -1,    -1,   381,
      -1,    -1,    -1,   385,    -1,    -1,    -1,   389,    -1,    -1,
     392,    -1,   394,    -1,    -1,   397,    -1,    -1,    -1,   401,
      -1,   403,    -1,   405,    -1,   407,    -1,   409,    -1,   411,
      -1,   413,    -1,    -1,   416,    -1,    -1,   419,    -1,    -1,
     422,    -1,    -1,   425,    -1,    -1,   428,    -1,    -1,   431,
      -1,    -1,   434,    -1,    -1,   437,    -1,    -1,   440,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   450,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   458,   459,    -1,   461,
     462,    -1,   464,   465,    -1,   467,    -1,   469,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   477,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   485,    -1,    -1,    -1,   489,    -1,    -1,
     492,    -1,   494,    -1,   496,    -1,    -1,   499,    -1,    -1,
     502,    -1,    -1,   505,    -1,    -1,   508,    -1,    -1,    -1,
     512,    -1,   514,    -1,    -1,   517,    -1,    -1,   520,    -1,
      -1,   523,    -1,    -1,   526,    -1,    -1,   529,    -1,   531,
      -1,    -1,   534,    -1,   536,    -1,   538,    -1,   540,    -1,
     542,    -1,   544,    -1,   546,    -1,   548,    -1,   550,    -1,
     552,    -1,    -1,   555,    -1,    -1,   558,    -1,   560,    -1,
     562,    -1,    -1,   565,    -1,   567,    -1,   569,    -1,    -1,
     572,    -1,    -1,   575,    -1,    -1,   578,    -1,    -1,   581,
      -1,    -1,   584,    -1,    -1,   587,    -1,    -1,   590,    -1,
      -1,   593,    -1,   595,    -1,   597,    -1,   599,    -1,   601,
      -1,   603,    -1,   605,    -1,    -1,   608,     3,     4,   611,
       6,    -1,   614,     9,    -1,    11,    12,    13,   620,    15,
      16,    -1,   624,    19,   626,    21,   628,    -1,   630,    -1,
     632,    -1,   634,    -1,    -1,   637,    -1,    -1,   640,    -1,
      -1,   643,    -1,    -1,   646,   647,   648,   649,   650,   651,
      -1,   653,   654,   655,   656,   657,   658,   659,   660,   661,
     662,   663,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    88,    -1,    -1,    -1,    -1,    -1,    94,    -1,
      96,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   125,
     126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,    -1,
     136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     156,    -1,    -1,    -1,   160,    -1,   162,   163,   164,   165,
      -1,   167,    -1,    -1,    -1,   171,   172,   173,   174,    -1,
     176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,
      -1,   187,    -1,   189,    -1,   191,    -1,   193,    -1,   195,
      -1,   197,    -1,   199,    -1,    -1,   202,    -1,   204,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   240,   241,   242,   243,   244,    -1,
      -1,    -1,   248,   249,   250,   251,    -1,    -1,   254,   255,
     256,   257,   258,   259,   260,   261,   262,   263,   264,   265,
     266,    -1,   268,    -1,   270,    -1,   272,    -1,   274,    -1,
     276,    -1,   278,    -1,   280,    -1,   282,    -1,   284,    -1,
     286,    -1,   288,    -1,   290,    -1,    -1,   293,    -1,    -1,
     296,    -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,   305,
      -1,    -1,   308,    -1,    -1,   311,    -1,    -1,   314,   315,
      -1,   317,    -1,   319,    -1,   321,    -1,   323,    -1,    -1,
      -1,   327,    -1,   329,    -1,   331,   332,    -1,    -1,   335,
      -1,    -1,   338,    -1,    -1,   341,    -1,    -1,   344,    -1,
      -1,   347,    -1,    -1,    -1,   351,   352,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   361,   362,    -1,    -1,   365,
      -1,    -1,    -1,   369,    -1,   371,    -1,   373,    -1,    -1,
     376,    -1,   378,    -1,    -1,   381,    -1,    -1,    -1,   385,
      -1,    -1,    -1,   389,    -1,    -1,   392,    -1,   394,    -1,
      -1,   397,    -1,    -1,    -1,   401,    -1,   403,    -1,   405,
      -1,   407,    -1,   409,    -1,   411,    -1,   413,    -1,    -1,
     416,    -1,    -1,   419,    -1,    -1,   422,    -1,    -1,   425,
      -1,    -1,   428,    -1,    -1,   431,    -1,    -1,   434,    -1,
      -1,   437,    -1,    -1,   440,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   458,   459,    -1,   461,   462,    -1,   464,   465,
      -1,   467,    -1,   469,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   485,
      -1,    -1,    -1,   489,    -1,    -1,   492,    -1,   494,    -1,
     496,    -1,    -1,   499,    -1,    -1,   502,    -1,    -1,   505,
      -1,    -1,   508,    -1,    -1,    -1,   512,    -1,   514,    -1,
      -1,   517,    -1,    -1,   520,    -1,    -1,   523,    -1,    -1,
     526,    -1,    -1,   529,    -1,   531,    -1,    -1,   534,    -1,
     536,    -1,   538,    -1,   540,    -1,   542,    -1,   544,    -1,
     546,    -1,   548,    -1,   550,    -1,   552,    -1,    -1,   555,
      -1,    -1,   558,    -1,   560,    -1,   562,    -1,    -1,   565,
      -1,   567,    -1,   569,    -1,    -1,   572,    -1,    -1,   575,
      -1,    -1,   578,    -1,    -1,   581,    -1,    -1,   584,    -1,
      -1,   587,    -1,    -1,   590,    -1,    -1,   593,    -1,   595,
      -1,   597,    -1,   599,    -1,   601,    -1,   603,    -1,   605,
      -1,    -1,   608,    -1,    -1,   611,    -1,    -1,   614,    -1,
      -1,    -1,    -1,    -1,   620,    -1,    -1,    -1,   624,    -1,
     626,    -1,   628,    -1,   630,    -1,   632,    -1,   634,    -1,
      -1,   637,    -1,    -1,   640,    -1,    -1,   643,    -1,    -1,
     646,   647,   648,   649,   650,   651,    -1,   653,   654,   655,
     656,   657,   658,   659,   660,   661,   662,   663,     3,     4,
      -1,     6,    -1,    -1,     9,    -1,    11,    -1,    13,    14,
      15,    16,    -1,    -1,    19,    -1,    21,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    88,    -1,    -1,    -1,    -1,    -1,    94,
      -1,    96,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,
      -1,   136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   156,    -1,    -1,    -1,   160,    -1,   162,   163,   164,
     165,    -1,   167,    -1,    -1,    -1,   171,   172,   173,   174,
      -1,   176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,
     185,    -1,   187,    -1,   189,    -1,   191,    -1,   193,    -1,
     195,    -1,   197,    -1,   199,    -1,    -1,   202,    -1,   204,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   240,   241,   242,   243,   244,
      -1,    -1,    -1,   248,   249,   250,   251,    -1,    -1,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,    -1,   268,    -1,   270,    -1,   272,    -1,   274,
      -1,   276,    -1,   278,    -1,   280,    -1,   282,    -1,   284,
      -1,   286,    -1,   288,    -1,   290,    -1,    -1,   293,    -1,
      -1,   296,    -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,
     305,    -1,    -1,   308,    -1,    -1,   311,    -1,    -1,   314,
     315,    -1,   317,    -1,   319,    -1,   321,    -1,   323,    -1,
      -1,    -1,   327,    -1,   329,    -1,   331,   332,    -1,    -1,
     335,    -1,    -1,   338,    -1,    -1,   341,    -1,    -1,   344,
      -1,    -1,   347,    -1,    -1,    -1,   351,   352,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   361,   362,    -1,    -1,
     365,    -1,    -1,    -1,   369,    -1,   371,    -1,   373,    -1,
      -1,   376,    -1,   378,    -1,    -1,   381,    -1,    -1,    -1,
     385,    -1,    -1,    -1,   389,    -1,    -1,   392,    -1,   394,
      -1,    -1,   397,    -1,    -1,    -1,   401,    -1,   403,    -1,
     405,    -1,   407,    -1,   409,    -1,   411,    -1,   413,    -1,
      -1,   416,    -1,    -1,   419,    -1,    -1,   422,    -1,    -1,
     425,    -1,    -1,   428,    -1,    -1,   431,    -1,    -1,   434,
      -1,    -1,   437,    -1,    -1,   440,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   458,   459,    -1,   461,   462,    -1,   464,
     465,    -1,   467,    -1,   469,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     485,    -1,    -1,    -1,   489,    -1,    -1,   492,    -1,   494,
      -1,   496,    -1,    -1,   499,    -1,    -1,   502,    -1,    -1,
     505,    -1,    -1,   508,    -1,    -1,    -1,   512,    -1,   514,
      -1,    -1,   517,    -1,    -1,   520,    -1,    -1,   523,    -1,
      -1,   526,    -1,    -1,   529,    -1,   531,    -1,    -1,   534,
      -1,   536,    -1,   538,    -1,   540,    -1,   542,    -1,   544,
      -1,   546,    -1,   548,    -1,   550,    -1,   552,    -1,    -1,
     555,    -1,    -1,   558,    -1,   560,    -1,   562,    -1,    -1,
     565,    -1,   567,    -1,   569,    -1,    -1,   572,    -1,    -1,
     575,    -1,    -1,   578,    -1,    -1,   581,    -1,    -1,   584,
      -1,    -1,   587,    -1,    -1,   590,    -1,    -1,   593,    -1,
     595,    -1,   597,    -1,   599,    -1,   601,    -1,   603,    -1,
     605,    -1,    -1,   608,     3,     4,   611,     6,    -1,   614,
       9,    -1,    11,    -1,    13,   620,    15,    16,    -1,   624,
      19,   626,    21,   628,    -1,   630,    -1,   632,    -1,   634,
      -1,    -1,   637,    -1,    -1,   640,    -1,    -1,   643,    -1,
      -1,   646,   647,   648,   649,   650,   651,    -1,   653,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   125,   126,    -1,    -1,
     129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,
      -1,   160,    -1,   162,   163,   164,   165,   166,   167,    -1,
      -1,    -1,   171,   172,   173,   174,    -1,   176,    -1,   178,
      -1,   180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,
     189,    -1,   191,    -1,   193,    -1,   195,    -1,   197,    -1,
     199,    -1,    -1,   202,    -1,   204,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   240,   241,   242,   243,   244,    -1,    -1,    -1,   248,
     249,   250,   251,    -1,    -1,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   263,   264,   265,   266,    -1,   268,
      -1,   270,    -1,   272,    -1,   274,    -1,   276,    -1,   278,
      -1,   280,    -1,   282,    -1,   284,    -1,   286,    -1,   288,
      -1,   290,    -1,    -1,   293,    -1,    -1,   296,    -1,    -1,
     299,    -1,    -1,    -1,    -1,    -1,   305,    -1,    -1,   308,
      -1,    -1,   311,    -1,    -1,   314,   315,    -1,   317,    -1,
     319,    -1,   321,    -1,   323,    -1,    -1,    -1,   327,    -1,
     329,    -1,   331,   332,    -1,    -1,   335,    -1,    -1,   338,
      -1,    -1,   341,    -1,    -1,   344,    -1,    -1,   347,    -1,
      -1,    -1,   351,   352,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   361,   362,    -1,    -1,   365,    -1,    -1,    -1,
     369,    -1,   371,    -1,   373,    -1,    -1,   376,    -1,   378,
      -1,    -1,   381,    -1,    -1,    -1,   385,    -1,    -1,    -1,
     389,    -1,    -1,   392,    -1,   394,    -1,    -1,   397,    -1,
      -1,    -1,   401,    -1,   403,    -1,   405,    -1,   407,    -1,
     409,    -1,   411,    -1,   413,    -1,    -1,   416,    -1,    -1,
     419,    -1,    -1,   422,    -1,    -1,   425,    -1,    -1,   428,
      -1,    -1,   431,    -1,    -1,   434,    -1,    -1,   437,    -1,
      -1,   440,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   450,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   458,
     459,    -1,   461,   462,    -1,   464,   465,    -1,   467,    -1,
     469,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   477,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   485,    -1,    -1,    -1,
     489,    -1,    -1,   492,    -1,   494,    -1,   496,    -1,    -1,
     499,    -1,    -1,   502,    -1,    -1,   505,    -1,    -1,   508,
      -1,    -1,    -1,   512,    -1,   514,    -1,    -1,   517,    -1,
      -1,   520,    -1,    -1,   523,    -1,    -1,   526,    -1,    -1,
     529,    -1,   531,    -1,    -1,   534,    -1,   536,    -1,   538,
      -1,   540,    -1,   542,    -1,   544,    -1,   546,    -1,   548,
      -1,   550,    -1,   552,    -1,    -1,   555,    -1,    -1,   558,
      -1,   560,    -1,   562,    -1,    -1,   565,    -1,   567,    -1,
     569,    -1,    -1,   572,    -1,    -1,   575,    -1,    -1,   578,
      -1,    -1,   581,    -1,    -1,   584,    -1,    -1,   587,    -1,
      -1,   590,    -1,    -1,   593,    -1,   595,    -1,   597,    -1,
     599,    -1,   601,    -1,   603,    -1,   605,    -1,    -1,   608,
       3,     4,   611,     6,    -1,   614,     9,    -1,    11,    -1,
      13,   620,    15,    16,    -1,   624,    19,   626,    21,   628,
      -1,   630,    -1,   632,    -1,   634,    -1,    -1,   637,    -1,
      -1,   640,    -1,    -1,   643,    -1,    -1,   646,   647,   648,
     649,   650,   651,    -1,   653,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    88,    -1,    -1,    -1,    -1,
      -1,    94,    -1,    96,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   125,   126,    -1,    -1,   129,    -1,    -1,    -1,
      -1,   134,    -1,   136,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   156,    -1,    -1,    -1,   160,    -1,   162,
     163,   164,   165,    -1,   167,    -1,    -1,    -1,   171,   172,
     173,   174,    -1,   176,    -1,   178,    -1,   180,    -1,    -1,
     183,    -1,   185,    -1,   187,    -1,   189,    -1,   191,    -1,
     193,    -1,   195,    -1,   197,    -1,   199,    -1,    -1,   202,
      -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   240,   241,   242,
     243,   244,   245,    -1,    -1,   248,   249,   250,   251,    -1,
      -1,   254,   255,   256,   257,   258,   259,   260,   261,   262,
     263,   264,   265,   266,    -1,   268,    -1,   270,    -1,   272,
      -1,   274,    -1,   276,    -1,   278,    -1,   280,    -1,   282,
      -1,   284,    -1,   286,    -1,   288,    -1,   290,    -1,    -1,
     293,    -1,    -1,   296,    -1,    -1,   299,    -1,    -1,    -1,
      -1,    -1,   305,    -1,    -1,   308,    -1,    -1,   311,    -1,
      -1,   314,   315,    -1,   317,    -1,   319,    -1,   321,    -1,
     323,    -1,    -1,    -1,   327,    -1,   329,    -1,   331,   332,
      -1,    -1,   335,    -1,    -1,   338,    -1,    -1,   341,    -1,
      -1,   344,    -1,    -1,   347,    -1,    -1,    -1,   351,   352,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   361,   362,
      -1,    -1,   365,    -1,    -1,    -1,   369,    -1,   371,    -1,
     373,    -1,    -1,   376,    -1,   378,    -1,    -1,   381,    -1,
      -1,    -1,   385,    -1,    -1,    -1,   389,    -1,    -1,   392,
      -1,   394,    -1,    -1,   397,    -1,    -1,    -1,   401,    -1,
     403,    -1,   405,    -1,   407,    -1,   409,    -1,   411,    -1,
     413,    -1,    -1,   416,    -1,    -1,   419,    -1,    -1,   422,
      -1,    -1,   425,    -1,    -1,   428,    -1,    -1,   431,    -1,
      -1,   434,    -1,    -1,   437,    -1,    -1,   440,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   450,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   458,   459,    -1,   461,   462,
      -1,   464,   465,    -1,   467,    -1,   469,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   477,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   485,    -1,    -1,    -1,   489,    -1,    -1,   492,
      -1,   494,    -1,   496,    -1,    -1,   499,    -1,    -1,   502,
      -1,    -1,   505,    -1,    -1,   508,    -1,    -1,    -1,   512,
      -1,   514,    -1,    -1,   517,    -1,    -1,   520,    -1,    -1,
     523,    -1,    -1,   526,    -1,    -1,   529,    -1,   531,    -1,
      -1,   534,    -1,   536,    -1,   538,    -1,   540,    -1,   542,
      -1,   544,    -1,   546,    -1,   548,    -1,   550,    -1,   552,
      -1,    -1,   555,    -1,    -1,   558,    -1,   560,    -1,   562,
      -1,    -1,   565,    -1,   567,    -1,   569,    -1,    -1,   572,
      -1,    -1,   575,    -1,    -1,   578,    -1,    -1,   581,    -1,
      -1,   584,    -1,    -1,   587,    -1,    -1,   590,    -1,    -1,
     593,    -1,   595,    -1,   597,    -1,   599,    -1,   601,    -1,
     603,    -1,   605,    -1,    -1,   608,     3,     4,   611,     6,
      -1,   614,     9,    -1,    11,    -1,    13,   620,    15,    16,
      -1,   624,    19,   626,    21,   628,    -1,   630,    -1,   632,
      -1,   634,    -1,    -1,   637,    -1,    -1,   640,    -1,    -1,
     643,    -1,    -1,   646,   647,   648,   649,   650,   651,    -1,
     653,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   125,   126,
      -1,    -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,
      -1,    -1,    -1,   160,    -1,   162,   163,   164,   165,    -1,
     167,    -1,    -1,    -1,   171,   172,   173,   174,    -1,   176,
      -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,    -1,
     187,    -1,   189,    -1,   191,    -1,   193,    -1,   195,    -1,
     197,    -1,   199,    -1,    -1,   202,    -1,   204,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   240,   241,   242,   243,   244,    -1,    -1,
      -1,   248,   249,   250,   251,   252,    -1,   254,   255,   256,
     257,   258,   259,   260,   261,   262,   263,   264,   265,   266,
      -1,   268,    -1,   270,    -1,   272,    -1,   274,    -1,   276,
      -1,   278,    -1,   280,    -1,   282,    -1,   284,    -1,   286,
      -1,   288,    -1,   290,    -1,    -1,   293,    -1,    -1,   296,
      -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,   305,    -1,
      -1,   308,    -1,    -1,   311,    -1,    -1,   314,   315,    -1,
     317,    -1,   319,    -1,   321,    -1,   323,    -1,    -1,    -1,
     327,    -1,   329,    -1,   331,   332,    -1,    -1,   335,    -1,
      -1,   338,    -1,    -1,   341,    -1,    -1,   344,    -1,    -1,
     347,    -1,    -1,    -1,   351,   352,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   361,   362,    -1,    -1,   365,    -1,
      -1,    -1,   369,    -1,   371,    -1,   373,    -1,    -1,   376,
      -1,   378,    -1,    -1,   381,    -1,    -1,    -1,   385,    -1,
      -1,    -1,   389,    -1,    -1,   392,    -1,   394,    -1,    -1,
     397,    -1,    -1,    -1,   401,    -1,   403,    -1,   405,    -1,
     407,    -1,   409,    -1,   411,    -1,   413,    -1,    -1,   416,
      -1,    -1,   419,    -1,    -1,   422,    -1,    -1,   425,    -1,
      -1,   428,    -1,    -1,   431,    -1,    -1,   434,    -1,    -1,
     437,    -1,    -1,   440,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   458,   459,    -1,   461,   462,    -1,   464,   465,    -1,
     467,    -1,   469,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   485,    -1,
      -1,    -1,   489,    -1,    -1,   492,    -1,   494,    -1,   496,
      -1,    -1,   499,    -1,    -1,   502,    -1,    -1,   505,    -1,
      -1,   508,    -1,    -1,    -1,   512,    -1,   514,    -1,    -1,
     517,    -1,    -1,   520,    -1,    -1,   523,    -1,    -1,   526,
      -1,    -1,   529,    -1,   531,    -1,    -1,   534,    -1,   536,
      -1,   538,    -1,   540,    -1,   542,    -1,   544,    -1,   546,
      -1,   548,    -1,   550,    -1,   552,    -1,    -1,   555,    -1,
      -1,   558,    -1,   560,    -1,   562,    -1,    -1,   565,    -1,
     567,    -1,   569,    -1,    -1,   572,    -1,    -1,   575,    -1,
      -1,   578,    -1,    -1,   581,    -1,    -1,   584,    -1,    -1,
     587,    -1,    -1,   590,    -1,    -1,   593,    -1,   595,    -1,
     597,    -1,   599,    -1,   601,    -1,   603,    -1,   605,    -1,
      -1,   608,     3,     4,   611,     6,    -1,   614,     9,    -1,
      11,    -1,    13,   620,    15,    16,    -1,   624,    19,   626,
      21,   628,    -1,   630,    -1,   632,    -1,   634,    -1,    -1,
     637,    -1,    -1,   640,    -1,    -1,   643,    -1,    -1,   646,
     647,   648,   649,   650,   651,    -1,   653,   654,   655,   656,
     657,   658,   659,   660,   661,   662,   663,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,    -1,
      -1,    -1,    -1,    94,    -1,    96,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   125,   126,    -1,    -1,   129,    -1,
      -1,    -1,    -1,   134,    -1,   136,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,
      -1,   162,   163,   164,   165,    -1,   167,    -1,    -1,    -1,
     171,   172,   173,   174,    -1,   176,    -1,   178,    -1,   180,
      -1,    -1,   183,    -1,   185,    -1,   187,    -1,   189,    -1,
     191,    -1,   193,    -1,   195,    -1,   197,    -1,   199,    -1,
      -1,   202,    -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   240,
     241,   242,   243,   244,    -1,    -1,    -1,   248,   249,   250,
     251,    -1,    -1,   254,   255,   256,   257,   258,   259,   260,
     261,   262,   263,   264,   265,   266,    -1,   268,    -1,   270,
      -1,   272,    -1,   274,    -1,   276,    -1,   278,    -1,   280,
      -1,   282,   283,   284,    -1,   286,    -1,   288,    -1,   290,
      -1,    -1,   293,    -1,    -1,   296,    -1,    -1,   299,    -1,
      -1,    -1,    -1,    -1,   305,    -1,    -1,   308,    -1,    -1,
     311,    -1,    -1,   314,   315,    -1,   317,    -1,   319,    -1,
     321,    -1,   323,    -1,    -1,    -1,   327,    -1,   329,    -1,
     331,   332,    -1,    -1,   335,    -1,    -1,   338,    -1,    -1,
     341,    -1,    -1,   344,    -1,    -1,   347,    -1,    -1,    -1,
     351,   352,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     361,   362,    -1,    -1,   365,    -1,    -1,    -1,   369,    -1,
     371,    -1,   373,    -1,    -1,   376,    -1,   378,    -1,    -1,
     381,    -1,    -1,    -1,   385,    -1,    -1,    -1,   389,    -1,
      -1,   392,    -1,   394,    -1,    -1,   397,    -1,    -1,    -1,
     401,    -1,   403,    -1,   405,    -1,   407,    -1,   409,    -1,
     411,    -1,   413,    -1,    -1,   416,    -1,    -1,   419,    -1,
      -1,   422,    -1,    -1,   425,    -1,    -1,   428,    -1,    -1,
     431,    -1,    -1,   434,    -1,    -1,   437,    -1,    -1,   440,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   450,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   458,   459,    -1,
     461,   462,    -1,   464,   465,    -1,   467,    -1,   469,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   477,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   485,    -1,    -1,    -1,   489,    -1,
      -1,   492,    -1,   494,    -1,   496,    -1,    -1,   499,    -1,
      -1,   502,    -1,    -1,   505,    -1,    -1,   508,    -1,    -1,
      -1,   512,    -1,   514,    -1,    -1,   517,    -1,    -1,   520,
      -1,    -1,   523,    -1,    -1,   526,    -1,    -1,   529,    -1,
     531,    -1,    -1,   534,    -1,   536,    -1,   538,    -1,   540,
      -1,   542,    -1,   544,    -1,   546,    -1,   548,    -1,   550,
      -1,   552,    -1,    -1,   555,    -1,    -1,   558,    -1,   560,
      -1,   562,    -1,    -1,   565,    -1,   567,    -1,   569,    -1,
      -1,   572,    -1,    -1,   575,    -1,    -1,   578,    -1,    -1,
     581,    -1,    -1,   584,    -1,    -1,   587,    -1,    -1,   590,
      -1,    -1,   593,    -1,   595,    -1,   597,    -1,   599,    -1,
     601,    -1,   603,    -1,   605,    -1,    -1,   608,     3,     4,
     611,     6,    -1,   614,     9,    -1,    11,    -1,    13,   620,
      15,    16,    -1,   624,    19,   626,    21,   628,    -1,   630,
      -1,   632,    -1,   634,    -1,    -1,   637,    -1,    -1,   640,
      -1,    -1,   643,    -1,    -1,   646,   647,   648,   649,   650,
     651,    -1,   653,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    88,    -1,    -1,    -1,    -1,    -1,    94,
      -1,    96,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,
      -1,   136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   156,    -1,    -1,    -1,   160,    -1,   162,   163,   164,
     165,    -1,   167,    -1,    -1,    -1,   171,   172,   173,   174,
      -1,   176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,
     185,    -1,   187,    -1,   189,    -1,   191,    -1,   193,    -1,
     195,    -1,   197,    -1,   199,    -1,    -1,   202,    -1,   204,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   240,   241,   242,   243,   244,
      -1,    -1,    -1,   248,   249,   250,   251,    -1,    -1,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,    -1,   268,    -1,   270,    -1,   272,    -1,   274,
      -1,   276,    -1,   278,    -1,   280,    -1,   282,    -1,   284,
      -1,   286,    -1,   288,    -1,   290,    -1,    -1,   293,   294,
      -1,   296,    -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,
     305,    -1,    -1,   308,    -1,    -1,   311,    -1,    -1,   314,
     315,    -1,   317,    -1,   319,    -1,   321,    -1,   323,    -1,
      -1,    -1,   327,    -1,   329,    -1,   331,   332,    -1,    -1,
     335,    -1,    -1,   338,    -1,    -1,   341,    -1,    -1,   344,
      -1,    -1,   347,    -1,    -1,    -1,   351,   352,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   361,   362,    -1,    -1,
     365,    -1,    -1,    -1,   369,    -1,   371,    -1,   373,    -1,
      -1,   376,    -1,   378,    -1,    -1,   381,    -1,    -1,    -1,
     385,    -1,    -1,    -1,   389,    -1,    -1,   392,    -1,   394,
      -1,    -1,   397,    -1,    -1,    -1,   401,    -1,   403,    -1,
     405,    -1,   407,    -1,   409,    -1,   411,    -1,   413,    -1,
      -1,   416,    -1,    -1,   419,    -1,    -1,   422,    -1,    -1,
     425,    -1,    -1,   428,    -1,    -1,   431,    -1,    -1,   434,
      -1,    -1,   437,    -1,    -1,   440,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   458,   459,    -1,   461,   462,    -1,   464,
     465,    -1,   467,    -1,   469,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     485,    -1,    -1,    -1,   489,    -1,    -1,   492,    -1,   494,
      -1,   496,    -1,    -1,   499,    -1,    -1,   502,    -1,    -1,
     505,    -1,    -1,   508,    -1,    -1,    -1,   512,    -1,   514,
      -1,    -1,   517,    -1,    -1,   520,    -1,    -1,   523,    -1,
      -1,   526,    -1,    -1,   529,    -1,   531,    -1,    -1,   534,
      -1,   536,    -1,   538,    -1,   540,    -1,   542,    -1,   544,
      -1,   546,    -1,   548,    -1,   550,    -1,   552,    -1,    -1,
     555,    -1,    -1,   558,    -1,   560,    -1,   562,    -1,    -1,
     565,    -1,   567,    -1,   569,    -1,    -1,   572,    -1,    -1,
     575,    -1,    -1,   578,    -1,    -1,   581,    -1,    -1,   584,
      -1,    -1,   587,    -1,    -1,   590,    -1,    -1,   593,    -1,
     595,    -1,   597,    -1,   599,    -1,   601,    -1,   603,    -1,
     605,    -1,    -1,   608,     3,     4,   611,     6,    -1,   614,
       9,    -1,    11,    -1,    13,   620,    15,    16,    -1,   624,
      19,   626,    21,   628,    -1,   630,    -1,   632,    -1,   634,
      -1,    -1,   637,    -1,    -1,   640,    -1,    -1,   643,    -1,
      -1,   646,   647,   648,   649,   650,   651,    -1,   653,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   125,   126,    -1,    -1,
     129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,
      -1,   160,    -1,   162,   163,   164,   165,    -1,   167,    -1,
      -1,    -1,   171,   172,   173,   174,    -1,   176,    -1,   178,
      -1,   180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,
     189,    -1,   191,    -1,   193,    -1,   195,    -1,   197,    -1,
     199,    -1,    -1,   202,    -1,   204,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   240,   241,   242,   243,   244,    -1,    -1,    -1,   248,
     249,   250,   251,    -1,   253,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   263,   264,   265,   266,    -1,   268,
      -1,   270,    -1,   272,    -1,   274,    -1,   276,    -1,   278,
      -1,   280,    -1,   282,    -1,   284,    -1,   286,    -1,   288,
      -1,   290,    -1,    -1,   293,    -1,    -1,   296,    -1,    -1,
     299,    -1,    -1,    -1,    -1,    -1,   305,    -1,    -1,   308,
      -1,    -1,   311,    -1,    -1,   314,   315,    -1,   317,    -1,
     319,    -1,   321,    -1,   323,    -1,    -1,    -1,   327,    -1,
     329,    -1,   331,   332,    -1,    -1,   335,    -1,    -1,   338,
      -1,    -1,   341,    -1,    -1,   344,    -1,    -1,   347,    -1,
      -1,    -1,   351,   352,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   361,   362,    -1,    -1,   365,    -1,    -1,    -1,
     369,    -1,   371,    -1,   373,    -1,    -1,   376,    -1,   378,
      -1,    -1,   381,    -1,    -1,    -1,   385,    -1,    -1,    -1,
     389,    -1,    -1,   392,    -1,   394,    -1,    -1,   397,    -1,
      -1,    -1,   401,    -1,   403,    -1,   405,    -1,   407,    -1,
     409,    -1,   411,    -1,   413,    -1,    -1,   416,    -1,    -1,
     419,    -1,    -1,   422,    -1,    -1,   425,    -1,    -1,   428,
      -1,    -1,   431,    -1,    -1,   434,    -1,    -1,   437,    -1,
      -1,   440,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   450,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   458,
     459,    -1,   461,   462,    -1,   464,   465,    -1,   467,    -1,
     469,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   477,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   485,    -1,    -1,    -1,
     489,    -1,    -1,   492,    -1,   494,    -1,   496,    -1,    -1,
     499,    -1,    -1,   502,    -1,    -1,   505,    -1,    -1,   508,
      -1,    -1,    -1,   512,    -1,   514,    -1,    -1,   517,    -1,
      -1,   520,    -1,    -1,   523,    -1,    -1,   526,    -1,    -1,
     529,    -1,   531,    -1,    -1,   534,    -1,   536,    -1,   538,
      -1,   540,    -1,   542,    -1,   544,    -1,   546,    -1,   548,
      -1,   550,    -1,   552,    -1,    -1,   555,    -1,    -1,   558,
      -1,   560,    -1,   562,    -1,    -1,   565,    -1,   567,    -1,
     569,    -1,    -1,   572,    -1,    -1,   575,    -1,    -1,   578,
      -1,    -1,   581,    -1,    -1,   584,    -1,    -1,   587,    -1,
      -1,   590,    -1,    -1,   593,    -1,   595,    -1,   597,    -1,
     599,    -1,   601,    -1,   603,    -1,   605,    -1,    -1,   608,
       3,     4,   611,     6,    -1,   614,     9,    -1,    11,    -1,
      13,   620,    15,    16,    -1,   624,    19,   626,    21,   628,
      -1,   630,    -1,   632,    -1,   634,    -1,    -1,   637,    -1,
      -1,   640,    -1,    -1,   643,    -1,    -1,   646,   647,   648,
     649,   650,   651,    -1,   653,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    88,    -1,    -1,    -1,    -1,
      -1,    94,    -1,    96,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   125,   126,    -1,    -1,   129,    -1,    -1,    -1,
      -1,   134,    -1,   136,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   156,    -1,    -1,    -1,   160,    -1,   162,
     163,   164,   165,    -1,   167,    -1,    -1,    -1,   171,   172,
     173,   174,    -1,   176,    -1,   178,    -1,   180,    -1,    -1,
     183,    -1,   185,    -1,   187,    -1,   189,    -1,   191,    -1,
     193,    -1,   195,    -1,   197,    -1,   199,    -1,    -1,   202,
      -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   240,   241,   242,
     243,   244,    -1,    -1,    -1,   248,   249,   250,   251,    -1,
      -1,   254,   255,   256,   257,   258,   259,   260,   261,   262,
     263,   264,   265,   266,    -1,   268,    -1,   270,    -1,   272,
      -1,   274,    -1,   276,    -1,   278,    -1,   280,    -1,   282,
      -1,   284,    -1,   286,    -1,   288,    -1,   290,    -1,    -1,
     293,    -1,   295,   296,    -1,    -1,   299,    -1,    -1,    -1,
      -1,    -1,   305,    -1,    -1,   308,    -1,    -1,   311,    -1,
      -1,   314,   315,    -1,   317,    -1,   319,    -1,   321,    -1,
     323,    -1,    -1,    -1,   327,    -1,   329,    -1,   331,   332,
      -1,    -1,   335,    -1,    -1,   338,    -1,    -1,   341,    -1,
      -1,   344,    -1,    -1,   347,    -1,    -1,    -1,   351,   352,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   361,   362,
      -1,    -1,   365,    -1,    -1,    -1,   369,    -1,   371,    -1,
     373,    -1,    -1,   376,    -1,   378,    -1,    -1,   381,    -1,
      -1,    -1,   385,    -1,    -1,    -1,   389,    -1,    -1,   392,
      -1,   394,    -1,    -1,   397,    -1,    -1,    -1,   401,    -1,
     403,    -1,   405,    -1,   407,    -1,   409,    -1,   411,    -1,
     413,    -1,    -1,   416,    -1,    -1,   419,    -1,    -1,   422,
      -1,    -1,   425,    -1,    -1,   428,    -1,    -1,   431,    -1,
      -1,   434,    -1,    -1,   437,    -1,    -1,   440,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   450,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   458,   459,    -1,   461,   462,
      -1,   464,   465,    -1,   467,    -1,   469,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   477,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   485,    -1,    -1,    -1,   489,    -1,    -1,   492,
      -1,   494,    -1,   496,    -1,    -1,   499,    -1,    -1,   502,
      -1,    -1,   505,    -1,    -1,   508,    -1,    -1,    -1,   512,
      -1,   514,    -1,    -1,   517,    -1,    -1,   520,    -1,    -1,
     523,    -1,    -1,   526,    -1,    -1,   529,    -1,   531,    -1,
      -1,   534,    -1,   536,    -1,   538,    -1,   540,    -1,   542,
      -1,   544,    -1,   546,    -1,   548,    -1,   550,    -1,   552,
      -1,    -1,   555,    -1,    -1,   558,    -1,   560,    -1,   562,
      -1,    -1,   565,    -1,   567,    -1,   569,    -1,    -1,   572,
      -1,    -1,   575,    -1,    -1,   578,    -1,    -1,   581,    -1,
      -1,   584,    -1,    -1,   587,    -1,    -1,   590,    -1,    -1,
     593,    -1,   595,    -1,   597,    -1,   599,    -1,   601,    -1,
     603,    -1,   605,    -1,    -1,   608,     3,     4,   611,     6,
      -1,   614,     9,    -1,    11,    -1,    13,   620,    15,    16,
      -1,   624,    19,   626,    21,   628,    -1,   630,    -1,   632,
      -1,   634,    -1,    -1,   637,    -1,    -1,   640,    -1,    -1,
     643,    -1,    -1,   646,   647,   648,   649,   650,   651,    -1,
     653,   654,   655,   656,   657,   658,   659,   660,   661,   662,
     663,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   125,   126,
      -1,    -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,
      -1,    -1,    -1,   160,    -1,   162,   163,   164,   165,    -1,
     167,    -1,    -1,    -1,   171,   172,   173,   174,    -1,   176,
      -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,    -1,
     187,    -1,   189,    -1,   191,    -1,   193,    -1,   195,    -1,
     197,    -1,   199,    -1,    -1,   202,    -1,   204,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   240,   241,   242,   243,   244,    -1,    -1,
      -1,   248,   249,   250,   251,    -1,    -1,   254,   255,   256,
     257,   258,   259,   260,   261,   262,   263,   264,   265,   266,
      -1,   268,    -1,   270,    -1,   272,    -1,   274,    -1,   276,
      -1,   278,    -1,   280,    -1,   282,    -1,   284,    -1,   286,
      -1,   288,    -1,   290,    -1,    -1,   293,    -1,    -1,   296,
      -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,   305,    -1,
      -1,   308,    -1,    -1,   311,    -1,    -1,   314,   315,    -1,
     317,    -1,   319,    -1,   321,    -1,   323,    -1,    -1,    -1,
     327,    -1,   329,    -1,   331,   332,    -1,    -1,   335,    -1,
      -1,   338,    -1,    -1,   341,    -1,    -1,   344,    -1,    -1,
     347,    -1,    -1,    -1,   351,   352,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   361,   362,    -1,    -1,   365,    -1,
      -1,    -1,   369,    -1,   371,    -1,   373,    -1,    -1,   376,
      -1,   378,    -1,    -1,   381,    -1,    -1,    -1,   385,    -1,
      -1,    -1,   389,    -1,    -1,   392,    -1,   394,    -1,    -1,
     397,    -1,    -1,    -1,   401,    -1,   403,    -1,   405,    -1,
     407,    -1,   409,    -1,   411,    -1,   413,    -1,    -1,   416,
      -1,    -1,   419,    -1,    -1,   422,    -1,    -1,   425,    -1,
      -1,   428,    -1,    -1,   431,    -1,    -1,   434,    -1,    -1,
     437,    -1,    -1,   440,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   458,   459,    -1,   461,   462,    -1,   464,   465,    -1,
     467,    -1,   469,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   485,    -1,
      -1,    -1,   489,    -1,   491,   492,    -1,   494,    -1,   496,
      -1,    -1,   499,    -1,    -1,   502,    -1,    -1,   505,    -1,
      -1,   508,    -1,    -1,    -1,   512,    -1,   514,    -1,    -1,
     517,    -1,    -1,   520,    -1,    -1,   523,    -1,    -1,   526,
      -1,    -1,   529,    -1,   531,    -1,    -1,   534,    -1,   536,
      -1,   538,    -1,   540,    -1,   542,    -1,   544,    -1,   546,
      -1,   548,    -1,   550,    -1,   552,    -1,    -1,   555,    -1,
      -1,   558,    -1,   560,    -1,   562,    -1,    -1,   565,    -1,
     567,    -1,   569,    -1,    -1,   572,    -1,    -1,   575,    -1,
      -1,   578,    -1,    -1,   581,    -1,    -1,   584,    -1,    -1,
     587,    -1,    -1,   590,    -1,    -1,   593,    -1,   595,    -1,
     597,    -1,   599,    -1,   601,    -1,   603,    -1,   605,    -1,
      -1,   608,     3,     4,   611,     6,    -1,   614,     9,    -1,
      11,    -1,    13,   620,    15,    16,    -1,   624,    19,   626,
      21,   628,    -1,   630,    -1,   632,    -1,   634,    -1,    -1,
     637,    -1,    -1,   640,    -1,    -1,   643,    -1,    -1,   646,
     647,   648,   649,   650,   651,    -1,   653,   654,   655,   656,
     657,   658,   659,   660,   661,   662,   663,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,    -1,
      -1,    -1,    -1,    94,    -1,    96,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   125,   126,    -1,    -1,   129,    -1,
      -1,    -1,    -1,   134,    -1,   136,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,
      -1,   162,   163,   164,   165,    -1,   167,    -1,    -1,    -1,
     171,   172,   173,   174,    -1,   176,    -1,   178,    -1,   180,
      -1,    -1,   183,    -1,   185,    -1,   187,    -1,   189,    -1,
     191,    -1,   193,    -1,   195,    -1,   197,    -1,   199,    -1,
      -1,   202,    -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   240,
     241,   242,   243,   244,    -1,    -1,   247,   248,   249,   250,
     251,    -1,    -1,   254,   255,   256,   257,   258,   259,   260,
     261,   262,   263,   264,   265,   266,    -1,   268,    -1,   270,
      -1,   272,    -1,   274,    -1,   276,    -1,   278,    -1,   280,
      -1,   282,    -1,   284,    -1,   286,    -1,   288,    -1,   290,
      -1,    -1,   293,    -1,    -1,   296,    -1,    -1,   299,    -1,
      -1,    -1,    -1,    -1,   305,    -1,    -1,   308,    -1,    -1,
     311,    -1,    -1,   314,   315,    -1,   317,    -1,   319,    -1,
     321,    -1,   323,    -1,    -1,    -1,   327,    -1,   329,    -1,
     331,   332,    -1,    -1,   335,    -1,    -1,   338,    -1,    -1,
     341,    -1,    -1,   344,    -1,    -1,   347,    -1,    -1,    -1,
     351,   352,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     361,   362,    -1,    -1,   365,    -1,    -1,    -1,   369,    -1,
     371,    -1,   373,    -1,    -1,   376,    -1,   378,    -1,    -1,
     381,    -1,    -1,    -1,   385,    -1,    -1,    -1,   389,    -1,
      -1,   392,    -1,   394,    -1,    -1,   397,    -1,    -1,    -1,
     401,    -1,   403,    -1,   405,    -1,   407,    -1,   409,    -1,
     411,    -1,   413,    -1,    -1,   416,    -1,    -1,   419,    -1,
      -1,   422,    -1,    -1,   425,    -1,    -1,   428,    -1,    -1,
     431,    -1,    -1,   434,    -1,    -1,   437,    -1,    -1,   440,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   450,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   458,   459,    -1,
     461,   462,    -1,   464,   465,    -1,   467,    -1,   469,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   477,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   485,    -1,    -1,    -1,   489,    -1,
      -1,   492,    -1,   494,    -1,   496,    -1,    -1,   499,    -1,
      -1,   502,    -1,    -1,   505,    -1,    -1,   508,    -1,    -1,
      -1,   512,    -1,   514,    -1,    -1,   517,    -1,    -1,   520,
      -1,    -1,   523,    -1,    -1,   526,    -1,    -1,   529,    -1,
     531,    -1,    -1,   534,    -1,   536,    -1,   538,    -1,   540,
      -1,   542,    -1,   544,    -1,   546,    -1,   548,    -1,   550,
      -1,   552,    -1,    -1,   555,    -1,    -1,   558,    -1,   560,
      -1,   562,    -1,    -1,   565,    -1,   567,    -1,   569,    -1,
      -1,   572,    -1,    -1,   575,    -1,    -1,   578,    -1,    -1,
     581,    -1,    -1,   584,    -1,    -1,   587,    -1,    -1,   590,
      -1,    -1,   593,    -1,   595,    -1,   597,    -1,   599,    -1,
     601,    -1,   603,    -1,   605,    -1,    -1,   608,     3,     4,
     611,     6,    -1,   614,     9,    -1,    11,    -1,    13,   620,
      15,    16,    -1,   624,    19,   626,    21,   628,    -1,   630,
      -1,   632,    -1,   634,    -1,    -1,   637,    -1,    -1,   640,
      -1,    -1,   643,    -1,    -1,   646,   647,   648,   649,   650,
     651,    -1,   653,   654,   655,   656,   657,   658,   659,   660,
     661,   662,   663,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    88,    -1,    -1,    -1,    -1,    -1,    94,
      -1,    96,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,
      -1,   136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   156,    -1,    -1,    -1,   160,    -1,   162,   163,   164,
     165,    -1,   167,    -1,    -1,    -1,   171,   172,   173,   174,
      -1,   176,    -1,   178,    -1,   180,    -1,   182,   183,    -1,
     185,    -1,   187,    -1,   189,    -1,   191,    -1,   193,    -1,
     195,    -1,   197,    -1,   199,    -1,    -1,   202,    -1,   204,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   240,   241,   242,   243,   244,
      -1,    -1,    -1,   248,   249,   250,   251,    -1,    -1,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,    -1,   268,    -1,   270,    -1,   272,    -1,   274,
      -1,   276,    -1,   278,    -1,   280,    -1,   282,    -1,   284,
      -1,   286,    -1,   288,    -1,   290,    -1,    -1,   293,    -1,
      -1,   296,    -1,    -1,   299,    -1,    -1,    -1,    -1,    -1,
     305,    -1,    -1,   308,    -1,    -1,   311,    -1,    -1,   314,
     315,    -1,   317,    -1,   319,    -1,   321,    -1,   323,    -1,
      -1,    -1,   327,    -1,   329,    -1,   331,   332,    -1,    -1,
     335,    -1,    -1,   338,    -1,    -1,   341,    -1,    -1,   344,
      -1,    -1,   347,    -1,    -1,    -1,   351,   352,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   361,   362,    -1,    -1,
     365,    -1,    -1,    -1,   369,    -1,   371,    -1,   373,    -1,
      -1,   376,    -1,   378,    -1,    -1,   381,    -1,    -1,    -1,
     385,    -1,    -1,    -1,   389,    -1,    -1,   392,    -1,   394,
      -1,    -1,   397,    -1,    -1,    -1,   401,    -1,   403,    -1,
     405,    -1,   407,    -1,   409,    -1,   411,    -1,   413,    -1,
      -1,   416,    -1,    -1,   419,    -1,    -1,   422,    -1,    -1,
     425,    -1,    -1,   428,    -1,    -1,   431,    -1,    -1,   434,
      -1,    -1,   437,    -1,    -1,   440,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   450,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   458,   459,    -1,   461,   462,    -1,   464,
     465,    -1,   467,    -1,   469,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   477,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     485,    -1,    -1,    -1,   489,    -1,    -1,   492,    -1,   494,
      -1,   496,    -1,    -1,   499,    -1,    -1,   502,    -1,    -1,
     505,    -1,    -1,   508,    -1,    -1,    -1,   512,    -1,   514,
      -1,    -1,   517,    -1,    -1,   520,    -1,    -1,   523,    -1,
      -1,   526,    -1,    -1,   529,    -1,   531,    -1,    -1,   534,
      -1,   536,    -1,   538,    -1,   540,    -1,   542,    -1,   544,
      -1,   546,    -1,   548,    -1,   550,    -1,   552,    -1,    -1,
     555,    -1,    -1,   558,    -1,   560,    -1,   562,    -1,    -1,
     565,    -1,   567,    -1,   569,    -1,    -1,   572,    -1,    -1,
     575,    -1,    -1,   578,    -1,    -1,   581,    -1,    -1,   584,
      -1,    -1,   587,    -1,    -1,   590,    -1,    -1,   593,    -1,
     595,    -1,   597,    -1,   599,    -1,   601,    -1,   603,    -1,
     605,    -1,    -1,   608,     3,     4,   611,     6,    -1,   614,
       9,    -1,    11,    -1,    13,   620,    15,    16,    -1,   624,
      19,   626,    21,   628,    -1,   630,    -1,   632,    -1,   634,
      -1,    -1,   637,    -1,    -1,   640,    -1,    -1,   643,    -1,
      -1,   646,   647,   648,   649,   650,   651,    -1,   653,   654,
     655,   656,   657,   658,   659,   660,   661,   662,   663,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   125,   126,    -1,    -1,
     129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,
      -1,   160,    -1,   162,   163,   164,   165,    -1,   167,    -1,
      -1,    -1,   171,   172,   173,   174,    -1,   176,    -1,   178,
      -1,   180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,
     189,    -1,   191,    -1,   193,    -1,   195,    -1,   197,    -1,
     199,    -1,    -1,   202,    -1,   204,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   240,   241,   242,   243,   244,    -1,    -1,    -1,   248,
     249,   250,   251,    -1,    -1,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   263,   264,   265,   266,    -1,   268,
      -1,   270,    -1,   272,    -1,   274,    -1,   276,    -1,   278,
      -1,   280,    -1,   282,    -1,   284,    -1,   286,    -1,   288,
      -1,   290,    -1,    -1,   293,    -1,    -1,   296,    -1,    -1,
     299,    -1,    -1,    -1,    -1,    -1,   305,    -1,    -1,   308,
      -1,    -1,   311,    -1,    -1,   314,   315,    -1,   317,    -1,
     319,    -1,   321,    -1,   323,    -1,    -1,    -1,   327,    -1,
     329,    -1,   331,   332,    -1,    -1,   335,    -1,    -1,   338,
      -1,    -1,   341,    -1,    -1,   344,    -1,    -1,   347,    -1,
      -1,    -1,   351,   352,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   361,   362,    -1,    -1,   365,    -1,    -1,    -1,
     369,    -1,   371,    -1,   373,    -1,    -1,   376,    -1,   378,
      -1,    -1,   381,    -1,    -1,    -1,   385,    -1,    -1,    -1,
     389,    -1,    -1,   392,    -1,   394,    -1,    -1,   397,    -1,
      -1,    -1,   401,    -1,   403,    -1,   405,    -1,   407,    -1,
     409,    -1,   411,    -1,   413,    -1,    -1,   416,    -1,    -1,
     419,    -1,    -1,   422,    -1,    -1,   425,    -1,    -1,   428,
      -1,    -1,   431,    -1,    -1,   434,    -1,    -1,   437,    -1,
      -1,   440,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   450,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   458,
     459,    -1,   461,   462,    -1,   464,   465,    -1,   467,    -1,
     469,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   477,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   485,    -1,    -1,    -1,
     489,    -1,    -1,   492,    -1,   494,    -1,   496,    -1,    -1,
     499,    -1,    -1,   502,    -1,    -1,   505,    -1,    -1,   508,
      -1,    -1,    -1,   512,    -1,   514,    -1,    -1,   517,    -1,
      -1,   520,    -1,    -1,   523,    -1,    -1,   526,    -1,    -1,
     529,    -1,   531,    -1,    -1,   534,    -1,   536,    -1,   538,
      -1,   540,    -1,   542,    -1,   544,    -1,   546,    -1,   548,
      -1,   550,    -1,   552,    -1,    -1,   555,    -1,    -1,   558,
      -1,   560,    -1,   562,    -1,    -1,   565,    -1,   567,    -1,
     569,    -1,    -1,   572,    -1,    -1,   575,    -1,    -1,   578,
      -1,    -1,   581,    -1,    -1,   584,    -1,    -1,   587,    -1,
      -1,   590,    -1,    -1,   593,    -1,   595,    -1,   597,    -1,
     599,    -1,   601,    -1,   603,    -1,   605,    -1,    -1,   608,
      -1,    -1,   611,    -1,    -1,   614,    -1,    -1,    -1,    -1,
      -1,   620,    -1,    -1,    -1,   624,    -1,   626,    -1,   628,
      -1,   630,    -1,   632,    -1,   634,    -1,    -1,   637,    -1,
      -1,   640,    -1,    -1,   643,    -1,    -1,   646,   647,   648,
     649,   650,   651,    -1,   653,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   663,     3,     4,    -1,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,
      -1,    19,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,
      -1,    -1,    -1,    31,    -1,    33,    -1,    35,    -1,    37,
      -1,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,
      58,    -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,
      68,    -1,    70,    -1,    72,    -1,    74,    -1,    76,    -1,
      78,    -1,    80,    -1,    82,    -1,    84,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,
      98,    -1,   100,    -1,   102,   103,   104,    -1,   106,    -1,
     108,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,   119,    -1,   121,    -1,   123,   124,   125,   126,    -1,
      -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,
     138,    -1,    -1,   141,    -1,   143,    -1,    -1,    -1,   147,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,
      -1,    -1,   160,   161,   162,    -1,    -1,   165,    -1,   167,
      -1,   169,    -1,    -1,    -1,    -1,   174,    -1,   176,    -1,
     178,    -1,   180,    -1,    -1,   183,    -1,   185,    -1,   187,
      -1,    -1,    -1,   191,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     3,     4,   204,     6,     7,     8,
       9,    10,    -1,    -1,    -1,    -1,    -1,    -1,    17,    -1,
      19,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,
      -1,    -1,    31,    -1,    33,    -1,    35,    -1,    37,    -1,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,
      -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,
      -1,    70,    -1,    72,    -1,    74,    -1,    76,    -1,    78,
      -1,    80,    -1,    82,    -1,    84,    -1,    -1,   286,   287,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    98,
      -1,   100,    -1,   102,   103,   104,    -1,   106,    -1,   108,
      -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,
     119,    -1,   121,    -1,   123,   124,   125,   126,    -1,    -1,
     129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,   138,
      -1,    -1,   141,    -1,   143,    -1,    -1,    -1,   147,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,
      -1,   160,   161,   162,    -1,    -1,   165,    -1,   167,    -1,
     169,    -1,    -1,    -1,    -1,   174,    -1,   176,    -1,   178,
      -1,   180,    -1,   182,   183,    -1,   185,    -1,   187,    -1,
      -1,    -1,   191,     3,     4,     5,     6,     7,     8,     9,
      -1,    -1,    -1,    -1,    -1,   204,    -1,    17,    -1,    19,
      -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,    -1,
      -1,    31,    -1,    33,    -1,    35,    -1,    37,    -1,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    -1,
      50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,    -1,
      60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,    -1,
      70,    -1,    72,    -1,    74,    -1,    76,    -1,    78,    -1,
      80,    -1,    82,    -1,    84,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    94,    -1,    96,   286,    98,    -1,
     100,    -1,   102,   103,   104,    -1,   106,    -1,   108,    -1,
      -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,
      -1,   121,    -1,   123,   124,   125,   126,    -1,    -1,   129,
      -1,    -1,    -1,    -1,   134,    -1,   136,    -1,   138,    -1,
      -1,   141,    -1,   143,    -1,    -1,    -1,   147,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,
     160,   161,   162,    -1,    -1,   165,    -1,   167,    -1,   169,
      -1,    -1,    -1,    -1,   174,    -1,   176,    -1,   178,    -1,
     180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,    -1,
      -1,   191,     3,     4,    -1,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,   204,    -1,    17,    -1,    19,    -1,
      21,    -1,    23,    -1,    25,    -1,    -1,    -1,    -1,    -1,
      31,    -1,    33,    -1,    35,    -1,    37,    -1,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    -1,    50,
      -1,    52,    -1,    54,    -1,    56,    -1,    58,    -1,    60,
      -1,    62,    -1,    64,    -1,    66,    -1,    68,    -1,    70,
      -1,    72,    -1,    74,    -1,    76,    -1,    78,    -1,    80,
      -1,    82,    -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    94,    -1,    96,   286,    98,    -1,   100,
      -1,   102,   103,   104,    -1,   106,    -1,   108,    -1,    -1,
      -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,
     121,   122,   123,   124,   125,   126,    -1,    -1,   129,    -1,
      -1,    -1,    -1,   134,    -1,   136,    -1,   138,    -1,    -1,
     141,    -1,   143,    -1,    -1,    -1,   147,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,
     161,   162,    -1,    -1,   165,    -1,   167,    -1,   169,    -1,
      -1,    -1,    -1,   174,    -1,   176,    -1,   178,    -1,   180,
      -1,    -1,   183,    -1,   185,    -1,   187,    -1,    -1,    -1,
     191,     3,     4,    -1,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,   204,    -1,    17,    -1,    19,    -1,    21,
      -1,    23,    -1,    25,    -1,    -1,    -1,    -1,    -1,    31,
      -1,    33,    -1,    35,    -1,    37,    -1,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    -1,    50,    -1,
      52,    -1,    54,    -1,    56,    -1,    58,    -1,    60,    -1,
      62,    -1,    64,    -1,    66,    -1,    68,    -1,    70,    -1,
      72,    -1,    74,    -1,    76,    -1,    78,    -1,    80,    -1,
      82,    -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    94,    -1,    96,   286,    98,    99,   100,    -1,
     102,   103,   104,    -1,   106,    -1,   108,    -1,    -1,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,   121,
      -1,   123,   124,   125,   126,    -1,    -1,   129,    -1,    -1,
      -1,    -1,   134,    -1,   136,    -1,   138,    -1,    -1,   141,
      -1,   143,    -1,    -1,    -1,   147,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,   161,
     162,    -1,    -1,   165,    -1,   167,    -1,   169,    -1,    -1,
      -1,    -1,   174,    -1,   176,    -1,   178,    -1,   180,    -1,
      -1,   183,    -1,   185,    -1,   187,    -1,    -1,    -1,   191,
       3,     4,    -1,     6,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,   204,    -1,    17,    -1,    19,    -1,    21,    -1,
      23,    -1,    25,    -1,    -1,    -1,    -1,    -1,    31,    -1,
      33,    -1,    35,    -1,    37,    -1,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    -1,    50,    -1,    52,
      -1,    54,    -1,    56,    -1,    58,    -1,    60,    -1,    62,
      -1,    64,    -1,    66,    -1,    68,    -1,    70,    -1,    72,
      -1,    74,    -1,    76,    -1,    78,    -1,    80,    -1,    82,
      -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    94,    -1,    96,   286,    98,    -1,   100,    -1,   102,
     103,   104,    -1,   106,   107,   108,    -1,    -1,    -1,   112,
      -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,   121,    -1,
     123,   124,   125,   126,    -1,    -1,   129,    -1,    -1,    -1,
      -1,   134,    -1,   136,    -1,   138,    -1,    -1,   141,    -1,
     143,    -1,    -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   156,    -1,    -1,    -1,   160,   161,   162,
      -1,    -1,   165,    -1,   167,    -1,   169,    -1,    -1,    -1,
      -1,   174,    -1,   176,    -1,   178,    -1,   180,    -1,    -1,
     183,    -1,   185,    -1,   187,    -1,    -1,    -1,   191,     3,
       4,    -1,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,   204,    -1,    17,    -1,    19,    -1,    21,    -1,    23,
      -1,    25,    -1,    -1,    -1,    -1,    -1,    31,    -1,    33,
      -1,    35,    -1,    37,    -1,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    -1,    50,    -1,    52,    -1,
      54,    -1,    56,    -1,    58,    -1,    60,    -1,    62,    -1,
      64,    -1,    66,    -1,    68,    -1,    70,    -1,    72,    -1,
      74,    -1,    76,    -1,    78,    -1,    80,    -1,    82,    -1,
      84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      94,    -1,    96,   286,    98,    -1,   100,    -1,   102,   103,
     104,    -1,   106,    -1,   108,   109,    -1,    -1,   112,    -1,
      -1,    -1,    -1,    -1,    -1,   119,    -1,   121,    -1,   123,
     124,   125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,
     134,    -1,   136,    -1,   138,    -1,    -1,   141,    -1,   143,
      -1,    -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   156,    -1,    -1,    -1,   160,   161,   162,    -1,
      -1,   165,    -1,   167,    -1,   169,    -1,    -1,    -1,    -1,
     174,    -1,   176,    -1,   178,    -1,   180,    -1,    -1,   183,
      -1,   185,    -1,   187,    -1,    -1,    -1,   191,     3,     4,
      -1,     6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,
     204,    -1,    17,    -1,    19,    -1,    21,    -1,    23,    -1,
      25,    -1,    -1,    -1,    -1,    -1,    31,    -1,    33,    -1,
      35,    -1,    37,    -1,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    -1,    50,    -1,    52,    -1,    54,
      -1,    56,    -1,    58,    -1,    60,    -1,    62,    -1,    64,
      -1,    66,    -1,    68,    -1,    70,    -1,    72,    -1,    74,
      -1,    76,    -1,    78,    -1,    80,    -1,    82,    -1,    84,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,
      -1,    96,   286,    98,    -1,   100,    -1,   102,   103,   104,
      -1,   106,    -1,   108,    -1,    -1,    -1,   112,    -1,    -1,
      -1,    -1,    -1,    -1,   119,   120,   121,    -1,   123,   124,
     125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,
      -1,   136,    -1,   138,    -1,    -1,   141,    -1,   143,    -1,
      -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   156,    -1,    -1,    -1,   160,   161,   162,    -1,    -1,
     165,    -1,   167,    -1,   169,    -1,    -1,    -1,    -1,   174,
      -1,   176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,
     185,    -1,   187,    -1,    -1,    -1,   191,     3,     4,    -1,
       6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,   204,
      -1,    17,    -1,    19,    -1,    21,    -1,    23,    -1,    25,
      -1,    -1,    -1,    -1,    -1,    31,    -1,    33,    -1,    35,
      -1,    37,    -1,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    -1,    50,    -1,    52,    -1,    54,    -1,
      56,    -1,    58,    -1,    60,    -1,    62,    -1,    64,    -1,
      66,    -1,    68,    -1,    70,    -1,    72,    -1,    74,    -1,
      76,    -1,    78,    -1,    80,    -1,    82,    -1,    84,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,
      96,   286,    98,    -1,   100,    -1,   102,   103,   104,    -1,
     106,    -1,   108,    -1,    -1,    -1,   112,    -1,    -1,    -1,
      -1,    -1,    -1,   119,    -1,   121,    -1,   123,   124,   125,
     126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,   135,
     136,    -1,   138,    -1,    -1,   141,    -1,   143,    -1,    -1,
      -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     156,    -1,    -1,    -1,   160,   161,   162,    -1,    -1,   165,
      -1,   167,    -1,   169,    -1,    -1,    -1,    -1,   174,    -1,
     176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,
      -1,   187,    -1,    -1,    -1,   191,     3,     4,    -1,     6,
       7,     8,     9,    -1,    -1,    -1,    -1,    -1,   204,    -1,
      17,    -1,    19,    -1,    21,    -1,    23,    -1,    25,    -1,
      -1,    -1,    -1,    -1,    31,    -1,    33,    -1,    35,    -1,
      37,    -1,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    -1,    50,    -1,    52,    -1,    54,    -1,    56,
      -1,    58,    -1,    60,    -1,    62,    -1,    64,    -1,    66,
      -1,    68,    -1,    70,    -1,    72,    -1,    74,    -1,    76,
      -1,    78,    -1,    80,    -1,    82,    -1,    84,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,
     286,    98,    -1,   100,    -1,   102,   103,   104,    -1,   106,
      -1,   108,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,
      -1,    -1,   119,    -1,   121,    -1,   123,   124,   125,   126,
      -1,    -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,
      -1,   138,    -1,    -1,   141,    -1,   143,    -1,    -1,    -1,
     147,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,
      -1,    -1,    -1,   160,   161,   162,    -1,    -1,   165,    -1,
     167,    -1,   169,   170,    -1,    -1,    -1,   174,    -1,   176,
      -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,    -1,
     187,    -1,    -1,    -1,   191,     3,     4,    -1,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,   204,    -1,    17,
      -1,    19,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,
      -1,    -1,    -1,    31,    -1,    33,    -1,    35,    -1,    37,
      -1,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,
      58,    -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,
      68,    -1,    70,    -1,    72,    -1,    74,    -1,    76,    -1,
      78,    -1,    80,    -1,    82,    -1,    84,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,   286,
      98,    -1,   100,    -1,   102,   103,   104,    -1,   106,    -1,
     108,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,   119,    -1,   121,    -1,   123,   124,   125,   126,    -1,
      -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,
     138,    -1,    -1,   141,    -1,   143,    -1,    -1,    -1,   147,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,
      -1,    -1,   160,   161,   162,    -1,    -1,   165,    -1,   167,
      -1,   169,    -1,    -1,    -1,    -1,   174,   175,   176,    -1,
     178,    -1,   180,    -1,    -1,   183,    -1,   185,    -1,   187,
      -1,    -1,    -1,   191,     3,     4,    -1,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,   204,    -1,    17,    -1,
      19,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,
      -1,    -1,    31,    -1,    33,    -1,    35,    -1,    37,    -1,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,
      -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,
      -1,    70,    -1,    72,    -1,    74,    -1,    76,    -1,    78,
      -1,    80,    -1,    82,    -1,    84,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,   286,    98,
      -1,   100,    -1,   102,   103,   104,    -1,   106,    -1,   108,
      -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,
     119,    -1,   121,    -1,   123,   124,   125,   126,    -1,    -1,
     129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,   138,
      -1,    -1,   141,    -1,   143,    -1,    -1,    -1,   147,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,
      -1,   160,   161,   162,    -1,    -1,   165,    -1,   167,    -1,
     169,    -1,    -1,    -1,    -1,   174,    -1,   176,    -1,   178,
      -1,   180,   181,    -1,   183,    -1,   185,    -1,   187,    -1,
      -1,    -1,   191,     3,     4,    -1,     6,     7,     8,     9,
      -1,    -1,    -1,    -1,    -1,   204,    -1,    17,    -1,    19,
      -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,    -1,
      -1,    31,    -1,    33,    -1,    35,    -1,    37,    -1,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    -1,
      50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,    -1,
      60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,    -1,
      70,    -1,    72,    -1,    74,    -1,    76,    -1,    78,    -1,
      80,    -1,    82,    -1,    84,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    94,    -1,    96,   286,    98,    -1,
     100,    -1,   102,   103,   104,    -1,   106,    -1,   108,    -1,
      -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,
      -1,   121,    -1,   123,   124,   125,   126,    -1,    -1,   129,
      -1,    -1,    -1,    -1,   134,    -1,   136,   137,   138,    -1,
      -1,   141,    -1,   143,    -1,    -1,    -1,   147,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,
     160,   161,   162,    -1,    -1,   165,    -1,   167,    -1,   169,
      -1,    -1,    -1,    -1,   174,    -1,   176,    -1,   178,    -1,
     180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,    -1,
      -1,   191,     3,     4,    -1,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,   204,    -1,    17,    -1,    19,    -1,
      21,    -1,    23,    -1,    25,    -1,    -1,    -1,    -1,    -1,
      31,    -1,    33,    -1,    35,    -1,    37,    -1,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    -1,    50,
      -1,    52,    -1,    54,    -1,    56,    -1,    58,    -1,    60,
      -1,    62,    -1,    64,    -1,    66,    -1,    68,    -1,    70,
      -1,    72,    -1,    74,    -1,    76,    -1,    78,    -1,    80,
      -1,    82,    -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    94,    -1,    96,   286,    98,    -1,   100,
      -1,   102,   103,   104,    -1,   106,    -1,   108,    -1,    -1,
      -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,
     121,    -1,   123,   124,   125,   126,    -1,    -1,   129,    -1,
      -1,    -1,    -1,   134,    -1,   136,    -1,   138,    -1,    -1,
     141,    -1,   143,    -1,    -1,    -1,   147,    -1,    -1,    -1,
      -1,   152,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,
     161,   162,    -1,    -1,   165,    -1,   167,    -1,   169,    -1,
      -1,    -1,    -1,   174,    -1,   176,    -1,   178,    -1,   180,
      -1,    -1,   183,    -1,   185,    -1,   187,    -1,    -1,    -1,
     191,     3,     4,    -1,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,   204,    -1,    17,    -1,    19,    -1,    21,
      -1,    23,    -1,    25,    -1,    -1,    -1,    -1,    -1,    31,
      -1,    33,    -1,    35,    -1,    37,    -1,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    -1,    50,    -1,
      52,    -1,    54,    -1,    56,    -1,    58,    -1,    60,    -1,
      62,    -1,    64,    -1,    66,    -1,    68,    -1,    70,    -1,
      72,    -1,    74,    -1,    76,    -1,    78,    -1,    80,    -1,
      82,    -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    94,    -1,    96,   286,    98,    -1,   100,    -1,
     102,   103,   104,    -1,   106,    -1,   108,    -1,    -1,    -1,
     112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,   121,
      -1,   123,   124,   125,   126,    -1,    -1,   129,    -1,    -1,
      -1,    -1,   134,    -1,   136,    -1,   138,    -1,    -1,   141,
      -1,   143,    -1,    -1,    -1,   147,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   156,   157,    -1,    -1,   160,   161,
     162,    -1,    -1,   165,    -1,   167,    -1,   169,    -1,    -1,
      -1,    -1,   174,    -1,   176,    -1,   178,    -1,   180,    -1,
      -1,   183,    -1,   185,    -1,   187,    -1,    -1,    -1,   191,
       3,     4,    -1,     6,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,   204,    -1,    17,    -1,    19,    -1,    21,    -1,
      23,    -1,    25,    -1,    -1,    -1,    -1,    -1,    31,    -1,
      33,    -1,    35,    -1,    37,    -1,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    -1,    50,    -1,    52,
      -1,    54,    -1,    56,    -1,    58,    -1,    60,    -1,    62,
      -1,    64,    -1,    66,    -1,    68,    -1,    70,    -1,    72,
      -1,    74,    -1,    76,    -1,    78,    -1,    80,    -1,    82,
      -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    94,    -1,    96,   286,    98,    -1,   100,    -1,   102,
     103,   104,    -1,   106,    -1,   108,    -1,    -1,    -1,   112,
      -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,   121,    -1,
     123,   124,   125,   126,    -1,    -1,   129,    -1,    -1,    -1,
      -1,   134,    -1,   136,    -1,   138,    -1,    -1,   141,    -1,
     143,    -1,    -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   156,    -1,    -1,    -1,   160,   161,   162,
      -1,    -1,   165,   166,   167,    -1,   169,    -1,    -1,    -1,
      -1,   174,    -1,   176,    -1,   178,    -1,   180,    -1,    -1,
     183,    -1,   185,    -1,   187,    -1,    -1,    -1,   191,     3,
       4,    -1,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,   204,    -1,    17,    -1,    19,    -1,    21,    -1,    23,
      -1,    25,    -1,    -1,    -1,    -1,    -1,    31,    -1,    33,
      -1,    35,    -1,    37,    -1,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    -1,    50,    -1,    52,    -1,
      54,    -1,    56,    -1,    58,    -1,    60,    -1,    62,    -1,
      64,    -1,    66,    -1,    68,    -1,    70,    -1,    72,    -1,
      74,    -1,    76,    -1,    78,    -1,    80,    -1,    82,    -1,
      84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      94,    -1,    96,   286,    98,    -1,   100,    -1,   102,   103,
     104,    -1,   106,    -1,   108,    -1,    -1,    -1,   112,    -1,
      -1,    -1,    -1,    -1,    -1,   119,    -1,   121,    -1,   123,
     124,   125,   126,    -1,   128,   129,    -1,    -1,    -1,    -1,
     134,    -1,   136,    -1,   138,    -1,    -1,   141,    -1,   143,
      -1,    -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   156,    -1,    -1,    -1,   160,   161,   162,    -1,
      -1,   165,    -1,   167,    -1,   169,    -1,    -1,    -1,    -1,
     174,    -1,   176,    -1,   178,    -1,   180,    -1,    -1,   183,
      -1,   185,    -1,   187,    -1,    -1,    -1,   191,     3,     4,
      -1,     6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,
     204,    -1,    17,    -1,    19,    -1,    21,    -1,    23,    -1,
      25,    -1,    -1,    -1,    -1,    -1,    31,    -1,    33,    -1,
      35,    -1,    37,    -1,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    -1,    50,    -1,    52,    -1,    54,
      -1,    56,    -1,    58,    -1,    60,    -1,    62,    -1,    64,
      -1,    66,    -1,    68,    -1,    70,    -1,    72,    -1,    74,
      -1,    76,    -1,    78,    -1,    80,    -1,    82,    -1,    84,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,
      -1,    96,   286,    98,    -1,   100,    -1,   102,   103,   104,
     105,   106,    -1,   108,    -1,    -1,    -1,   112,    -1,    -1,
      -1,    -1,    -1,    -1,   119,    -1,   121,    -1,   123,   124,
     125,   126,    -1,    -1,   129,    -1,    -1,    -1,    -1,   134,
      -1,   136,    -1,   138,    -1,    -1,   141,    -1,   143,    -1,
      -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   156,    -1,    -1,    -1,   160,   161,   162,    -1,    -1,
     165,    -1,   167,    -1,   169,    -1,    -1,    -1,    -1,   174,
      -1,   176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,
     185,    -1,   187,    -1,    -1,    -1,   191,     3,     4,    -1,
       6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,   204,
      -1,    17,    -1,    19,    -1,    21,    -1,    23,    -1,    25,
      -1,    -1,    -1,    -1,    -1,    31,    -1,    33,    -1,    35,
      -1,    37,    -1,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    -1,    50,    -1,    52,    -1,    54,    -1,
      56,    -1,    58,    -1,    60,    -1,    62,    -1,    64,    -1,
      66,    -1,    68,    -1,    70,    -1,    72,    -1,    74,    -1,
      76,    -1,    78,    -1,    80,    -1,    82,    -1,    84,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,
      96,   286,    98,    -1,   100,    -1,   102,   103,   104,    -1,
     106,    -1,   108,    -1,    -1,    -1,   112,    -1,    -1,    -1,
      -1,    -1,    -1,   119,    -1,   121,    -1,   123,   124,   125,
     126,    -1,    -1,   129,    -1,    -1,   132,    -1,   134,    -1,
     136,    -1,   138,    -1,    -1,   141,    -1,   143,    -1,    -1,
      -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     156,    -1,    -1,    -1,   160,   161,   162,    -1,    -1,   165,
      -1,   167,    -1,   169,    -1,    -1,    -1,    -1,   174,    -1,
     176,    -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,
      -1,   187,    -1,    -1,    -1,   191,     3,     4,    -1,     6,
       7,     8,     9,    -1,    -1,    -1,    -1,    -1,   204,    -1,
      17,    -1,    19,    -1,    21,    -1,    23,    -1,    25,    -1,
      -1,    -1,    -1,    -1,    31,    -1,    33,    -1,    35,    -1,
      37,    -1,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    -1,    50,    -1,    52,    -1,    54,    -1,    56,
      -1,    58,    -1,    60,    -1,    62,    -1,    64,    -1,    66,
      -1,    68,    -1,    70,    -1,    72,    -1,    74,    -1,    76,
      -1,    78,    -1,    80,    -1,    82,    -1,    84,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,
     286,    98,    -1,   100,    -1,   102,   103,   104,    -1,   106,
      -1,   108,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,
      -1,    -1,   119,    -1,   121,    -1,   123,   124,   125,   126,
      -1,    -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,
      -1,   138,   139,    -1,   141,    -1,   143,    -1,    -1,    -1,
     147,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,
      -1,    -1,    -1,   160,   161,   162,    -1,    -1,   165,    -1,
     167,    -1,   169,    -1,    -1,    -1,    -1,   174,    -1,   176,
      -1,   178,    -1,   180,    -1,    -1,   183,    -1,   185,    -1,
     187,    -1,    -1,    -1,   191,     3,     4,    -1,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,   204,    -1,    17,
      -1,    19,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,
      -1,    -1,    -1,    31,    -1,    33,    -1,    35,    -1,    37,
      -1,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,
      58,    -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,
      68,    -1,    70,    -1,    72,    -1,    74,    -1,    76,    -1,
      78,    -1,    80,    -1,    82,    -1,    84,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    94,    -1,    96,   286,
      98,    -1,   100,    -1,   102,   103,   104,    -1,   106,    -1,
     108,    -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,
      -1,   119,    -1,   121,    -1,   123,   124,   125,   126,    -1,
      -1,   129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,
     138,    -1,    -1,   141,    -1,   143,    -1,    -1,    -1,   147,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,
      -1,    -1,   160,   161,   162,    -1,    -1,   165,    -1,   167,
      -1,   169,    -1,    -1,    -1,    -1,   174,    -1,   176,    -1,
     178,    -1,   180,   181,    -1,   183,    -1,   185,    -1,   187,
      -1,    -1,    -1,   191,     3,     4,    -1,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,   204,    -1,    17,    -1,
      19,    -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,
      -1,    -1,    31,    -1,    33,    -1,    35,    -1,    37,    -1,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      -1,    50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,
      -1,    60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,
      -1,    70,    -1,    72,    -1,    74,    -1,    76,    -1,    78,
      -1,    80,    -1,    82,    -1,    84,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    94,    -1,    96,   286,    98,
      -1,   100,    -1,   102,   103,   104,    -1,   106,    -1,   108,
      -1,    -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,
     119,    -1,   121,    -1,   123,   124,   125,   126,    -1,   128,
     129,    -1,    -1,    -1,    -1,   134,    -1,   136,    -1,   138,
      -1,    -1,   141,    -1,   143,    -1,    -1,    -1,   147,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,
      -1,   160,   161,   162,    -1,    -1,   165,    -1,   167,    -1,
     169,    -1,    -1,    -1,    -1,   174,    -1,   176,    -1,   178,
      -1,   180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,
      -1,    -1,   191,     3,     4,    -1,     6,     7,     8,     9,
      -1,    -1,    -1,    -1,    -1,   204,    -1,    17,    -1,    19,
      -1,    21,    -1,    23,    -1,    25,    -1,    -1,    -1,    -1,
      -1,    31,    -1,    33,    -1,    35,    -1,    37,    -1,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    -1,
      50,    -1,    52,    -1,    54,    -1,    56,    -1,    58,    -1,
      60,    -1,    62,    -1,    64,    -1,    66,    -1,    68,    -1,
      70,    -1,    72,    -1,    74,    -1,    76,    -1,    78,    -1,
      80,    -1,    82,    -1,    84,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    94,    -1,    96,   286,    98,    -1,
     100,    -1,   102,   103,   104,    -1,   106,    -1,   108,    -1,
      -1,    -1,   112,    -1,    -1,    -1,    -1,    -1,   118,   119,
      -1,   121,    -1,   123,   124,   125,   126,    -1,    -1,   129,
      -1,    -1,    -1,    -1,   134,    -1,   136,    -1,   138,    -1,
      -1,   141,    -1,   143,    -1,    -1,    -1,   147,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,
     160,   161,   162,    -1,    -1,   165,    -1,   167,    -1,   169,
      -1,    -1,    -1,    -1,   174,    -1,   176,    -1,   178,    -1,
     180,    -1,    -1,   183,    -1,   185,    -1,   187,    -1,    -1,
      -1,   191,     3,     4,    -1,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,   204,    -1,    17,    -1,    19,    -1,
      21,    -1,    23,    -1,    25,    -1,    -1,    -1,    -1,    -1,
      31,    -1,    33,    -1,    35,    -1,    37,    -1,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    -1,    50,
      -1,    52,    -1,    54,    -1,    56,    -1,    58,    -1,    60,
      -1,    62,    -1,    64,    -1,    66,    -1,    68,    -1,    70,
      -1,    72,    -1,    74,    -1,    76,    -1,    78,    -1,    80,
      -1,    82,    -1,    84,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    94,    -1,    96,   286,    98,    -1,   100,
      -1,   102,   103,   104,    -1,   106,    -1,   108,    -1,    -1,
      -1,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,
     121,    -1,   123,   124,   125,   126,    -1,    -1,   129,    -1,
      -1,    -1,    -1,   134,    -1,   136,    -1,   138,    -1,    -1,
     141,    -1,   143,    -1,    -1,    -1,   147,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   156,    -1,    -1,    -1,   160,
     161,   162,    -1,    -1,   165,    -1,   167,    -1,   169,    -1,
      -1,    -1,    -1,   174,    -1,   176,    -1,   178,    -1,   180,
      -1,    -1,   183,    -1,   185,    -1,   187,    -1,    -1,    -1,
     191,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   286
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   665,   666,     0,     3,     4,     5,     6,     7,     8,
       9,    17,    19,    21,    23,    25,    31,    33,    35,    37,
      39,    41,    43,    45,    47,    50,    52,    54,    56,    58,
      60,    62,    64,    66,    68,    70,    72,    74,    76,    78,
      80,    82,    84,    94,    96,    98,   100,   102,   103,   104,
     106,   108,   112,   119,   121,   123,   124,   125,   126,   129,
     134,   136,   138,   141,   143,   147,   156,   160,   161,   162,
     165,   167,   169,   174,   176,   178,   180,   183,   185,   187,
     191,   204,   286,   667,   685,   690,   697,   700,   702,   703,
     709,   722,   723,   786,   791,   802,   810,   815,   861,   866,
     877,   883,     3,   736,   680,   784,   738,   724,   726,   728,
     734,   742,   730,   764,   744,   750,   740,   732,   746,   748,
     752,   754,   756,   758,   760,   766,   768,   770,   772,   774,
     776,   778,   780,   782,   787,   789,   691,   668,   677,   679,
     676,   675,   701,   666,   670,   673,   698,   809,   686,   710,
     711,   151,   704,   707,   158,     8,   106,   805,   165,   723,
     805,    41,   682,   808,   809,   808,   683,   672,   792,   793,
     794,   808,   146,   714,   867,   862,   684,   666,   666,   666,
     666,   666,   666,   666,   666,   666,   666,   666,   666,   666,
     666,   666,   666,   666,   666,   666,   666,   666,   666,   666,
     666,   666,   666,   666,   666,   666,   666,   666,   666,   666,
     666,   666,   125,   689,   666,   666,   114,   692,   666,   122,
     127,   133,   666,   699,   140,   165,   165,   708,   148,   707,
     689,   159,   806,     3,     4,     3,     3,   762,   166,   811,
     709,   812,   816,   666,   666,   180,   723,   795,   795,   666,
     165,   167,   884,   878,   167,   167,   666,   737,   681,   785,
     739,   725,   727,   729,   735,   743,   731,   765,   745,   751,
     741,   733,   747,   749,   753,   755,   757,   759,   761,   767,
     769,   771,   773,   775,   777,   779,   781,   783,   788,   790,
      99,   669,   103,   107,   109,   693,   113,   120,   671,   674,
     135,   666,   687,   185,   809,   666,   689,    10,   666,   666,
     803,     3,   804,   666,     8,   814,   666,   814,    10,   170,
     175,   796,   795,   177,   179,   181,   166,   165,   886,   184,
     165,   167,   879,   880,   881,   868,   863,   287,    18,    20,
      22,    24,    26,    32,    34,    38,    40,    42,    44,    46,
      48,    51,    53,    55,    57,    59,    61,    63,    65,    67,
      69,    71,    73,    75,    77,    79,    81,    83,    85,    95,
      97,   101,   678,   689,   666,   131,   798,   137,   145,   713,
     714,   714,   152,    10,   705,   157,   807,   723,   723,   763,
       3,     4,     6,     9,    11,    13,    15,    16,    19,    21,
      88,   125,   126,   129,   160,   162,   163,   164,   165,   167,
     171,   172,   173,   174,   176,   178,   180,   189,   193,   195,
     197,   199,   202,   204,   244,   248,   249,   250,   251,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   268,   270,   272,   274,   276,   278,   280,   282,
     284,   286,   288,   290,   293,   296,   299,   305,   308,   311,
     314,   315,   317,   319,   321,   323,   327,   329,   331,   332,
     335,   338,   341,   344,   347,   351,   352,   361,   362,   365,
     369,   371,   373,   376,   378,   381,   385,   389,   392,   394,
     397,   401,   403,   405,   407,   409,   411,   413,   416,   419,
     422,   425,   428,   431,   434,   437,   440,   450,   458,   459,
     461,   462,   464,   465,   467,   469,   477,   485,   489,   492,
     494,   496,   499,   502,   505,   508,   512,   514,   517,   520,
     523,   526,   529,   531,   534,   536,   538,   540,   542,   544,
     546,   548,   550,   552,   555,   558,   560,   562,   565,   567,
     569,   572,   575,   578,   581,   584,   587,   590,   593,   595,
     597,   599,   601,   603,   605,   608,   611,   614,   620,   624,
     626,   628,   630,   632,   634,   637,   640,   643,   646,   647,
     648,   649,   650,   651,   653,   654,   655,   656,   657,   658,
     659,   660,   661,   662,   722,   809,   825,   829,   846,   849,
     856,   857,   861,   864,   866,   877,   883,   894,   895,   906,
     924,   925,   926,   930,   931,   942,   947,   948,   982,  1048,
    1067,  1093,  1150,  1168,  1179,  1181,  1182,  1183,  1196,  1200,
    1222,   166,   829,   817,   666,   886,   887,   891,    10,   882,
     880,   186,   881,   165,   168,   869,   879,   666,   115,   128,
     799,   130,   688,   154,   715,   716,   717,   715,   706,   715,
     107,    42,     3,   828,   829,   838,   840,   896,   898,    90,
     842,   809,   809,   801,   907,   830,   828,   826,   832,   834,
     836,   865,   858,   182,   848,   198,   943,   993,   203,   945,
     932,   843,   844,   845,   938,   909,   911,   910,   912,   913,
     915,   916,   917,   914,   918,   919,   940,   936,   934,   165,
    1005,   980,   952,   951,   954,   955,   956,    11,    11,     3,
       3,   165,   997,   999,  1001,   983,   986,   987,   231,   231,
     232,   232,   995,   855,   221,   375,     3,   929,   929,  1009,
    1011,  1013,  1015,  1017,  1020,  1021,  1022,  1023,   211,   929,
     929,  1065,  1049,  1051,  1053,  1055,  1057,  1059,  1061,  1063,
    1201,  1205,  1211,  1210,  1212,  1213,  1214,  1215,  1216,  1223,
    1225,  1227,  1229,   929,   929,  1072,  1074,  1076,  1078,   929,
     929,  1080,  1082,  1084,  1086,  1088,  1090,  1091,   235,   212,
     238,   234,   216,   214,   236,   213,   239,   553,   556,   215,
     208,   563,   209,   210,   570,   573,   576,   579,   582,   585,
     588,   591,   229,   230,   225,   220,  1151,   929,   929,  1154,
    1155,  1156,  1158,  1184,  1180,   929,  1193,  1170,   218,  1171,
    1242,  1243,  1242,   697,   786,   828,   166,   828,   828,   828,
     891,   828,   828,   828,   828,   828,   828,   828,   828,   208,
     209,   210,   211,   212,   213,   214,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,   237,   238,
     239,   368,   375,   388,   553,   556,   563,   570,   573,   576,
     579,   582,   585,   588,   591,  1198,   663,  1197,   828,   240,
     241,   242,   243,  1241,   828,   828,  1187,   168,   809,   819,
     797,   891,   828,   165,   890,   892,   166,   828,   168,   870,
     188,   168,   105,   695,   696,   666,   666,    10,   186,   716,
     666,   718,   719,   720,   721,   712,   715,   166,   828,   828,
     666,   666,   850,   828,   903,   900,     3,     6,   895,   828,
     168,   666,   795,   795,   666,   879,   165,   166,   847,   828,
     829,   829,   828,   829,   828,   828,   828,   828,   828,   829,
     829,   829,   829,   829,   829,   829,   829,   828,   829,   829,
     829,   829,   828,  1003,   927,   949,   829,   829,   929,   929,
     929,   929,   964,   979,   964,   853,   854,     3,   829,   829,
     829,   929,   927,   829,   989,   990,   991,   992,   829,   829,
    1007,  1027,  1025,  1026,   829,   829,   829,   829,   829,   355,
    1035,  1035,   929,   284,  1024,  1029,  1031,   829,   829,   829,
     829,   829,   829,   829,   829,   829,   197,   202,   929,  1231,
     244,   829,   829,   829,   829,   829,   829,   197,   197,   929,
    1232,   197,   929,  1233,   226,   829,  1068,  1069,   829,   829,
     829,   829,  1070,  1071,   829,   829,   829,   829,   829,   929,
     829,  1142,  1106,  1146,  1134,  1118,  1110,  1144,  1108,  1148,
    1138,  1122,  1114,  1094,  1096,  1098,  1102,  1112,  1116,  1120,
    1124,  1136,  1140,  1100,  1104,  1130,  1132,  1128,  1126,   829,
     929,   929,   609,   612,   829,  1160,  1193,   165,  1193,  1193,
    1182,   723,  1169,   635,  1179,  1189,  1190,  1173,  1175,  1177,
     808,   808,   809,   165,   860,   165,  1186,  1188,   813,   786,
     814,   820,   822,   824,   181,   890,    10,   182,   888,   828,
     168,   824,   182,   876,   828,   192,   116,   666,   132,   139,
      10,   166,    10,   182,   720,   721,   166,    12,    14,   897,
     899,   829,   127,   133,   920,   908,   166,   828,   827,   177,
     179,   181,   190,   859,   165,   879,   944,   200,   946,   245,
     252,   267,   269,   271,   273,   275,   277,   279,   281,   283,
     285,   287,   289,   937,   294,   922,   829,   829,   309,   312,
     829,   829,   829,    12,   929,    12,   829,   829,   166,   333,
     336,   339,   829,   829,   348,   929,   202,   929,   202,   996,
     370,   829,   829,   829,   829,   382,   386,   390,  1016,  1018,
    1036,  1193,  1193,   829,   829,   829,   829,   829,   414,   417,
     420,   423,   426,   429,   432,   435,   438,  1238,  1237,   197,
     202,   446,   929,   460,   460,   463,   463,   466,   466,   929,
    1238,   197,   202,  1224,  1238,   197,   202,  1226,  1234,  1230,
    1044,  1045,  1035,   497,   500,   503,   506,  1044,  1035,   515,
     518,   521,   524,   527,   829,   532,   829,   829,   829,   829,
     829,   829,   829,   829,   829,   829,   829,   829,   829,   829,
     829,   829,   829,   829,   829,   829,   829,   829,   829,   829,
     829,   829,   829,   829,   602,  1152,  1153,   929,   929,  1157,
    1159,   618,   166,   624,  1193,   197,   829,  1182,  1191,  1172,
     723,   829,   829,   829,   828,   828,   828,   828,   809,   808,
     825,    10,   165,   165,   795,   165,   889,   166,    10,   166,
     182,   166,   876,   117,   667,   800,   142,   144,   839,   841,
      20,    22,    91,   904,   901,   723,   165,   197,   202,   895,
     921,   930,   831,   175,   833,   835,   837,   828,   196,   198,
     994,   203,   933,   939,   292,   935,   829,   928,   306,   929,
     197,   316,   318,   320,   183,   185,   965,   957,   328,   330,
     165,   998,  1000,  1002,   342,   928,   988,  1044,  1035,  1044,
    1035,   366,  1008,  1028,   377,   379,   929,   929,   388,   393,
     395,  1044,   357,  1041,  1043,  1043,   404,   285,   408,  1030,
    1032,   929,   929,   929,   929,   929,   929,   929,   929,   929,
     444,   442,  1238,  1237,  1202,   454,  1218,   198,   473,  1238,
    1237,   475,   481,  1238,  1237,   483,   202,   490,   493,   829,
     929,   929,   929,   929,   929,   509,   929,   929,   929,   929,
    1087,   929,   530,   929,  1143,  1107,  1147,  1135,  1119,  1111,
    1145,  1109,  1149,  1139,  1123,  1115,  1095,  1097,  1099,  1103,
    1113,  1117,  1121,  1125,  1137,  1141,  1101,  1105,  1131,  1133,
    1129,  1127,   829,   829,   829,   829,   616,  1163,  1193,   829,
     165,   829,   629,   929,   633,   723,   202,   638,   641,   644,
      10,   166,    10,   166,   182,   819,   819,   828,   828,   166,
     824,   166,   824,   166,   166,   694,   798,   809,   828,   828,
     851,   666,   798,   895,   828,   828,   828,   828,   888,   197,
     246,   248,   941,   828,   828,   923,  1006,   929,   953,   929,
     929,   929,   929,   165,   968,   714,    13,   325,   959,   960,
       3,     3,     3,   829,   829,   829,   929,   345,   248,   349,
    1033,   353,   203,   363,   203,   368,   372,   374,  1010,  1012,
    1014,   929,  1037,  1042,   399,   399,   929,   406,   410,   412,
    1066,  1050,   929,  1054,  1056,  1058,  1060,  1062,  1064,   829,
     829,   444,   442,   829,   197,   456,   829,   829,   473,   471,
     829,   829,   481,   479,   829,   829,   828,   929,  1046,  1041,
    1073,  1075,  1077,  1079,   929,  1041,  1081,  1083,  1085,   829,
    1089,   929,  1092,   535,   537,   539,   541,   543,   545,   547,
     549,   551,   554,   557,   559,   561,   564,   566,   568,   571,
     574,   577,   580,   583,   586,   589,   592,   594,   596,   596,
     600,   604,   606,   610,   613,  1164,   615,   622,  1161,   619,
     828,   625,   198,   829,  1192,   929,   929,   929,   166,   194,
     166,   165,   166,   168,   821,    10,   182,   823,   823,   893,
     791,   885,   871,   666,    92,   128,   130,   166,   166,   829,
     828,   246,   253,   295,   297,   300,   950,   829,   929,   166,
     973,   966,   964,   165,   958,   960,   166,   334,   337,   340,
     984,   929,   349,   829,   929,   929,   929,   929,   829,   829,
     829,   829,   829,   356,   829,   929,   929,   929,   929,   829,
     829,  1052,   829,   829,   829,   829,   829,   829,   445,   443,
     829,   829,   447,   929,  1206,   468,   474,   829,   829,   476,
     482,   829,   829,   484,   203,   491,   929,   829,   829,   829,
     829,   929,   829,   829,   829,   525,   829,   829,   929,   929,
     929,   929,   197,  1167,  1162,  1163,    10,   182,  1185,  1193,
     631,   203,  1174,  1176,  1178,   194,   166,   818,   820,   166,
     166,   824,   165,   118,   829,   905,   902,   198,   247,   828,
    1004,   829,   310,   929,   969,   165,   971,   974,   165,   975,
     978,    14,   961,    13,   342,   346,   829,   350,   359,  1038,
    1038,   367,   383,   387,   391,  1019,  1047,   358,   829,   829,
     415,   418,   829,   424,   427,   430,   433,   436,   439,   198,
     203,   445,   443,  1203,   198,   829,   198,   474,   472,   470,
     198,   482,   480,   478,  1236,   495,   498,   501,   504,   507,
     513,   516,   519,   522,   528,   533,   197,  1165,   829,   621,
     166,  1194,   636,   829,   829,   829,   625,   809,    10,   824,
     824,   872,    93,   808,   808,   201,   247,   166,   307,   929,
     165,   828,   184,   976,   165,   967,   322,   829,   964,   829,
     350,  1039,  1193,  1193,   396,   400,   400,   421,   929,   929,
     198,   203,   448,   455,   457,   929,   198,   203,   929,   198,
     203,  1235,   929,   895,   623,  1167,   627,  1195,   639,   642,
     645,   819,   828,   852,   165,   981,   198,   828,    10,   166,
     182,   828,    10,   166,   186,   182,    14,   985,   829,  1041,
    1041,   398,   402,  1240,  1239,  1240,  1239,   929,   245,  1240,
    1240,  1239,  1240,  1240,  1239,  1228,   198,  1166,  1193,   876,
      89,   929,   313,    10,   182,   970,   166,   972,   166,   182,
     166,   962,   324,   343,  1040,   929,   929,   202,   202,   829,
     248,  1199,   202,   202,   202,   202,   487,   607,   617,   166,
     829,   166,   165,   977,   975,   166,   929,   360,   354,   364,
    1237,  1237,   449,   246,  1237,  1237,  1237,  1237,   829,   198,
     873,   166,   298,  1034,   166,   166,   666,   442,   442,  1204,
     929,   471,   471,   479,   479,   488,   165,   298,   166,   165,
     810,   963,   829,   829,  1217,  1207,   829,   829,   829,   829,
     486,   874,   808,   326,   443,   443,   441,   452,   472,   472,
     480,   480,   828,   203,   203,   829,   203,   203,   203,   203,
     876,  1239,  1239,   453,  1239,  1239,  1239,  1239,   166,  1208,
     875,   454,  1219,   824,   197,  1209,  1220,   247,   895,   451,
    1221,   198,   455
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 381 "hermes.y"
    {flushText();;}
    break;

  case 6:
#line 389 "hermes.y"
    {
	 	AddPHint(0);
	 	p("<abstract>\n");
	 	AddPHint(1);
	 	;}
    break;

  case 7:
#line 394 "hermes.y"
    {
	 	AddPHint(0);
	 	p("</abstract>\n");
	 	AddPHint(1);
	 	;}
    break;

  case 9:
#line 401 "hermes.y"
    {
			printAbsLang();
		;}
    break;

  case 10:
#line 405 "hermes.y"
    {AddPHint(0);pHints=0;noDVIY=1;p("<ref>");;}
    break;

  case 11:
#line 406 "hermes.y"
    {printRef();p("<pref>");;}
    break;

  case 12:
#line 408 "hermes.y"
    {p("</pref></ref>");noDVIY=0;pHints=1;AddPHint(1);;}
    break;

  case 13:
#line 410 "hermes.y"
    {p("<label>");mathText=1;;}
    break;

  case 14:
#line 412 "hermes.y"
    {mathText=0;p("</label>");;}
    break;

  case 15:
#line 415 "hermes.y"
    {AddPHint(0);pHints=0;inCitation=1;p("<cite>");;}
    break;

  case 16:
#line 416 "hermes.y"
    {printCiteSRef();;}
    break;

  case 17:
#line 418 "hermes.y"
    {p("</cite>");pHints=1;AddPHint(1);inCitation=0;;}
    break;

  case 18:
#line 421 "hermes.y"
    {
				AddPHint(0);noDVIY=1;
				if (!hasSections)	hasSections=1;
				else p("</section>\n");
				p("<section>\n");
			;}
    break;

  case 19:
#line 428 "hermes.y"
    {noDVIY=0;AddPHint(1);;}
    break;

  case 20:
#line 430 "hermes.y"
    {AddPHint(0);printId();AddPHint(1);;}
    break;

  case 21:
#line 432 "hermes.y"
    {printBkgColor();;}
    break;

  case 22:
#line 435 "hermes.y"
    {
		AddPHint(0);
		p("\n<bibliography>\n");
		AddPHint(1);
		inBibliography=1;;}
    break;

  case 23:
#line 442 "hermes.y"
    {
		AddPHint(0);
		p("\n</bibliography>\n");
		AddPHint(1);
		inBibliography=0;
		;}
    break;

  case 24:
#line 449 "hermes.y"
    {AddPHint(0);p("\n</item>\n<item>");AddPHint(1);;}
    break;

  case 25:
#line 451 "hermes.y"
    {noDVIY=1;AddPHint(0);p("\n<list>\n");;}
    break;

  case 26:
#line 452 "hermes.y"
    {p("\n<item>\n");AddPHint(1);noDVIY=0;;}
    break;

  case 27:
#line 455 "hermes.y"
    {AddPHint(0);p("\n</item>\n</list>\n");AddPHint(1);;}
    break;

  case 28:
#line 458 "hermes.y"
    {AddPHint(0);p("<label>\n");AddPHint(1);;}
    break;

  case 29:
#line 461 "hermes.y"
    {AddPHint(0);p("\n</label>\n");AddPHint(1);;}
    break;

  case 30:
#line 464 "hermes.y"
    {if (mathmode && !mathOp) {mathBox++;mathText=1;p("<mtext>");};}
    break;

  case 31:
#line 466 "hermes.y"
    {if (mathmode && !mathOp) {p("</mtext>");mathBox--;mathText=0;};}
    break;

  case 35:
#line 471 "hermes.y"
    {AddPHint(0);flushText(); if(!mathBox) flushMath();AddPHint(1);;}
    break;

  case 37:
#line 473 "hermes.y"
    {if (!mathBox) {mathmode=0;mathText=0;};}
    break;

  case 39:
#line 474 "hermes.y"
    {pHints=0;p("<file>");;}
    break;

  case 40:
#line 474 "hermes.y"
    {p("</file>");pHints=1;;}
    break;

  case 41:
#line 476 "hermes.y"
    {mathmode=0;mathText=0;AddPHint(0);p("<underline>");AddPHint(1);;}
    break;

  case 42:
#line 479 "hermes.y"
    {AddPHint(0);p("</underline>");AddPHint(1);;}
    break;

  case 48:
#line 485 "hermes.y"
    {printFigureFileName();;}
    break;

  case 49:
#line 486 "hermes.y"
    {printEPSFigureFileName();;}
    break;

  case 52:
#line 492 "hermes.y"
    {AddPHint(0);p("<float>\n");;}
    break;

  case 53:
#line 493 "hermes.y"
    {printFType();;}
    break;

  case 54:
#line 494 "hermes.y"
    {AddPHint(1);;}
    break;

  case 55:
#line 496 "hermes.y"
    {AddPHint(0);p("</float>\n");AddPHint(1);;}
    break;

  case 57:
#line 501 "hermes.y"
    {
			AddPHint(0);
			if (inBibliography) {
				p("\n</item>\n<item>");
			}
			printId();
			AddPHint(1);
		;}
    break;

  case 58:
#line 513 "hermes.y"
    {AddPHint(0);p("<env>\n");printEnvType();AddPHint(1);;}
    break;

  case 59:
#line 516 "hermes.y"
    {AddPHint(0);p("</env>\n");AddPHint(1);;}
    break;

  case 60:
#line 520 "hermes.y"
    {printSectType();AddPHint(1);;}
    break;

  case 61:
#line 525 "hermes.y"
    {AddPHint(0);p("<title>");AddPHint(1);;}
    break;

  case 62:
#line 527 "hermes.y"
    {AddPHint(0);p("</title>");noDVIY=1;;}
    break;

  case 64:
#line 531 "hermes.y"
    {AddPHint(0);p("<label>");AddPHint(1);noDVIY=1;;}
    break;

  case 65:
#line 533 "hermes.y"
    {AddPHint(0);p("</label>");AddPHint(1);noDVIY=1;;}
    break;

  case 66:
#line 538 "hermes.y"
    {canbreak=0; AddPHint(0);pHints=0;p("<fnmark>");;}
    break;

  case 67:
#line 541 "hermes.y"
    {p("</fnmark>\n");pHints=1;AddPHint(1);canbreak=1;;}
    break;

  case 68:
#line 544 "hermes.y"
    {canbreak=0;AddPHint(0);p("<footnote>");AddPHint(1);;}
    break;

  case 69:
#line 547 "hermes.y"
    {AddPHint(0);p("\n</footnote>\n");AddPHint(1);canbreak=1;;}
    break;

  case 70:
#line 553 "hermes.y"
    {mathmode=0;pHints=1;AddPHint(0);canbreak=0;p("\n<caption>\n");AddPHint(1);;}
    break;

  case 71:
#line 556 "hermes.y"
    {AddPHint(0);p("\n</caption>\n");noDVIY=0;canbreak=1;AddPHint(1);;}
    break;

  case 74:
#line 573 "hermes.y"
    {AddPHint(0);inTable=1;p("<tabular>\n");;}
    break;

  case 75:
#line 575 "hermes.y"
    {p("</tabular>\n");AddPHint(1);inTable=0;;}
    break;

  case 76:
#line 578 "hermes.y"
    {AddPHint(0);inTable=1;p("<tabular>\n");;}
    break;

  case 77:
#line 580 "hermes.y"
    {p("</tabular>");AddPHint(1);inTable=0;;}
    break;

  case 78:
#line 585 "hermes.y"
    {pHints=1;AddPHint(0);canbreak=0;p("\n<caption>\n");AddPHint(1);;}
    break;

  case 79:
#line 588 "hermes.y"
    {AddPHint(0);p("\n</caption>\n");canbreak=1;AddPHint(1);;}
    break;

  case 80:
#line 594 "hermes.y"
    {AddPHint(0);inTable=1;noDVIY=1;p("<tabular>\n");;}
    break;

  case 81:
#line 597 "hermes.y"
    {p("</tabular>\n");AddPHint(1);inTable=0;noDVIY=0;;}
    break;

  case 82:
#line 599 "hermes.y"
    {AddPHint(0);inTable=1;noDVIY=1;p("\n<tabular>\n");;}
    break;

  case 83:
#line 602 "hermes.y"
    {p("\n</tabular>\n");AddPHint(1);inTable=0;noDVIY=1;;}
    break;

  case 84:
#line 602 "hermes.y"
    {noDVIY=0;;}
    break;

  case 86:
#line 607 "hermes.y"
    {printOption();;}
    break;

  case 88:
#line 610 "hermes.y"
    {printOption();;}
    break;

  case 93:
#line 625 "hermes.y"
    {p("<tr>\n<td>");pHints=1;AddPHint(1);noDVIY=0;;}
    break;

  case 94:
#line 625 "hermes.y"
    {AddPHint(0);p("\n</td>\n</tr>\n");noDVIY=1;;}
    break;

  case 99:
#line 636 "hermes.y"
    {AddPHint(0);p("\n</td>\n<td>\n");AddPHint(1);;}
    break;

  case 103:
#line 648 "hermes.y"
    {theFont.map();;}
    break;

  case 104:
#line 649 "hermes.y"
    {p("_");inhibitspace=1;;}
    break;

  case 105:
#line 650 "hermes.y"
    {fakesp=0;p("<dviy/>");;}
    break;

  case 107:
#line 652 "hermes.y"
    { theFont.map();;}
    break;

  case 108:
#line 653 "hermes.y"
    {p(" ");;}
    break;

  case 109:
#line 656 "hermes.y"
    {AddPHint(0);pHints=0;p("<ics>");;}
    break;

  case 110:
#line 658 "hermes.y"
    {p("</ics>");pHints=1;AddPHint(1);;}
    break;

  case 112:
#line 662 "hermes.y"
    {AddPHint(0);p("<matverw>");AddPHint(1);;}
    break;

  case 113:
#line 664 "hermes.y"
    {AddPHint(0);p("</matverw>\n");AddPHint(1);;}
    break;

  case 115:
#line 668 "hermes.y"
    {AddPHint(0);p("<zwigeb>\n");AddPHint(1);;}
    break;

  case 116:
#line 670 "hermes.y"
    {AddPHint(0);p("</zwigeb>\n");AddPHint(1);;}
    break;

  case 118:
#line 673 "hermes.y"
    {
		canbreak=0;	mathmode=0;AddPHint(0);
		p("\n<author>");
		AddPHint(1);
		;}
    break;

  case 119:
#line 678 "hermes.y"
    {
		AddPHint(0);
		p("\n</author>");canbreak=1;
		AddPHint(1);
		;}
    break;

  case 121:
#line 685 "hermes.y"
    {mathmode=0;
		canbreak=0;	AddPHint(0);
		p("<cauthor>\n");
		AddPHint(1);
		;}
    break;

  case 122:
#line 690 "hermes.y"
    {
		AddPHint(0);
		p("</cauthor>\n");canbreak=1;
		AddPHint(1);
		;}
    break;

  case 124:
#line 698 "hermes.y"
    {AddPHint(0);canbreak=0;p("<number>\n");AddPHint(1);;}
    break;

  case 125:
#line 700 "hermes.y"
    {AddPHint(0);p("</number>\n");canbreak=1;AddPHint(1);;}
    break;

  case 127:
#line 704 "hermes.y"
    {AddPHint(0);p("");AddPHint(1);;}
    break;

  case 128:
#line 706 "hermes.y"
    {AddPHint(0);p("");AddPHint(1);;}
    break;

  case 130:
#line 710 "hermes.y"
    {mathmode=0;AddPHint(0);p("<published>");AddPHint(1);;}
    break;

  case 131:
#line 712 "hermes.y"
    {AddPHint(0);p("</published>\n");AddPHint(1);;}
    break;

  case 133:
#line 716 "hermes.y"
    {AddPHint(0);p("<comment>\n");AddPHint(1);;}
    break;

  case 134:
#line 718 "hermes.y"
    {AddPHint(0);p("</comment>\n");AddPHint(1);;}
    break;

  case 136:
#line 722 "hermes.y"
    {AddPHint(0);p("");AddPHint(1);;}
    break;

  case 137:
#line 725 "hermes.y"
    {mathmode=0;canbreak=0;AddPHint(0);p("\n<title>");AddPHint(1);;}
    break;

  case 138:
#line 727 "hermes.y"
    {AddPHint(0);p("</title>\n");canbreak=1;AddPHint(1);;}
    break;

  case 140:
#line 730 "hermes.y"
    {mathmode=0;
		AddPHint(0);p("\n<date>");AddPHint(1);;}
    break;

  case 141:
#line 733 "hermes.y"
    {AddPHint(0);p("</date>");	AddPHint(1);;}
    break;

  case 143:
#line 737 "hermes.y"
    {AddPHint(0);p("<subjectClass>");AddPHint(1);;}
    break;

  case 144:
#line 739 "hermes.y"
    {AddPHint(0);p("</subjectClass>\n");AddPHint(1);;}
    break;

  case 146:
#line 743 "hermes.y"
    {AddPHint(0);p("<dedicatory>");AddPHint(1);;}
    break;

  case 147:
#line 745 "hermes.y"
    {AddPHint(0);p("</dedicatory>\n");AddPHint(1);;}
    break;

  case 149:
#line 749 "hermes.y"
    {AddPHint(0);p("<thanks>");AddPHint(1);;}
    break;

  case 150:
#line 751 "hermes.y"
    {AddPHint(0);p("</thanks>\n");AddPHint(1);;}
    break;

  case 152:
#line 755 "hermes.y"
    {mathmode=0;canbreak=0;AddPHint(0);pHints=0;p("<vaddress>");;}
    break;

  case 153:
#line 757 "hermes.y"
    {canbreak=1;p("</vaddress>\n");pHints=1;AddPHint(1);;}
    break;

  case 155:
#line 761 "hermes.y"
    {mathmode=0;canbreak=0;AddPHint(0);pHints=0;p("<email>");;}
    break;

  case 156:
#line 763 "hermes.y"
    {canbreak=1;p("</email>\n");pHints=1;AddPHint(1);;}
    break;

  case 158:
#line 767 "hermes.y"
    {mathmode=0;AddPHint(0);p("<affiliation>");AddPHint(1);;}
    break;

  case 159:
#line 769 "hermes.y"
    {AddPHint(0);p("</affiliation>");AddPHint(1);;}
    break;

  case 161:
#line 773 "hermes.y"
    {mathmode=0;AddPHint(0);p("<address>");AddPHint(1);;}
    break;

  case 162:
#line 775 "hermes.y"
    {AddPHint(0);p("</address>");AddPHint(1);;}
    break;

  case 164:
#line 779 "hermes.y"
    {mathmode=0;AddPHint(0);p("<caddress>");AddPHint(1);;}
    break;

  case 165:
#line 781 "hermes.y"
    {AddPHint(0);p("</caddress>");AddPHint(1);;}
    break;

  case 167:
#line 785 "hermes.y"
    {
		mathmode=0;canbreak=0;AddPHint(0);
		p("\n<author>");	AddPHint(1);
		;}
    break;

  case 168:
#line 790 "hermes.y"
    {
		AddPHint(0);p("\n</author>");
		canbreak=1;AddPHint(1);
		;}
    break;

  case 170:
#line 797 "hermes.y"
    {
		mathmode=0;canbreak=0;AddPHint(0);
		p("\n<name>");	AddPHint(1);
		;}
    break;

  case 171:
#line 802 "hermes.y"
    {
		AddPHint(0);p("</name>");
		canbreak=1;AddPHint(1);
		;}
    break;

  case 173:
#line 808 "hermes.y"
    {AddPHint(0);AddPHint(1);;}
    break;

  case 174:
#line 811 "hermes.y"
    {AddPHint(0);pHints=0;p("<keywords>");;}
    break;

  case 175:
#line 813 "hermes.y"
    {p("</keywords>");pHints=1;AddPHint(1);;}
    break;

  case 177:
#line 817 "hermes.y"
    {AddPHint(0);pHints=0;p("<PACS>");;}
    break;

  case 178:
#line 819 "hermes.y"
    {p("</PACS>");pHints=1;AddPHint(1);;}
    break;

  case 180:
#line 823 "hermes.y"
    {AddPHint(0);p("<idline>");AddPHint(1);;}
    break;

  case 181:
#line 825 "hermes.y"
    {AddPHint(0);p("</idline>");AddPHint(1);;}
    break;

  case 183:
#line 829 "hermes.y"
    {AddPHint(0);pHints=0;p("<doi>");;}
    break;

  case 184:
#line 831 "hermes.y"
    {p("</doi>");pHints=1;AddPHint(1);;}
    break;

  case 186:
#line 835 "hermes.y"
    {pHints=1;AddPHint(0);p("\n<copyright>");AddPHint(1);;}
    break;

  case 187:
#line 837 "hermes.y"
    {pHints=1;AddPHint(0);p("</copyright>\n");AddPHint(1);;}
    break;

  case 189:
#line 841 "hermes.y"
    {AddPHint(0);pHints=0;p("<location>");;}
    break;

  case 190:
#line 843 "hermes.y"
    {p("</location>");pHints=1;AddPHint(1);;}
    break;

  case 192:
#line 847 "hermes.y"
    {AddPHint(0);p("<journal>");AddPHint(1);;}
    break;

  case 193:
#line 849 "hermes.y"
    {AddPHint(0);p("</journal>");AddPHint(1);;}
    break;

  case 195:
#line 853 "hermes.y"
    {pHints=1;AddPHint(0);p("<logo>");AddPHint(1);;}
    break;

  case 196:
#line 855 "hermes.y"
    {AddPHint(0);p("</logo>");pHints=1;AddPHint(1);;}
    break;

  case 198:
#line 859 "hermes.y"
    {pHints=1;AddPHint(0);p("\n<branch>");AddPHint(1);;}
    break;

  case 199:
#line 861 "hermes.y"
    {AddPHint(0);p("</branch>\n");pHints=1;AddPHint(1);;}
    break;

  case 201:
#line 864 "hermes.y"
    {p("<fbox>");;}
    break;

  case 202:
#line 864 "hermes.y"
    {p("</fbox>");;}
    break;

  case 204:
#line 869 "hermes.y"
    {AddPHint(0);p("<headline>");AddPHint(1);;}
    break;

  case 205:
#line 871 "hermes.y"
    {AddPHint(0);p("</headline>");AddPHint(1);;}
    break;

  case 207:
#line 875 "hermes.y"
    {AddPHint(0);p("<footline>");AddPHint(1);;}
    break;

  case 208:
#line 877 "hermes.y"
    {AddPHint(0);p("</footline>");AddPHint(1);;}
    break;

  case 210:
#line 882 "hermes.y"
    {
		mathmode=0;infhp=1;p("<foot>");
	;}
    break;

  case 211:
#line 885 "hermes.y"
    {
		p("</foot>");infhp=0;
	;}
    break;

  case 212:
#line 889 "hermes.y"
    {
		mathmode=0;infhp=1;p("<head>");
	;}
    break;

  case 213:
#line 892 "hermes.y"
    {
		p("</head>");infhp=0;
	;}
    break;

  case 214:
#line 896 "hermes.y"
    {
		mathmode=0;pHints=0;	infhp=1;	p("<page nr=\"");
	;}
    break;

  case 215:
#line 899 "hermes.y"
    {
		p("\"/>");infhp=0;pHints=1;
	;}
    break;

  case 218:
#line 909 "hermes.y"
    {mathmode=0;pHints=0; canbreak=0;infhp=1;p("<page nr=\"");;}
    break;

  case 219:
#line 911 "hermes.y"
    {p("\"/>");canbreak=1;infhp=0;pHints=1;;}
    break;

  case 222:
#line 916 "hermes.y"
    {p("<pref>");;}
    break;

  case 223:
#line 916 "hermes.y"
    {p("</pref>");;}
    break;

  case 226:
#line 920 "hermes.y"
    {fakesp=0;p("<dviy/>");;}
    break;

  case 227:
#line 924 "hermes.y"
    {saveAccent(*yytext);;}
    break;

  case 228:
#line 924 "hermes.y"
    {contractTextAccent();inhibitspace=0;noDVIY=0;;}
    break;

  case 229:
#line 925 "hermes.y"
    {theFont.map();inhibitspace=0;noDVIY=0;;}
    break;

  case 230:
#line 926 "hermes.y"
    {saveAccentUnder(*yytext);contractTextAccent();inhibitspace=0;noDVIY=0;;}
    break;

  case 231:
#line 927 "hermes.y"
    {saveAccent(*yytext);;}
    break;

  case 232:
#line 927 "hermes.y"
    {contractTextAccent();inhibitspace=0;;}
    break;

  case 234:
#line 933 "hermes.y"
    {AddPHint(0);p("\n<label>");AddPHint(1);;}
    break;

  case 235:
#line 935 "hermes.y"
    {AddPHint(0);p("</label>\n");pHints=1;AddPHint(1);;}
    break;

  case 237:
#line 937 "hermes.y"
    {AddPHint(0);AddPHint(1);;}
    break;

  case 238:
#line 940 "hermes.y"
    {
	if (mathBox && mathText) {p("</mtext>"); mathText=0;} 
	mathmode=1;
	;}
    break;

  case 239:
#line 945 "hermes.y"
    { 
	if (mathBox) {p("<mtext>"); mathText=1;}
	else mathmode=0;
	;}
    break;

  case 240:
#line 951 "hermes.y"
    {mathblock=0;;}
    break;

  case 242:
#line 955 "hermes.y"
    {mathblock=1;;}
    break;

  case 243:
#line 957 "hermes.y"
    {if (Wraps[depth]) wrap(0); Wraps[depth]=0;;}
    break;

  case 251:
#line 966 "hermes.y"
    {AddPHint(0);AddPHint(1);;}
    break;

  case 252:
#line 968 "hermes.y"
    {mathblock=1;;}
    break;

  case 253:
#line 968 "hermes.y"
    {p("<mtr><mtd>");;}
    break;

  case 254:
#line 970 "hermes.y"
    {p("</mtd></mtr>");;}
    break;

  case 259:
#line 976 "hermes.y"
    {p("</mtd></mtr><mtr><mtd>");;}
    break;

  case 264:
#line 983 "hermes.y"
    {p("</mtd><mtd>");;}
    break;

  case 268:
#line 989 "hermes.y"
    {p("<label>");mathText=1;;}
    break;

  case 269:
#line 989 "hermes.y"
    {mathText=0;p("</label>");;}
    break;

  case 276:
#line 998 "hermes.y"
    {if (mathBox) {p("<mtext>"); mathText=1;};}
    break;

  case 277:
#line 1000 "hermes.y"
    {if (mathBox && mathText) {p("</mtext>"); mathText=0;};}
    break;

  case 283:
#line 1006 "hermes.y"
    {mathmode=0;p("<foot>");;}
    break;

  case 284:
#line 1006 "hermes.y"
    {p("</foot>");mathmode=1;;}
    break;

  case 286:
#line 1007 "hermes.y"
    {mathmode=0;p("<head>");;}
    break;

  case 287:
#line 1007 "hermes.y"
    {p("</head>");mathmode=1;;}
    break;

  case 289:
#line 1008 "hermes.y"
    {mathmode=0;pHints=0;p("<page nr=\"");;}
    break;

  case 290:
#line 1008 "hermes.y"
    {p("\"/>");mathmode=1;;}
    break;

  case 297:
#line 1014 "hermes.y"
    {mDelimiter=1;p("<mrow>");;}
    break;

  case 298:
#line 1016 "hermes.y"
    {blockthis=0xFFFF;p("<mrow>");mDelimiter=0;Wraps[depth]++;;}
    break;

  case 300:
#line 1018 "hermes.y"
    {mDelimiter=1;mathmode=1;p("</mrow>");;}
    break;

  case 301:
#line 1020 "hermes.y"
    {blockthis=0xFFFF;p("</mrow>");mDelimiter=0;if (Wraps[depth]==0) wrap(-1); else Wraps[depth]--; ;}
    break;

  case 311:
#line 1030 "hermes.y"
    {printId();;}
    break;

  case 313:
#line 1031 "hermes.y"
    {p("<OVER/>");;}
    break;

  case 315:
#line 1032 "hermes.y"
    {p("<CHOOSE/>");;}
    break;

  case 317:
#line 1033 "hermes.y"
    {p("<ATOP/>");;}
    break;

  case 321:
#line 1040 "hermes.y"
    {p("<mtable><mtr>");depth++;;}
    break;

  case 322:
#line 1042 "hermes.y"
    {p("</mtr></mtable>");depth--;;}
    break;

  case 325:
#line 1049 "hermes.y"
    {p("<mfrac linethickness=\"0\"><mrow>");;}
    break;

  case 326:
#line 1049 "hermes.y"
    {p("</mrow><mrow>");;}
    break;

  case 327:
#line 1049 "hermes.y"
    {p("</mrow></mfrac>");;}
    break;

  case 329:
#line 1050 "hermes.y"
    {pMathType=ld;pmt(0x2329);;}
    break;

  case 330:
#line 1050 "hermes.y"
    {pMathType=rd;pmt('|');;}
    break;

  case 331:
#line 1051 "hermes.y"
    {pMathType=ld;pmt('|');;}
    break;

  case 332:
#line 1051 "hermes.y"
    {pMathType=rd;pmt(0x232A);;}
    break;

  case 333:
#line 1052 "hermes.y"
    {pMathType=ld;pmt('(');p("<mo>mod</mo>");;}
    break;

  case 334:
#line 1052 "hermes.y"
    {pMathType=rd;pmt(')');;}
    break;

  case 336:
#line 1057 "hermes.y"
    {mathblock=1;;}
    break;

  case 337:
#line 1057 "hermes.y"
    {p("<mtr><mtd>");;}
    break;

  case 339:
#line 1059 "hermes.y"
    {p("</mtd></mtr>");;}
    break;

  case 340:
#line 1060 "hermes.y"
    {p("</mtd></mtr>");;}
    break;

  case 341:
#line 1064 "hermes.y"
    {mathmode=1;;}
    break;

  case 342:
#line 1064 "hermes.y"
    {p("<mtable><mtr>");depth++;;}
    break;

  case 343:
#line 1066 "hermes.y"
    {p("</mtr></mtable>");depth--;mathmode=0;;}
    break;

  case 344:
#line 1070 "hermes.y"
    {p("<mtable><mtr>");depth++;;}
    break;

  case 345:
#line 1072 "hermes.y"
    {p("</mtr></mtable>");depth--;;}
    break;

  case 346:
#line 1077 "hermes.y"
    {mathmode=1;mathblock=1;p("<mtable>");depth++;;}
    break;

  case 347:
#line 1081 "hermes.y"
    {p("</mtable>");mathmode=0;mathblock=0;depth--;;}
    break;

  case 350:
#line 1088 "hermes.y"
    {p("<mtr><mtd>");wrap(1);;}
    break;

  case 351:
#line 1088 "hermes.y"
    {wrap(0);p("</mtd>");;}
    break;

  case 352:
#line 1089 "hermes.y"
    {p("<mtd>");wrap(1);;}
    break;

  case 353:
#line 1089 "hermes.y"
    {wrap(0);p("</mtd>");;}
    break;

  case 354:
#line 1090 "hermes.y"
    {p("<mtd>");wrap(1);;}
    break;

  case 355:
#line 1090 "hermes.y"
    {wrap(0);p("</mtd>");;}
    break;

  case 356:
#line 1091 "hermes.y"
    {p("</mtr>");;}
    break;

  case 359:
#line 1101 "hermes.y"
    {p("<mtable><mtr>");depth++;;}
    break;

  case 360:
#line 1103 "hermes.y"
    {p("</mtr></mtable>");depth--;;}
    break;

  case 365:
#line 1119 "hermes.y"
    {p("<mtd>");wrap(1);;}
    break;

  case 366:
#line 1119 "hermes.y"
    {wrap(0);p("</mtd>");;}
    break;

  case 367:
#line 1121 "hermes.y"
    {p("</mtr><mtr>");;}
    break;

  case 368:
#line 1125 "hermes.y"
    {p("</mtd></mtr>");;}
    break;

  case 373:
#line 1133 "hermes.y"
    {p("<mtr><mtd>");;}
    break;

  case 375:
#line 1134 "hermes.y"
    {p("</mtd></mtr><mtr><mtd>");;}
    break;

  case 376:
#line 1134 "hermes.y"
    {p("</mtd><mtd>");;}
    break;

  case 377:
#line 1134 "hermes.y"
    {p("</mtd></mtr><mtr><mtd>");;}
    break;

  case 382:
#line 1139 "hermes.y"
    {p("</mtd><mtd>");;}
    break;

  case 383:
#line 1140 "hermes.y"
    {p("</mtd></mtr><mtr><mtd>");;}
    break;

  case 388:
#line 1147 "hermes.y"
    {theFont.map();;}
    break;

  case 389:
#line 1148 "hermes.y"
    {theFont.map();;}
    break;

  case 391:
#line 1150 "hermes.y"
    {pMathType=mi;pmt(0x0127);;}
    break;

  case 392:
#line 1151 "hermes.y"
    {pMathType=mo;pmt('_');;}
    break;

  case 393:
#line 1152 "hermes.y"
    {pMathType=mo;pmt(' ');;}
    break;

  case 394:
#line 1155 "hermes.y"
    {if (!mathOp) {mathBox++;mathText=1;p("<mtext>");};}
    break;

  case 395:
#line 1157 "hermes.y"
    {if (!mathOp) {p("</mtext>");mathBox--;mathText=0;};}
    break;

  case 397:
#line 1159 "hermes.y"
    {mathBox++;mathText=1;p("<mtext>");;}
    break;

  case 398:
#line 1159 "hermes.y"
    {p("</mtext>");mathBox--;mathText=0;;}
    break;

  case 400:
#line 1160 "hermes.y"
    {pMathType=mo;pmt(0x2209);;}
    break;

  case 401:
#line 1161 "hermes.y"
    {p("<mrow><mrow>");;}
    break;

  case 402:
#line 1162 "hermes.y"
    {p("</mrow></mrow>");;}
    break;

  case 403:
#line 1166 "hermes.y"
    {AddPHint(0);pHints=0;p("<cite>");;}
    break;

  case 404:
#line 1167 "hermes.y"
    {printCiteSRef();;}
    break;

  case 405:
#line 1170 "hermes.y"
    {p("</cite>");pHints=1;AddPHint(1);;}
    break;

  case 407:
#line 1172 "hermes.y"
    {AddPHint(0);pHints=0;noDVIY=1;p("<ref>");;}
    break;

  case 408:
#line 1173 "hermes.y"
    {printRef();p("<pref>");;}
    break;

  case 409:
#line 1175 "hermes.y"
    {p("</pref></ref>");noDVIY=0;pHints=1;AddPHint(1);;}
    break;

  case 411:
#line 1179 "hermes.y"
    {p("<mover><mrow>");;}
    break;

  case 412:
#line 1179 "hermes.y"
    {p("</mrow><mrow>");;}
    break;

  case 413:
#line 1179 "hermes.y"
    {p("</mrow>");endMAccent();p("</mover>");;}
    break;

  case 414:
#line 1180 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 415:
#line 1181 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x02190));p("</mo></mover>");;}
    break;

  case 416:
#line 1182 "hermes.y"
    {p("<munder accentunder=\"true\"><mrow>");hbrace=1;;}
    break;

  case 417:
#line 1183 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x02190));p("</mo></munder>");;}
    break;

  case 418:
#line 1184 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 419:
#line 1185 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x02192));p("</mo></mover>");;}
    break;

  case 420:
#line 1186 "hermes.y"
    {p("<munder accentunder=\"true\"><mrow>");hbrace=1;;}
    break;

  case 421:
#line 1187 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x02192));p("</mo></munder>");;}
    break;

  case 422:
#line 1188 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 423:
#line 1189 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x0FE37));p("</mo></mover>");;}
    break;

  case 424:
#line 1190 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 425:
#line 1191 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x02d9));p("</mo></mover>");;}
    break;

  case 426:
#line 1192 "hermes.y"
    {p("<munder accentunder=\"true\"><mrow>");hbrace=1;;}
    break;

  case 427:
#line 1193 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x0FE38));p("</mo></munder>");;}
    break;

  case 428:
#line 1194 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 429:
#line 1195 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8('^'));p("</mo></mover>");;}
    break;

  case 430:
#line 1196 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 431:
#line 1197 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8('~'));p("</mo></mover>");;}
    break;

  case 432:
#line 1198 "hermes.y"
    {p("<mover accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 433:
#line 1199 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x000AF));p("</mo></mover>");;}
    break;

  case 434:
#line 1200 "hermes.y"
    {p("<munder accent=\"true\"><mrow>");hbrace=1;;}
    break;

  case 435:
#line 1201 "hermes.y"
    {hbrace=0;p("</mrow><mo>");p(ul2utf8(0x00332));p("</mo></munder>");;}
    break;

  case 436:
#line 1202 "hermes.y"
    {saveAccent(*yytext);;}
    break;

  case 437:
#line 1202 "hermes.y"
    {contractTextAccent();;}
    break;

  case 441:
#line 1207 "hermes.y"
    {p("<degree>");;}
    break;

  case 442:
#line 1208 "hermes.y"
    {p("</degree>");;}
    break;

  case 443:
#line 1211 "hermes.y"
    {p("<mo>");;}
    break;

  case 444:
#line 1211 "hermes.y"
    {p("</mo>");;}
    break;

  case 445:
#line 1212 "hermes.y"
    {p("<mo>");;}
    break;

  case 446:
#line 1212 "hermes.y"
    {p("</mo>");;}
    break;

  case 447:
#line 1213 "hermes.y"
    {pMathType=mo;pmt(0x2A05);;}
    break;

  case 448:
#line 1214 "hermes.y"
    {pMathType=mo;pmt(0x2A06);;}
    break;

  case 449:
#line 1215 "hermes.y"
    {pMathType=mo;pmt(0x21A6);;}
    break;

  case 450:
#line 1216 "hermes.y"
    {pMathType=mo;pmt(0x27FC);;}
    break;

  case 451:
#line 1217 "hermes.y"
    {pMathType=mo;pmt(0x22A7);;}
    break;

  case 452:
#line 1218 "hermes.y"
    {pMathType=mo;pmt(0x21A9);;}
    break;

  case 453:
#line 1219 "hermes.y"
    {pMathType=mo;pmt(0x21AA);;}
    break;

  case 454:
#line 1220 "hermes.y"
    {pMathType=mo;pmt(0x27F5);;}
    break;

  case 455:
#line 1221 "hermes.y"
    {pMathType=mo;pmt(0x27F8);;}
    break;

  case 456:
#line 1222 "hermes.y"
    {pMathType=mo;pmt(0x27F6);;}
    break;

  case 457:
#line 1223 "hermes.y"
    {pMathType=mo;pmt(0x27F9);;}
    break;

  case 458:
#line 1224 "hermes.y"
    {pMathType=mo;pmt(0x27F7);;}
    break;

  case 459:
#line 1225 "hermes.y"
    {pMathType=mo;pmt(0x27FA);;}
    break;

  case 460:
#line 1226 "hermes.y"
    {pMathType=mo;pmt(0x22C8);;}
    break;

  case 461:
#line 1229 "hermes.y"
    {p(" LD ");;}
    break;

  case 462:
#line 1230 "hermes.y"
    {p(" RD ");;}
    break;

  case 464:
#line 1234 "hermes.y"
    {p("<mo>");;}
    break;

  case 465:
#line 1234 "hermes.y"
    {p("</mo>");;}
    break;

  case 467:
#line 1236 "hermes.y"
    {p("<mfrac><mrow>");;}
    break;

  case 468:
#line 1236 "hermes.y"
    {p("</mrow><mrow>");;}
    break;

  case 470:
#line 1238 "hermes.y"
    {p("<mroot><mrow>");;}
    break;

  case 471:
#line 1239 "hermes.y"
    {p("</mrow><mrow>");;}
    break;

  case 472:
#line 1240 "hermes.y"
    {p("</mrow></mroot>");;}
    break;

  case 473:
#line 1241 "hermes.y"
    {p("<msqrt>");;}
    break;

  case 474:
#line 1241 "hermes.y"
    {p("</msqrt>");;}
    break;

  case 476:
#line 1242 "hermes.y"
    {p("<mover><mrow>");;}
    break;

  case 477:
#line 1243 "hermes.y"
    {p("</mrow><mrow>");;}
    break;

  case 478:
#line 1244 "hermes.y"
    {p("</mrow></mover>");;}
    break;

  case 479:
#line 1245 "hermes.y"
    {decorated=0;mathOp=1;p("<mo>");;}
    break;

  case 480:
#line 1245 "hermes.y"
    {mathOp=0;if (!decorated) p("</mo>");;}
    break;

  case 481:
#line 1249 "hermes.y"
    {p("</mrow></mfrac>");;}
    break;

  case 482:
#line 1250 "hermes.y"
    {p("</mrow></mfrac>");;}
    break;

  case 483:
#line 1255 "hermes.y"
    {
				if (!mathText) {
					if (mathOp && !decorated) p("</mo>");
					beginSuperScript();
				}
			;}
    break;

  case 484:
#line 1262 "hermes.y"
    {
				if (!mathText) 
					endSuperScript();
			;}
    break;

  case 486:
#line 1269 "hermes.y"
    {
				if (!mathText){ 
					if (mathOp && !decorated) p("</mo>");
					beginSubScript();
				}
			;}
    break;

  case 487:
#line 1276 "hermes.y"
    {
				if (!mathText) 
				endSubScript();
			;}
    break;

  case 499:
#line 1298 "hermes.y"
    {p("<ci>");;}
    break;

  case 500:
#line 1298 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 502:
#line 1299 "hermes.y"
    {p("<apply><inverse/><ci>");;}
    break;

  case 503:
#line 1299 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 504:
#line 1300 "hermes.y"
    {p("<apply><compose/><ci>");;}
    break;

  case 505:
#line 1300 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 506:
#line 1300 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 507:
#line 1301 "hermes.y"
    {p("<apply><domain/><ci type=\"function\">");;}
    break;

  case 508:
#line 1301 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 509:
#line 1302 "hermes.y"
    {p("<apply><codomain/><ci type=\"function\">");;}
    break;

  case 510:
#line 1302 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 511:
#line 1303 "hermes.y"
    {p("<apply><image/><ci type=\"function\">");;}
    break;

  case 512:
#line 1303 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 514:
#line 1305 "hermes.y"
    {p("<piecewise>");;}
    break;

  case 515:
#line 1305 "hermes.y"
    {p("</piecewise>");;}
    break;

  case 519:
#line 1316 "hermes.y"
    {p("<piece><ci>");;}
    break;

  case 520:
#line 1317 "hermes.y"
    {p("</ci><ci><mtext>");mathBox=mathText=1;;}
    break;

  case 521:
#line 1318 "hermes.y"
    {p("</mtext></ci></piece>");mathBox=mathText=0;;}
    break;

  case 526:
#line 1326 "hermes.y"
    {p("<piecewise>");;}
    break;

  case 527:
#line 1326 "hermes.y"
    {p("</piecewise>");;}
    break;

  case 530:
#line 1332 "hermes.y"
    {p("<piecewise><piece><ci>");;}
    break;

  case 532:
#line 1333 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 533:
#line 1333 "hermes.y"
    {p("</ci></piece><piece><ci>");;}
    break;

  case 534:
#line 1335 "hermes.y"
    {p("</ci></piece></piecewise>");;}
    break;

  case 538:
#line 1339 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 539:
#line 1340 "hermes.y"
    {p("</ci></piece><piece><ci>");;}
    break;

  case 540:
#line 1343 "hermes.y"
    {p("<piece><ci>");;}
    break;

  case 541:
#line 1343 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 542:
#line 1345 "hermes.y"
    {p("</ci></piece>");;}
    break;

  case 547:
#line 1361 "hermes.y"
    {p("<interval closure=\"-\">");;}
    break;

  case 548:
#line 1362 "hermes.y"
    {
	char*temp=strrchr(doc_math,0),*open="open",*closed="closed";
	temp=MatchTagLeft(temp,"<interval");
	if (strchr(temp,'(')) {
		Insert(strchr(temp,'\"')+1,open) ;
		Clean(temp,"<mrow><mo>(</mo><mrow>",1);
	}
	if (strchr(temp,'[')) {
	Insert(strchr(temp,'\"')+1,closed) ;
	Clean(temp,"<mrow><mo>[</mo><mrow>",1);
	}
	if (strchr(temp,')')) {
	Insert(strchr(temp,'-')+1,open) ;
	Clean(temp,"</mrow><mo>)</mo></mrow>",1);
	}
	if (strchr(temp,']')) {
	Insert(strchr(temp,'-')+1,closed) ;
	Clean(temp,"</mrow><mo>]</mo></mrow>",1);
	}
	p("</ci></interval>");
;}
    break;

  case 549:
#line 1387 "hermes.y"
    {p("<apply><quotient/><ci>");;}
    break;

  case 550:
#line 1387 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 551:
#line 1387 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 553:
#line 1388 "hermes.y"
    {p("<apply><factorial/><ci>");;}
    break;

  case 554:
#line 1388 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 555:
#line 1389 "hermes.y"
    {p("<apply><divide><ci>");;}
    break;

  case 556:
#line 1389 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 558:
#line 1390 "hermes.y"
    {p("<apply><max/>");;}
    break;

  case 559:
#line 1390 "hermes.y"
    {p("</apply>");;}
    break;

  case 560:
#line 1391 "hermes.y"
    {p("<apply><max/>");;}
    break;

  case 561:
#line 1391 "hermes.y"
    {p("</apply>");;}
    break;

  case 562:
#line 1392 "hermes.y"
    {p("<apply><min/>");;}
    break;

  case 563:
#line 1392 "hermes.y"
    {p("</apply>");;}
    break;

  case 564:
#line 1393 "hermes.y"
    {p("<apply><min/>");;}
    break;

  case 565:
#line 1393 "hermes.y"
    {p("</apply>");;}
    break;

  case 566:
#line 1394 "hermes.y"
    {p("<apply><power/><ci>");;}
    break;

  case 567:
#line 1394 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 568:
#line 1394 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 569:
#line 1395 "hermes.y"
    {p("<apply><rem/><ci>");;}
    break;

  case 570:
#line 1395 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 571:
#line 1395 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 572:
#line 1396 "hermes.y"
    {p("<apply><plus/><ci>");;}
    break;

  case 573:
#line 1396 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 574:
#line 1396 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 575:
#line 1397 "hermes.y"
    {p("<apply><minus/><ci>");;}
    break;

  case 576:
#line 1397 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 577:
#line 1397 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 578:
#line 1398 "hermes.y"
    {p("<apply><times/><ci>");;}
    break;

  case 579:
#line 1398 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 580:
#line 1398 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 581:
#line 1399 "hermes.y"
    {p("<apply><root/>");;}
    break;

  case 582:
#line 1399 "hermes.y"
    {p("<ci>");;}
    break;

  case 583:
#line 1399 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 584:
#line 1400 "hermes.y"
    {p("<apply><root/><degree><cn>2</cn></degree><ci>");;}
    break;

  case 585:
#line 1400 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 587:
#line 1401 "hermes.y"
    {p("<apply><gcd/><ci>");;}
    break;

  case 588:
#line 1401 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 590:
#line 1402 "hermes.y"
    {p("<apply><and/><ci>");;}
    break;

  case 591:
#line 1402 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 592:
#line 1402 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 593:
#line 1403 "hermes.y"
    {p("<apply><or/><ci>");;}
    break;

  case 594:
#line 1403 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 595:
#line 1403 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 596:
#line 1404 "hermes.y"
    {p("<apply><xor/><ci>");;}
    break;

  case 597:
#line 1404 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 598:
#line 1404 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 599:
#line 1405 "hermes.y"
    {p("<apply><not/><ci>");;}
    break;

  case 600:
#line 1405 "hermes.y"
    {p("</ci>");;}
    break;

  case 602:
#line 1406 "hermes.y"
    {p("<apply><implies/><ci>");;}
    break;

  case 603:
#line 1406 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 604:
#line 1406 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 606:
#line 1407 "hermes.y"
    {p("<apply><forall/>");;}
    break;

  case 607:
#line 1407 "hermes.y"
    {p("</apply>");;}
    break;

  case 608:
#line 1408 "hermes.y"
    {p("<apply><exists/>");;}
    break;

  case 609:
#line 1408 "hermes.y"
    {p("</apply>");;}
    break;

  case 610:
#line 1409 "hermes.y"
    {p("<apply><abs/><ci>");;}
    break;

  case 611:
#line 1409 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 612:
#line 1410 "hermes.y"
    {p("<apply><conjugate/><ci>");;}
    break;

  case 613:
#line 1410 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 614:
#line 1411 "hermes.y"
    {p("<apply><arg/><ci>");;}
    break;

  case 615:
#line 1411 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 616:
#line 1412 "hermes.y"
    {p("<apply><real/><ci>");;}
    break;

  case 617:
#line 1412 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 618:
#line 1413 "hermes.y"
    {p("<apply><imaginary/><ci>");;}
    break;

  case 619:
#line 1413 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 620:
#line 1414 "hermes.y"
    {p("<apply><lcm/><ci>");;}
    break;

  case 621:
#line 1414 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 623:
#line 1415 "hermes.y"
    {p("<apply><floor/><ci>");;}
    break;

  case 624:
#line 1415 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 626:
#line 1416 "hermes.y"
    {p("<apply><ceiling/><ci>");;}
    break;

  case 627:
#line 1416 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 629:
#line 1420 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 630:
#line 1421 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 633:
#line 1430 "hermes.y"
    {p("<bvar>");;}
    break;

  case 634:
#line 1430 "hermes.y"
    {p("</bvar>");;}
    break;

  case 637:
#line 1432 "hermes.y"
    {p("<ci>");;}
    break;

  case 638:
#line 1432 "hermes.y"
    {p("</ci>");;}
    break;

  case 640:
#line 1433 "hermes.y"
    {p("<condition>");;}
    break;

  case 641:
#line 1433 "hermes.y"
    {p("</condition>");;}
    break;

  case 644:
#line 1439 "hermes.y"
    {p(" LIST <ci>");;}
    break;

  case 646:
#line 1441 "hermes.y"
    {
	char*temp=strrchr(doc_math,0),*tail,*lock;
	while (temp!=strstr(temp," LIST ")) temp--;
	lock=temp;
	while ((temp=strstr(temp,"<mo>,</mo>"))){
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp+strlen("<mo>,</mo>"));
		strcpy(temp,"</ci><ci>");
		strcat(temp,tail);
		free(tail);
	}
	tail=(char*)malloc(strlen(lock)+1);
	strcpy(tail,lock+strlen(" LIST "));
	*lock=0;
	strcpy(lock,tail);
	free(tail);
	p("</ci>");
;}
    break;

  case 647:
#line 1462 "hermes.y"
    {
	char*temp=strrchr(doc_math,0),*tail,*lock;
	while (temp!=strstr(temp,"<bvar>")) temp--;
	lock=temp;
	while ((temp=strstr(temp,"</ci><ci>"))){
		if (strstr(temp,"</bvar")){
			tail=(char*)malloc(strlen(temp)+1);
			strcpy(tail,temp+strlen("</ci><ci>"));
			strcpy(temp,"</ci></bvar><bvar><ci>");
			lock=strrchr(temp,0);
			strcat(temp,tail);
			temp=lock;
			free(tail);
		}else break;
	}
;}
    break;

  case 648:
#line 1481 "hermes.y"
    {p("<apply><eq/><ci>");;}
    break;

  case 649:
#line 1481 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 650:
#line 1481 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 651:
#line 1482 "hermes.y"
    {p("<apply><neq/><ci>");;}
    break;

  case 652:
#line 1482 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 653:
#line 1482 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 654:
#line 1483 "hermes.y"
    {p("<apply><leq/><ci>");;}
    break;

  case 655:
#line 1483 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 656:
#line 1483 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 657:
#line 1484 "hermes.y"
    {p("<apply><geq/><ci>");;}
    break;

  case 658:
#line 1484 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 659:
#line 1484 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 660:
#line 1485 "hermes.y"
    {p("<apply><equivalent/><ci>");;}
    break;

  case 661:
#line 1485 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 662:
#line 1485 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 663:
#line 1486 "hermes.y"
    {p("<apply><approx/><ci>");;}
    break;

  case 664:
#line 1486 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 665:
#line 1486 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 666:
#line 1487 "hermes.y"
    {p("<apply><gt/><ci>");;}
    break;

  case 667:
#line 1487 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 668:
#line 1487 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 669:
#line 1488 "hermes.y"
    {p("<apply><lt/><ci>");;}
    break;

  case 670:
#line 1488 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 671:
#line 1488 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 672:
#line 1489 "hermes.y"
    {p("<apply><factorof/><ci>");;}
    break;

  case 673:
#line 1489 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 674:
#line 1489 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 675:
#line 1493 "hermes.y"
    {p("<set>");;}
    break;

  case 676:
#line 1493 "hermes.y"
    {p("</set>");;}
    break;

  case 677:
#line 1494 "hermes.y"
    {p("<set>");;}
    break;

  case 678:
#line 1494 "hermes.y"
    {p("</set>");;}
    break;

  case 679:
#line 1495 "hermes.y"
    {p("<list>");;}
    break;

  case 680:
#line 1495 "hermes.y"
    {p("</list>");;}
    break;

  case 681:
#line 1496 "hermes.y"
    {p("<list>");;}
    break;

  case 682:
#line 1496 "hermes.y"
    {p("</list>");;}
    break;

  case 683:
#line 1497 "hermes.y"
    {p("<apply><prsubset/><ci>");;}
    break;

  case 684:
#line 1497 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 685:
#line 1497 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 686:
#line 1498 "hermes.y"
    {p("<apply><subset/><ci>");;}
    break;

  case 687:
#line 1498 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 688:
#line 1498 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 689:
#line 1499 "hermes.y"
    {p("<apply><notprsubset/><ci>");;}
    break;

  case 690:
#line 1499 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 691:
#line 1499 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 692:
#line 1500 "hermes.y"
    {p("<apply><notsubset/><ci>");;}
    break;

  case 693:
#line 1500 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 694:
#line 1500 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 695:
#line 1501 "hermes.y"
    {p("<apply><union/><ci>");;}
    break;

  case 696:
#line 1501 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 697:
#line 1501 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 698:
#line 1502 "hermes.y"
    {p("<apply><intersect/><ci>");;}
    break;

  case 699:
#line 1502 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 700:
#line 1502 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 701:
#line 1503 "hermes.y"
    {p("<apply><in/><ci>");;}
    break;

  case 702:
#line 1503 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 703:
#line 1503 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 704:
#line 1504 "hermes.y"
    {p("<apply><notin/><ci>");;}
    break;

  case 705:
#line 1504 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 706:
#line 1504 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 707:
#line 1505 "hermes.y"
    {p("<apply><setdiff/><ci>");;}
    break;

  case 708:
#line 1505 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 709:
#line 1505 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 710:
#line 1506 "hermes.y"
    {p("<apply><card/><ci>");;}
    break;

  case 711:
#line 1506 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 712:
#line 1507 "hermes.y"
    {p("<apply><cartesianproduct/><ci>");;}
    break;

  case 713:
#line 1507 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 714:
#line 1507 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 715:
#line 1511 "hermes.y"
    {p("<apply><arccos/><ci>");;}
    break;

  case 716:
#line 1511 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 718:
#line 1512 "hermes.y"
    {p("<apply><arccosh/><ci>");;}
    break;

  case 719:
#line 1512 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 721:
#line 1513 "hermes.y"
    {p("<apply><arcsin/><ci>");;}
    break;

  case 722:
#line 1513 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 724:
#line 1514 "hermes.y"
    {p("<apply><arcsinh/><ci>");;}
    break;

  case 725:
#line 1514 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 727:
#line 1515 "hermes.y"
    {p("<apply><arctan/><ci>");;}
    break;

  case 728:
#line 1515 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 730:
#line 1516 "hermes.y"
    {p("<apply><arctanh/><ci>");;}
    break;

  case 731:
#line 1516 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 733:
#line 1517 "hermes.y"
    {p("<apply><cos/><ci>");;}
    break;

  case 734:
#line 1517 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 736:
#line 1518 "hermes.y"
    {p("<apply><cosh/><ci>");;}
    break;

  case 737:
#line 1518 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 739:
#line 1519 "hermes.y"
    {p("<apply><cot/><ci>");;}
    break;

  case 740:
#line 1519 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 742:
#line 1520 "hermes.y"
    {p("<apply><arccot/><ci>");;}
    break;

  case 743:
#line 1520 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 745:
#line 1521 "hermes.y"
    {p("<apply><coth/><ci>");;}
    break;

  case 746:
#line 1521 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 748:
#line 1522 "hermes.y"
    {p("<apply><arccoth/><ci>");;}
    break;

  case 749:
#line 1522 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 751:
#line 1523 "hermes.y"
    {p("<apply><csc/><ci>");;}
    break;

  case 752:
#line 1523 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 754:
#line 1524 "hermes.y"
    {p("<apply><arccsc/><ci>");;}
    break;

  case 755:
#line 1524 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 757:
#line 1525 "hermes.y"
    {p("<apply><csch/><ci>");;}
    break;

  case 758:
#line 1525 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 760:
#line 1526 "hermes.y"
    {p("<apply><arccsch/><ci>");;}
    break;

  case 761:
#line 1526 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 763:
#line 1527 "hermes.y"
    {p("<apply><exp/><ci>");;}
    break;

  case 764:
#line 1527 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 766:
#line 1528 "hermes.y"
    {p("<apply><lg/><logbase><cn>10</cn></logbase><ci>");;}
    break;

  case 767:
#line 1528 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 769:
#line 1529 "hermes.y"
    {p("<apply><ln/><ci>");;}
    break;

  case 770:
#line 1529 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 772:
#line 1530 "hermes.y"
    {p("<apply><log/><ci>");;}
    break;

  case 773:
#line 1530 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 775:
#line 1531 "hermes.y"
    {p("<apply><sec/><ci>");;}
    break;

  case 776:
#line 1531 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 778:
#line 1532 "hermes.y"
    {p("<apply><arcsec/><ci>");;}
    break;

  case 779:
#line 1532 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 781:
#line 1533 "hermes.y"
    {p("<apply><sech/><ci>");;}
    break;

  case 782:
#line 1533 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 784:
#line 1534 "hermes.y"
    {p("<apply><arcsech/><ci>");;}
    break;

  case 785:
#line 1534 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 787:
#line 1535 "hermes.y"
    {p("<apply><sin/><ci>");;}
    break;

  case 788:
#line 1535 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 790:
#line 1536 "hermes.y"
    {p("<apply><sinh/><ci>");;}
    break;

  case 791:
#line 1536 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 793:
#line 1537 "hermes.y"
    {p("<apply><tan/><ci>");;}
    break;

  case 794:
#line 1537 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 796:
#line 1538 "hermes.y"
    {p("<apply><tanh/><ci>");;}
    break;

  case 797:
#line 1538 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 799:
#line 1542 "hermes.y"
    {p("<apply><mean/><ci>");;}
    break;

  case 800:
#line 1542 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 801:
#line 1543 "hermes.y"
    {p("<apply><sdev/><ci>");;}
    break;

  case 802:
#line 1543 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 803:
#line 1544 "hermes.y"
    {p("<apply><variance/><ci>");;}
    break;

  case 804:
#line 1544 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 805:
#line 1545 "hermes.y"
    {p("<apply><median/><ci>");;}
    break;

  case 806:
#line 1545 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 807:
#line 1546 "hermes.y"
    {p("<apply><mode/><ci>");;}
    break;

  case 808:
#line 1546 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 809:
#line 1547 "hermes.y"
    {p("<apply><moment/><ci>");;}
    break;

  case 810:
#line 1547 "hermes.y"
    {p("</ci>");;}
    break;

  case 812:
#line 1548 "hermes.y"
    {p("<apply><moment/><ci>");;}
    break;

  case 813:
#line 1548 "hermes.y"
    {p("</ci>");;}
    break;

  case 817:
#line 1552 "hermes.y"
    {p("<momentabout><ci>");;}
    break;

  case 818:
#line 1552 "hermes.y"
    {p("</ci></momentabout>");;}
    break;

  case 820:
#line 1553 "hermes.y"
    {p("<degree>");;}
    break;

  case 821:
#line 1553 "hermes.y"
    {p("<cn>");;}
    break;

  case 822:
#line 1553 "hermes.y"
    {p("</cn>");;}
    break;

  case 823:
#line 1553 "hermes.y"
    {p("</degree>");;}
    break;

  case 824:
#line 1554 "hermes.y"
    {
	//make the first child the last
	char*temp=strrchr(doc_math,0), *tail,*lock;
	lock=MatchTagLeft(temp,"<apply");temp=NULL;
	if ((temp=strstr(lock,"<momentabout")));
	else temp=strstr(lock,"<degree");
	if (temp){
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp);*temp=0;
		lock=strstr(lock,"<ci");
		Insert(lock,tail);
		free(tail);
	}
	p("</apply>");
;}
    break;

  case 827:
#line 1573 "hermes.y"
    {p("<apply><determinant/><ci>");;}
    break;

  case 828:
#line 1573 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 829:
#line 1574 "hermes.y"
    {p("<apply><transpose/><ci type=\"matrix\">");;}
    break;

  case 830:
#line 1574 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 831:
#line 1575 "hermes.y"
    {p("<apply><selector/>");;}
    break;

  case 832:
#line 1575 "hermes.y"
    {p("<cn>");;}
    break;

  case 834:
#line 1576 "hermes.y"
    {p("<vectorproduct/><ci>");;}
    break;

  case 835:
#line 1576 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 836:
#line 1576 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 837:
#line 1577 "hermes.y"
    {p("<scalarproduct/><ci>");;}
    break;

  case 838:
#line 1577 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 839:
#line 1577 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 840:
#line 1578 "hermes.y"
    {p("<outerproduct/><ci>");;}
    break;

  case 841:
#line 1578 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 842:
#line 1578 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 843:
#line 1581 "hermes.y"
    {p("<vector><ci>");;}
    break;

  case 847:
#line 1587 "hermes.y"
    {p("<matrix><matrixrow><ci>");;}
    break;

  case 849:
#line 1588 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 850:
#line 1588 "hermes.y"
    {p("</ci></matrixrow><matrixrow><ci>");;}
    break;

  case 851:
#line 1590 "hermes.y"
    {p("</ci></matrixrow></matrix>");;}
    break;

  case 854:
#line 1594 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 855:
#line 1595 "hermes.y"
    {p("</ci></matrixrow><matrixrow><ci>");;}
    break;

  case 856:
#line 1598 "hermes.y"
    {p("<ci type=\"vector\">");;}
    break;

  case 857:
#line 1598 "hermes.y"
    {p("</ci>");;}
    break;

  case 858:
#line 1599 "hermes.y"
    {p("<ci type=\"matrix\">");;}
    break;

  case 859:
#line 1599 "hermes.y"
    {p("</ci>");;}
    break;

  case 865:
#line 1607 "hermes.y"
    {
	char*temp=strrchr(doc_math,0),*lock,*tail;
	temp=MatchTagLeft(temp,"<vector");
	temp=strstr(temp,">");temp++;
	lock=temp;
	//replace <mo>,</mo> with </ci><ci>
	while ((temp=strstr(temp,"<mo>,</mo>"))){
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp+strlen("<mo>,</mo>"));
		strcpy(temp,"</ci><ci>");
		strcat(temp,tail);
		free(tail);
	}
	temp=lock;
	while ((temp=strstr(temp,"<mo> CR </mo>"))){
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp+strlen("<mo> CR </mo>"));
		strcpy(temp,"</ci><ci>");
		strcat(temp,tail);
		free(tail);
	}
	p("</ci></vector>");
;}
    break;

  case 866:
#line 1631 "hermes.y"
    {
	char*temp=strrchr(doc_math,0),*lock,*tail;
	temp=MatchTagLeft(temp,"<apply");
	temp=strstr(temp,">");temp++;
	lock=temp;
	//replace <mo>,</mo> with </cn><cn>
	while ((temp=strstr(temp,"<mo>,</mo>"))){
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp+strlen("<mo>,</mo>"));
		strcpy(temp,"</cn><cn>");
		strcat(temp,tail);
		free(tail);
	}
	p("</cn></apply>");
;}
    break;

  case 867:
#line 1648 "hermes.y"
    {p("<integers/>");;}
    break;

  case 868:
#line 1649 "hermes.y"
    {p("<naturalnumbers/>");;}
    break;

  case 869:
#line 1650 "hermes.y"
    {p("<rationals/>");;}
    break;

  case 870:
#line 1651 "hermes.y"
    {p("<reals/>");;}
    break;

  case 871:
#line 1652 "hermes.y"
    {p("<complexes/>");;}
    break;

  case 872:
#line 1653 "hermes.y"
    {p("<primes/>");;}
    break;

  case 873:
#line 1654 "hermes.y"
    {p("<exponentiale/>");;}
    break;

  case 874:
#line 1655 "hermes.y"
    {p("<imaginaryi/>");;}
    break;

  case 875:
#line 1656 "hermes.y"
    {p("<notanumber/>");;}
    break;

  case 876:
#line 1657 "hermes.y"
    {p("<emptyset/>");;}
    break;

  case 877:
#line 1658 "hermes.y"
    {p("<true/>");;}
    break;

  case 878:
#line 1659 "hermes.y"
    {p("<false/>");;}
    break;

  case 879:
#line 1660 "hermes.y"
    {p("<pi/>");;}
    break;

  case 880:
#line 1661 "hermes.y"
    {p("<eulergamma/>");;}
    break;

  case 881:
#line 1662 "hermes.y"
    {p("<infinity/>");;}
    break;

  case 882:
#line 1663 "hermes.y"
    {p("<ident/>");;}
    break;

  case 883:
#line 1668 "hermes.y"
    {p("tr");;}
    break;

  case 884:
#line 1672 "hermes.y"
    {p("arccos");;}
    break;

  case 885:
#line 1673 "hermes.y"
    {p("arccosh");;}
    break;

  case 886:
#line 1674 "hermes.y"
    {p("arcsin");;}
    break;

  case 887:
#line 1675 "hermes.y"
    {p("arcsinh");;}
    break;

  case 888:
#line 1676 "hermes.y"
    {p("arctan");;}
    break;

  case 889:
#line 1677 "hermes.y"
    {p("arctanh");;}
    break;

  case 890:
#line 1678 "hermes.y"
    {p("arg");;}
    break;

  case 891:
#line 1679 "hermes.y"
    {p("cos");;}
    break;

  case 892:
#line 1680 "hermes.y"
    {p("cosh");;}
    break;

  case 893:
#line 1681 "hermes.y"
    {p("cot");;}
    break;

  case 894:
#line 1682 "hermes.y"
    {p("arccot");;}
    break;

  case 895:
#line 1683 "hermes.y"
    {p("coth");;}
    break;

  case 896:
#line 1684 "hermes.y"
    {p("arccoth");;}
    break;

  case 897:
#line 1685 "hermes.y"
    {p("csc");;}
    break;

  case 898:
#line 1686 "hermes.y"
    {p("arccsc");;}
    break;

  case 899:
#line 1687 "hermes.y"
    {p("csch");;}
    break;

  case 900:
#line 1688 "hermes.y"
    {p("arccsch");;}
    break;

  case 901:
#line 1689 "hermes.y"
    {p("deg");;}
    break;

  case 902:
#line 1690 "hermes.y"
    {p("det");;}
    break;

  case 903:
#line 1691 "hermes.y"
    {p("dim");;}
    break;

  case 904:
#line 1692 "hermes.y"
    {p("exp");;}
    break;

  case 905:
#line 1693 "hermes.y"
    {p("gcd");;}
    break;

  case 906:
#line 1694 "hermes.y"
    {p("lcm");;}
    break;

  case 907:
#line 1695 "hermes.y"
    {p("hom");;}
    break;

  case 908:
#line 1696 "hermes.y"
    {p("inf");;}
    break;

  case 909:
#line 1697 "hermes.y"
    {p("ker");;}
    break;

  case 910:
#line 1698 "hermes.y"
    {p("log");;}
    break;

  case 911:
#line 1699 "hermes.y"
    {p("lim");;}
    break;

  case 912:
#line 1700 "hermes.y"
    {p("liminf");;}
    break;

  case 913:
#line 1701 "hermes.y"
    {p("limsup");;}
    break;

  case 914:
#line 1702 "hermes.y"
    {p("ln");;}
    break;

  case 915:
#line 1703 "hermes.y"
    {p("log");;}
    break;

  case 916:
#line 1704 "hermes.y"
    {p("max");;}
    break;

  case 917:
#line 1705 "hermes.y"
    {p("min");;}
    break;

  case 918:
#line 1706 "hermes.y"
    {p("pr");;}
    break;

  case 919:
#line 1707 "hermes.y"
    {p("sec");;}
    break;

  case 920:
#line 1708 "hermes.y"
    {p("arcsec");;}
    break;

  case 921:
#line 1709 "hermes.y"
    {p("sech");;}
    break;

  case 922:
#line 1710 "hermes.y"
    {p("arcsech");;}
    break;

  case 923:
#line 1711 "hermes.y"
    {p("sin");;}
    break;

  case 924:
#line 1712 "hermes.y"
    {p("sinh");;}
    break;

  case 925:
#line 1713 "hermes.y"
    {p("sup");;}
    break;

  case 926:
#line 1714 "hermes.y"
    {p("tan");;}
    break;

  case 927:
#line 1715 "hermes.y"
    {p("tanh");;}
    break;

  case 928:
#line 1717 "hermes.y"
    {p("mod");;}
    break;

  case 929:
#line 1718 "hermes.y"
    {p("xor");;}
    break;

  case 932:
#line 1727 "hermes.y"
    {p("<apply><int/>");;}
    break;

  case 933:
#line 1727 "hermes.y"
    {p("<ci>");;}
    break;

  case 934:
#line 1727 "hermes.y"
    {p("</ci><bvar><ci>");;}
    break;

  case 935:
#line 1727 "hermes.y"
    {p("</ci></bvar>");;}
    break;

  case 937:
#line 1728 "hermes.y"
    {p("<apply><diff/>");;}
    break;

  case 938:
#line 1728 "hermes.y"
    {p("<ci>");;}
    break;

  case 939:
#line 1730 "hermes.y"
    {p("</ci><bvar><ci>");;}
    break;

  case 940:
#line 1730 "hermes.y"
    {p("</ci>");;}
    break;

  case 941:
#line 1730 "hermes.y"
    {p("</bvar></apply>");;}
    break;

  case 943:
#line 1731 "hermes.y"
    {p("<apply><divergence/><ci>");;}
    break;

  case 944:
#line 1731 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 945:
#line 1732 "hermes.y"
    {p("<apply><divergence/><ci>");;}
    break;

  case 946:
#line 1732 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 947:
#line 1733 "hermes.y"
    {p("<apply><grad/><ci>");;}
    break;

  case 948:
#line 1733 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 949:
#line 1734 "hermes.y"
    {p("<apply><grad/><ci>");;}
    break;

  case 950:
#line 1734 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 951:
#line 1735 "hermes.y"
    {p("<apply><curl/><ci>");;}
    break;

  case 952:
#line 1735 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 953:
#line 1736 "hermes.y"
    {p("<apply><curl/><ci>");;}
    break;

  case 954:
#line 1736 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 955:
#line 1737 "hermes.y"
    {p("<apply><laplacian/><ci>");;}
    break;

  case 956:
#line 1737 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 957:
#line 1741 "hermes.y"
    {
	char*temp=strrchr(doc_math,0),*tail;
	while (strstr(temp,"</bvar")!=temp) temp--;
	temp=MatchTagLeft(temp,"<bvar");
	tail=(char*)malloc(strlen(temp)+1);
	strcpy(tail,temp);*temp=0;
	while (strstr(temp,"</ci")!=temp) temp--;
	temp=MatchTagLeft(temp,"<ci");
	Insert(temp,tail);
	free(tail);
	p("</apply>");
;}
    break;

  case 961:
#line 1759 "hermes.y"
    {p("<degree><ci>");;}
    break;

  case 962:
#line 1759 "hermes.y"
    {p("</ci></degree>");;}
    break;

  case 964:
#line 1762 "hermes.y"
    {p("<apply><sum/>");;}
    break;

  case 965:
#line 1762 "hermes.y"
    {p("<ci>");;}
    break;

  case 966:
#line 1762 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 967:
#line 1763 "hermes.y"
    {p("<apply><product/>");;}
    break;

  case 968:
#line 1763 "hermes.y"
    {p("<ci>");;}
    break;

  case 969:
#line 1763 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 970:
#line 1764 "hermes.y"
    {p("<apply><limit/>");;}
    break;

  case 971:
#line 1764 "hermes.y"
    {p("<ci>");;}
    break;

  case 972:
#line 1764 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 973:
#line 1765 "hermes.y"
    {p("<apply><tendsto/><ci>");;}
    break;

  case 974:
#line 1765 "hermes.y"
    {p("</ci><ci>");;}
    break;

  case 975:
#line 1765 "hermes.y"
    {p("</ci></apply>");;}
    break;

  case 995:
#line 1796 "hermes.y"
    {p("<condition>");;}
    break;

  case 996:
#line 1797 "hermes.y"
    {p("</condition>");;}
    break;

  case 997:
#line 1798 "hermes.y"
    {
	char*temp=doc_math,*limit,*lock=doc_math,*tail,*bvar;
	while ((temp=strstr(temp,"<limit/>"))) lock=temp++;
	limit=temp=lock;
	limit=strstr(limit,">")+1;
	while ((temp=strstr(temp,"<condition>"))) lock=temp++;
	temp=lock;
	while ((temp=strstr(temp,"<ci"))) lock=temp++;
	temp=lock;
	lock=strstr(temp,"</ci>")+strlen("</ci>");
	tail=(char*)malloc(strlen(lock)+1);
	strcpy(tail,lock);*lock=0;
	bvar=(char*)malloc(strlen(temp)+1);
	strcpy(bvar,temp);
	strcat(temp,tail);free(tail);
	limit=Insert(limit,"<bvar>");
	limit=Insert(limit,bvar);
	Insert(limit,"</bvar>");free(bvar);
;}
    break;

  case 998:
#line 1819 "hermes.y"
    {p("<lowlimit><ci>");;}
    break;

  case 999:
#line 1820 "hermes.y"
    {p("<uplimit><ci>");;}
    break;

  case 1000:
#line 1821 "hermes.y"
    {p("</ci></lowlimit>");;}
    break;

  case 1001:
#line 1822 "hermes.y"
    {p("</ci></uplimit>");;}
    break;

  case 1002:
#line 1826 "hermes.y"
    {p(ul2utf8(0x022EF));;}
    break;

  case 1003:
#line 1827 "hermes.y"
    {p(ul2utf8(0x022F1));;}
    break;

  case 1004:
#line 1828 "hermes.y"
    {p(ul2utf8(0x02026));;}
    break;

  case 1005:
#line 1829 "hermes.y"
    {p(ul2utf8(0x022EE));;}
    break;

  case 1006:
#line 1832 "hermes.y"
    {p("<apply>");;}
    break;

  case 1007:
#line 1834 "hermes.y"
    {
	p("<apply>");
;}
    break;


/* Line 1267 of yacc.c.  */
#line 12280 "hermes.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 1839 "hermes.y"


int main(int argc, char*argv[])
{
	unsigned int p2post, al,fontIndex,fontNumber;
	unsigned char i,k, endian[5],*temp;
	unsigned char test[512];
	short int j=1;
	doc_math=NULL;
	doc_text=NULL;
	endian[4]=0;//just in case :)
	BigEndian=((char*)&j)[1];
	if (argc==1) {
		printf("Hermes version %s, %s, covered by GNU GPL; description at %s\n\
		usage: hermes name.s.dvi\n", VERSION, DATE, DESCRIPTION);
		exit(EXIT_SUCCESS);
	}
	if(argc>=2){
		yyin=fopen(argv[1],"rb");
		if (yyin==NULL){
			printf("%s not found",argv[1]);
			exit(EXIT_FAILURE);
		}
//		if (argc==3) {INFER_CONTENT=1;}
		//if (argc==3) {DEBUG=1;}
		DEBUG=1;
		fseek(yyin,0,SEEK_SET);
		fread(&i,1,1,yyin);
		if (i!=247){
			fprintf(stderr,"expected the dvi 'pre' command, got %d,\nthis might not be a dvi file, quitting\n",i);
			fclose(yyin);
			exit(EXIT_FAILURE);
		}
		if (!BigEndian){
			for(j=3;j>=0;j--){
				fread(endian+j,1,1,yyin);
			}
			scale.num=*((unsigned int*) endian);
		}else
			fread(&scale.num,4,1,yyin);
		if (!BigEndian){
			for(j=3;j>=0;j--){
				fread(endian+j,1,1,yyin);
			}
			scale.den=*((unsigned int*) endian);
		}else
			fread(&scale.den,4,1,yyin);
		if (!BigEndian){
			for(j=3;j>=0;j--){
				fread(endian+j,1,1,yyin);
			}
			scale.mag=*((unsigned int*) endian);
		}else
			fread(&scale.mag,4,1,yyin);

		fseek(yyin,0,SEEK_END);
		fseek(yyin,-1,SEEK_CUR);
		do{
			fread(&i,1,1,yyin);
			fseek(yyin,-2,SEEK_CUR);
		}while(i==223);
		if (i!=2){
			printf("not prepared for right to left typesetting\n");
			fclose(yyin);
			exit(EXIT_FAILURE);
		}
		fseek(yyin,-3,SEEK_CUR);
		if (!BigEndian){
			for(j=3;j>=0;j--){
				fread(endian+j,1,1,yyin);
			}
			p2post=*((unsigned int*) endian);
		}else
			fread(&p2post,4,1,yyin);

		fseek(yyin,p2post,SEEK_SET);
		fread(&i,1,1,yyin);
		if (i!=248){//DVI POST
			fclose(yyin);
			die("didn't find 'post' where it should be,\nthis input maybe corrupted, ....\n");
		}
		
		//jump to font definitions, count fonts used 
		fseek(yyin,28,SEEK_CUR);
		fread(&i,1,1,yyin);
		maxFontNr=0;
		while(i<=246 && i>=243){//read fontdefs
			fseek(yyin,(i-242)+12,SEEK_CUR);
			fread(&i,1,1,yyin);al=i;
			fread(&i,1,1,yyin);al+=i;
			fread(test,al,1,yyin);
			maxFontNr++;
			fread(&i,1,1,yyin);
		}
		
		
		//allocate space for the font structures
		if (!(pFont=malloc(maxFontNr*sizeof(struct _Font)))) 
			die("not enough memory\n");
	
		//reread the fonts, this time map them
		fseek(yyin,p2post,SEEK_SET);
		fread(&i,1,1,yyin);
		fseek(yyin,28,SEEK_CUR);//jump to font definitions
		fread(&i,1,1,yyin);
		fontsMissing=0;
		fontIndex=0;
		while(i<=246 && i>=243){//read fontdefs
			switch(i){
			case 243:
				fread(&k,1,1,yyin);
				fontNumber=k;
			break;
			case 244:
				fread(&k,1,1,yyin);
				fontNumber=k<<8;
				fread(&k,1,1,yyin);
				fontNumber+=k;
			break;
			case 245:
				fread(&k,1,1,yyin);
				fontNumber=k<<16;
				fread(&k,1,1,yyin);
				fontNumber+=k<<8;
				fread(&k,1,1,yyin);
				fontNumber+=k;
			break;
			case 246:
				fread(&k,1,1,yyin);
				fontNumber=k<<24;
				fread(&k,1,1,yyin);
				fontNumber+=k<<16;
				fread(&k,1,1,yyin);
				fontNumber+=k<<8;
				fread(&k,1,1,yyin);
				fontNumber+=k;
			break;
			}
	
			theFont.number=fontNumber; //save the font number
			
			fseek(yyin,12,SEEK_CUR);
			fread(&i,1,1,yyin);al=i;
			fread(&i,1,1,yyin);al+=i;
			fread(test,al,1,yyin);
			test[al]=0;//make the fontname a C string
			
			temp=strrchr(test,0);	
			while (temp!=test){
				temp--;
				if (!isdigit(*temp))	{temp++;break;}
			}
			if (strlen(temp)){
				strcpy(theFont.size,temp);
				if ((temp=strstr(test,temp))) *temp=0; //drop the design size
			}
			
			strcpy(theFont.name,test);	//save the font name, without design size
			
			mapFonts(0);	//infer a font map based on font name
			if (theFont.map==NULL) {
				fprintf(stderr,"error: font %s not mapped yet\n",theFont.name);
				fontsMissing=1;
			}	else{
				strcpy((*pFont)[fontIndex].name,theFont.name);
				strcpy((*pFont)[fontIndex].size,theFont.size);
				(*pFont)[fontIndex].map=theFont.map;
				(*pFont)[fontIndex].number=theFont.number;
				(*pFont)[fontIndex].width=theFont.width;
				(*pFont)[fontIndex].family=theFont.family;
				(*pFont)[fontIndex].variant=theFont.variant;
				(*pFont)[fontIndex].style=theFont.style;
				(*pFont)[fontIndex].weight=theFont.weight;
				//fprintf(stderr,"font:\nname:%s, size:%s, number:%ld\n",(*pFont)[fontIndex].name,(*pFont)[fontIndex].size,(*pFont)[fontIndex].number);
			}
			fontIndex++;
			fread(&i,1,1,yyin);
		}
				
		fseek(yyin,0,SEEK_SET);
	}
	
		
	if (fontsMissing)	die("some fonts are not mapped yet\n");
	doc_math=(char*)malloc(LIMIT);
	doc_text=(char*)malloc(LIMIT);
	*doc_math=0;*doc_text=0;
	strcpy(fname,argv[1]);
	fprintf(stdout,"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
	fprintf(stdout,"<document>\n<generator>\n");
	fprintf(stdout,"<name>Hermes</name>\n");
	fprintf(stdout,"<version>%s</version>\n",VERSION);
	fprintf(stdout,"<date>%s</date>\n",DATE);
	fprintf(stdout,"<license>GNU GPL</license>\n");
	fprintf(stdout,"<description>%s</description>\n",DESCRIPTION);
	fprintf(stdout,"</generator>\n");
	AddPHint(1);
	yyparse ();
	AddPHint(0);
	fprintf(stdout,"</ph>\n");
	if (hasSections)	fprintf(stdout,"</section>");
	fprintf(stdout,"</document>");
 	if(yyin) fclose(yyin);
 	if(yyout) fclose(yyout);
 	if (doc_math) free(doc_math);
 	if (doc_text) free(doc_text);
 	return 0;
}


int yywrap() {
return 1;
}

int yyerror(char* msg) {
	flushText();
	fflush(stdout);

	if (*lastToken)
		fprintf(stderr,"\n\nparsing error:\nlast token received was '%s'\n",lastToken);
 	if (doc_math){
	 	if ( *doc_math) {
	 		fprintf(stderr,"\nmath leftovers:\n'%s'\n",doc_math);
	 	}
		free(doc_math);
	}
//		showcontext();
	fprintf(stderr,"cleaning up...\n");
	if (pFont) free(pFont);
 	clearStack();
	fprintf(stderr,"...bye.\n");
	exit(EXIT_FAILURE);
}

void p(char*s){
	char *temp=doc_text,*lock=doc_text;
	if (!fakesp){
		//doc_text is flushed at each space or 'dviy' encountered
		fakesp=1;
		//rid of hyphenchar
		if (*doc_text){
			lock=temp=strrchr(doc_text,0);
			temp--;lock--;
			if (*temp=='-')*temp=0;
			else{
				if (*temp!=' ' && *temp!='>' && !inCitation) 
					strcat(doc_text," ");
			}
		}
		if (!inhibitspace){
			if(*doc_math && (!mathmode ||mathText) && !mathOp)
				strcat(doc_math," ");
		} else inhibitspace=0;
		fprintf(stdout,"%s",doc_text);
		if (strcmp(s,"<dviy/>")==0){
			if (*lock==' ') {while(*lock==' ')lock--;}
			if (strpbrk(lock,":.!?") && canbreak){
					while(*lock!=' ' && *lock!='>' && lock!=doc_text) {
						lock--;
					}
					if (*lock=='>' || *lock==' ') lock++;
					if ((*lock <'A' || *lock >'Z') && !inTable && !inBibliography) {
						fprintf(stdout,"<br/>\n");
					}
			}
			*doc_text=0;
			return;
		}
		*doc_text=0;
	}
	if ((mathmode || mathText)&& !infhp) strcat(doc_math,s);
	else strcat(doc_text,s);
	//if (strstr(s,"</mtext>")==s) mathText=0;
}



char* MoveLeft(char*where,char*temp)
{
	char*seek,*tail;
	while(temp!=strstr(temp,"</c") && temp!=strstr(temp," RD ") && temp!=strstr(temp," RD </apply>")) temp--;
	if (temp==strstr(temp," RD </apply>")){
		temp=SkipBracketsLeft(temp);
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp);*temp=0;
		if (strrchr(where,'<')!=strstr(seek=strrchr(where,'<'),"<c")){
			while(temp!=strstr(temp,"<apply>")) {if (temp==where) break;temp--;}
			if(temp!=where)
				temp=MoveLeft(where,temp=seek);
		}
		strcat(temp,tail);
		free(tail);
	}else{
		if (temp==strstr(temp,"</ci>"))
			temp=MatchTagLeft(temp,"<ci");
		else{
			if (temp==strstr(temp,"</cn>"))
				temp=MatchTagLeft(temp,"<cn");
			else{
				if (temp==strstr(temp," RD ")){
					temp=SkipBracketsLeft(temp);
				}
			}
		}

	}
	return temp;
}


int IsComplete(char*temp){

	if (strstr(temp,"<csymbol")==temp) return 1;

	if (strstr(temp,"<plus/>")==temp) return 1;
	if (strstr(temp,"<minus/>")==temp) return 1;
	if (strstr(temp,"<power/>")==temp) return 1;
	if (strstr(temp,"<eq/>")==temp) return 1;

	if (strstr(temp,"<root/>")==temp) return 1;
	if (strstr(temp,"<gcd/>")==temp) return 1;
	if (strstr(temp,"<lcm/>")==temp) return 1;
	if (strstr(temp,"<not/>")==temp) return 1;
	if (strstr(temp,"<partialdiff/>")==temp) return 1;
	if (strstr(temp,"<real/>")==temp) return 1;
	if (strstr(temp,"<imaginary/>")==temp) return 1;
	if (strstr(temp,"<int/>")==temp) return 1;
	if (strstr(temp,"<diff/>")==temp) return 1;
	if (strstr(temp,"<divergence/>")==temp) return 1;
	if (strstr(temp,"<grad/>")==temp) return 1;
	if (strstr(temp,"<curl/>")==temp) return 1;
	if (strstr(temp,"<laplacian/>")==temp) return 1;
	if (strstr(temp,"<mean/>")==temp) return 1;
	if (strstr(temp,"<sdev/>")==temp) return 1;
	if (strstr(temp,"<variance/>")==temp) return 1;
	if (strstr(temp,"<median/>")==temp) return 1;
	if (strstr(temp,"<mode/>")==temp) return 1;
	if (strstr(temp,"<limit/>")==temp) return 1;
	if (strstr(temp,"<moment/>")==temp) return 1;
	if (strstr(temp,"<sum/>")==temp) return 1;
	if (strstr(temp,"<product/>")==temp) return 1;
	if (strstr(temp,"<limit/>")==temp) return 1;
	if (strstr(temp,"<transpose/>")==temp) return 1;
	if (strstr(temp,"<selector/>")==temp) return 1;
	if (strstr(temp,"<vectorproduct/>")==temp) return 1;
	if (strstr(temp,"<scalarproduct/>")==temp) return 1;
	if (strstr(temp,"<outerproduct/>")==temp) return 1;
	if (strstr(temp,"<card/>")==temp) return 1;
	if (strstr(temp,"<max/>")==temp) return 1;
	if (strstr(temp,"<min/>")==temp) return 1;
	if (strstr(temp,"<forall/>")==temp) return 1;
	if (strstr(temp,"<exists/>")==temp) return 1;
	if (strstr(temp,"<abs/>")==temp) return 1;
	if (strstr(temp,"<conjugate/>")==temp) return 1;
	if (strstr(temp,"<arg/>")==temp) return 1;
	if (strstr(temp,"<floor/>")==temp) return 1;
	if (strstr(temp,"<ceiling/>")==temp) return 1;

	if (strstr(temp,"<inverse/>")==temp) return 1;
	if (strstr(temp,"<domain/>")==temp) return 1;
	if (strstr(temp,"<codomain/>")==temp) return 1;
	if (strstr(temp,"<image/>")==temp) return 1;

	if (strstr(temp,"<factorial/>")==temp) return 1;
	//if (strstr(temp,"<tendsto/>")==temp) return wrapped[complete=tendsto];
	//if (strstr(temp,"<in/>")==temp) return wrapped[complete=in];
	//if (strstr(temp,"<notin/>")==temp) return wrapped[complete=notin];
	//if (strstr(temp,"<intersect/>")==temp) return wrapped[complete=intersect];
	//if (strstr(temp,"<union/>")==temp) return wrapped[complete=union_];
	//if (strstr(temp,"<compose/>")==temp) return wrapped[complete=compose];
	//if (strstr(temp,"<power/>")==temp) return wrapped[complete=power];
	//if (strstr(temp,"<divide/>")==temp) return wrapped[complete=divide];
	//if (strstr(temp,"<times/>")==temp) return wrapped[complete=times];
	//if (strstr(temp,"<minus/>")==temp) return wrapped[complete=minus];
	//if (strstr(temp,"<plus/>")==temp) return wrapped[complete=plus];
	//if (strstr(temp,"<rem/>")==temp) return wrapped[complete=rem];
	//if (strstr(temp,"<gt/>")==temp) return wrapped[complete=gt];
	//if (strstr(temp,"<lt/>")==temp) return wrapped[complete=lt];
	//if (strstr(temp,"<eq/>")==temp) return wrapped[complete=eq];
	//if (strstr(temp,"<neq/>")==temp) return wrapped[complete=neq];
	//if (strstr(temp,"<geq/>")==temp) return wrapped[complete=geq];
	//if (strstr(temp,"<leq/>")==temp) return wrapped[complete=leq];
	//if (strstr(temp,"<equivalent/>")==temp) return wrapped[complete=equivalent];
	//if (strstr(temp,"<approx/>")==temp) return wrapped[complete=approx];
	//if (strstr(temp,"<cartesianproduct/>")==temp) return wrapped[complete=cartesianproduct];
	//if (strstr(temp,"<setdiff/>")==temp) return wrapped[complete=setdiff];
	//if (strstr(temp,"<subset/>")==temp) return wrapped[complete=subset];
	//if (strstr(temp,"<prsubset/>")==temp) return wrapped[complete=prsubset];
//	if (strstr(temp,"<notsubset/>")==temp) return wrapped[complete=notsubset];
//	if (strstr(temp,"<notprsubset/>")==temp) return wrapped[complete=notprsubset];
//	if (strstr(temp,"<and/>")==temp) return wrapped[complete=and];
//	if (strstr(temp,"<or/>")==temp) return wrapped[complete=or];
//	if (strstr(temp,"<xor/>")==temp) return wrapped[complete=xor];
//	if (strstr(temp,"<implies/>")==temp) return wrapped[complete=implies];

	if (strstr(temp,"<arccos/>")==temp) return 1;
	if (strstr(temp,"<arccosh/>")==temp) return 1;
	if (strstr(temp,"<arcsin/>")==temp) return 1;
	if (strstr(temp,"<arcsinh/>")==temp) return 1;
	if (strstr(temp,"<arctan/>")==temp) return 1;
	if (strstr(temp,"<arctanh/>")==temp) return 1;
	if (strstr(temp,"<arg/>")==temp) return 1;
	if (strstr(temp,"<cos/>")==temp) return 1;
	if (strstr(temp,"<cosh/>")==temp) return 1;
	if (strstr(temp,"<cot/>")==temp) return 1;
	if (strstr(temp,"<arccot/>")==temp) return 1;
	if (strstr(temp,"<coth/>")==temp) return 1;
	if (strstr(temp,"<arccoth/>")==temp) return 1;
	if (strstr(temp,"<csc/>")==temp) return 1;
	if (strstr(temp,"<arccsc/>")==temp) return 1;
	if (strstr(temp,"<csch/>")==temp) return 1;
	if (strstr(temp,"<arccsch/>")==temp) return 1;
	if (strstr(temp,"<determinant/>")==temp) return 1;
	if (strstr(temp,"<exp/>")==temp) return 1;
	if (strstr(temp,"<ln/>")==temp) return 1;
	if (strstr(temp,"<log/>")==temp) return 1;
	if (strstr(temp,"<max/>")==temp) return 1;
	if (strstr(temp,"<min/>")==temp) return 1;
	if (strstr(temp,"<sec/>")==temp) return 1;
	if (strstr(temp,"<arcsec/>")==temp) return 1;
	if (strstr(temp,"<sech/>")==temp) return 1;
	if (strstr(temp,"<arcsech/>")==temp) return 1;
	if (strstr(temp,"<sin/>")==temp) return 1;
	if (strstr(temp,"<sinh/>")==temp) return 1;
	if (strstr(temp,"<tan/>")==temp) return 1;
	if (strstr(temp,"<tanh/>")==temp) return 1;

	return 0;
}

int IsMMLContainerEnd(char*temp){
	if (*(temp+1)!='/') return 0;
	if (strstr(temp,"</mtable>")==temp) return 1;
	if (strstr(temp,"</mlabeledtr")==temp) return 1;
	if (strstr(temp,"</mtr>")==temp) return 1;
	if (strstr(temp,"</mtd>")==temp) return 1;
	if (strstr(temp,"</mrow>")==temp) return 1;
	if (strstr(temp,"</mtext>")==temp) return 1;
	if (strstr(temp,"</mi>")==temp) return 1;
	if (strstr(temp,"</mn>")==temp) return 1;
	if (strstr(temp,"</mo>")==temp) return 1;
	if (strstr(temp,"</mover>")==temp) return 1;
	if (strstr(temp,"</munder>")==temp) return 1;
	if (strstr(temp,"</msub>")==temp) return 1;
	if (strstr(temp,"</msup>")==temp) return 1;
	if (strstr(temp,"</msubsup>")==temp) return 1;
	if (strstr(temp,"</mfrac>")==temp) return 1;
	if (strstr(temp,"</msqrt>")==temp) return 1;
	if (strstr(temp,"</mroot>")==temp) return 1;
	if (strstr(temp,"</ms>")==temp) return 1;

	if (strstr(temp,"</ci>")==temp) return 1;
	if (strstr(temp,"</cn>")==temp) return 1;
	if (strstr(temp,"</csymbol>")==temp) return 1;
	if (strstr(temp,"</apply>")==temp) return 1;
	if (strstr(temp,"</logbase>")==temp) return 1;
	if (strstr(temp,"</bvar>")==temp) return 1;
	if (strstr(temp,"</degree>")==temp) return 1;
	if (strstr(temp,"</condition>")==temp) return 1;
	if (strstr(temp,"</vector>")==temp) return 1;
	if (strstr(temp,"</matrix>")==temp) return 1;
	if (strstr(temp,"</matrixrow>")==temp) return 1;
	if (strstr(temp,"</lowlimit>")==temp) return 1;
	if (strstr(temp,"</uplimit>")==temp) return 1;
	if (strstr(temp,"</moment>")==temp) return 1;
	if (strstr(temp,"</momentabout>")==temp) return 1;
	if (strstr(temp,"</set>")==temp) return 1;
	if (strstr(temp,"</list>")==temp) return 1;
	if (strstr(temp,"</interval>")==temp) return 1;
	if (strstr(temp,"</piece>")==temp) return 1;
	if (strstr(temp,"</piecewise>")==temp) return 1;

	return 0;
}
int IsMMLContainerStart(char*temp){
	if(*(temp+1)=='m'){
		if (strstr(temp,"<mtable")==temp) return 1;
		if (strstr(temp,"<mlabeledtr")==temp) return 1;
		if (strstr(temp,"<mtr")==temp) return 1;
		if (strstr(temp,"<mtd")==temp) return 1;
		if (strstr(temp,"<mrow")==temp) return 1;
		if (strstr(temp,"<mtext")==temp) return 1;
		if (strstr(temp,"<mi")==temp) return 1;
		if (strstr(temp,"<mn")==temp) return 1;
		if (strstr(temp,"<mover")==temp) return 1;
		if (strstr(temp,"<munder")==temp) return 1;
		if (strstr(temp,"<mo")==temp) return 1;
		if (strstr(temp,"<msubsup")==temp) return 1;
		if (strstr(temp,"<msub")==temp) return 1;
		if (strstr(temp,"<msup")==temp) return 1;
		if (strstr(temp,"<mfrac")==temp) return 1;
		if (strstr(temp,"<msqrt")==temp) return 1;
		if (strstr(temp,"<mroot")==temp) return 1;
		if (strstr(temp,"<ms")==temp) return 1;
	}
	if (strstr(temp,"<ci")==temp) return 1;
	if (strstr(temp,"<cn")==temp) return 1;
	if (strstr(temp,"<csymbol")==temp) return 1;
	if (strstr(temp,"<apply")==temp) return 1;
	if (strstr(temp,"<logbase")==temp) return 1;
	if (strstr(temp,"<bvar")==temp) return 1;
	if (strstr(temp,"<degree")==temp) return 1;
	if (strstr(temp,"<condition")==temp) return 1;
	if (strstr(temp,"<vector")==temp) return 1;
	if (strstr(temp,"<matrix")==temp) return 1;
	if (strstr(temp,"<matrixrow")==temp) return 1;
	if (strstr(temp,"<lowlimit")==temp) return 1;
	if (strstr(temp,"<uplimit")==temp) return 1;
	if (strstr(temp,"<moment")==temp) return 1;
	if (strstr(temp,"<momentabout")==temp) return 1;
	if (strstr(temp,"<set")==temp) return 1;
	if (strstr(temp,"<list")==temp) return 1;
	if (strstr(temp,"<interval")==temp) return 1;
	if (strstr(temp,"<piece")==temp) return 1;
	if (strstr(temp,"<piecewise")==temp) return 1;

	return 0;
}

int IsMMLConstant(char*temp){
	if (strstr(temp,"<integers/>")==temp) return 1;
	if (strstr(temp,"<reals/>")==temp) return 1;
	if (strstr(temp,"<rationals/>")==temp) return 1;
	if (strstr(temp,"<naturalnumbers/>")==temp) return 1;
	if (strstr(temp,"<complexes/>")==temp) return 1;
	if (strstr(temp,"<primes/>")==temp) return 1;
	if (strstr(temp,"<exponentiale/>")==temp) return 1;
	if (strstr(temp,"<imaginaryi/>")==temp) return 1;
	if (strstr(temp,"<notanumber/>")==temp) return 1;
	if (strstr(temp,"<true/>")==temp) return 1;
	if (strstr(temp,"<false/>")==temp) return 1;
	if (strstr(temp,"<emptyset/>")==temp) return 1;
	if (strstr(temp,"<pi/>")==temp) return 1;
	if (strstr(temp,"<eulergamma/>")==temp) return 1;
	if (strstr(temp,"<infinity/>")==temp) return 1;
	if (strstr(temp,"<ident/>")==temp) return 1;
	return 0;
}

char* Insert(char*at,char*what){
	//return a pointer to the next byte after the inserted string
	char*s,*final;
	if(*at){
		s=(char*)malloc(strlen(at)+1);
		strcpy(s,at);
		strcpy(at,what);final=strrchr(at,0);
		strcat(at,s);
		free(s);
	}else{
		strcpy(at,what);final=strrchr(at,0);
	}
	assert(final);
	return final;
}


char* MatchTagLeft(char*from, char*what){ //start from closing tag, match to left
	char*temp=from,*ctag;
	int wraps=1;
	ctag=(char*)malloc(strlen(what)+2);
	strcpy(ctag,"</");strcat(ctag,what+1);//assuming 'what' is an opening tag
	while(wraps){
		if (temp==doc_math) {
			free(ctag);
			die("can't match tag left...");
		}
		temp--;
		while(temp!=strstr(temp,what)) {
			if (temp==strstr(temp," RD ")) temp=SkipBracketsLeft(temp);
			else if (temp==strstr(temp,ctag)) wraps++;
			temp--;
			if (temp==doc_math && temp!=strstr(temp,what)){
				free(ctag);
				die("error:\ncan't match tag left...\n");
			}
		}
		wraps--;
		assert(wraps>=0);
	}
	free(ctag);
	assert(temp);
	return temp;
}

char* MatchTagRight(char*from){
	//in: pointer to a starting tag
	//returns: a pointer to the first byte after 
	//the corresponding enclosing tag
	char *temp,*btag,*etag,*check;
	int wraps=1, len=strcspn(from,"> ");

	//create the begin and end tags
	temp=from;
	if (temp==strstr(temp,"<apply")){
		len=strcspn(from,"/");
		btag=(char*)malloc(len+3);
		check=btag;
		while(*temp!='/')
			*check++=*temp++;
		*check=0;
		strcat(btag,"/>");
		len=strcspn(btag,"> ");
		etag=(char*)malloc(len+3);
		strcpy(etag,"</");
		check=strrchr(etag,0);temp=btag+1;
		while(*temp!='>' && *temp!=' ')
			*check++=*temp++;
		*check=0;
		strcat(etag,">");
	}else{
		btag=(char*)malloc(len+2);
		check=btag;
		while(*temp!='>' && *temp!=' ')
			*check++=*temp++;
		*check=0;
		etag=(char*)malloc(strlen(btag)+3);
		strcpy(etag,"</");strcat(etag,btag+1);strcat(etag,">");
	}

	if (!strstr(from,etag)){
		printf("\n error:\ninput was:\n %s\n", doc_math);
		printf("for %s, couldn't find '%s' tag...\n", btag,etag);
		free(btag);
		free(etag);
		yyerror("");
	}

	temp=from;
	while(wraps){
		temp++;
		while(temp!=strstr(temp,etag)) {
			if (temp==strstr(temp," LD ")) temp=SkipBracketsRight(temp);
			else {
				if (temp==strstr(temp,btag)) wraps++;
				else {
					if (temp==strstr(temp,"<apply>")){
						check=strstr(temp,">");check++;
						check=strstr(check,"<");
						if (IsComplete(check) && btag==strstr(btag,"<apply>")) wraps ++;
					}
				}
				if (*temp) temp++;
				else {
					printf("\ncan't find end tag %s for starting tag %s...\n", etag,btag);
					free(btag);
					free(etag);
					yyerror("");
				}
			}
		}
		wraps--;
		assert(wraps>=0);
	}
	assert(temp);
	temp+=strlen(etag);
	free(btag);
	free(etag);
	return temp;
}

char* SkipBracketsLeft(char*from){//assume start from right bracket
	int wraps=1;
	char*temp=from;
	while(wraps) {
		temp--;
		if(temp!=strstr(temp," LD ")){
			if(temp==strstr(temp," RD ")) wraps++;
		}else wraps--;
	}
	assert(temp);
	return temp;
}

char* SkipBracketsRight(char*from){//assume start from left bracket
	int wraps=1;
	char*temp=from+strlen(" LD ");
	temp--;
	while(wraps) {
		temp++;
		if(temp!=strstr(temp," RD ")){
			if(temp==strstr(temp," LD ")) wraps++;
		}else wraps--;
	}
	assert(temp);
	temp+=strlen(" RD ");
	return temp;
}

void pretty(char*s, int eraseBrackets){

	char* temp,*pick,*shadow=0;
	int spaces;
	temp=s;pick=s;
	spaces=0;
	if (eraseBrackets && strstr(s," LD ")){ //strip LDs
		shadow=temp=(char*)malloc(strlen(s)+1);
		while(*pick){
			if (pick!=strstr(pick," LD ") && pick!=strstr(pick," RD ")) {
					*shadow++=*pick++;
			}else
				pick+=strlen(" LD ");
		}
		*shadow=0;
		shadow=temp;
	}
	if (mathblock)	
		printf("<math xmlns=\"http://www.w3.org/1998/Math/MathML\" display=\"block\"");
	else	
		printf("<math xmlns=\"http://www.w3.org/1998/Math/MathML\"");
		
	//print indented
	if (*id) printf(" id=\"%s\">",id);
	else printf(">");
	*id=0;
	while (*temp){
		if (IsMMLContainerStart(temp)){
			temp=IndentContainer(temp,&spaces,1);
		}else{
			if (IsMMLContainerEnd(temp)){
				temp=IndentContainer(temp,&spaces,0);
			}else
				printf("%c",*temp++);
		}
	}
	// we check a kind of wellformedness here 
	if (spaces) 
		die("\nwellformedness error: an opening/closing parenthesis is missing...\n");
	printf("\n</math>\n");
	if (eraseBrackets && shadow) free (shadow);

}

char* IndentContainer(char*pos,int* spaces,int start){
	int i;
	if (start){
		printf("\n");
		i=*spaces;
		while (i-- >0) fputc(' ',stdout);
		if (*(pos+1)=='a'){
			if (strstr(pos,"<apply>")==pos){
				do{	fputc(*pos,stdout);
				}while(strstr(pos,"/>")!=pos++);
			}
		}
		do{	fputc(*pos,stdout);
		}while(*pos++!='>');

		while(*pos && *pos!='<' && (!(*pos=='/' && *(pos+1)=='>')) )
			fputc(*pos++,stdout);
		if((*pos=='/' && *(pos+1)=='>')||(*pos=='<' && *(pos+1)=='/')){
			while(*pos && *pos!='>') fputc(*pos++,stdout);
			(*spaces)--;
		}
		(*spaces)++;
	}else{
		printf("\n");
		(*spaces)-=1;i=*spaces;
		while (i-- >0) fputc(' ',stdout);
		do{	fputc(*pos,stdout);
		}while(*pos && *pos++!='>');
	}
	return pos;
}

void Clean(char*from, char*what,int how){
//how=0 clean just "<apply><times/> what"
//how=1 clean just "what"
//how=2 clean both "<apply><times/> what" and "what" after
	char *temp=from,*tail,*trash;
	if (how==0 || how==2){
		trash=(char*)malloc(strlen("<apply><times/>")+strlen(what)+1);
		strcpy(trash,"<apply><times/>");strcat(trash,what);
		while ((temp=strstr(temp,trash))){		// clean the 'trash' starting at 'from'
			tail=(char*)malloc(strlen(temp)+1);
			strcpy(tail,temp+strlen(trash));
			*temp=0;
			strcpy(temp,tail);
			free(tail);
		}
		free(trash);
	}
	temp=from;
	if (how==1 || how==2){
		while ((temp=strstr(temp,what))){		// clean the 'what' starting at 'from'
			tail=(char*)malloc(strlen(temp)+1);
			strcpy(tail,temp+strlen(what));
			*temp=0;
			strcpy(temp,tail);
			free(tail);
		}
	}
}

void flushText()
{
	int length;
	if (doc_text){
		if (*doc_text==0) return;
		length=strlen(doc_text);
		assert(length<LIMIT);
		fprintf(stdout,"%s\n",doc_text);*doc_text=0;
	}
}

void flushMath()
{
char*temp,*lock;
int length=strlen(doc_math);
assert(length<LIMIT);
//fprintf(stderr,"math:%s\n",doc_math);
if (mathBox) die("bug: found unbalanced mathBox\n");
//there should be no random spaces between tags in 'doc_math'
	fixBackParsedPrimitive("<OVER/>");
	fixBackParsedPrimitive("<ATOP/>");
	fixBackParsedPrimitive("<CHOOSE/>");
	fixLabels();
	fixIds();
	
	if ((lock=temp=strstr(doc_math,"<source"))){//fake math, it was a figure
		temp=strstr(temp,"</source>");
		temp=strstr(temp,">");
		temp++;*temp=0;
		fprintf(stdout,"\n%s\n",lock);
	}else
		pretty(doc_math,1);
	*doc_math=0;
	return;
};

void die(char* text){
	fprintf(stderr,"\n%s\n",text);
	yyerror("");
}

void fixLabels(){
//getting the full math string
//locating and positioning Labels:
//creating mtable with mlabeledtr wrappers where found
char *temp=doc_math,*tail,*lock,*pelabel,*plabel=label;
//fprintf(stdout,":www:%s\n",doc_math);
	while((temp=strstr(doc_math,"<label>"))){
		if (temp==doc_math){
			//simple left labeled expression
			//copy label contents
			lock=strstr(temp,">");
			lock++;
			while(*lock && *lock!='<'){
				*plabel++=*lock++;
			};
			*plabel=0;
			lock=strstr(lock,">");
			if (lock){
				lock++;
				//backup the rest of doc_math
				tail=(char*)malloc(strlen(lock)+1);
				strcpy(tail,lock);
				strcpy(doc_math,"<mtable><mlabeletdr><mtd><mtext>");
				strcat(doc_math,label);
				strcat(doc_math,"</mtext></mtd><mtd>");
				strcat(doc_math,tail);
				strcat(doc_math,"</mtd></mlabeletdr></mtable>");
				free(tail);
			}
			return;
		}
		temp=strstr(temp,"<label>");
		pelabel=strstr(temp,"</label>");
		//copy label contents
		lock=strstr(temp,">");lock++;
		plabel=label;
		while(lock!=pelabel){
			*plabel++=*lock++;
		};
		*plabel=0;
		lock=strstr(lock,">");lock++;
		//rid of the label element
		tail=(char*)malloc(strlen(lock)+1);
		strcpy(tail,lock);
		strcpy(temp,tail);
		free(tail);
		if (temp==strstr(temp,"</mtr>")){
			temp+=3;
			Insert(temp,"labeled");
			temp=MatchTagLeft(temp,"<mtr");
			temp+=2;
			Insert(temp,"labeled");
			temp=strstr(temp,">");temp++;
			temp=Insert(temp,"<mtd><mtext>");
			temp=Insert(temp,label);
			Insert(temp,"</mtext></mtd>");
		}else{
			//label is the last
			//if (*temp) die("error:label should be the last, and it isn't\n");
			strcat(doc_math,"</mtd></mlabeledtr></mtable>");
			temp=doc_math;
			temp=Insert(temp,"<mtable><mlabeledtr><mtd><mtext>");
			temp=Insert(temp,label);
			Insert(temp,"</mtext></mtd><mtd>");
		}
	}
}

void fixBackParsedPrimitive(const char * what)
{
	char *temp=doc_math,*tail,*lock;
	
	while((temp=strstr(doc_math,what))){
		lock=strstr(temp,">");lock++;
		tail=(char*)malloc(strlen(lock)+1);
		strcpy(tail,lock);
		*temp=0;
	
		temp=MatchTagLeft(temp,"<mrow");
		temp=Insert(temp,"<mfrac");
		if (strcmp(what,"<OVER/>")==0)
			Insert(temp,">");
		else
			Insert(temp," linethickness=\"0\">");
		strcat(temp,"</mrow>");
		lock=strrchr(temp,0);
		strcat(temp,"<mrow>");
		strcat(temp,tail);
		free (tail);
		temp=MatchTagRight(lock);
		Insert(temp,"</mfrac>");
	}
}

void fixIds(){
//getting the full math string
//locating and positioning Ids:
//moving id labels content from cells to their parent rows
char *temp=doc_math,*tail,*lock,*pid=id;

	while((temp=strstr(doc_math,"<id>"))){
		temp=strstr(temp,"<id>");
		//copy id contents
		lock=strstr(temp,">");lock++;
		pid=id;
		while(*lock!='<'){
			*pid++=*lock++;
		};
		*pid=0;
		lock=strstr(lock,">");lock++;
		//rid of the id element
		tail=(char*)malloc(strlen(lock)+1);
		strcpy(tail,lock);
		strcpy(temp,tail);
		free(tail);
		//locate the parent mtr or mlabeledtr
		//or point to the math wrapper
		lock=strstr(temp,"</mlabeledtr");
		tail=strstr(temp,"</mtr");
		if (lock&& tail){
			if (tail==strstr(lock,"</mtr>")){
				temp=lock;
				temp=MatchTagLeft(temp,"<mlabeledtr");
			}else{
				temp=tail;
				temp=MatchTagLeft(temp,"<mtr");
			}
		}else{
			if (tail){
				temp=tail;
				temp=MatchTagLeft(temp,"<mtr");
			}else{
				if (lock){
					temp=lock;
					temp=MatchTagLeft(temp,"<mlabeledtr");
				}else
					return;
			}
		}
		//and load the id
		temp=strstr(temp,">");
		temp=Insert(temp," id=\"");
		temp=Insert(temp,id);
		temp=Insert(temp,"\"");
		*id=0;
	}
}


//font mapping, no poetry here

void selectFont(unsigned int fnum){
	int i=0;
	while((*pFont)[i].number!=fnum) {
	i++;
		if (i>maxFontNr) 
		{fprintf(stderr,"error:\nfont number overflow, requested %d, available %d, quitting\n",i,maxFontNr); exit(EXIT_FAILURE);}
	}
	strcpy(theFont.name,(*pFont)[i].name);
	strcpy(theFont.size,(*pFont)[i].size);
	theFont.number=(*pFont)[i].number;
	theFont.map=(*pFont)[i].map;
	theFont.width=(*pFont)[i].width;
	theFont.family=(*pFont)[i].family;
	theFont.variant=(*pFont)[i].variant;
	theFont.style=(*pFont)[i].style;
	theFont.weight=(*pFont)[i].weight;

}

void mapFonts(int check){
//parsing fontname for encoding, variant, width, style and weight
int total=0,pos=0;
char* currentFont=theFont.name;
pos=strlen(theFont.name);
total=pos;
assert(pos);

//defaults
theFont.width=regularWidth;
theFont.family=serif;
theFont.variant=normal;
theFont.style=upright;
theFont.weight=normalWeight;
theFont.map=NULL;

//weight:abcdhjklmprsux
//var:cfikmostuvwxyz
//5[aistwz]
//6[abcdikmstwxyz]
//7[acdfkmtvyz] 
//8[234acefimnnqrtuvwxyz]
//9[cdeiostuxz]
//width:cenopqrtuvwx

//parsing the fontname backwards

	while((*currentFont=='z' && pos>2) || pos>1 ){
		switch(currentFont[pos]){
			case 'a': 
				switch(currentFont[pos-1]){
				case '8': 
					theFont.map=fontMap8a;
					break;
				case '7': //alternate characters, not mapped yet
					break;
				case '6': //T2A, not mapped yet
					break;
				case '5': //phonetic alternate, not mapped yet
					break;
				case 's':
					if (pos==2 && *currentFont=='m')	//msam
						theFont.map=fontMapMsam;
					break;
				case 'y':	//[px,tx]sya
						theFont.map=fontMapMsam;
					break;
				default:
					theFont.weight=hairline;
				}
			break;
			case 'b': 
				switch(currentFont[pos-1]){
				case '6': //cyrillic 7 bit from ISO 8859-5, not mapped yet
					break;
				case 's':
					if (pos==2 && *currentFont=='m')	//msbm
						theFont.map=fontMapMsbm;
					else
						theFont.weight=bold;
					break;
				case 'c':	
					if (pos==2 && *currentFont=='e')	//ecb
						theFont.map=fontMap8t;
					if (pos==2 && *currentFont=='t')	//tcb
						theFont.map=fontMap8c;
					theFont.weight=bold;
					break;
				case 'e':
					if (pos==2 && *currentFont=='a')	//aeb
					{
						theFont.map=fontMap8t;
						theFont.weight=bold;
					}
				break;
				case 'm': //cmb
					if (currentFont[pos-2]=='c')	//cmb..
						if (!theFont.map) theFont.map=fontMap7t;
						theFont.weight=bold;
					break;
				case 'y':	//[px,tx]syb
						theFont.map=fontMapMsbm;
						theFont.weight=bold;
					break;
				case 'l':
					if (currentFont[pos-2]=='p' && *currentFont=='p')	//pplb...
					if (!theFont.map) 	theFont.map=fontMapDvips;
					theFont.weight=bold;
				break;
				case 'x':
					if (!theFont.map) theFont.map=fontMap7t; //[t,p]x...
					theFont.weight=bold;
				break;
				default:
					theFont.weight=bold;
				}
			break;
			case 'c': 
				switch(currentFont[pos-1]){
				case '9': 
					theFont.map=fontMap8c;
					break;
				case '8':
					theFont.map=fontMap8c;	
					break;
				case '7':
					theFont.map=fontMap7c;	
					break;
				case '6':	//T2C, not mapped yet
					break;
				case 'c':
					if (pos==2 && *currentFont=='e')	//ecc... fonts
						if (!theFont.map) theFont.map=fontMap8t;
						theFont.variant=smallCaps;
					break;
				case 'm':
					if (pos==2 && *currentFont=='c')	//cmc... fonts
						if (!theFont.map) theFont.map=fontMap7tt;
					break;
				case 's':
					if (strstr(currentFont,"ec")==currentFont) {//ecsc
						theFont.style=italic;
						theFont.weight=black;
						}
					else{
						if (!theFont.map) theFont.map=fontMap7tt;
					}
					theFont.variant=smallCaps;
					break;
				default:
					if (pos>total/2+1)
						theFont.weight=black;
					else
						theFont.width=condensed;
				}
			break;
			case 'd': 
				switch(currentFont[pos-1]){
				case '9': 
					theFont.map=fontMap8t;	
					break;
				case '7':	//old style digit enc, not mapped yet
					break;
				case '6':	//cyrillic, CP866
					break;
				default:
					if (pos<total/2+1)
						theFont.weight=demiBold;
				}
			break;
			case 'e': 
				switch(currentFont[pos-1]){
				case '9': 
					theFont.map=fontMap8t;	
					break;
				case '8':	//Adobe CE, not mapped yet
					break;
				case 'u':
					if (*currentFont=='e')	//euex...
						theFont.map=fontMapMathExt;
				break;
				default:
					if (pos<total/2+1)
						theFont.width=expanded;
				}
				break;
			case 'f': 
				switch(currentFont[pos-1]){
				case '7':	//Fraction, not mapped yet
					break;
				case '8':	//TeXAfricanLatin, not mapped yet
					break;
				case 'm':
					theFont.map=fontMap7t; //[c]mff... 
					if (currentFont[pos+1]=='i')	//[c]mfi... 
						theFont.style=italic;
				break;
				case 'u':
					if (*currentFont=='e')	//eufm...
						theFont.map=fontMap7c;
				break;
				default:
					theFont.map=fontMap7c; //make it fraktur
				}
				break;
			case 'h': 
				theFont.weight=heavy; 
				break;
			case 'i': 
				switch(currentFont[pos-1]){
				case '5':	// PhoneticIPA, not mapped yet
					break;
				case '6':	//ISO 8859-5, not mapped yet
					break;
				case '8':	//TC and standard, not mapped yet
					break;
				case '9':	//TSOX, not mapped yet
					break;
				case 'm':	
					if (pos>2 && !theFont.map) theFont.map=fontMapMathItalic; 
					if (currentFont[pos+1]=='a') theFont.map=fontMapMathItalicA;	//[px,tx]mia
					break;
				case 'x':
				if (pos==2 && ((*currentFont=='t') ||(*currentFont=='p')))	//[p,t]xsi... fonts
					if (!theFont.map) theFont.map=fontMap7t;
				break;
				default:
					theFont.style=italic; 
				}
				break;
			case 'j': 
				theFont.weight=extraLight; 
				break;
			case 'k': //greek, not mapped yet
				break;
			case 'l': 
				if (currentFont[pos-1]=='s') theFont.style=oblique;
				else{
					if ((pos>2 && *currentFont!='z') ||(pos>3 && *currentFont=='z')) theFont.weight=light; 
				}
				break;
			case 'm': 
				switch(currentFont[pos-1]){
				case '6':	//cyrillic Macintosh encoding, not mapped yet
					break;
				case '7':	
					theFont.map=fontMapMathItalic;
					break;
				case '8':	//Macintosh standard encoding, not mapped yet
					break;
				case 'b':	
				if (*currentFont=='b') //bbm
					theFont.map=fontMap7t;
					theFont.family=doubleStruck;
					break;
				default:
					if (pos>6)
						theFont.map=fontMapMathItalic;
					else {
						if (strstr(currentFont,"cm")!=currentFont) theFont.weight=medium;
						}
				}
				break;
			case 'n': 
				switch(currentFont[pos-1]){
				case '8':	//LM1 textures???, not mapped yet
					break;
				default:
					if (!theFont.map)
						theFont.width=narrow;
				}
				break;
			case 'o': 
				switch(currentFont[pos-1]){
				case '9':	//expert+oldstyle+tex
					theFont.map=fontMap7t;
					break;
				default:
					if (pos<total/2)
						theFont.width=ultraCondensed;
					else
						theFont.style=oblique;
				}
				break;
			case 'q':
				if (currentFont[pos-1]=='8')
					theFont.map=fontMap8q;
				break;
			case 'r':
				switch(currentFont[pos-1]){
				case '8':	
					theFont.map=fontMap8r;
					break;
				case 'c':	
				if (!theFont.map && pos==2){ 
				if (*currentFont=='e')	//ecr... fonts
						theFont.map=fontMap8t;
					
				if (*currentFont=='t')	//tcr
						theFont.map=fontMap8c;
				}
				break;
				case 'e':	
				if (*currentFont=='a')//aer...
					theFont.map=fontMap8t;
				break;
				case 'l':
					if (currentFont[pos-2]=='p' && *currentFont=='p')	//pplr... fonts
						if (!theFont.map) theFont.map=fontMapDvips;
				break;
				case 'm': //cm
					if (currentFont[pos-2]=='c')	//cmr..
						if (!theFont.map)theFont.map=fontMap7t;
					break;
				case 'o': //co
					if (currentFont[pos-2]=='c')	//cor..
						if (!theFont.map)theFont.map=fontMap8t;
					break;
				case 's': //dsrom
					if (*currentFont=='d')	//dsr..
						if (!theFont.map)theFont.map=fontMap7t;
						theFont.family=doubleStruck;
					break;
				case 'u':
					if (*currentFont=='e')	//eur...
						theFont.map=fontMapMathItalic;
				break;
				case 'x': 
					if (pos==2 && *currentFont=='t')	//txr
						if (!theFont.map) theFont.map=fontMap7t;
					break;
				default:
					if (pos<total/2)
						theFont.width=ultraCondensed;
					else
						theFont.style=oblique;
				}
				break;
			case 's': 
				switch(currentFont[pos-1]){
				case '5':	//sil-IPA, not mapped yet
					break;
				case '6':	//Storm extra encoding, not mapped yet
					break;
				case '9':	//superfont, not mapped yet
					break;
				case 'a':
					if (pos==2 && *currentFont=='l')	//las... fonts
						theFont.map=fontMapLasy;
					break;
				case 'c':	
					if (!theFont.map && pos==2){
						if (*currentFont=='e')	//ecs...
							theFont.map=fontMap8t;
						if (*currentFont=='t')	//tcs...
							theFont.map=fontMap8c;
					} 
					break;
				case 'e': 
					if (*currentFont=='a')//aess...
						theFont.map=fontMap8t;
					break;
				case 'm':	
				if (pos==2 && *currentFont=='c')	//cms... fonts
					if (!theFont.map) theFont.map=fontMap7t;
				break;
				case 's':
					theFont.family=sans;
				break;
				case 'u':
					if (*currentFont=='e')	//eusm...
						theFont.map=fontMapMathSymbol;
				break;
				case 'x':
				if (pos==2 && ((*currentFont=='t') ||(*currentFont=='p')))	//[p,t]xsl... fonts
					if (!theFont.map) theFont.map=fontMap7t;
				break;
				default:
					if (pos<total/2)
						theFont.weight=semiBold;
					else
						theFont.family=sans;
				}
				break;
			case 't': 
				switch(currentFont[pos-1]){
				case '5': //TeX-IPA, not mapped yet
					break;
				case '6': //T2B, not mapped yet
					break;
				case '7': 
					theFont.map=fontMap7t;
					break;
				case '8': 
					theFont.map=fontMap8t;
					break;
				case '9': //expert??? + TeX
					theFont.map=fontMap7t;
					break;
				case 'c':
					if (pos==2){
						if (*currentFont=='e')	//ect..
							theFont.map=fontMap8t;
						if (*currentFont=='t')	//tct..
							theFont.map=fontMap8c;
						}
					break;
				case 'e': 
					if (*currentFont=='a')//aeti...
						theFont.map=fontMap8t;
					break;
				case 'm':
					if (pos>1 && currentFont[pos-2]=='c')	//cmt... 
						if (!theFont.map) theFont.map=fontMap7t;
					if (currentFont[pos+1]=='e' && currentFont[pos+2]=='x') //cmtex
						theFont.map=fontMapCmTeX;
				break;
				case 't':
					if ((*currentFont=='c' && currentFont[1]=='m')|| (currentFont[1]=='x' && (*currentFont=='t' || *currentFont=='p'))) {
						if (!theFont.map) theFont.map=fontMap7tt;
					}	else {
						if (!theFont.map) theFont.map=fontMap8t;
					}
					theFont.family=monospace;
				break;
				default:
					if (pos<total/2)
						theFont.width=thin;
					else 
						theFont.family=monospace;
				}
			break;
			case 'u': 
				switch(currentFont[pos-1]){
				case '8': 
					theFont.map=fontMap8u;
					break;
				case '9': //Unicode compatible???, not mapped yet
					break;
				case 'm': //cmu
					if (pos==2 && *currentFont=='c')
						theFont.map=fontMap7t;
					break;
				default:
					if (pos<total/2)	
						theFont.weight=ultraBlack;
					else 	
						theFont.width=ultraCompressed;
				}
			break;
			case 'v': 
				switch(currentFont[pos-1]){
				case '7': 
					theFont.map=fontMapMathExt;
					break;
				case '8': //TeX vietnamese, not mapped yet
					break;
				case 'm': 
					if (pos>1 && currentFont[pos-2]=='c')	//cmv... fonts
						theFont.map=fontMap7t;
					break;
				default:
					if (theFont.map)	
						theFont.width=extraExpanded;
					else
						theFont.map=fontMapMathExt;
				}
			break;
			case 'x': 
				switch(currentFont[pos-1]){
				case '1':
					if (pos==2 && *currentFont=='t')	//t1x...
						theFont.map=fontMap8t;
				break;
				case '6': //X2???, not mapped yet
					break;
				case '8':	//expert???, not mapped yet
					break;
				case '9': 
					theFont.map=fontMap8y;
					break;
				case 'c':
					switch(*currentFont){
						case 't':
							theFont.map=fontMap8c;	//tcx...
							break;
						case 'e':
							theFont.map=fontMap8t;	//ecx...
							theFont.variant=smallCaps;
							break;
					}
					break;
				case 'e':
					if (pos>2){	
						if (currentFont[pos+1]=='a') //[tx,px]exa... fonts
							theFont.map=fontMapMathExtA;
						if (currentFont[pos+1]==0)		//[cm,tx,px]ex... fonts
							theFont.map=fontMapMathExt;
					}
				break;
				case 'y':
					if (pos==2 && *currentFont=='t')	//tyx...
						theFont.map=fontMap8y;
				break;
				default:
					if (pos<total/2+1)
						theFont.weight=extraBold;
					else 
						theFont.width=extended;
				}
			break;
			case 'y': 
				switch(currentFont[pos-1]){
				case '6': //LCY???, not mapped yet
					break;
				case '8':	
					theFont.map=fontMap8y;
					break;
				case 's':
					switch(currentFont[pos+1]){
					case 'a':
						theFont.map=fontMapMsam;
						break;
					case 'b':
						theFont.map=fontMapMsbm;
						break;
					case 'c':
						theFont.map=fontMapMathSymbolC;
						break;
					default:
							theFont.map=fontMapMathSymbol;
					}
					break;
				default:
						theFont.map=fontMapMathSymbol;
				}
			break;
			case 'z': 
				switch(currentFont[pos-1]){
				case '5': //user, not mapped
					break;
				case '6': //user, not mapped
					break;
				case '7': //user, not mapped
					break;
				case '8': 
					theFont.map=fontMap8z;
					break;
				case '9': //user, not mapped
					break;
				}
			break;
		}
		pos--;
	}
		
	if (!theFont.map) {
		fontsMissing=1;
		if (!check && fontsMissing){
			fprintf(stderr,"\nerror: font %s not mapped yet\n",currentFont);
			die("");
		}
	}

//print the mapping
/*	
	fprintf(stderr,"%s\t",currentFont);
	fprintf(stderr,"M:");
	if (theFont.map==fontMap7t)
		fprintf(stderr,"7t");
	if (theFont.map==fontMap7tp)
		fprintf(stderr,"7p");
	if (theFont.map==fontMap7tt)
		fprintf(stderr,"7tt");
	if (theFont.map==fontMap7ttp)
		fprintf(stderr,"7ttp");
	if (theFont.map==fontMap8a)
		fprintf(stderr,"8a");
	if (theFont.map==fontMapDvips)
		fprintf(stderr,"Dvips");
	if (theFont.map==fontMap8r)
		fprintf(stderr,"8r");
	if (theFont.map==fontMap8a)
		fprintf(stderr,"8a");
	if (theFont.map==fontMap8t)
		fprintf(stderr,"8t");
	if (theFont.map==fontMap8c)
		fprintf(stderr,"8c");
	if (theFont.map==fontMap8q)
		fprintf(stderr,"qx");
	if (theFont.map==fontMap8y)
		fprintf(stderr,"8y");
	if (theFont.map==fontMap8z)
		fprintf(stderr,"8z");
	if (theFont.map==fontMap8u)
		fprintf(stderr,"8u");
	if (theFont.map==fontMapMathExt)
		fprintf(stderr,"mx");
	if (theFont.map==fontMapMathExtA)
		fprintf(stderr,"xa");
	if (theFont.map==fontMapMathSymbol)
		fprintf(stderr,"sy");
	if (theFont.map==fontMapMathSymbolC)
		fprintf(stderr,"cm");
	if (theFont.map==fontMapCmTeX)
		fprintf(stderr,"ct");
	if (theFont.map==fontMapMathItalic)
		fprintf(stderr,"mi");
	if (theFont.map==fontMapMathItalicA)
		fprintf(stderr,"ma");
	if (theFont.map==fontMapLasy)
		fprintf(stderr,"ly");
	if (theFont.map==fontMapWasy)
		fprintf(stderr,"wy");
	if (theFont.map==fontMap7c)
		fprintf(stderr,"7c");
	if (theFont.map==fontMapMsam)
		fprintf(stderr,"am");
	if (theFont.map==fontMapMsbm)
		fprintf(stderr,"bm");
	

	fprintf(stderr," F=");
	switch(theFont.family){
	case serif:
	fprintf(stderr,"se");
	break;
	case sans:
	fprintf(stderr,"ss");
	break;
	case monospace:
	fprintf(stderr,"tt");
	break;
	case cursive:
	fprintf(stderr,"sp");
	break;
	case fantasy:
	fprintf(stderr,"fn");
	break;
	case fraktur:
	fprintf(stderr,"fr");
	break;
	case doubleStruck:
	fprintf(stderr,"ds");
	break;
	}
	
	fprintf(stderr," V=");
	if (theFont.variant==smallCaps)
		fprintf(stderr,"c");
	else
		fprintf(stderr,"r");

	fprintf(stderr," S=");
	switch(theFont.style){
	case upright:
	fprintf(stderr,"r");
	break;
	case italic:
	fprintf(stderr,"i");
	break;
	case oblique:
	fprintf(stderr,"o");
	break;
	}
	
	fprintf(stderr," W=");
	switch(theFont.width){
	case ultraCompressed:
	fprintf(stderr,"ucm");
	break;
	case ultraCondensed:
	fprintf(stderr,"ucn");
	break;
	case extraCondensed:
	fprintf(stderr,"ecn");
	break;
	case compressed:
	fprintf(stderr,"cmp");
	break;
	case condensed:
	fprintf(stderr,"cnd");
	break;
	case thin:
	fprintf(stderr,"thn");
	break;
	case narrow:
	fprintf(stderr,"nrw");
	break;
	case regularWidth:
	fprintf(stderr,"reg");
	break;
	case extended:
	fprintf(stderr,"ext");
	break;
	case expanded:
	fprintf(stderr,"exp");
	break;
	case extraExpanded:
	fprintf(stderr,"eex");
	break;
	case wide:
	fprintf(stderr,"wid");
	break;
	}

	fprintf(stderr," G=");
	switch(theFont.weight){
	case hairline:
	fprintf(stderr,"hrl");
	break;
	case extraLight:
	fprintf(stderr,"xli");
	break;
	case light:
	fprintf(stderr,"lit");
	break;
	case book:
	fprintf(stderr,"bok");
	break;
	case normalWeight:
	fprintf(stderr,"reg");
	break;
	case medium:
	fprintf(stderr,"med");
	break;
	case demiBold:
	fprintf(stderr,"dbo");
	break;
	case semiBold:
	fprintf(stderr,"sbo");
	break;
	case bold:
	fprintf(stderr,"bol");
	break;
	case extraBold:
	fprintf(stderr,"xbo");
	break;
	case heavy:
	fprintf(stderr,"hvy");
	break;
	case black:
	fprintf(stderr,"bla");
	break;
	case ultraBlack:
	fprintf(stderr,"ubl");
	break;
	case poster:
	fprintf(stderr,"pst");
	break;
	}

	fprintf(stderr,"\n");		
*/
	
}

void fontMap7t(){//cmr 7 bit
unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;//Omega
	case 0x0B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
	case 0x0C:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x0D:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x0E:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
	case 0x0F:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

	case 0x10:pMathType=mo;pmt(0x0131);break;//imath
	case 0x11:pMathType=mo;pmt(0x006A);break;//jmath,pmt(0x0237);break;//jmath
	case 0x12:
		if (spacing || mathmode) {pMathType=mo;pmt(0x0060);spacing=0;} 
		else 	combiningUnicode=0x0300;
		break;	//grave accent
	case 0x13:
		if (spacing || mathmode) {pMathType=mo;pmt(0x00B4);spacing=0;} 
		else 	combiningUnicode=0x0301;
		break;	//acute accent
	case 0x14:
		if (spacing || mathmode) {pMathType=mo;pmt(0x02C7);spacing=0;} 
		else 	combiningUnicode=0x030C;
		break;	//caron, hacek
	case 0x15:
		if (spacing || mathmode) {pMathType=mo;pmt(0x02D8);spacing=0;} 
		else 	combiningUnicode=0x0306;
		break;	//breve
	case 0x16:
		if (spacing || mathmode) {pMathType=mo;pmt(0x00AF);spacing=0;} 
		else 	combiningUnicode=0x0304;
		break;	//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;//latin ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;//latin oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;//latin AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;//latin OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;//O slash

	case 0x20:combiningUnicode=0x0337;break;//.notdef, overlay short solidus
	case 0x21:pMathType=mo;pmt(*temp);break;//!
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23://number sign
	case 0x24://US dollar symbol
	case 0x25:pMathType=mo;pmt(*temp);break;//percent
	case 0x26://ampersand
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;
	case 0x27:pMathType=mo;pmt(*temp);break;//'
	case 0x28:pMathType=mo;pmt(*temp);break;//(
	case 0x29:pMathType=mo;pmt(*temp);break;//)
	case 0x2A://asterisk
	case 0x2B://plus
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;//comma
	case 0x2D://hyphen
	case 0x2E://period
	case 0x2F:pMathType=mo;pmt(*temp);break;//slash

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;//:
	case 0x3B:pMathType=mo;pmt(*temp);break;//;
	case 0x3C:pMathType=mo;pmt(0x00A1);break;//inverted exclamation mark
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E:pMathType=mo;pmt(0x00BF);break;//inverted question mark
	case 0x3F:pMathType=mo;pmt(*temp);break;//?

	case 0x40:pMathType=mo;pmt(*temp);break;//@ //at
	
	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	case 0x5E:
		if (spacing || mathmode) {pMathType=mo;pmt(*temp);spacing=0;} 
		else 	combiningUnicode=0x0302;
		break;	//hat
	case 0x5F:
		if (spacing || mathmode) {pMathType=mo;pmt(0x02D9);spacing=0;} 
		else 	combiningUnicode=0x0307;
		break;	//dot above

	case 0x60:pMathType=mo;pmt(*temp);break;//`//quoteleft
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;//double acute accent, 0x30B combining
	case 0x7E:
		if (spacing || mathmode) {pMathType=mo;pmt(*temp);spacing=0;} 
		else combiningUnicode=0x0342;
		break;	//diaeresis
	case 0x7F:
		if (spacing || mathmode) {pMathType=mo;pmt(0x00A8);spacing=0;} 
		else combiningUnicode=0x0308;
		break;	//diaeresis
	
	case 0x8A:pMathType=mo;pmt(0x0141);break;//L with stroke
	case 0xA2:pMathType=mo;pmt(*temp);break;//cent sign
	case 0xA3:pMathType=mo;pmt(*temp);break;//pound sign
	case 0xAA:pMathType=mo;pmt(0x0142);break;//l with stroke
	case 0xC5:pMathType=mo;pmt(*temp);break;//A with ring above, Angstrom
	case 0xE5:pMathType=mo;pmt(*temp);break;//a with ring above
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMap7tp(){//OT1++ (pound for dollar)
unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;//Omega
	case 0x0B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
	case 0x0C:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x0D:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x0E:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
	case 0x0F:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

	case 0x10:pMathType=mo;pmt(0x0131);break;//imath
	case 0x11:pMathType=mo;pmt(0x006A);break;//jmath,pmt(0x0237);break;//jmath
	case 0x12:pMathType=mo;pmt(0x0060);break;//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;//latin ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;//latin oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;//latin AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;//latin OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;//O slash

	case 0x20:combiningUnicode=0x0337;break;//.notdef, overlay short solidus
	case 0x21:pMathType=mo;pmt(*temp);break;//exclamation sign
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23://number sign
	case 0x24:pMathType=mo;pmt(0x00A3);break;//sterling
	case 0x25:pMathType=mo;pmt(*temp);break;//percent
	case 0x26://ampersand
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;
	case 0x27:pMathType=mo;pmt(*temp);break;//apostrophe
	case 0x28:pMathType=mo;pmt(*temp);break;//left parenthesis
	case 0x29:pMathType=mo;pmt(*temp);break;//right parenthesis
	case 0x2A://asterisk
	case 0x2B://plus
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;//comma
	case 0x2D://hyphen
	case 0x2E://period
	case 0x2F:pMathType=mo;pmt(*temp);break;//slash

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;//:
	case 0x3B:pMathType=mo;pmt(*temp);break;//;
	case 0x3C:pMathType=mo;pmt(0x00A1);break;//inverted exclamation mark
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E:pMathType=mo;pmt(0x00BF);break;//inverted question mark
	case 0x3F:pMathType=mo;pmt(*temp);break;//?

	case 0x40:pMathType=mo;pmt(*temp);break;//@ //at
	
	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	case 0x5E:pMathType=mo;pmt(*temp);break;//^
	case 0x5F:pMathType=mo;pmt(0x02D9);break;//dot above

	case 0x60:pMathType=mo;pmt(*temp);break;//`//quoteleft
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;//double acute accent, 0x30B combining
	case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
	case 0x7F:
		if (spacing || mathmode) {pMathType=mo;pmt(0x00A8);spacing=0;} 
		else 
		combiningUnicode=0x0308;
		break;	//diaeresis
	
	case 0x8A:pMathType=mo;pmt(0x0141);break;//L with stroke
	case 0xA2:pMathType=mo;pmt(*temp);break;//cent sign
	case 0xA3:pMathType=mo;pmt(*temp);break;//pound sign
	case 0xAA:pMathType=mo;pmt(0x0142);break;//l with stroke
	case 0xC5:pMathType=mo;pmt(*temp);break;//A with ring above, Angstrom
	case 0xE5:pMathType=mo;pmt(*temp);break;//a with ring above
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMap7tt(){//OT1++ , typewriter 
//cmtt, cmcsc, cmsltt, cmtcsc, cmtl, cmsltl, cccsc
//cmitt (pound for dollar)
//px[sc,bsc], rpx[bsl,bsc,i,r,sc,sl], rtx[b,bi,bsc,bsssc]
//tx[tt,ttsc,ttsl,sc,sssc,btt,bttsc,bsc,bsssc]
//pcrr7n
//cmitt 

unsigned char* temp=(unsigned char*)yytext; 

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;//Omega
	case 0x0B:pMathType=mo;pmt(0x2191);break;//up arrow
	case 0x0C:pMathType=mo;pmt(0x2193);break;//down arrow
	case 0x0D:pMathType=mo;pmt(0x2032);break;//prime
	case 0x0E:pMathType=mo;pmt(0x00A1);break;//inverted exclamation mark
	case 0x0F:pMathType=mo;pmt(0x00BF);break;//inverted question mark

	case 0x10:pMathType=mo;pmt(0x026A);break;//latin i small capital
	case 0x11:pMathType=mo;pmt(0x006A);break;//j (ascii)
	case 0x12:pMathType=mo;pmt(0x0060);break;//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;//german SS (XXX)
	case 0x1A:pMathType=mo;pmt(0x00E6);break;//ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;//oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;//AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;//OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;//O slash

	case 0x20:combiningUnicode=0x0337;break;//overlay short solidus
	case 0x21:pMathType=mo;pmt(*temp);break;//exclamation mark
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23:
	case 0x24:
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText)
			p("<mo>&amp;</mo>");
		else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(*temp);break;//apostrophe
	case 0x28:pMathType=mo;pmt(*temp);break;//left parenthesis
	case 0x29:pMathType=mo;pmt(*temp);break;//right parenthesis
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;//:
	case 0x3B:pMathType=mo;pmt(*temp);break;//;
		
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	{
			if (mathmode && !mathText)
				p("<mo>&lt;</mo>");
			else 
				p("&lt;");
		}
		break;
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&gt;</mo>");
			else 
				p("&gt;");
		}
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;//question mark
	case 0x40:pMathType=mo;pmt(*temp);break;//at sign

	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	case 0x5E:pMathType=mo;pmt(*temp);break;//^
	case 0x5F:pMathType=mo;pmt(0x02D9);break;//dot above

	case 0x60:pMathType=mo;pmt(*temp);break;//`
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;//double acute accent
	case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;//diaeresis

	case 0x8A:pMathType=mo;pmt(0x0141);break;//L with stroke
	case 0xA2:pMathType=mo;pmt(*temp);break;//cent sign
	case 0xA3:pMathType=mo;pmt(*temp);break;//pound sign
	case 0xAA:pMathType=mo;pmt(0x0142);break;//l with stroke
	case 0xC5:pMathType=mo;pmt(*temp);break;//A with ring above, Angstrom
	case 0xE5:pMathType=mo;pmt(*temp);break;//a with ring above
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMap7ttp(){//OT1++ , typewriter 
//cmitt (pound for dollar)

unsigned char* temp=(unsigned char*)yytext; 

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;	//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;	//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;	//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;	//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;	//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;	//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;	//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;	//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;	//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;	//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;	//Omega
	case 0x0B:pMathType=mo;pmt(0x2191);break;	//up arrow
	case 0x0C:pMathType=mo;pmt(0x2193);break;	//down arrow
	case 0x0D:pMathType=mo;pmt(0x2032);break;	//prime
	case 0x0E:pMathType=mo;pmt(0x00A1);break;	//inverted exclamation mark
	case 0x0F:pMathType=mo;pmt(0x00BF);break;	//inverted question mark

	case 0x10:pMathType=mo;pmt(0x026A);break;	//latin i small capital
	case 0x11:pMathType=mo;pmt(0x006A);break;	//j (ascii)
	case 0x12:pMathType=mo;pmt(0x0060);break;	//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;	//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;	//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;	//ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;	//oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;	//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;	//AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;	//OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;	//O slash

	case 0x20:combiningUnicode=0x0337;break;//overlay short solidus
	case 0x21:pMathType=mo;pmt(*temp);break;//exclamation mark
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23:
	case 0x24:pMathType=mo;pmt(0x00A3);break;//sterling
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText)
			p("<mo>&amp;</mo>");
		else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(*temp);break;//apostrophe
	case 0x28:pMathType=mo;pmt(*temp);break;//left parenthesis
	case 0x29:pMathType=mo;pmt(*temp);break;//right parenthesis
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;//:
	case 0x3B:pMathType=mo;pmt(*temp);break;//;
		
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	{
			if (mathmode && !mathText)
				p("<mo>&lt;</mo>");
			else 
				p("&lt;");
		}
		break;
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&gt;</mo>");
			else 
				p("&gt;");
		}
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;//question mark
	case 0x40:pMathType=mo;pmt(*temp);break;//at sign

	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	case 0x5E:pMathType=mo;pmt(*temp);break;//^
	case 0x5F:pMathType=mo;pmt(0x02D9);break;//dot above

	case 0x60:pMathType=mo;pmt(*temp);break;//`
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;//double acute accent
	case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;//diaeresis

	case 0x8A:pMathType=mo;pmt(0x0141);break;//L with stroke
	case 0xA2:pMathType=mo;pmt(*temp);break;//cent sign
	case 0xA3:pMathType=mo;pmt(*temp);break;//pound sign
	case 0xAA:pMathType=mo;pmt(0x0142);break;//l with stroke
	case 0xC5:pMathType=mo;pmt(*temp);break;//A with ring above, Angstrom
	case 0xE5:pMathType=mo;pmt(*temp);break;//a with ring above
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMap8a(){//8a, Standard Encoding
//rpag[d,do,k,ko]

unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:
	case 0x01:
	case 0x02:
	case 0x03:
	case 0x04:
	case 0x05:
	case 0x06:
	case 0x07:
	case 0x08:
	case 0x09:
	case 0x0A:
	case 0x0B:
	case 0x0C:
	case 0x0D:
	case 0x0E:
	case 0x0F:

	case 0x10:
	case 0x11:
	case 0x12:
	case 0x13:
	case 0x14:
	case 0x15:
	case 0x16:
	case 0x17:
	case 0x18:
	case 0x19:
	case 0x1A:
	case 0x1B:
	case 0x1C:
	case 0x1D:
	case 0x1E:
	case 0x1F:

	case 0x20:pMathType=mo;pmt(*temp);break;	//space
	case 0x21:pMathType=mo;pmt(*temp);break;	//exclamation sign
	case 0x22:pMathType=mo;pmt(0x201D);break;	//right double quotation mark
	case 0x23:
	case 0x24:
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(*temp);break;	//apostrophe
	case 0x28:pMathType=mo;pmt(*temp);break;	//left parenthesis
	case 0x29:pMathType=mo;pmt(*temp);break;	//right parenthesis
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;	//0-9 digits
	case 0x3A:pMathType=mo;pmt(*temp);break;	//colon
	case 0x3B:pMathType=mo;pmt(*temp);break;	//semicolon
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&lt;</mo>");
			else 
				p("&lt;");
			break;
		}
		break;
	case 0x3D:pMathType=mo;pmt(0x002F);break;	//slash
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&gt;</mo>");
			else 
				p("&gt;");
			break;
		}
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;	//question mark

	case 0x40:pMathType=mo;pmt(*temp);break;	//at sign
	
	//ascii capital letters
	
	case 0x5B:pMathType=mo;pmt(*temp);break;	//left square bracket
	case 0x5C:pMathType=mo;pmt(*temp);break;	//backslash
	case 0x5D:pMathType=mo;pmt(*temp);break;	//rightt square bracket
	
	case 0x5E:pMathType=mo;pmt(*temp);break;	//circumflex
	case 0x5F:pMathType=mo;pmt(*temp);break;	//underscore
	
	case 0x60:pMathType=mo;pmt(*temp);break;	//left single quote
	
	//ascii small letters

	case 0x7B:pMathType=mo;pmt(*temp);break;	//left brace
	case 0x7C:pMathType=mo;pmt(*temp);break;	//vertical bar
	case 0x7D:pMathType=mo;pmt(*temp);break;	//right brace
	case 0x7E:pMathType=mo;pmt(*temp);break;	//tilde
	case 0x7F:break;	//notdef
	
	case 0x80:
	case 0x81:
	case 0x82:
	case 0x83:
	case 0x84:
	case 0x85:
	case 0x86:
	case 0x87:
	case 0x88:
	case 0x89:
	case 0x8A:
	case 0x8B:
	case 0x8C:
	case 0x8D:
	case 0x8E:
	case 0x8F:

	case 0x90:
	case 0x91:
	case 0x92:
	case 0x93:
	case 0x94:
	case 0x95:
	case 0x96:
	case 0x97:
	case 0x98:
	case 0x99:
	case 0x9A:
	case 0x9B:
	case 0x9C:
	case 0x9D:
	case 0x9E:
	case 0x9F:

	case 0xA0:
	case 0xA1:break;	//notdef
	case 0xA2:	//cent
	case 0xA3:pMathType=mo;pmt(*temp);break;	//sterling
	case 0xA4:pMathType=mo;pmt(0x2044);break;	//fraction slash
	case 0xA5:pMathType=mo;pmt(*temp);break;	//yen
	case 0xA6:pMathType=mo;pmt(0x0192);break;	//florin currency
	case 0xA7:pMathType=mo;pmt(*temp);break;	//section mark
	case 0xA8:pMathType=mo;pmt(0x00A4);break;	//currency sign
	case 0xA9:pMathType=mo;pmt(0x2019);break;	//right single quot-mark
	case 0xAA:pMathType=mo;pmt(0x201C);break;	//left double quot-mark
	
	case 0xAB:pMathType=mo;pmt(*temp);break;	//left guillemet
	case 0xAC:pMathType=mo;pmt(0x2039);break;	//left single guillemet
	case 0xAD:pMathType=mo;pmt(0x2040);break;	//right single guillemet
	case 0xAE:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;	//p(ul2utf8(0xFB01));break;//ligature fi
	case 0xAF:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;	//p(ul2utf8(0xFB02));break;//ligature fl

	case 0xB0:break;	//notdef
	case 0xB1:pMathType=mo;pmt(0x2013);break;	//en-dash
	case 0xB2:pMathType=mo;pmt(0x2020);break;	//dagger
	case 0xB3:pMathType=mo;pmt(0x2021);break;	//double dagger
	case 0xB4:pMathType=mo;pmt(0x00B7);break;	//centered dot
	case 0xB5:break;//notdef
	case 0xB6:pMathType=mo;pmt(*temp);break;	//paragraph
	case 0xB7:pMathType=mo;pmt(0x2022);break;	//bullet
	case 0xB8:pMathType=mo;pmt(0x201A);break;	//quot-mark single base
	case 0xB9:pMathType=mo;pmt(0x201E);break;	//quot-mark double base
	case 0xBA:pMathType=mo;pmt(0x201D);break;	//quot-mark double right
	case 0xBB:pMathType=mo;pmt(*temp);break;	//right guillemet
	case 0xBC:pMathType=mo;pmt(0x2026);break;	//horizontal ellipsis
	case 0xBD:pMathType=mo;pmt(0x2030);break; //per mille
	case 0xBE:break;//notdef
	case 0xBF:pMathType=mo;pmt(*temp);break;
	
	case 0xC0:break;//notdef
	case 0xC1:pMathType=mo;pmt(0x0060);break;	//grave accent
	case 0xC2:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0xC3:pMathType=mo;pmt(0x005E);break;	//hat
	case 0xC4:pMathType=mo;pmt(0x007E);break;	//tilde
	case 0xC5:pMathType=mo;pmt(0x00AF);break;	//macron 
	case 0xC6:pMathType=mo;pmt(0x02D8);break;	//breve 
	case 0xC7:pMathType=mo;pmt(0x02D9);break;	//dot above 
	case 0xC8:pMathType=mo;pmt(0x0308);break;	//diaeresis, XXX, it is combining, should be put in combineAccent 
	case 0xC9:break;//notdef
	case 0xCA:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0xCB:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0xCC:break;//notdef
	case 0xCD:pMathType=mo;pmt(0x02DD);break;	//double acute accent 
	case 0xCE:pMathType=mo;pmt(0x02DB);break;	//ogonek 
	case 0xCF:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	
	case 0xD0:pMathType=mo;pmt(0x2014);break;	//em-dash
	case 0xD1:
	case 0xD2:
	case 0xD3:
	case 0xD4:
	case 0xD5:
	case 0xD6:
	case 0xD7:
	case 0xD8:
	case 0xD9:
	case 0xDA:
	case 0xDB:
	case 0xDC:
	case 0xDD:
	case 0xDE:
	case 0xDF:
	
	case 0xE0:break;	//notdef
	case 0xE1:pMathType=mo;pmt(0x00C6);break;	//AE
	case 0xE2:break;	//notdef
	case 0xE3:pMathType=mo;pmt(0x00AA);break;	//ordinal feminine
	case 0xE4:
	case 0xE5:
	case 0xE6:
	case 0xE7:break;	//notdef
	case 0xE8:pMathType=mo;pmt(0x0141);break;	//L stroke
	case 0xE9:pMathType=mo;pmt(0x00D8);break;	//O stroke
	case 0xEA:pMathType=mo;pmt(0x0152);break;	//OE
	case 0xEB:pMathType=mo;pmt(0x00BA);break;	//ordinal masculine
	case 0xEC:
	case 0xED:
	case 0xEE:
	case 0xEF:
	
	case 0xF0:break;	//notdef
	case 0xF1:pMathType=mo;pmt(0x00E6);break;	//ae
	case 0xF2:
	case 0xF3:
	case 0xF4:break;	//notdef
	case 0xF5:pMathType=mo;pmt(0x0131);break;	//imath
	case 0xF6:
	case 0xF7:break;	//notdef
	case 0xF8:pMathType=mo;pmt(0x0142);break;	//l stroke
	case 0xF9:pMathType=mo;pmt(0x00F8);break;	//o stroke
	case 0xFA:pMathType=mo;pmt(0x0153);break;	//oe
	case 0xFB:pMathType=mo;pmt(0x00DF);break;	//german eszett
	case 0xFC:
	case 0xFD:
	case 0xFE:
	case 0xFF:break;//notdef
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;

}

void fontMapDvips(){
//pag[k,kc,ko,dc,do]
//pbk[d,dc,di,do,l,lc,li,lo]
//rpbk[d,dc,di,do,l,lc,li,lo]
//pcr[b,bc,bo,r,rc,ro]
//rpcr[b,bo,rr,ro
//phv[r,rc,ro,ron,rrn,bc,bo,bon,brn]
//rphv[b,bo,bon,brn,r,ro,ronrrn]
//pnc[b,bc,bo,r,rc,ri,ro]
//rpnc[b,bi,cr,cri]
//ppl[b,bc,bi,bo,bu,r,rc,ri,ro,rre,rrn,ru]
//rppl[r,ri,ro,rre,rrn,ru,b,bi,bu
//ptm[r,rc,ri,ro,rre,rrn,b,bc,bi,bo]
//rptm[r,ri,ro,rre,rrn,b,bi,bo
//rpxcmi
unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:
	case 0x01:
	case 0x02:
	case 0x03:
	case 0x04:
	case 0x05:
	case 0x06:
	case 0x07:
	case 0x08:
	case 0x09:
	case 0x0A:
	case 0x0B:
	case 0x0C:break;//notdef
	case 0x0D:pMathType=mo;pmt('\'');break;//quote single
	case 0x0E:pMathType=mo;pmt(0x00A1);break;//inverted exclamation mark
	case 0x0F:pMathType=mo;pmt(0x00BF);break;//inverted question mark

	case 0x10:pMathType=mo;pmt(0x0131);break;//imath
	case 0x11:pMathType=mo;pmt(0x006A);break;//jmath,pmt(0x0237);break;//jmath
	case 0x12:pMathType=mo;pmt(0x0060);break;//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;//latin ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;//latin oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;//latin AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;//latin OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;//O slash

	case 0x20://space
	case 0x21:pMathType=mo;pmt(*temp);break;//!
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23:
	case 0x24:
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(*temp);break;//'
	case 0x28:pMathType=mo;pmt(*temp);break;//(
	case 0x29:pMathType=mo;pmt(*temp);break;//)
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;
	case 0x3A:pMathType=mo;pmt(*temp);break;//:
	case 0x3B:pMathType=mo;pmt(*temp);break;//;
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	p("<mo>&lt;</mo>");
		break;
	case 0x3D:pMathType=mo;pmt(0x002F);break;//slash
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	p("<mo>&gt;</mo>");
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;//?

	case 0x40:pMathType=mo;pmt(*temp);break;//@
	
	//ascii capital letters
	
	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(*temp);break;//backslash
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	
	case 0x5E:pMathType=mo;pmt(*temp);break;//^
	case 0x5F:pMathType=mo;pmt(*temp);break;//_
	
	case 0x60:pMathType=mo;pmt(*temp);break;//`
	
	//ascii small letters

	case 0x7B:pMathType=mo;pmt(*temp);break;//left brace
	case 0x7C:pMathType=mo;pmt(*temp);break;//vertical bar
	case 0x7D:pMathType=mo;pmt(*temp);break;//right brace
	case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;//diaeresis
	
	case 0x80:pMathType=mo;pmt(0x005E);break;//ascii circumflex
	case 0x81:pMathType=mo;pmt(0x223C);break;//tilde operator
	case 0x82:pMathType=mo;pmt(0x00C7);break;//C cedilla
	case 0x83:pMathType=mo;pmt(0x00CD);break;//I aigu
	case 0x84:pMathType=mo;pmt(0x00CE);break;//I circumflex
	case 0x85:pMathType=mo;pmt(0x00E3);break;//a tilde
	case 0x86:pMathType=mo;pmt(0x00EB);break;//e diaeresis
	case 0x87:pMathType=mo;pmt(0x00E8);break;//e grave
	case 0x88:pMathType=mo;pmt(0x0161);break;//s caron
	case 0x89:pMathType=mo;pmt(0x017E);break;//z caron
	case 0x8A:pMathType=mo;pmt(0x00D0);break;//ETH
	
	case 0x8B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff 
	case 0x8C:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi 
	case 0x8D:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl 
	case 0x8E:
	case 0x8F:

	case 0x90:
	case 0x91:break;//notdef
	case 0x92:pMathType=mo;pmt(0x0160);break;//S caron
	case 0x93:
	case 0x94:
	case 0x95:
	case 0x96:
	case 0x97:break;//notdef
	case 0x98:pMathType=mo;pmt(0x0178);break;//Y diaeresis
	case 0x99:break;//notdef
	case 0x9A:pMathType=mo;pmt(0x017D);break;//Z caron
	case 0x9B:
	case 0x9C:
	case 0x9D:
	case 0x9E:
	case 0x9F:

	case 0xA0:
	case 0xA1:break;//notdef
	case 0xA2://cent
	case 0xA3:pMathType=mo;pmt(*temp);break;//sterling
	case 0xA4:pMathType=mo;pmt(0x2044);break;//fraction slash
	case 0xA5:pMathType=mo;pmt(*temp);break;//yen
	case 0xA6:pMathType=mo;pmt(0x0192);break;//florin currency
	case 0xA7:pMathType=mo;pmt(*temp);break;//section mark
	case 0xA8:pMathType=mo;pmt(0x00A4);break;//currency sign
	case 0xA9:pMathType=mo;pmt(*temp);break;//copyright
	case 0xAA:pMathType=mo;pmt(0x201C);break;//left double quot-mark
	case 0xAB:pMathType=mo;pmt(*temp);break;//left guillemet
	case 0xAC:pMathType=mo;pmt(0x2039);break;//left single guillemet
	case 0xAD:pMathType=mo;pmt(0x2040);break;//right single guillemet
	case 0xAE:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0xAF:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl

	case 0xB0:pMathType=mo;pmt(*temp);break;//degree
	case 0xB1:pMathType=mo;pmt(0x2013);break;//en-dash
	case 0xB2:pMathType=mo;pmt(0x2020);break;//dagger
	case 0xB3:pMathType=mo;pmt(0x2021);break;//double dagger
	case 0xB4:pMathType=mo;pmt(0x00B7);break;//centered dot
	case 0xB5:break;//notdef
	case 0xB6:pMathType=mo;pmt(*temp);break;//paragraph
	case 0xB7:pMathType=mo;pmt(0x2022);break;//bullet
	
	case 0xB8:pMathType=mo;pmt(0x201A);break;//quot-mark single base
	case 0xB9:pMathType=mo;pmt(0x201E);break;//quot-mark double base
	case 0xBA:pMathType=mo;pmt(0x201D);break;//quot-mark double right
	case 0xBB:pMathType=mo;pmt(*temp);break;//right guillemet
	case 0xBC:pMathType=mo;pmt(0x2026);break;//horizontal ellipsis
	case 0xBD:pMathType=mo;pmt(0x2030);break; //per mille
	case 0xBE:
	case 0xBF:break;//notdef
	
	case 0xC6:break;//notdef
	case 0xC7:pMathType=mo;pmt(0x02D9);break;//dot above
	
	case 0xCD:pMathType=mo;pmt(0x02DD);break;//double acute accent
	case 0xCE:pMathType=mo;pmt(0x02DB);break;//ogonek
	
	case 0xD0:pMathType=mo;pmt(0x2014);break;//em-dash
	
	case 0xD7:
	case 0xD8:break;//notdef
	
	case 0xDF:break;//notdef
	
	case 0xE3:pMathType=mo;pmt(0x00AA);break;//ordinal feminine
	
	case 0xEB:pMathType=mo;pmt(0x00BA);break;//ordinal masculine
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;

}

void fontMap8r(){//TeXBase1 Encoding
//rpxppl[b,bi,bo,r,ri,ro]
//rtxphv[b,bo,r,ro,rtxptm[b,bi,bo,r,ri,ro]
//pag[d,do,k,ko]8r
//pbk[d,di,do,l,li,lo]8r
//pcr[b,bo,r,ro]8r
//pfr[r,ri,l,li,b,bi,c,ci,u]8r,pfr[r,l,b,c,u]8rc
//phv[r,ro,b,bo]8r,phv[r,ro,b,bo]8rn
//pnc[r,ri,ro,b,bi,bo]8r
//ppl[r,r,c,ri,rij,ro,ru,b,bi,bij,bj,bo,bu]8r, pplrr8re
//pcrr8rn
//ptm[r,ri,ro,b,bi,bo]8r,ptmrr8re
//pzcmi8r
unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:break;	//notdef
	case 0x01:pMathType=mo;pmt(0x02D9);break;	//dot above
	case 0x02:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x03:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x04:pMathType=mo;pmt(0x2044);break;	//fraction slash
	case 0x05:pMathType=mo;pmt(0x02DD);break;	//double acute accent
	case 0x06:pMathType=mo;pmt(0x0141);break;	//L stroke
	case 0x07:pMathType=mo;pmt(0x0142);break;	//l stroke
	case 0x08:pMathType=mo;pmt(0x02DB);break;	//ogonek 
	case 0x09:pMathType=mo;pmt(0x02DA);break;	//ring above 
	case 0x0A:break;//notdef
	case 0x0B:pMathType=mo;pmt(0x02D8);break;	//breve 
	case 0x0C:pMathType=mo;pmt(0x2212);break;	//minus
	case 0x0D:break;//notdef
	case 0x0E:pMathType=mo;pmt(0x017D);break;	//Z caron
	case 0x0F:pMathType=mo;pmt(0x017E);break;	//z caron
	

	case 0x10:pMathType=mo;pmt(0x02C7);break;	//caron
	case 0x11:pMathType=mo;pmt(0x0131);break; //dotless i
	case 0x12:pMathType=mo;pmt(0x0237);break; //dotless j
	case 0x13:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff 
	case 0x14:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi 
	case 0x15:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl 
	case 0x16:pMathType=mo;pmt(0x2260);break; //not equal
	case 0x17:pMathType=mo;pmt(0x221E);break; //infinity
	case 0x18:pMathType=mo;pmt(0x2264);break;	//less or equal 
	case 0x19:pMathType=mo;pmt(0x2264);break;	//greater or equal
	case 0x1A:pMathType=mo;pmt(0x2202);break; //partial diff	
	case 0x1B:pMathType=mo;pmt(0x2211);break; //summation
	case 0x1C:pMathType=mo;pmt(0x220F);break; //product
	case 0x1D:pMathType=mo;pmt(0x03C0);break; //pi
	case 0x1E:pMathType=mo;pmt(0x0060);break;	//grave
	case 0x1F:pMathType=mo;pmt(0x2019);break;	//quote single
	
	//default to ascii
	
	case 0x26:
		if (mathmode && !mathText)
			p("<mo>&amp;</mo>");
		else 
			p("&amp;");
		break;//ampersand
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&lt;</mo>");
			else 
				p("&lt;");
		}
		break;
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&gt;</mo>");
			else 
				p("&gt;");
		}
		break;

	//default to ascii
	
	case 0x7F:break;	//notdef
	
	//combined accented 
	case 0x80:pMathType=mo;pmt(0x20AC);break;	//euro sign
	case 0x81:pMathType=mo;pmt(0x222B);break;	//integral sign
	case 0x82:pMathType=mo;pmt(0x2019);break;	//quote single base
	case 0x83:pMathType=mo;pmt(0x0192);break;	//florin
	case 0x84:pMathType=mo;pmt(0x201E);break;	//double base quot-mark
	case 0x85:pMathType=mo;pmt(0x2026);break;	//horizontal ellipsis
	case 0x86:pMathType=mo;pmt(0x2020);break;	//dagger
	case 0x87:pMathType=mo;pmt(0x2021);break;	//double dagger
	case 0x88:pMathType=mo;pmt(0x005E);break;	//circumflex
	case 0x89:pMathType=mo;pmt(0x2030);break; //per mille
	case 0x8A:pMathType=mo;pmt(0x0160);break;	//S caron
	case 0x8B:pMathType=mo;pmt(0x2039);break;	//left single guillemet
	case 0x8C:pMathType=mo;pmt(0x0152);break;	//OE
	case 0x8D:pMathType=mo;pmt(0x03A9);break;	//Omega	
	case 0x8E:pMathType=mo;pmt(0x221A);break;	//radical sign
	case 0x8F:pMathType=mo;pmt(0x224A);break;	//approxeq

	case 0x90:
	case 0x91:
	case 0x92:break;	//notdef
	case 0x93:pMathType=mo;pmt(0x201C);break;	//left double quot-mark
	case 0x94:pMathType=mo;pmt(0x201D);break;	//right double quot-mark
	case 0x95:pMathType=mo;pmt(0x2022);break;	//bullet
	case 0x96:pMathType=mo;pmt(0x2013);break;	//en-dash
	case 0x97:pMathType=mo;pmt(0x2014);break;	//em-dash
	case 0x98:pMathType=mo;pmt(0x007E);break;	//tilde
	case 0x99:pMathType=mo;pmt(0x2122);break;	//TradeMark
	case 0x9A:pMathType=mo;pmt(0x0161);break;	//s caron
	case 0x9B:pMathType=mo;pmt(0x2040);break;	//right single guillemet
	case 0x9C:pMathType=mo;pmt(0x0153);break;	//oe
	case 0x9D:pMathType=mo;pmt(0x0394);break;	//Delta
	case 0x9E:pMathType=mo;pmt(0x25CA);break;	//lozenge
	case 0x9F:pMathType=mo;pmt(0x0178);break;	//Y diaeresis
	
	//default to Unicode A0-FF
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;

}

void fontMap8t(){//Cork Encoding
//ebbx, ebmo, ebmr, ebso, ebsr, ebtl, ebto
//p1x[r,i,sl,sc, b, bi,bsc, bsl]
//t1x[r,b,i,bi,bsc,bsl,bss,bsssc,bsssl,sl,sc,ss,sssl,sssc,tt,ttsl,ttsc,btt,bttsl,bttsc]
//ecb, ecbi, ecbx eccc, ecrb, ecrm, ecsc, ecsl, ecss, ecssdc, ecti, ectt
//eocc, eorm, eosl, eoti
//lm[r,ri,ro,ss,sso,ssq,ssqo,ssqbo,ssqbx,ssbo,ssbx,ssdc,ssdo,b,bo,bx,bxi,bxo,csc,csco]
//lmtt, lmtcsc, lmtti, lmtto, lmvtt, lmvtto
//pag[dc,do,k,kc,ko]8t
//pbk[d,dc,di,do,l,lc,li,lo]8t
//pcr[r,r,c,ro,b,bc,bo]8t
//pfr[b,bi,c,ci,l,li,r,ri,u]8t,pfr[b,c,l,r,u]8tc
//phv[r,rc,ro,b,bc,bo]8t,phv[r,rc,ro,b,bc,bo]8tn
//pnc[r,r,c,ri,ro,b,bc,bi,bo]8t
//ppl[r,r,c,ri,ro,b,bc,bi,bo]8t
//pcrr8tn
//ptm[r,rc,ri,ro,b,bc,bi,bo]8t
//pzcmi8t

unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0060);break;	//grave accent
	case 0x01:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0x02:pMathType=mo;pmt(0x005E);break;	//hat
	case 0x03:pMathType=mo;pmt(0x007E);break;	//tilde
	case 0x04:pMathType=mo;pmt(0x0308);break;	//XXX, it is combining, should be put in combineAccent
	case 0x05:pMathType=mo;pmt(0x02DD);break;	//double acute accent
	case 0x06:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0x07:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0x08:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0x09:pMathType=mo;pmt(0x00AF);break;	//macron
	case 0x0A:pMathType=mo;pmt(0x02D9);break;	//dot above
	case 0x0B:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0x0C:pMathType=mo;pmt(0x02DB);break;	//ogonek
	case 0x0D:pMathType=mo;pmt(0x201A);break;	//single low quot-mark
	case 0x0E:pMathType=mo;pmt(0x2329);break;	//left angle
	case 0x0F:pMathType=mo;pmt(0x232A);break;	//right angle
	

	case 0x10:pMathType=mo;pmt(0x201C);break;	//left double quotation mark
	case 0x11:pMathType=mo;pmt(0x201D);break;	//right double quotation mark
	case 0x12:pMathType=mo;pmt(0x0311);break;	//frown, combining inverted breve
	case 0x13:pMathType=mo;pmt(0x030F);break;	//combining double breve
	case 0x14:pMathType=mo;pmt(0x0306);break;	//combining breve, XXX should be cyrillic breve
	case 0x15:pMathType=mo;pmt(0x2013);break;	//en dash
	case 0x16:pMathType=mo;pmt(0x2014);break;	//em dash
	case 0x17:break;	//notdef
	case 0x18:pMathType=mo;pmt(0x00B0);break; //degree sign
	case 0x19:pMathType=mo;pmt(0x0131);break;	//dotless i
	case 0x1A:pMathType=mo;pmt(0x0237);break; //dotless j
	case 0x1B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
	case 0x1C:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x1D:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x1E:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
	case 0x1F:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

	case 0x20:pMathType=mo;pmt(0x2423);break;//graphic for space
	
	case 0x21:pMathType=mo;pmt(*temp);break;//!
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23:
	case 0x24:
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(0x2019);break;//right single quot-mark
	case 0x28:pMathType=mo;pmt(*temp);break;//(
	case 0x29:pMathType=mo;pmt(*temp);break;//)
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;
	case 0x3A:pMathType=mo;pmt(*temp);break;//:
	case 0x3B:pMathType=mo;pmt(*temp);break;//;
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&lt;</mo>");
			else 
				p("&lt;");
		}
		break;
	case 0x3D:pMathType=mo;pmt(0x002F);break;//slash
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&gt;</mo>");
			else 
				p("&gt;");
		}
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;//question mark

	case 0x40:pMathType=mo;pmt(*temp);break;//at sign

	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(*temp);break;//backslash
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	
	case 0x5E:pMathType=mo;pmt(*temp);break;//circumflex
	case 0x5F:pMathType=mo;pmt(*temp);break;//underscore
	case 0x60:pMathType=mo;pmt(0x2018);break;//left single quot-mark
	
	//ascii small letters

	case 0x7B:pMathType=mo;pmt(*temp);break;//left brace
	case 0x7C:pMathType=mo;pmt(*temp);break;//vertical bar
	case 0x7D:pMathType=mo;pmt(*temp);break;//right brace
	case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
	case 0x7F:pMathType=mo;pmt(0x2012);break;//figure dash
	
	//combined accented 
	case 0x80:pMathType=mo;pmt(0x0102);break;//A breve
	case 0x81:pMathType=mo;pmt(0x0104);break;//A ogonek
	case 0x82:pMathType=mo;pmt(0x0106);break;//C acute
	case 0x83:pMathType=mo;pmt(0x010C);break;//C caron
	case 0x84:pMathType=mo;pmt(0x010E);break;//D caron
	case 0x85:pMathType=mo;pmt(0x011A);break;//E caron
	case 0x86:pMathType=mo;pmt(0x0118);break;//E ogonek
	case 0x87:pMathType=mo;pmt(0x011E);break;//G breve
	case 0x88:pMathType=mo;pmt(0x0139);break;//L acute
	case 0x89:pMathType=mo;pmt(0x013D);break;//L caron
	case 0x8A:pMathType=mo;pmt(0x0141);break;//L stroke
	case 0x8B:pMathType=mo;pmt(0x0143);break;//N acute
	case 0x8C:pMathType=mo;pmt(0x0147);break;//N caron
	case 0x8D:pMathType=mo;pmt(0x014A);break;//ENG
	case 0x8E:pMathType=mo;pmt(0x0150);break;//O double acute
	case 0x8F:pMathType=mo;pmt(0x0154);break;//R acute

	case 0x90:pMathType=mo;pmt(0x0158);break;//R caron
	case 0x91:pMathType=mo;pmt(0x015A);break;//S acute
	case 0x92:pMathType=mo;pmt(0x0160);break;//S caron
	case 0x93:pMathType=mo;pmt(0x015E);break;//S cedilla
	case 0x94:pMathType=mo;pmt(0x0164);break;//T caron
	case 0x95:pMathType=mo;pmt(0x0162);break;//T cedilla
	case 0x96:pMathType=mo;pmt(0x0170);break;//U double acute
	case 0x97:pMathType=mo;pmt(0x016E);break;//U ring above
	case 0x98:pMathType=mo;pmt(0x0178);break;//Y diaeresis
	case 0x99:pMathType=mo;pmt(0x0179);break;//Z acute
	case 0x9A:pMathType=mo;pmt(0x017D);break;//Z caron
	case 0x9B:pMathType=mo;pmt(0x017B);break;//Z dot above
	case 0x9C:pMathType=mo;pmt(0x0132);break;//ligature IJ
	case 0x9D:pMathType=mo;pmt(0x0130);break;//I dot above
	case 0x9E:pMathType=mo;pmt(0x0111);break;//d stroke
	case 0x9F:pMathType=mo;pmt(0x00A7);break;//section sign

	case 0xA0:pMathType=mo;pmt(0x0103);break;//a breve
	case 0xA1:pMathType=mo;pmt(0x0104);break;//a ogonek
	case 0xA2:pMathType=mo;pmt(0x0107);break;//c acute
	case 0xA3:pMathType=mo;pmt(0x010D);break;//c caron
	case 0xA4:pMathType=mo;pmt(0x010F);break;//d caron
	case 0xA5:pMathType=mo;pmt(0x011B);break;//e caron
	case 0xA6:pMathType=mo;pmt(0x0119);break;//e ogonek
	case 0xA7:pMathType=mo;pmt(0x011F);break;//g breve
	case 0xA8:pMathType=mo;pmt(0x013A);break;//l acute
	case 0xA9:pMathType=mo;pmt(0x013E);break;//l caron
	case 0xAA:pMathType=mo;pmt(0x0142);break;//l stroke
	case 0xAB:pMathType=mo;pmt(0x0144);break;//n acute
	case 0xAC:pMathType=mo;pmt(0x0148);break;//n caron
	case 0xAD:pMathType=mo;pmt(0x014B);break;//eng
	case 0xAE:pMathType=mo;pmt(0x0151);break;//o double acute
	case 0xAF:pMathType=mo;pmt(0x0155);break;//r acute
	
	case 0xB0:pMathType=mo;pmt(0x0159);break;//r caron
	case 0xB1:pMathType=mo;pmt(0x015B);break;//s acute
	case 0xB2:pMathType=mo;pmt(0x0161);break;//s caron
	case 0xB3:pMathType=mo;pmt(0x015F);break;//s cedilla
	case 0xB4:pMathType=mo;pmt(0x0165);break;//t caron
	case 0xB5:pMathType=mo;pmt(0x0163);break;//t cedilla
	case 0xB6:pMathType=mo;pmt(0x0171);break;//u double acute
	case 0xB7:pMathType=mo;pmt(0x016F);break;//u ring above
	case 0xB8:pMathType=mo;pmt(0x00FF);break;//y diaeresis
	case 0xB9:pMathType=mo;pmt(0x017A);break;//z acute
	case 0xBA:pMathType=mo;pmt(0x017E);break;//z caron
	case 0xBB:pMathType=mo;pmt(0x017C);break;//z dot above
	case 0xBC:pMathType=mo;pmt(0x0133);break;//ligature ij
	case 0xBD:pMathType=mo;pmt(0x00A1);break;//inverted exclamation sign
	case 0xBE:pMathType=mo;pmt(0x00BF);break;//inverted question sign
	case 0xBF:pMathType=mo;pmt(0x00A3);break;//pound sterling

	case 0xC0://A grave
	case 0xC1://A acute
	case 0xC2://A circumflex
	case 0xC3://A tilde
	case 0xC4://A diaeresis
	case 0xC5://A ring above
	case 0xC6://AE ligature
	case 0xC7://C cedilla
	case 0xC8://E grave
	case 0xC9://E acute
	case 0xCA://E circumflex
	case 0xCB://E diaeresis
	case 0xCC://I grave
	case 0xCD://I acute
	case 0xCE://I circumflex
	case 0xCF:pMathType=mo;pmt(*temp);break;//I diaeresis

	case 0xD0://ETH
	case 0xD1://N tilde
	case 0xD2://O grave
	case 0xD3://O acute
	case 0xD4://O circumflex
	case 0xD5://O tilde
	case 0xD6://O diaeresis
	case 0xD7://C cedilla
	case 0xD8://E grave
	case 0xD9://E acute
	case 0xDA://E circumflex
	case 0xDB://E diaeresis
	case 0xDC://I grave
	case 0xDD://I acute
	case 0xDE:pMathType=mo;pmt(*temp);break;//I circumflex
	case 0xDF:pMathType=mo;pmt(0x0152);break;//ligature OE
	
	case 0xE0://a grave
	case 0xE1://a acute
	case 0xE2://a circumflex
	case 0xE3://a tilde
	case 0xE4://a diaeresis
	case 0xE5://a ring above
	case 0xE6://ligature ae
	case 0xE7://c cedilla
	case 0xE8://e grave
	case 0xE9://e acute
	case 0xEA://e circumflex
	case 0xEB://e diaeresis
	case 0xEC://i grave
	case 0xED://i acute
	case 0xEE://i circumflex
	case 0xEF:pMathType=mo;pmt(*temp);break;//i diaeresis
	
	case 0xF0://eth
	case 0xF1://n tilde
	case 0xF2://o grave
	case 0xF3://o acute
	case 0xF4://o circumflex
	case 0xF5://o tilde
	case 0xF6:pMathType=mo;pmt(*temp);break;//o diaeresis
	case 0xF7:pMathType=mo;pmt(0x0153);break;//ligature oe
	case 0xF8://o stroke
	case 0xF9://u grave
	case 0xFA://u acute
	case 0xFB://u circumflex
	case 0xFC://u diaeresis
	case 0xFD://y acute
	case 0xFE:pMathType=mo;pmt(*temp);break;//thorn
	case 0xFF:pMathType=mo;pmt(0x00DF);break;//sharp s, german eszett
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMap8c(){
//tbbx, tbmo, tbmr, tbso, tbsr, tbtl, tbto
//tcssdc, torm, tosl, toti
//ts1-lm[r,ri,ro,ss, ssbo, ssbx, ssdc, ssdo, sso,ssq, ssqbo, ssqbx, ssqo, b,bo,bx,bxi,bxo,csc,csco, tcsc, tt, tti, tto, vtt, vtto]
//[r]pcx[b,bi,	bsl,i,r,sl]
//rtcx[b,bi,bsl,bss,bsso,i,r,sl,ss,sssl,]
//tcx[r,sl,ss,sssl,i,b,bi,bss,bsl,bsssl,btt,bttsl,tt,ttsl,

unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0060);break;//grave accent
	case 0x01:pMathType=mo;pmt(0x00B4);break;//acute accent
	case 0x02:pMathType=mo;pmt(0x005E);break;//hat
	case 0x03:pMathType=mo;pmt(0x007E);break;//tilde
	case 0x04:pMathType=mo;pmt(0x0308);break;//XXX, it is combining, should be put in combineAccent
	case 0x05:pMathType=mo;pmt(0x02DD);break;//double acute accent
	case 0x06:pMathType=mo;pmt(0x02DA);break;//ring above
	case 0x07:pMathType=mo;pmt(0x02C7);break;//caron, hacek
	case 0x08:pMathType=mo;pmt(0x02D8);break;//breve
	case 0x09:pMathType=mo;pmt(0x00AF);break;//macron
	case 0x0A:pMathType=mo;pmt(0x02D9);break;//dot above
	case 0x0B:pMathType=mo;pmt(0x00B8);break;//cedilla
	case 0x0C:pMathType=mo;pmt(0x02DB);break;//ogonek
	case 0x0D:pMathType=mo;pmt(0x201A);break;//single low quot-mark
	case 0x0E:
	case 0x0F:break;//notdef
	

	case 0x10:
	case 0x11:break;//notdef
	case 0x12:pMathType=mo;pmt(0x201E);break;//low double quot-mark
	case 0x13:
	case 0x14:break;//notdef
	case 0x15:pMathType=mo;pmt(0x2013);break;//en-dash (XXX,12 ???)
	case 0x16:pMathType=mo;pmt(0x2014);break;//em-dash (XXX,3/4 ???)
	case 0x17:break;//notdef
	case 0x18:pMathType=mo;pmt(0x2190);break;//leftarrow
	case 0x19:pMathType=mo;pmt(0x2192);break;//rightarrow
	case 0x1A:pMathType=mo;pmt(0x2040);break;//tie (lower case, XXX not in Unicode 4.1)
	case 0x1B:pMathType=mo;pmt(0x2040);break;//tie (capital, XXX not in Unicode 4.1)
	case 0x1C:pMathType=mo;pmt(0x2040);break;//tie (lower case, XXX not in Unicode 4.1)
	case 0x1D:pMathType=mo;pmt(0x2040);break;//tie (capital, XXX not in Unicode 4.1)
	case 0x1E:
	case 0x1F:break;//notdef

	case 0x20:pMathType=mo;pmt(0x2422);break;//graphic for space
	case 0x21:
	case 0x22:
	case 0x23:break;//notdef
	case 0x24:pMathType=mo;pmt(*temp);break;//dollar sign
	case 0x25:
	case 0x26:break;//notdef
	case 0x27:pMathType=mo;pmt(0x2019);break;//right single quot-mark
	case 0x28:
	case 0x29:break;//notdef
	case 0x2A:pMathType=mo;pmt(*temp);break;//*
	case 0x2B:break;//notdef
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;//comma
	case 0x2D:break;//notdef
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;//fraction

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;
	case 0x3A:break;//notdef
	case 0x3B:
	case 0x3C:
	case 0x3D:
	case 0x3E:
	case 0x3F:

	case 0x40:
	case 0x41:
	case 0x42:
	case 0x43:
	case 0x44:
	case 0x45:
	case 0x46:
	case 0x47:
	case 0x48:
	case 0x49:
	case 0x4A:
	case 0x4B:
	case 0x4C:break;//notdef
	case 0x4D:pMathType=mo;pmt(0x2127);break;//mho
	case 0x4E:break;//notdef
	case 0x4F:pMathType=mo;pmt(0x25CB);break;//white circle
	
	case 0x50:
	case 0x51:
	case 0x52:
	case 0x53:
	case 0x54:
	case 0x55:
	case 0x56:break;//notdef
	case 0x57:pMathType=mo;pmt(0x2126);break;//ohm sign
	case 0x58:
	case 0x59:
	case 0x5A:break;//notdef
	case 0x5B:pMathType=mo;pmt(0x27E6);break;//left ds square parenthesis
	case 0x5C:break;//notdef
	case 0x5D:pMathType=mo;pmt(0x27E7);break;//right ds square parenthesis
	case 0x5E:pMathType=mo;pmt(0x2191);break;//up arrow
	case 0x5F:pMathType=mo;pmt(0x2193);break;//down arrow
	
	case 0x60:pMathType=mo;pmt(0x2018);break;//left single quot-mark
	case 0x61:break;//notdef
	case 0x62:pMathType=mo;pmt(0x22C6);break;//star operator (XXX, born, Uni???)
	case 0x63:pMathType=mo;pmt(0x26AE);break;//divorce
	case 0x64:pMathType=mo;pmt(0x271D);break;//cross (XXX, died, Uni???)
	case 0x65:
	case 0x66:
	case 0x67:
	case 0x68:
	case 0x69:
	case 0x6A:
	case 0x6B:break;//notdef
	case 0x6C:pMathType=mo;pmt(0x2618);break;//leaf (XXX, Uni.shamrock???)
	case 0x6D:pMathType=mo;pmt(0x26AE);break;//marriage
	case 0x6E:pMathType=mo;pmt(0x266A);break;//musical 1/8
	case 0x6F:break;//notdef
	
	case 0x70:
	case 0x71:
	case 0x72:
	case 0x73:
	case 0x74:
	case 0x75:
	case 0x76:
	case 0x77:
	case 0x78:
	case 0x79:
	case 0x7A:
	case 0x7B:
	case 0x7C:
	case 0x7D:break;//notdef
	case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
	case 0x7F:pMathType=mo;pmt('=');break;//short equals (XXX,Uni????)
	
	//combined accented 
	case 0x80:pMathType=mo;pmt(0x02D8);break;//breve
	case 0x81:pMathType=mo;pmt(0x02C7);break;//caron, hacek
	case 0x82:pMathType=mo;pmt(0x301E);break;//double prime quot-mark
	case 0x83:pMathType=mo;pmt(0x301D);break;//reversed double prime quot-mark
	case 0x84:pMathType=mo;pmt(0x2020);break;//dagger
	case 0x85:pMathType=mo;pmt(0x2021);break;//double dagger
	case 0x86:pMathType=mo;pmt(0x2225);break;//double vert
	case 0x87:pMathType=mo;pmt(0x2030);break; //per mille
	
	case 0x88:pMathType=mo;pmt(0x2022);break;//bullet
	case 0x89:pMathType=mo;pmt(0x2103);break;//degree Celsius
	case 0x8A:pMathType=mo;pmt('$');break;//dollar oldstyle (XXX,Uni????)
	case 0x8B:pMathType=mo;pmt(0x00A2);break;//cent oldstyle (XXX,Uni????)
	case 0x8C:pMathType=mo;pmt(0x0192);break;//florin
	case 0x8D:pMathType=mo;pmt(0x20A1);break;//colon
	case 0x8E:pMathType=mo;pmt(0x20A9);break;//won
	case 0x8F:pMathType=mo;pmt(0x20A6);break;//naira

	case 0x90:pMathType=mo;pmt(0x20B2);break;//guarani
	case 0x91:pMathType=mo;pmt(0x20B1);break;//peso
	case 0x92:pMathType=mo;pmt(0x20A4);break;//lira
	case 0x93:pMathType=mo;pmt(0x211E);break;//recipe
	case 0x94:pMathType=mo;pmt(0x203D);break;//interrobang
	case 0x95:pMathType=mo;pmt(0x00BF);break;//gnaborretni (XXX, Uni????)
	case 0x96:pMathType=mo;pmt(0x20AB);break;//dong sign
	case 0x97:pMathType=mo;pmt(0x2122);break;//TM
	case 0x98:pMathType=mo;pmt(0x2031);break;//per ten thousand
	case 0x99:pMathType=mo;pmt(0x00B6);break;//paragraph?? (XXX,Uni????)
	case 0x9A:pMathType=mo;pmt(0x0E3F);break;//Baht
	case 0x9B:pMathType=mo;pmt(0x2116);break;//Numero sign
	case 0x9C:pMathType=mo;pmt(0x2052);break;//commercial minus
	case 0x9D:pMathType=mo;pmt(0x212E);break;//estimated
	case 0x9E:pMathType=mo;pmt(0x25E6);break;//white bullet
	case 0x9F:pMathType=mo;pmt(0x2120);break;//service mark

	//defaults go directly Unicode
	
	case 0xAB:pMathType=mo;pmt(0x0254);break;//copyleft  (XXX,Uni????)
	case 0xAD:pMathType=mo;pmt(0x2117);break;//sound recording copyright
	
	case 0xB8:pMathType=mo;pmt(0x203B);break;//reference mark
	case 0xBB:break;//notdef
	
	case 0xBF:pMathType=mo;pmt(0x20AC);break;//euro sign

	//should be none, but let them go
	
	case 0xE6:pMathType=mo;pmt(0x00D7);break;//multiplication sign
	
	//should be none, but let them go
	
	case 0xF6:pMathType=mo;pmt(0x00F7);break;//division sign
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;

}



void fontMap8q(){
//qx-lmr[i,o],qx-lmss[bo,bx,dc,do,o,q,qo, qbo,qbx] qx-lmb[o,x], qx-lmbx[i,o], qx-lmcsc[o]
//qx-lmtcsc, qx-lmtt[i,o], qx-lmvtt[o]
//qb[kb,kbi,kr,kri], qh[vb,vbi,vcb,vcbi,vcr,vcri,vr,vri], qpl[b,bi,r,ri], qcr[b,bi,rr,rri] (tt)
//qtm[b,bi,r,ri,]
//qzcmi
//txbex
//vn[b,bx,bxsl,bxti,csc,dunh,ff,fi,fib,itt,r,sl,sltt,ss,ssbx,ssdc,ssi,ssq,ssqi,tcsc,ti,ttu,vtt
unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x03B1);break;//alpha
	case 0x01:pMathType=mo;pmt(0x0394);break;//Delta
	case 0x02:pMathType=mi;pmt(0x03B2);break;//beta
	case 0x03:pMathType=mi;pmt(0x03B4);break;//delta
	case 0x04:pMathType=mi;pmt(0x03C0);break;//pi
	case 0x05:pMathType=mo;pmt(0x03A0);break;//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;//Sigma
	case 0x07:pMathType=mi;pmt(0x03BC);break;//mu
	case 0x08:pMathType=mo;pmt(0x2026);break;//horizontal ellipsis
	case 0x09:pMathType=mo;pmt(0x2620);break;//poison
	case 0x0A:pMathType=mo;pmt(0x03A9);break;//Omega
	case 0x0B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
	case 0x0C:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x0D:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x0E:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
	case 0x0F:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

	case 0x10:pMathType=mo;pmt(0x0131);break;//dotless i
	case 0x11:pMathType=mo;pmt(0x0237);break;//dotless j
	case 0x12:pMathType=mo;pmt(0x0060);break;//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;//latin ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;//latin oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;//latin AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;//latin OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;//O slash

	//space to default
	case 0x21:pMathType=mo;pmt(*temp);break;//!
	case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
	case 0x23://number sign
	case 0x24://US dollar symbol
	case 0x25:pMathType=mo;pmt(*temp);break;//percent
	case 0x26://ampersand
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;
	case 0x27:pMathType=mo;pmt(0x2019);break;//right single quot-mark
	case 0x28:pMathType=mo;pmt(*temp);break;//(
	case 0x29:pMathType=mo;pmt(*temp);break;//)
	case 0x2A://asterisk
	case 0x2B://plus
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;//comma
	case 0x2D://hyphen
	case 0x2E://period
	case 0x2F:pMathType=mo;pmt(*temp);break;//slash

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;	//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;	//colon
	case 0x3B:pMathType=mo;pmt(*temp);break;	//semicolon
	case 0x3C:pMathType=mo;pmt(0x00A1);break;	//inverted exclamation mark
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E:pMathType=mo;pmt(0x00BF);break;	//inverted question mark
	case 0x3F:pMathType=mo;pmt(*temp);break;	//question mark

	case 0x40:pMathType=mo;pmt(*temp);break; //at
	
	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;	//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;	//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;	//]
	case 0x5E:pMathType=mo;pmt(*temp);break;	//^
	case 0x5F:pMathType=mo;pmt(0x02D9);break;	//dot above

	case 0x60:pMathType=mo;pmt(*temp);break;	//quoteleft
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;	//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;	//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;	//double acute accent, 0x30B combining
	case 0x7E:pMathType=mo;pmt(*temp);break;	//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;	//diaeresis
	
	case 0x80:pMathType=mo;pmt(0x20AC);break;	//euro sign
	case 0x81:pMathType=mo;pmt(0x0104);break;	//A ogonek
	case 0x82:pMathType=mo;pmt(0x0106);break;	//C acute
	case 0x83:p("&gt;");//greater
	case 0x84:pMathType=mo;pmt(0x2265);break;	//greater equal
	case 0x85:pMathType=mo;pmt(0x224A);break;	//approxequal
	case 0x86:pMathType=mo;pmt(0x0118);break;	//E ogonek
	case 0x87:pMathType=mo;pmt(0x012E);break;	//I ogonek
	case 0x88:p("&lt;");//less
	case 0x89:pMathType=mo;pmt(0x2264);break;	//less equal
	case 0x8A:pMathType=mo;pmt(0x0141);break;	//L stroke
	case 0x8B:pMathType=mo;pmt(0x0143);break;	//N acute
	case 0x8C:pMathType=mo;pmt('~');break;		//ascii tilde
	case 0x8D:pMathType=mo;pmt('^');break;		//ascii circumflex
	case 0x8E:pMathType=mo;pmt(0x2113);break;	//ell script
	case 0x8F:pMathType=mo;pmt(0x2020);break;	//dagger
	
	case 0x90:pMathType=mo;pmt(0x2021);break;	//double dagger
	case 0x91:pMathType=mo;pmt(0x015A);break;	//S acute
	case 0x92:pMathType=mo;pmt(0x015C);break;	//S caron
	case 0x93:pMathType=mo;pmt(0x0218);break;	//S commma-under accent, romanian Sh
	case 0x94:pMathType=mo;pmt(0x00B0);break; //degree sign
	case 0x95:pMathType=mo;pmt(0x021A);break;	//T commma-under accent, romanian Ts
	case 0x96:pMathType=mo;pmt(0x02DB);break;	//ogonek
	case 0x97:pMathType=mo;pmt(0x0172);break;	//U ogonek
	case 0x98:pMathType=mo;pmt(0x0178);break;	//Y diaeresis
	case 0x99:pMathType=mo;pmt(0x0179);break;	//Z acute
	case 0x9A:pMathType=mo;pmt(0x017D);break;	//Z caron
	case 0x9B:pMathType=mo;pmt(0x017B);break;	//Z dot accent
	case 0x9C:pMathType=mo;pmt(0x0132);break;	//IJ
	case 0x9D:pMathType=mo;pmt('{');break;		//brace left
	case 0x9E:pMathType=mo;pmt('}');break;		//brace right
	case 0x9F:pMathType=mo;pmt(0x00A7);break;	//section

	case 0xA0:break;											//notdef
	case 0xA1:pMathType=mo;pmt(0x0105);break;	//a ogonek
	case 0xA2:pMathType=mo;pmt(0x0107);break;	//c acute
	case 0xA3:pMathType=mo;pmt(0x00AE);break;	//registered mark
	case 0xA4:pMathType=mo;pmt(0x2117);break;	//copyright sign
	case 0xA5:pMathType=mo;pmt(0x007C);break;	//division
	case 0xA6:pMathType=mo;pmt(0x0119);break;	//e ogonek
	case 0xA7:pMathType=mo;pmt(0x012F);break;	//i ogonek
	case 0xA8:pMathType=mo;pmt(0x2212);break;	//minus
	case 0xA9:pMathType=mo;pmt(0x00D7);break;	//multiplication sign
	case 0xAA:pMathType=mo;pmt(0x0142);break;	//l with stroke
	case 0xAB:pMathType=mo;pmt(0x0144);break;	//n acute
	case 0xAC:pMathType=mo;pmt(0x00B1);break;	//plus-minus
	case 0xAD:pMathType=mo;pmt(0x221E);break;	//infinity
	case 0xAE:pMathType=mo;pmt(0x00AB);break;	//left guillemet
	case 0xAF:pMathType=mo;pmt(0x00BB);break;	//right guillemet

	case 0xB0:pMathType=mo;pmt(0x0086);break;	//paragraph
	case 0xB1:pMathType=mo;pmt(0x015B);break;	//s acute
	case 0xB2:pMathType=mo;pmt(0x0161);break;	//s caron
	case 0xB3:pMathType=mo;pmt(0x0219);break;	//s comma-under accent, romanian sh
	case 0xB4:pMathType=mo;pmt(0x2022);break;	//bullet
	case 0xB5:pMathType=mo;pmt(0x021B);break;	//t comma-under accent, romanian ts
	case 0xB6:pMathType=mo;pmt(0x2014);break;	//em-dash (XXX, 3/4 em-dash, Uni????)
	case 0xB7:pMathType=mo;pmt(0x0173);break;	//u ogonek
	case 0xB8:pMathType=mo;pmt(0x00FF);break;	//y diaeresis
	case 0xB9:pMathType=mo;pmt(0x017A);break;	//z acute
	case 0xBA:pMathType=mo;pmt(0x017E);break;	//z caron
	case 0xBB:pMathType=mo;pmt(0x017C);break;	//z dot accent
	case 0xBC:pMathType=mo;pmt(0x0133);break;	//ij
	case 0xBD:pMathType=mo;pmt(0x00B7);break;	//centered dot
	case 0xBE:pMathType=mo;pmt('\"');break;		//quote double
	case 0xBF:pMathType=mo;pmt('\'');break;		//quote single

	case 0xC6:pMathType=mo;pmt('\\');break;		//backslash
	
	case 0xD7:pMathType=mo;pmt(0x00A4);break;	//currency sign
	case 0xD8:pMathType=mo;pmt(0x2030);break; //per mille	
	
	case 0xDF:pMathType=mo;pmt('|');break; 		//vertical bar

	case 0xE6:pMathType=mo;pmt('_');break;		//underscore
	
	case 0xF7:pMathType=mo;pmt(0x2222);break;	//angle arc
	case 0xF8:pMathType=mo;pmt(0x2300);break;	//diameter
	
	case 0xFF:pMathType=mo;pmt(0x201E);break;//low double comma quote-mark
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;

}


void fontMap8y(){//TeXnANSI
//texnansi-lmr[i,o], texnansi-lmss[bo,bx,dc,do,o,q,qo, qbo,qbx], texnansi-lmb[o,x,xi,xo], texnansi-lmcsc[o]
//texnansi-lmtt[i,o], texnansi-lmtcsc, texnansi-lmvtt[o]
//tyx[r,i,b,sc,sl,ss,sssc,sssl, tt,ttsl,ttsc,bi,bsc,bsl,bss,bsssc,bsssl,btt,bttsc,bttsl,
//pag[k,ko,d,do]8c (euro in 0xBF), pag[d,k,ko]8r
//pbk[d,di,do,l,li,lo]8c (euro in 0xBF)
//pcr[r,ro,b,bo]8c (euro in 0xBF)
//pzcmi8c (euro in 0xBF)
//pfr[b,i,c,ci,l,li,r,ri,u]8c, pfr[b,c,l,r,u]8cc
//phv[r,ro,b,bo]8c,phv[ro,bo]8cn
//pnc[b,bi,bo,r,ri,ro]8c
//ppl[b,bi,bo,r,ri,ro]8c
//ptm[b,bi,bo,r,ri,ro]8c

unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:break;//notdef
	case 0x01:pMathType=mo;pmt(0x20AC);break;	//euro sign
	case 0x02:break;	//notdef
	case 0x03:break;	//notdef
	case 0x04:pMathType=mo;pmt(0x2044);break;	//fraction slash
	case 0x05:pMathType=mo;pmt(0x02D9);break;	//dot above
	case 0x06:pMathType=mo;pmt(0x02DD);break;	//double acute accent
	case 0x07:pMathType=mo;pmt(0x02DB);break;	//ogonek
	case 0x08:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x09:break;//notdef
	case 0x0A:break;//notdef
	case 0x0B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
	case 0x0C:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x0D:break;//notdef
	case 0x0E:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
	case 0x0F:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

	case 0x10:pMathType=mo;pmt(0x0131);break;	//imath
	case 0x11:pMathType=mo;pmt(0x006A);break;	//jmath,pmt(0x0237);break;//jmath
	case 0x12:pMathType=mo;pmt(0x0060);break;	//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;	//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;	//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;	//latin ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;	//latin oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;	//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;	//latin AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;	//latin OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;	//O slash

	case 0x20:pMathType=mo;pmt(0x2423);break;	//graphic for space
	
	case 0x21:pMathType=mo;pmt(*temp);break;	//exclamation sign
	case 0x22:pMathType=mo;pmt(0x201D);break;	//right double quotation mark
	case 0x23:
	case 0x24:
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(*temp);break;	//right single quot-mark
	case 0x28:pMathType=mo;pmt(*temp);break;	//(
	case 0x29:pMathType=mo;pmt(*temp);break;	//)
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;
	case 0x3A:pMathType=mo;pmt(*temp);break;	//colon
	case 0x3B:pMathType=mo;pmt(*temp);break;	//semicolon
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	p("<mo>&lt;</mo>");
		break;
	case 0x3D:pMathType=mo;pmt(0x002F);break;	//slash
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	p("<mo>&gt;</mo>");
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;	//question sign

	case 0x40:pMathType=mo;pmt(*temp);break;	//at sign
	
	//ascii capital letters
	
	case 0x5B:pMathType=mo;pmt(*temp);break;//[
	case 0x5C:pMathType=mo;pmt(*temp);break;//backslash
	case 0x5D:pMathType=mo;pmt(*temp);break;//]
	
	case 0x5E:pMathType=mo;pmt(*temp);break;	//circumflex
	case 0x5F:pMathType=mo;pmt(*temp);break;	//underscore
	
	case 0x60:pMathType=mo;pmt(*temp);break;	//left single quot-mark
	
	//ascii small letters

	case 0x7B:pMathType=mo;pmt(*temp);break;	//left brace
	case 0x7C:pMathType=mo;pmt(*temp);break;	//vertical bar
	case 0x7D:pMathType=mo;pmt(*temp);break;	//right brace
	case 0x7E:pMathType=mo;pmt(*temp);break;	//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;	//diaeresis
	
	//LY1 specific
	case 0x80:pMathType=mo;pmt(0x0141);break;	//L stroke
	case 0x81:pMathType=mo;pmt(0x201B);break;	//quote single
	case 0x82:pMathType=mo;pmt(0x201A);break;	//single low quot-mark
	case 0x83:pMathType=mo;pmt(0x0192);break;	//florin currency
	case 0x84:pMathType=mo;pmt(0x201E);break;	//double low quot-mark
	case 0x85:pMathType=mo;pmt(0x2026);break;	//horizontal ellipsis
	case 0x86:pMathType=mo;pmt(0x2020);break;	//dagger
	case 0x87:pMathType=mo;pmt(0x2021);break;	//double dagger
	case 0x88:pMathType=mo;pmt(0x005E);break;	//circumflex
	case 0x89:pMathType=mo;pmt(0x2030);break; //per mille
	case 0x8A:pMathType=mo;pmt(0x0160);break;	//S caron
	case 0x8B:pMathType=mo;pmt(0x2039);break;	//left single guillemet
	case 0x8C:pMathType=mo;pmt(0x0152);break;	//OE
	case 0x8D:pMathType=mo;pmt(0x017D);break;	//Z caron
	case 0x8E:pMathType=mo;pmt(0x005E);break;	//ascii circumflex
	case 0x8F:pMathType=mo;pmt(0x2212);break;	//minus

	case 0x90:pMathType=mo;pmt(0x0142);break;	//l stroke
	case 0x91:pMathType=mo;pmt(0x2018);break;	//left single quot-mark
	case 0x92:pMathType=mo;pmt(0x2019);break;	//right single quot-mark
	case 0x93:pMathType=mo;pmt(0x201C);break;	//left double quot-mark
	case 0x94:pMathType=mo;pmt(0x201D);break;	//right double quot-mark
	case 0x95:pMathType=mo;pmt(0x2022);break;	//bullet
	case 0x96:pMathType=mo;pmt(0x2013);break;	//en-dash
	case 0x97:pMathType=mo;pmt(0x2014);break;	//em-dash
	case 0x98:pMathType=mo;pmt(0x007E);break;	//tilde
	case 0x99:pMathType=mo;pmt(0x2122);break;	//TradeMark
	case 0x9A:pMathType=mo;pmt(0x0161);break;	//s caron
	case 0x9B:pMathType=mo;pmt(0x2040);break;	//right single guillemet
	case 0x9C:pMathType=mo;pmt(0x0153);break;	//oe
	case 0x9D:pMathType=mo;pmt(0x017E);break;	//z caron
	case 0x9E:pMathType=mo;pmt(0x223C);break;	//tilde operator
	case 0x9F:pMathType=mo;pmt(0x0178);break;	//Y diaeresis

	//0xA0-0xFF go to default:mo, //Unicode4.1 Latin-1 supplement
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;

}


void fontMap8z(){//OT1+ISO Latin2, XL2
//cmr, cmsl, cmss, cmssbx, cmssbxo, cmssdc, cmssi, cmsssq, cmssqi, cmb, cmbx, cmbxsl, cmdunh, cmff, cmfib, cmfibs, cmvtt
//cmbr, cmbrbx, cmbrsl, cmsslu, cmssu	
//cmu, cmti, cmbxti, cmffi, cmbxcd, cmvtti, ccti (with pound instead of dollar)
//ccr, ccsl, ccslc
//lcmss[b]
//zplmb7t, zplmr7t
//px[r, i,b,bi,bsl,sl] +(6glyphs);
//rpx[b,bi]
//rtx[r,sl,ss,sssc,sssl,bsl,bss,bsssl] (with <, >, instead of exclam up/question down)
//tx[r,i,sl,ss,sssl,b,bi,bsl,bss,bsssl]
//pag[k,kc,ko,dc,do]7t
//pbk[d,dc,di,do,l,lcli,lo]7t
//pcr[b,bc,bo,r,rc,ro]7t
//pfr[r,ri,c,ci,l,li,b,bi,u]7t, pfr[r,ri,b,c,l,li,u]7tc
//phv[r,rc,ro,b,bc,bo]7t,phv[r,rc,ro,b,bc,bo]7tn
//pnc[b,bi,bo,r,rc,ri,ro]7t
//ppl[b,bc,bi,bo,r,rc,ri,ro]7t,zpple[r,b]7t
//ptm[,b,bc,bi,bo,r,rc,ri,ro]7t, zptmcm7t
//pzmi7t

unsigned char* temp=(unsigned char*)yytext; 
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;	//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;	//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;	//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;	//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;	//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;	//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;	//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;	//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;	//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;	//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;	//Omega
	case 0x0B:pMathType=mo;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
	case 0x0C:pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
	case 0x0D:pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
	case 0x0E:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
	case 0x0F:pMathType=mo;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

	case 0x10:pMathType=mo;pmt(0x0131);break;	//imath
	case 0x11:pMathType=mo;pmt(0x006A);break;	//jmath,pmt(0x0237);break;//jmath
	case 0x12:pMathType=mo;pmt(0x0060);break;	//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;	//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;	//german SS
	case 0x1A:pMathType=mo;pmt(0x00E6);break;	//latin ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;	//latin oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;	//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;	//latin AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;	//latin OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;	//O slash

	case 0x20:combiningUnicode=0x0374;break;	//.notdef, overlay short solidus
	case 0x21:pMathType=mo;pmt(*temp);break;	//exclamation sign
	case 0x22:pMathType=mo;pmt(0x201D);break;	//right double quotation mark
	case 0x23://number sign
	case 0x24://US dollar symbol
	case 0x25:pMathType=mo;pmt(*temp);break;//percent
	case 0x26://ampersand
		if (mathmode && !mathText){
			p("<mo>&amp;</mo>");
		}else 
			p("&amp;");
		break;
	case 0x27:pMathType=mo;pmt(0x2018);break;	//left single quot-mark
	case 0x28:pMathType=mo;pmt(*temp);break;	//(
	case 0x29:pMathType=mo;pmt(*temp);break;	//)
	case 0x2A://asterisk
	case 0x2B://plus
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;//comma
	case 0x2D://hyphen
	case 0x2E://period
	case 0x2F:pMathType=mo;pmt(*temp);break;	//slash

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;	//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;	//colon
	case 0x3B:pMathType=mo;pmt(*temp);break;	//semicolon
	case 0x3C:pMathType=mo;pmt(0x00A1);break;	//inverted exclamation mark
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E:pMathType=mo;pmt(0x00BF);break;	//inverted question mark
	case 0x3F:pMathType=mo;pmt(*temp);break;	//question mark

	case 0x40:pMathType=mo;pmt(*temp);break; //at sign
	
	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;	//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;	//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;	//]
	case 0x5E:pMathType=mo;pmt(*temp);break;	//circumflex
	case 0x5F:pMathType=mo;pmt(0x02D9);break;	//dot above

	case 0x60:pMathType=mo;pmt(0x2019);break;	//right single quot-mark
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;	//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;	//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;	//double acute accent, 0x30B combining
	case 0x7E:pMathType=mo;pmt(*temp);break;	//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;	//diaeresis

	case 0x80:pMathType=mo;pmt(0x2026);break;	//horizontal ellipsis	
	case 0x81:pMathType=mo;pmt(0x2020);break;	//dagger
	case 0x82:pMathType=mo;pmt(0x2021);break;	//ddagger
	case 0x83:pMathType=mo;pmt(0x2022);break;	//bullet
	case 0x84:pMathType=mo;pmt(0x00A3);break;	//pound sterling
	case 0x85:pMathType=mo;pmt(*temp);break;	//paragraph
	case 0x86:
	case 0x87:
	case 0x88:
	case 0x89:
	case 0x8A:
	case 0x8B:
	case 0x8C:break;	//notdef
	case 0x8D:pMathType=mo;pmt(0x2030);break; //per mille
	case 0x8E:
	case 0x8F:
	
	case 0x90:
	case 0x91:
	case 0x92:
	case 0x93:
	case 0x94:
	case 0x95:
	case 0x96:
	case 0x97:break;	//notdef
	case 0x98:pMathType=mo;pmt(0x00C0);break; //A grave
	case 0x99:
	case 0x9A:
	case 0x9B:break;	//notdef
	case 0x9C:pMathType=mo;pmt(0x002D);break; //hyphen
	case 0x9D:pMathType=mo;pmt(0x02DB);break;	//ogonek	
	case 0x9E:pMathType=mo;pmt(0x00AB);break;	//guillemet left 	
	case 0x9F:pMathType=mo;pmt(0x00BB);break;	//guillemet right 
	
	case 0xA0:break;	//notdef
	case 0xA1:pMathType=mo;pmt(0x0104);break;	//A ogonek
	case 0xA2:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0xA3:pMathType=mo;pmt(0x0141);break;	//L stroke	
	case 0xA4:pMathType=mo;pmt(*temp);break;	//currency sign
	case 0xA5:pMathType=mo;pmt(0x013D);break;	//L caron
	case 0xA6:pMathType=mo;pmt(0x015A);break;	//S acute	
	case 0xA7:	//section	
	case 0xA8:pMathType=mo;pmt(*temp);break;	//diaeresis	
	case 0xA9:pMathType=mo;pmt(0x0160);break;	//S caron	
	case 0xAA:pMathType=mo;pmt(0x015E);break;	//S cedilla	
	case 0xAB:pMathType=mo;pmt(0x0164);break;	//T caron	
	case 0xAC:pMathType=mo;pmt(0x0179);break;	//Z acute
	case 0xAD:break;	//notdef
	case 0xAE:pMathType=mo;pmt(0x017D);break;	//Z caron
	case 0xAF:pMathType=mo;pmt(0x017B);break;	//Z dot above
	
	case 0xB0:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0xB1:pMathType=mo;pmt(0x0104);break;	//a ogonek
	case 0xB2:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0xB3:pMathType=mo;pmt(0x0142);break;	//l stroke
	case 0xB4:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0xB5:pMathType=mo;pmt(0x013E);break;	//l caron
	case 0xB6:pMathType=mo;pmt(0x015B);break;	//s acute
	case 0xB7:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0xB8:pMathType=mo;pmt(0x00E0);break;	//a grave
	case 0xB9:pMathType=mo;pmt(0x0161);break;	//s caron
	case 0xBA:pMathType=mo;pmt(0x015F);break;	//s cedilla
	case 0xBB:pMathType=mo;pmt(0x0165);break;	//t caron
	case 0xBC:pMathType=mo;pmt(0x017A);break;	//z acute
	case 0xBD:pMathType=mo;pmt(0x02DD);break;	//double acute accent, 0x30B combining
	case 0xBE:pMathType=mo;pmt(0x017E);break;	//z caron
	case 0xBF:pMathType=mo;pmt(0x02DD);break;	//double acute accent, 0x30B combining
	
	case 0xC0:pMathType=mo;pmt(0x0154);break;//R acute
	case 0xC1:	//A acute
	case 0xC2:pMathType=mo;pmt(*temp);break;	//A circumflex
	case 0xC3:pMathType=mo;pmt(0x0102);break;	//A breve
	case 0xC4:pMathType=mo;pmt(*temp);break;	//A diaeresis
	case 0xC5:pMathType=mo;pmt(0x0139);break;	//L acute
	case 0xC6:pMathType=mo;pmt(0x0106);break;	//C acute
	case 0xC7:pMathType=mo;pmt(*temp);break;	//C cedilla
	case 0xC8:pMathType=mo;pmt(0x00C0);break; //A grave
	case 0xC9:pMathType=mo;pmt(0x010C);break;	//C caron
	case 0xCA:pMathType=mo;pmt(0x00C9);break;	//E acute
	case 0xCB:pMathType=mo;pmt(0x0118);break;	//E ogonek
	case 0xCC:pMathType=mo;pmt(0x00CB);break; //E diaeresis
	case 0xCD:pMathType=mo;pmt(0x011A);break;	//E caron
	case 0xCE:pMathType=mo;pmt(0x00CD);break;	//I acute
	case 0xCF:pMathType=mo;pmt(0x010E);break;	//D caron
	
	case 0xD0:pMathType=mo;pmt(*temp);break;	//Eth
	case 0xD1:pMathType=mo;pmt(0x0143);break;	//N acute
	case 0xD2:pMathType=mo;pmt(0x0147);break;	//N caron
	case 0xD3:pMathType=mo;pmt(*temp);break;	//O acute
	case 0xD4:pMathType=mo;pmt(*temp);break;	//O circumflex
	case 0xD5:pMathType=mo;pmt(0x0150);break;	//O double acute
	case 0xD6:pMathType=mo;pmt(*temp);break;	//O diaeresis
	case 0xD7:pMathType=mo;pmt(0x00D7);break;	//multiply 
	case 0xD8:pMathType=mo;pmt(0x0158);break;	//R caron
	case 0xD9:pMathType=mo;pmt(0x016E);break;	//U ring above
	case 0xDA:pMathType=mo;pmt(*temp);break;	//U acute
	case 0xDB:pMathType=mo;pmt(0x0170);break;	//U double acute
	case 0xDC: //U diaeresis
	case 0xDD:pMathType=mo;pmt(*temp);break;	//Y acute
	case 0xDE:pMathType=mi;p("T");p(ul2utf8(0x0328)); break;//T ogonek
	case 0xDF:pMathType=mo;pmt(0x010E);break;	//D caron
	
	case 0xE0:pMathType=mo;pmt(0x0155);break;	//r acute
	case 0xE1:pMathType=mo;pmt(*temp);break;	//a acute
	case 0xE2:pMathType=mo;pmt(*temp);break;	//a circumflex
	case 0xE3:pMathType=mo;pmt(0x0103);break;	//a breve
	case 0xE4:pMathType=mo;pmt(*temp);break;	//a diaeresis
	case 0xE5:pMathType=mo;pmt(0x013A);break;	//l acute
	case 0xE6:pMathType=mo;pmt(0x0107);break;	//c acute
	case 0xE7:pMathType=mo;pmt(*temp);break;	//c cedilla
	case 0xE8:pMathType=mo;pmt(0x010D);break;	//c caron
	case 0xE9:pMathType=mo;pmt(*temp);break;	//e acute
	case 0xEA:pMathType=mo;pmt(0x0119);break;	//e ogonek
	case 0xEB:pMathType=mo;pmt(*temp);break;	//e diaeresis
	case 0xEC:pMathType=mo;pmt(0x011B);break;	//e caron
	case 0xED:	//i acute
	case 0xEE:pMathType=mo;pmt(*temp);break;	//i circumflex
	case 0xEF:pMathType=mo;pmt(0x010F);break;	//d caron
	
	case 0xF0:pMathType=mo;pmt(0x00D0);break;	//eth
	case 0xF1:pMathType=mo;pmt(0x0144);break;	//n acute
	case 0xF2:pMathType=mo;pmt(0x0148);break;	//n caron
	case 0xF3://o acute
	case 0xF4:pMathType=mo;pmt(*temp);break;	//o circumflex
	case 0xF5:pMathType=mo;pmt(0x0151);break;	//o double acute
	case 0xF6:pMathType=mo;pmt(*temp);break;	//o diaeresis
	case 0xF7:pMathType=mo;pmt(*temp);break;	//divide
	case 0xF8:pMathType=mo;pmt(0x0159);break;	//r caron
	case 0xF9:pMathType=mo;pmt(0x016F);break;	//u ring above
	case 0xFA:pMathType=mo;pmt(*temp);break;	//u acute
	case 0xFB:pMathType=mo;pmt(0x0171);break;	//u double acute
	case 0xFC:	//u diaeresis
	case 0xFD:pMathType=mo;pmt(*temp);break;	//y acute
	case 0xFE:pMathType=mo;pmt(0x201E);break;	//double low quot-mark
	case 0xFF:pMathType=mo;pmt(0x201C);break;	//left double quotation mark
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}


void fontMap8u(){//OT1+ ISO Latin2, typewriter 
//cmtt, cmcsc, cmsltt, cmtcsc, cmtl, cmsltl, cccsc
//cmitt (pound for dollar)
//px[sc,bsc], rpx[bsl,bsc,i,r,sc,sl], rtx[b,bi,bsc,bsssc]
//tx[tt,ttsc,ttsl,sc,sssc,btt,bttsc,bsc,bsssc]
//pcrr7n
//cmitt 

unsigned char* temp=(unsigned char*)yytext; 

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;	//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;	//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;	//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;	//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;	//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;	//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;	//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;	//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;	//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;	//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;	//Omega
	case 0x0B:pMathType=mo;pmt(0x2191);break;	//up arrow
	case 0x0C:pMathType=mo;pmt(0x2193);break;	//down arrow
	case 0x0D:pMathType=mo;pmt(0x2032);break;	//prime
	case 0x0E:pMathType=mo;pmt(0x00A1);break;	//inverted exclamation mark
	case 0x0F:pMathType=mo;pmt(0x00BF);break;	//inverted question mark

	case 0x10:pMathType=mo;pmt(0x026A);break;	//latin i small capital
	case 0x11:pMathType=mo;pmt(0x006A);break;	//j (ascii)
	case 0x12:pMathType=mo;pmt(0x0060);break;	//grave accent
	case 0x13:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0x14:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0x15:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0x16:pMathType=mo;pmt(0x00AF);break;	//macron
	case 0x17:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0x18:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0x19:pMathType=mo;pmt(0x00DF);break;	//german SS (XXX)
	case 0x1A:pMathType=mo;pmt(0x00E6);break;	//ae
	case 0x1B:pMathType=mo;pmt(0x0153);break;	//oe
	case 0x1C:pMathType=mo;pmt(0x00F8);break;	//o slash
	case 0x1D:pMathType=mo;pmt(0x00C6);break;	//AE
	case 0x1E:pMathType=mo;pmt(0x0152);break;	//OE
	case 0x1F:pMathType=mo;pmt(0x00D8);break;	//O slash

	case 0x20:break;	//notdef
	case 0x21:pMathType=mo;pmt(*temp);break;	//exclamation mark
	case 0x22:pMathType=mo;pmt(0x201D);break;	//right double quotation mark
	case 0x23:
	case 0x24:
	case 0x25:pMathType=mo;pmt(*temp);break;
	case 0x26:
		if (mathmode && !mathText)
			p("<mo>&amp;</mo>");
		else 
			p("&amp;");
		break;//ampersand
	case 0x27:pMathType=mo;pmt(*temp);break;	//right single quot-mark
	case 0x28:pMathType=mo;pmt(*temp);break;	//left parenthesis
	case 0x29:pMathType=mo;pmt(*temp);break;	//right parenthesis
	case 0x2A:
	case 0x2B:
	case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
	case 0x2D:
	case 0x2E:
	case 0x2F:pMathType=mo;pmt(*temp);break;

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;	//numbers 0-9
	case 0x3A:pMathType=mo;pmt(*temp);break;	//colon
	case 0x3B:pMathType=mo;pmt(*temp);break;	//semicolon
		
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	{
			if (mathmode && !mathText)
				p("<mo>&lt;</mo>");
			else 
				p("&lt;");
		}
		break;
	case 0x3D: //equal
		pMathType=mo;
		precomposedNegative(*temp, 0x2260);
		break;
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else{
			if (mathmode && !mathText)
				p("<mo>&gt;</mo>");
			else 
				p("&gt;");
		}
		break;
	case 0x3F:pMathType=mo;pmt(*temp);break;	//question mark
	case 0x40:pMathType=mo;pmt(*temp);break;	//at sign

	//A to Z go to default: mo
	
	case 0x5B:pMathType=mo;pmt(*temp);break;	//[
	case 0x5C:pMathType=mo;pmt(0x201C);break;	//left double quotation mark
	case 0x5D:pMathType=mo;pmt(*temp);break;	//]
	case 0x5E:pMathType=mo;pmt(*temp);break;	//circumflex
	case 0x5F:pMathType=mo;pmt(0x02D9);break;	//dot above

	case 0x60:pMathType=mo;pmt(*temp);break;	//left single quotation mark
	
	//a to z go to default: mo
	
	case 0x7B:pMathType=mo;pmt(0x2013);break;	//en dash
	case 0x7C:pMathType=mo;pmt(0x2014);break;	//em dash
	case 0x7D:pMathType=mo;pmt(0x02DD);break;	//double acute accent
	case 0x7E:pMathType=mo;pmt(*temp);break;	//tilde
	case 0x7F:pMathType=mo;pmt(0x00A8);break;	//diaeresis

	case 0x80:pMathType=mo;pmt(0x2026);break;	//horizontal ellipsis	
	case 0x81:pMathType=mo;pmt(0x2020);break;	//dagger
	case 0x82:pMathType=mo;pmt(0x2021);break;	//ddagger
	case 0x83:pMathType=mo;pmt(0x2022);break;	//bullet
	case 0x84:pMathType=mo;pmt(0x00A3);break;	//pound sterling
	case 0x85:pMathType=mo;pmt(*temp);break;	//paragraph
	case 0x86:
	case 0x87:
	case 0x88:
	case 0x89:
	case 0x8A:
	case 0x8B:
	case 0x8C:break;	//notdef
	case 0x8D:pMathType=mo;pmt(0x2030);break; //per mille
	case 0x8E:
	case 0x8F:
	
	case 0x90:
	case 0x91:
	case 0x92:
	case 0x93:
	case 0x94:
	case 0x95:
	case 0x96:
	case 0x97:break;	//notdef
	case 0x98:pMathType=mo;pmt(0x00C0);break; //A grave
	case 0x99:
	case 0x9A:
	case 0x9B:break;	//notdef
	case 0x9C:pMathType=mo;pmt(0x002D);break; //hyphen
	case 0x9D:pMathType=mo;pmt(0x02DB);break;	//ogonek	
	case 0x9E:pMathType=mo;pmt(0x00AB);break;	//guillemet left 	
	case 0x9F:pMathType=mo;pmt(0x00BB);break;	//guillemet right 
	
	case 0xA0:break;	//notdef
	case 0xA1:pMathType=mo;pmt(0x0104);break;	//A ogonek
	case 0xA2:pMathType=mo;pmt(0x02D8);break;	//breve
	case 0xA3:pMathType=mo;pmt(0x0141);break;	//L stroke	
	case 0xA4:pMathType=mo;pmt(*temp);break;	//currency sign
	case 0xA5:pMathType=mo;pmt(0x013D);break;	//L caron
	case 0xA6:pMathType=mo;pmt(0x015A);break;	//S acute	
	case 0xA7:	//section	
	case 0xA8:pMathType=mo;pmt(*temp);break;	//diaeresis	
	case 0xA9:pMathType=mo;pmt(0x0160);break;	//S caron	
	case 0xAA:pMathType=mo;pmt(0x015E);break;	//S cedilla	
	case 0xAB:pMathType=mo;pmt(0x0164);break;	//T caron	
	case 0xAC:pMathType=mo;pmt(0x0179);break;	//Z acute
	case 0xAD:break;	//notdef
	case 0xAE:pMathType=mo;pmt(0x017D);break;	//Z caron
	case 0xAF:pMathType=mo;pmt(0x017B);break;	//Z dot above
	
	case 0xB0:pMathType=mo;pmt(0x02DA);break;	//ring above
	case 0xB1:pMathType=mo;pmt(0x0104);break;	//a ogonek
	case 0xB2:pMathType=mo;pmt(0x00B8);break;	//cedilla
	case 0xB3:pMathType=mo;pmt(0x0142);break;	//l stroke
	case 0xB4:pMathType=mo;pmt(0x00B4);break;	//acute accent
	case 0xB5:pMathType=mo;pmt(0x013E);break;	//l caron
	case 0xB6:pMathType=mo;pmt(0x015B);break;	//s acute
	case 0xB7:pMathType=mo;pmt(0x02C7);break;	//caron, hacek
	case 0xB8:pMathType=mo;pmt(0x00E0);break;	//a grave
	case 0xB9:pMathType=mo;pmt(0x0161);break;	//s caron
	case 0xBA:pMathType=mo;pmt(0x015F);break;	//s cedilla
	case 0xBB:pMathType=mo;pmt(0x0165);break;	//t caron
	case 0xBC:pMathType=mo;pmt(0x017A);break;	//z acute
	case 0xBD:pMathType=mo;pmt(0x02DD);break;	//double acute accent, 0x30B combining
	case 0xBE:pMathType=mo;pmt(0x017E);break;	//z caron
	case 0xBF:pMathType=mo;pmt(0x02DD);break;	//double acute accent, 0x30B combining
	
	case 0xC0:pMathType=mo;pmt(0x0154);break;//R acute
	case 0xC1:	//A acute
	case 0xC2:pMathType=mo;pmt(*temp);break;	//A circumflex
	case 0xC3:pMathType=mo;pmt(0x0102);break;	//A breve
	case 0xC4:pMathType=mo;pmt(*temp);break;	//A diaeresis
	case 0xC5:pMathType=mo;pmt(0x0139);break;	//L acute
	case 0xC6:pMathType=mo;pmt(0x0106);break;	//C acute
	case 0xC7:pMathType=mo;pmt(*temp);break;	//C cedilla
	case 0xC8:pMathType=mo;pmt(0x00C0);break; //A grave
	case 0xC9:pMathType=mo;pmt(0x010C);break;	//C caron
	case 0xCA:pMathType=mo;pmt(0x00C9);break;	//E acute
	case 0xCB:pMathType=mo;pmt(0x0118);break;	//E ogonek
	case 0xCC:pMathType=mo;pmt(0x00CB);break; //E diaeresis
	case 0xCD:pMathType=mo;pmt(0x011A);break;	//E caron
	case 0xCE:pMathType=mo;pmt(0x00CD);break;	//I acute
	case 0xCF:pMathType=mo;pmt(0x010E);break;	//D caron
	
	case 0xD0:pMathType=mo;pmt(*temp);break;	//Eth
	case 0xD1:pMathType=mo;pmt(0x0143);break;	//N acute
	case 0xD2:pMathType=mo;pmt(0x0147);break;	//N caron
	case 0xD3:pMathType=mo;pmt(*temp);break;	//O acute
	case 0xD4:pMathType=mo;pmt(*temp);break;	//O circumflex
	case 0xD5:pMathType=mo;pmt(0x0150);break;	//O double acute
	case 0xD6:pMathType=mo;pmt(*temp);break;	//O diaeresis
	case 0xD7:pMathType=mo;pmt(0x00D7);break;	//multiply 
	case 0xD8:pMathType=mo;pmt(0x0158);break;	//R caron
	case 0xD9:pMathType=mo;pmt(0x016E);break;	//U ring above
	case 0xDA:pMathType=mo;pmt(*temp);break;	//U acute
	case 0xDB:pMathType=mo;pmt(0x0170);break;	//U double acute
	case 0xDC: //U diaeresis
	case 0xDD:pMathType=mo;pmt(*temp);break;	//Y acute
	case 0xDE:pMathType=mi;p("T");p(ul2utf8(0x0328)); break;//T ogonek
	case 0xDF:pMathType=mo;pmt(0x010E);break;	//D caron
	
	case 0xE0:pMathType=mo;pmt(0x0155);break;	//r acute
	case 0xE1:pMathType=mo;pmt(*temp);break;	//a acute
	case 0xE2:pMathType=mo;pmt(*temp);break;	//a circumflex
	case 0xE3:pMathType=mo;pmt(0x0103);break;	//a breve
	case 0xE4:pMathType=mo;pmt(*temp);break;	//a diaeresis
	case 0xE5:pMathType=mo;pmt(0x013A);break;	//l acute
	case 0xE6:pMathType=mo;pmt(0x0107);break;	//c acute
	case 0xE7:pMathType=mo;pmt(*temp);break;	//c cedilla
	case 0xE8:pMathType=mo;pmt(0x010D);break;	//c caron
	case 0xE9:pMathType=mo;pmt(*temp);break;	//e acute
	case 0xEA:pMathType=mo;pmt(0x0119);break;	//e ogonek
	case 0xEB:pMathType=mo;pmt(*temp);break;	//e diaeresis
	case 0xEC:pMathType=mo;pmt(0x011B);break;	//e caron
	case 0xED:	//i acute
	case 0xEE:pMathType=mo;pmt(*temp);break;	//i circumflex
	case 0xEF:pMathType=mo;pmt(0x010F);break;	//d caron
	
	case 0xF0:pMathType=mo;pmt(0x00D0);break;	//eth
	case 0xF1:pMathType=mo;pmt(0x0144);break;//n acute
	case 0xF2:pMathType=mo;pmt(0x0148);break;//n caron
	case 0xF3://o acute
	case 0xF4:pMathType=mo;pmt(*temp);break;	//o circumflex
	case 0xF5:pMathType=mo;pmt(0x0151);break;	//o double acute
	case 0xF6:pMathType=mo;pmt(*temp);break;	//o diaeresis
	case 0xF7:pMathType=mo;pmt(*temp);break;	//divide
	case 0xF8:pMathType=mo;pmt(0x0159);break;	//r caron
	case 0xF9:pMathType=mo;pmt(0x016F);break;	//u ring above
	case 0xFA:pMathType=mo;pmt(*temp);break;	//u acute
	case 0xFB:pMathType=mo;pmt(0x0171);break;	//u double acute
	case 0xFC:	//u diaeresis
	case 0xFD:pMathType=mo;pmt(*temp);break;	//y acute
	case 0xFE:pMathType=mo;pmt(0x201E);break;	//double low quot-mark
	case 0xFF:pMathType=mo;pmt(0x201C);break;//left double quotation mark
	
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMapMathExt(){
//cmex, px[b]ex, xccex, zeuex, tx[b]ex
	
unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0028);break;	//left parenthesis
	case 0x01:pMathType=mo;pmt(0x0029);break;	//right parenthesis
	case 0x02:pMathType=mo;pmt(0x005B);break;	//left bracket
	case 0x03:pMathType=mo;pmt(0x005D);break;	//right bracket
	case 0x04:pMathType=mo;pmt(0x230A);break;	//left floor
	case 0x05:pMathType=mo;pmt(0x230B);break;	//right floor
	case 0x06:pMathType=mo;pmt(0x2308);break;	//left ceil
	case 0x07:pMathType=mo;pmt(0x2309);break;	//right ceil
	case 0x08:pMathType=mo;pmt(0x007b);break;	//left brace
	case 0x09:pMathType=mo;pmt(0x007d);break;	//right brace
	case 0x0A:pMathType=mo;pmt(0x2329);break;	//left angle
	case 0x0B:pMathType=mo;pmt(0x232A);break;	//right angle
	case 0x0C:pMathType=mo;pmt(0x007C);blockthis=0x007c;break;//vertical line
	case 0x0D:pMathType=mo;pmt(0x2016);blockthis=0x2016;break;//double vertical line
	case 0x0E:pMathType=mo;pmt(0x007C);break;	//division
	case 0x0F:pMathType=mo;pmt(0x2216);break;	//set minus

	case 0x10:pMathType=mo;pmt(0x0028);break;	//left parenthesis
	case 0x11:pMathType=mo;pmt(0x0029);break;	//right parenthesis
	case 0x12:pMathType=mo;pmt(0x0028);break;	//left parenthesis
	case 0x13:pMathType=mo;pmt(0x0029);break;	//right parenthesis
	case 0x14:pMathType=mo;pmt(0x005B);break;	//left bracket
	case 0x15:pMathType=mo;pmt(0x005D);break;	//right bracket
	case 0x16:pMathType=mo;pmt(0x230A);break;	//left floor
	case 0x17:pMathType=mo;pmt(0x230B);break;	//right floor
	case 0x18:pMathType=mo;pmt(0x2308);break;	//left ceil
	case 0x19:pMathType=mo;pmt(0x2309);break;	//right ceil
	case 0x1A:pMathType=mo;pmt(0x007B);break;	//left brace
	case 0x1B:pMathType=mo;pmt(0x007D);break;	//right brace
	case 0x1C:pMathType=mo;pmt(0x2329);break;	//left angle
	case 0x1D:pMathType=mo;pmt(0x232A);break;	//right angle
	case 0x1E:pMathType=mo;pmt(0x007C);break;	//division
	case 0x1F:pMathType=mo;pmt(0x2216);break;	//set minus

	case 0x20:pMathType=mo;pmt(0x0028);break;	//left parenthesis
	case 0x21:pMathType=mo;pmt(0x0029);break;	//right parenthesis
	case 0x22:pMathType=mo;pmt(0x005B);break;	//left bracket
	case 0x23:pMathType=mo;pmt(0x005D);break;	//right bracket
	case 0x24:pMathType=mo;pmt(0x230A);break;	//left floor
	case 0x25:pMathType=mo;pmt(0x230B);break;	//right floor
	case 0x26:pMathType=mo;pmt(0x2308);break;	//left ceil
	case 0x27:pMathType=mo;pmt(0x2309);break;	//right ceil
	case 0x28:pMathType=mo;pmt(0x007B);break;	//left curly bracket
	case 0x29:pMathType=mo;pmt(0x007D);break;	//right curly bracket
	case 0x2A:pMathType=mo;pmt(0x2329);break;	//left angle bracket
	case 0x2B:pMathType=mo;pmt(0x232A);break;	//right angle bracket
	case 0x2C:pMathType=mo;pmt(0x007C);break;	//division
	case 0x2D:pMathType=mo;pmt(0x2216);break;	//set minus
	case 0x2E:pMathType=mo;pmt(0x2215);break;	//division
	case 0x2F:pMathType=mo;pmt(0x2216);break;	//set minus

	case 0x30:pMathType=mo;pmt(0x0028);break;//pMathType=ld_b;pmt(0x239B);break;//left parenthesis top
	case 0x31:pMathType=mo;pmt(0x0029);break;//pMathType=rd_b;pmt(0x239E);break;//right parenthesis top
	case 0x32:pMathType=mo;pmt(0x005B);break;//pMathType=ld_b;pmt(0x23A1);break;//left bracket upper corner
	case 0x33:pMathType=mo;pmt(0x005D);break;//pMathType=rd_b;pmt(0x23A4);break;//right bracket upper corner
	case 0x34:break;//pMathType=ld_e;pmt(0x23A3);break;//left bracket lower corner
	case 0x35:break;//pMathType=rd_e;pmt(0x23A6);break;//right bracket lower corner
	case 0x36:break;//pMathType=ld_x;pmt(0x23A2);break;//left bracket extension
	case 0x37:break;//pMathType=rd_x;pmt(0x23A5);break;//right bracket extension
	case 0x38:pMathType=mo;pmt(0x007B);break;//pMathType=ld_b;pmt(0x23A7);break;//left curly bracket top
	case 0x39:pMathType=mo;pmt(0x007D);break;//pMathType=rd_b;pmt(0x23AB);break;//right curly bracket top
	case 0x3A:break;//pMathType=ld_e;pmt(0x23A9);break;//left curly bracket bottom
	case 0x3B:break;//pMathType=rd_e;pmt(0x23AD);break;//right curly bracket bottom
	case 0x3C:break;//pMathType=ld_x;pmt(0x23A8);break;//left curly bracket middle piece
	case 0x3D:break;//pMathType=rd_x;pmt(0x23AC);break;//right curly bracket middle piece
	case 0x3E:break;//pMathType=ld_x;pmt(0x23AA);break;//curly bracket extension
	case 0x3F:break;//pMathType=mo;pmt(0x23D0);break;//vertical arrow extension

	case 0x40:break;//pMathType=ld_e;pmt(0x239D);break;//left parenthesis bottom
	case 0x41:break;//pMathType=rd_e;pmt(0x23A0);break;//right parenthesis bottom
	case 0x42:break;//pMathType=ld_x;pmt(0x239C);break;//left parenthesis extension
	case 0x43:break;//pMathType=rd_x;pmt(0x239F);break;//right parenthesis extension
	case 0x44:pMathType=mo;pmt(0x2329);break;	//left angle bracket
	case 0x45:pMathType=mo;pmt(0x232A);break;	//right angle bracket
	case 0x46:pMathType=mo;pmt(0x2294);break;	//square cup
	case 0x47:pMathType=mo;pmt(0x2294);break;	//square cup
	case 0x48:pMathType=mo;pmt(0x222E);break;	//textstyle contour integral
	case 0x49:pMathType=mo;pmt(0x222E);break;	//displaystyle contour integral
	case 0x4A:pMathType=mo;pmt(0x2299);break;	//circled dot operator
	case 0x4B:pMathType=mo;pmt(0x2A00);break;	//n-ary circled dot operator
	case 0x4C:pMathType=mo;pmt(0x2295);break;	//circled plus
	case 0x4D:pMathType=mo;pmt(0x2295);break;	//circled plus//pmt(0x2A01);break;//n-ary circled plus, XXX not yet available in fonts
	case 0x4E:pMathType=mo;pmt(0x2297);break;	//circled times
	case 0x4F:pMathType=mo;pmt(0x2297);break;	//circled times//pmt(0x2A02);break;//n-ary circled times, XXX not yet available in fonts

	case 0x50:pMathType=mo;pmt(0x2211);break;	//n-ary summation
	case 0x51:pMathType=mo;pmt(0x220F);break;	//n-ary product
	case 0x52:pMathType=mo;pmt(0x222B);break;	//integral sign
	case 0x53:pMathType=mo;pmt(0x222A);break;	//cup
	case 0x54:pMathType=mo;pmt(0x2229);break;	//cap
	case 0x55:pMathType=mo;pmt(0x228E);break;	//multiset union
	case 0x56:pMathType=mo;pmt(0x2227);break;	//logical and
	case 0x57:pMathType=mo;pmt(0x2228);break;	//logical or
	case 0x58:pMathType=mo;pmt(0x2211);break;	//n-ary sigma
	case 0x59:pMathType=mo;pmt(0x220F);break;	//n-ary product
	case 0x5A:pMathType=mo;pmt(0x222B);break;	//integral sign
	case 0x5B:pMathType=mo;pmt(0x22C3);break;	//n-ary cap
	case 0x5C:pMathType=mo;pmt(0x22C2);break;	//n-ary cup
	case 0x5D:pMathType=mo;pmt(0x2A04);break;	//n-ary multiset union
	case 0x5E:pMathType=mo;pmt(0x22C0);break;	//n-ary logical and
	case 0x5F:pMathType=mo;pmt(0x22C1);break;	//n-ary logical or

	case 0x60:pMathType=mo;pmt(0x220F);break;	//n-ary coproduct
	case 0x61:pMathType=mo;pmt(0x220F);break;	//n-ary coproduct
	case 0x62:pMathType=mo;pmt(0x005E);break;	//hat
	case 0x63:pMathType=mo;pmt(0x005E);break;	//hat
	case 0x64:pMathType=mo;pmt(0x005E);break;	//hat
	case 0x65:pMathType=mo;pmt(0x007E);break;	//tilde
	case 0x66:pMathType=mo;pmt(0x22CF);break;	//tilde
	case 0x67:pMathType=mo;pmt(0x22CE);break;	//tilde
	case 0x68:pMathType=mo;pmt(0x005B);break;	//left bracket
	case 0x69:pMathType=mo;pmt(0x005D);break;	//right bracket
	case 0x6A:pMathType=mo;pmt(0x230A);break;	//left floor
	case 0x6B:pMathType=mo;pmt(0x230B);break;	//right floor
	case 0x6C:pMathType=mo;pmt(0x2308);break;	//left ceil
	case 0x6D:pMathType=mo;pmt(0x2309);break;	//right ceil
	case 0x6E:pMathType=mo;pmt(0x007B);break;	//left curly bracket
	case 0x6F:pMathType=mo;pmt(0x007D);break;	//right curly bracket

	case 0x70:pMathType=mo;pmt(0x221A);break;	//radical sign
	case 0x71:pMathType=mo;pmt(0x221A);break;	//radical sign
	case 0x72:pMathType=mo;pmt(0x221A);break;	//radical sign
	case 0x73:pMathType=mo;pmt(0x221A);break;	//radical sign
	case 0x74:pMathType=mo;pmt(0x221A);break;	//radical sign extensible XXX
	case 0x75:break;	//radical sign extension	XXX
	case 0x76:break;	//radical sign top	XXX
	case 0x77:break;	//double vertical line extension  XXX
	case 0x78:break;	//tip vertical arrow upwards	XXXXX
	case 0x79:break;	//tip vertical arrow downwards	XXXXXX
	case 0x7A:break;	//horizontal curly bracket tip down-left,	handled in grammar at overbrace
	case 0x7B:break;	//horizontal curly bracket tip down-right,	same here
	case 0x7C:break;	//horizontal curly bracket tip up-left, handled in grammar at underbrace
	case 0x7D:break;	//horizontal curly bracket tip up-right,	same here
	case 0x7E:break;	//tip vertical double arrow upwards		XXX
	case 0x7F:break;	//tip vertical double arrow downwards XXX

	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp) ;
return;
}

void fontMapMathExtA(){
//pxexa, txexa"
	unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:
	case 0x01:
	case 0x02:
	case 0x03:
	case 0x04:
	case 0x05:pMathType=mo;pmt(0x2639);break;	//XXX not found in Unicode 4.1,
	case 0x06:	
	case 0x07:pMathType=mo;pmt(0x2293);break;	//square cap
	case 0x08:
	case 0x09:pMathType=mo;pmt(0x222F);break;	//surface integral
	case 0x0A:
	case 0x0B:pMathType=mo;pmt(0x2233);break;	//anti-clockwise contour integral
	case 0x0C:
	case 0x0D:pMathType=mo;pmt(0x2232);break;	//clockwise contour integral
	case 0x0E:
	case 0x0F:pMathType=mo;pmt(0x2A16);break;	//quaternion integral operator

	case 0x10:
	case 0x11:pMathType=mo;pmt(0x00D7);break;	//multiplication sign
	case 0x12:pMathType=mo;pmt(0x27E6);break;	//math left white square bracket
	case 0x13:pMathType=mo;pmt(0x27E7);break;	//math right white square bracket
	case 0x14:pMathType=mo;pmt(0x27E6);break;	//math left white square bracket
	case 0x15:pMathType=mo;pmt(0x27E7);break;	//math right white square bracket
	case 0x16:pMathType=mo;pmt(0x27E6);break;	//math left white square bracket
	case 0x17:pMathType=mo;pmt(0x27E7);break;	//math right white square bracket
	case 0x18:pMathType=mo;pmt(0x27E6);break;	//math left white square bracket
	case 0x19:pMathType=mo;pmt(0x27E7);break;	//math right white square bracket
	case 0x1A:pMathType=mo;pmt(0x27E6);break;	//math left white square bracket
	case 0x1B:pMathType=mo;pmt(0x27E7);break;	//math right white square bracket
	case 0x1C:break;//ignore, left bracket bottom
	case 0x1D:break;//ignore, right bracket bottom
	case 0x1E:break;//ignore, left bracket extension
	case 0x1F:break;//ignore, right bracket extension

	case 0x20:break;//should be horizontal brace extension
	case 0x21:
	case 0x22:pMathType=mo;pmt(0x222C);break;	//double integral
	case 0x23:
	case 0x24:pMathType=mo;pmt(0x222D);break;	//triple integral
	case 0x25:
	case 0x26:pMathType=mo;pmt(0x2A0C);break;	//quad integral
	case 0x27:
	case 0x28:p("<mo>");p(ul2utf8(0x222B));p(ul2utf8(0x2026));p(ul2utf8(0x222B));p("</mo>");break;//integral dots integral
	case 0x29:
	case 0x2A:pMathType=mo;pmt(0x2230);break;	//volume integral
	case 0x2B:
	case 0x2C:pMathType=mo;pmt(0x2233);break;	//anti-clockwise contour integral
	case 0x2D:
	case 0x2E:pMathType=mo;pmt(0x2232);break;	//clockwise contour integral
	case 0x2F:break;//nothing here

	case 0x30:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x31:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x32:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x33:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x34:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x35:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x36:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x37:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x38:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x39:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x3A:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x3B:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x3C:pMathType=mo;pmt(0x27C5);break;	//left s-bag
	case 0x3D:pMathType=mo;pmt(0x27C6);break;	//right s-bag
	case 0x3E:
	case 0x3F:pMathType=mo;pmt(0x2A0F);break;	//integral avergae with slash

	case 0x40://XXX should be anti-clockwise
	case 0x41://XXX should be anti-clockwise
	case 0x42://XXX should be clockwise
	case 0x43:pMathType=mo;pmt(0x222F);break;	//surface integral, XXX should be clockwise
	case 0x44:
	case 0x45:
	case 0x46:
	case 0x47:pMathType=mo;pmt(0x2230);break;	//volume integral, XXX should be oriented
	case 0x48:
	case 0x49:
	case 0x4A:
	case 0x4B:pMathType=mo;pmt(0x222F);break;	//surface integral, XXX should be variations of 0x40-0x43
	case 0x4C:
	case 0x4D:
	case 0x4E:
	case 0x4F:pMathType=mo;pmt(0x2230);break;	//volume integral, XXX should be variations of 0x44-0x47

	case 0x50:
	case 0x51:
	case 0x52:
	case 0x53:pMathType=mo;pmt(0x222F);break;	//surface integral, XXX should be quaternion and oriented
	case 0x54:
	case 0x55:
	case 0x56:
	case 0x57:
	case 0x58:
	case 0x59:
	case 0x5A:
	case 0x5B:
	case 0x5C:
	case 0x5D:
	case 0x5E:
	case 0x5F:break;
	
	//nothing else in the TeX pxexa font;
	}
	temp++;
}while(*temp) ;
return;
}

void fontMapMathSymbol(){
//cmsy, cmbrsy, xccsy
//zeusm, zeusb (+11 glyphs);
//euxm (+-)
//zplmb7y, zplmr7y
//px[b]sy
//tx[b]sy
int staticStyle;

unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x2212);break;	//minus
	case 0x01:pMathType=mo;pmt(0x22C5);break;	//dot operator
	case 0x02:pMathType=mo;pmt(0x00D7);break;	//times
	case 0x03:pMathType=mo;pmt(0x002a);break;	//asterisk
	case 0x04:pMathType=mo;pmt(0x00F7);break;	//div
	case 0x05:pMathType=mo;pmt(0x22C4);break;	//diamond
	case 0x06:pMathType=mo;pmt(0x00B1);break;	//plus-minus
	case 0x07:pMathType=mo;pmt(0x2213);break;	//minus-plus
	case 0x08:pMathType=mo;pmt(0x2295);break;	//oplus
	case 0x09:pMathType=mo;pmt(0x2296);break;	//ominus
	case 0x0A:pMathType=mo;pmt(0x2297);break;	//otimes
	case 0x0B:pMathType=mo;pmt(0x2298);break;	//odivision
	case 0x0C:pMathType=mo;pmt(0x2299);break;	//odot
	case 0x0D:pMathType=mo;
	if (combiningUnicode=='c')	pmt(0x01); //dirty trick to recover the copyright symbol
	else	pmt(0x25EF);
		break;//bigcirc
	case 0x0E:pMathType=mo;pmt(0x2218);break;	//empty ring
	case 0x0F:pMathType=mo;pmt(0x2219);break;	//filled ring

	case 0x10:pMathType=mo;pmt(0x224D);break;	//equivalent to
	case 0x11:pMathType=mo;//\equiv, identical to
		precomposedNegative(0x2261,0x2262);
		break;
	break;
	case 0x12:pMathType=mo; //subset equal
		precomposedNegative(0x2286,0x2288);
		break;
	case 0x13:pMathType=mo; //superset equal
		precomposedNegative(0x2287,0x2289);
		break;
	case 0x14:pMathType=mo;		//less equal
		precomposedNegative(0x2264,0x2270);
		break;
	case 0x15:pMathType=mo;		//greater equal
		precomposedNegative(0x2265,0x2271);
		break;
	case 0x16:pMathType=mo;	//precedes equal
		precomposedNegative(0x227C,0x22E0);
		break;
	case 0x17:pMathType=mo;	//succeedes equal
		precomposedNegative(0x227D,0x22E1);
		break;
	case 0x18:pMathType=mo;//similar
		precomposedNegative(0x223C,0x2241);
		break;
	case 0x19:pMathType=mo;	//almost equal
		precomposedNegative(0x2248,0x2249);
		break;
	case 0x1A:pMathType=mo; //subset
		precomposedNegative(0x2282,0x2284);
		break;
	case 0x1B:pMathType=mo; //superset
		precomposedNegative(0x2283,0x2285);
		break;
	case 0x1C:pMathType=mo;pmt(0x226A);break;	//much less
	case 0x1D:pMathType=mo;pmt(0x226B);break;	//much greater
	case 0x1E:pMathType=mo;							//precedes
		precomposedNegative(0x227A,0x2280);
		break;
	case 0x1F:pMathType=mo;							//succeedes
		precomposedNegative(0x227B,0x2281);
		break;
	case 0x20:pMathType=mo;pmt(0x2190);break;	//leftarrow
	case 0x21:pMathType=mo;pmt(0x2192);break;	//rightarrow
	case 0x22:pMathType=mo;pmt(0x2191);break;	//uparrow
	case 0x23:pMathType=mo;pmt(0x2193);break;	//downarrow
	case 0x24:pMathType=mo;pmt(0x2194);break;	//leftrightarrow
	case 0x25:pMathType=mo;pmt(0x2197);break;	//nearrow
	case 0x26:pMathType=mo;pmt(0x2198);break;	//searrow
	case 0x27:pMathType=mo;	//asympequal
		precomposedNegative(0x2243, 0x2244);
		break;			
	case 0x28:pMathType=mo;pmt(0x21D0);break;	//left double arrow
	case 0x29:pMathType=mo;pmt(0x21D2);break;	//right double arrow
	case 0x2A:pMathType=mo;pmt(0x21D1);break;	//up double arrow
	case 0x2B:pMathType=mo;pmt(0x21D3);break;	//down double arrow
	case 0x2C:pMathType=mo;pmt(0x21D4);break;	//leftright double arrow
	case 0x2D:pMathType=mo;pmt(0x2196);break;	//nwarrow
	case 0x2E:pMathType=mo;pmt(0x2199);break;	//swarrow
	case 0x2F:pMathType=mo;pmt(0x221D);break;	//propto

	case 0x30:pMathType=mo;pmt(0x2032);break;	//prime
	case 0x31:pMathType=mo;pmt(0x221E);break;	//infinity
	case 0x32:pMathType=mo;//belongs
		precomposedNegative(0x2208,0x2209);
	break;
	case 0x33:pMathType=mo;pmt(0x220B);break;	//contains
	case 0x34:pMathType=mo;pmt(0x25B3);break;	//up triangle
	case 0x35:pMathType=mo;pmt(0x25BD);break;	//down triangle
	case 0x36:combiningUnicode=0x0338;break;	//combining slash
	case 0x37:pMathType=mo;pmt(0x22A6);break;	//assertion
	case 0x38:pMathType=mo;pmt(0x2200);break;	//forall
	case 0x39:pMathType=mo;pmt(0x2203);break;	//exists
	case 0x3A:pMathType=mo;pmt(0x00AC);break;	//not
	case 0x3B:pMathType=mo;pmt(0x2205);break;	//emptyset
	case 0x3C:pMathType=mo;pmt(0x211C);break;	//real part
	case 0x3D:pMathType=mo;pmt(0x2111);break;	//image part
	case 0x3E:pMathType=mo;pmt(0x22A4);break;	//down tack
	case 0x3F:pMathType=mo;pmt(0x22A5);break;	//up tack

	case 0x40:pMathType=mo;pmt(0x2135);break;//aleph
	case 0x41:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mib;pmt(0x1D49C);break;//A script
	case 0x42:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x212C);theFont.family=staticStyle;break;//B script
	case 0x43:	//pMathType=mib;pmt(0x1D49E);break;//C script
	case 0x44:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mib;pmt(0x1D49F);break;//D script
	case 0x45:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x2130);theFont.family=staticStyle;break;//E script
	case 0x46:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x2131);theFont.family=staticStyle;break;//F script
	case 0x47:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mib;pmt(0x1D4A2);break;//G script
	case 0x48:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x210B);theFont.family=staticStyle;break;//H script
	case 0x49:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x2110);theFont.family=staticStyle;break;//I script
	case 0x4A:	//pMathType=mib;pmt(0x1D4A5);break;//J script
	case 0x4B:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mib;pmt(0x1D4A6);break;//K script
	case 0x4C:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x2112);theFont.family=staticStyle;break;//L script
	case 0x4D:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x2133);theFont.family=staticStyle;break;//M script
	case 0x4E:	//pMathType=mib;pmt(0x1D4A9);break;//N script
	case 0x4F:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mib;pmt(0x1D4AA);break;//O script

	case 0x50:	//pMathType=mi;pmt(0x1D4AB);break;//P script
	case 0x51:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mi;pmt(0x1D4AC);break;//Q script
	case 0x52:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(0x211B);theFont.family=staticStyle;break;//R script
	case 0x53:	//pMathType=mi;pmt(0x1D4AE);break;//S script
	case 0x54:	//pMathType=mi;pmt(0x1D4AF);break;//T script
	case 0x55:	//pMathType=mi;pmt(0x1D4B0);break;//U script
	case 0x56:	//pMathType=mi;pmt(0x1D4B1);break;//V script
	case 0x57:	//pMathType=mi;pmt(0x1D4B2);break;//W script
	case 0x58:	//pMathType=mi;pmt(0x1D4B3);break;//X script
	case 0x59:	//pMathType=mi;pmt(0x1D4B4);break;//Y script
	case 0x5A:pMathType=mi;staticStyle=theFont.family;theFont.family=cursive;pmt(*temp);theFont.family=staticStyle;break;//pMathType=mi;pmt(0x1D4B5);break;//Z script
	case 0x5B:pMathType=mo;pmt(0x222A);break;	//cup
	case 0x5C:pMathType=mo;pmt(0x2229);break;	//cap
	case 0x5D:pMathType=mo;pmt(0x228E);break;	//multiset union
	case 0x5E:pMathType=mo;pmt(0x2227);break;	//logical and, wedge
	case 0x5F:pMathType=mo;pmt(0x2228);break;	//logical or, vee

	case 0x60:pMathType=mo; //right tack
		precomposedNegative(0x22A2,0x22AC);
		break;
	case 0x61:pMathType=mo;pmt(0x22A3);break;	//left tack
	case 0x62:pMathType=mo;pmt(0x230A);break;	//left floor
	case 0x63:pMathType=mo;pmt(0x230B);break;	//right floor
	case 0x64:pMathType=mo;pmt(0x2308);break;	//left ceiling
	case 0x65:pMathType=mo;pmt(0x2309);break;	//right ceiling
	case 0x66:pMathType=mo;pmt(0x007B);break;	//left brace
	case 0x67:pMathType=mo;pmt(0x007D);break;	//right brace
	case 0x68:pMathType=mo;pmt(0x2329);break;	//left angle bracket
	case 0x69:pMathType=mo;pmt(0x232A);break;	//right angle bracket
	case 0x6A:pMathType=mo;pmt(0x007C);break;	//divides, vert
	case 0x6B:pMathType=mo;pmt(0x2225);break;	//parallel
	case 0x6C:pMathType=mo;pmt(0x2195);break;	//up down arrow
	case 0x6D:pMathType=mo;pmt(0x21D5);break;	//up down double arrow
	case 0x6E:pMathType=mo;pmt(0x005C);break;	//backslash
	case 0x6F:pMathType=mo;pmt(0x2240);break;	//wreath product

	case 0x70:pMathType=mo;pmt(0x2713);break;	//square root
	case 0x71:pMathType=mo;pmt(0x2210);break;	//binary product
	case 0x72:pMathType=mo;pmt(0x2207);break;	//nabla
	case 0x73:pMathType=mo;pmt(0x2228);break;	//integral
	case 0x74:pMathType=mo;pmt(0x2294);break;	//square cup
	case 0x75:pMathType=mo;pmt(0x2293);break;	//square cap
	case 0x76:pMathType=mo;	//square image equal
		precomposedNegative(0x2291,0x22E2);
		break;
	case 0x77:pMathType=mo;	//square original equal
		precomposedNegative(0x2292,0x22E3);
		break;
	case 0x78:pMathType=mo;pmt(0x00A7);break;	//section
	case 0x79:pMathType=mo;pmt(0x2020);break;	//dagger
	case 0x7A:pMathType=mo;pmt(0x2021);break;	//ddagger
	case 0x7B:pMathType=mo;pmt(0x0086);break;	//paragraph
	case 0x7C:pMathType=mo;pmt(0x2663);break;	//black club suit
	case 0x7D:pMathType=mo;pmt(0x2662);break;	//white diamond suit
	case 0x7E:pMathType=mo;pmt(0x2661);break;	//white heart suit
	case 0x7F:pMathType=mo;pmt(0x2660);break;	//black spade suit
	}
	temp++;
}while(*temp) ;
return;
}


void fontMapMathItalic(){
//cmmi[b], cmbrmb, cmbrmi
//xccmi, ccmi
//zeurm, zeurb (+/zplmb7m3 glyphs);
//px[mi,mi1, bmi,bmi1]
//zplmb7m, zplmr7m
//rpx[bmi,mi],rtx[mi, bmi]
//tx[b]mi[1]

int staticFontFamily=theFont.family;
int staticFontStyle=theFont.style;
unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:pMathType=mi;theFont.style=italic;pmt(0x0393);theFont.style=staticFontStyle;break;	//Gamma
	case 0x01:pMathType=mi;theFont.style=italic;pmt(0x0394);theFont.style=staticFontStyle;break;	//Delta
	case 0x02:pMathType=mi;theFont.style=italic;pmt(0x0398);theFont.style=staticFontStyle;break;	//Theta
	case 0x03:pMathType=mi;theFont.style=italic;pmt(0x039B);theFont.style=staticFontStyle;break;	//Lambda
	case 0x04:pMathType=mi;theFont.style=italic;pmt(0x039E);theFont.style=staticFontStyle;break;	//Xi
	case 0x05:pMathType=mi;theFont.style=italic;pmt(0x03A0);theFont.style=staticFontStyle;break;	//Pi
	case 0x06:pMathType=mi;theFont.style=italic;pmt(0x03A3);theFont.style=staticFontStyle;break;	//Sigma
	case 0x07:pMathType=mi;theFont.style=italic;pmt(0x03D2);theFont.style=staticFontStyle;break;	//Upsilon with hook
	case 0x08:pMathType=mi;theFont.style=italic;pmt(0x03A6);theFont.style=staticFontStyle;break;	//Phi
	case 0x09:pMathType=mi;theFont.style=italic;pmt(0x03A8);theFont.style=staticFontStyle;break;	//Psi
	case 0x0A:pMathType=mi;theFont.style=italic;pmt(0x03A9);theFont.style=staticFontStyle;break;	//Omega
	case 0x0B:pMathType=mi;theFont.style=italic;pmt(0x03B1);theFont.style=staticFontStyle;break;	//alpha
	case 0x0C:pMathType=mi;theFont.style=italic;pmt(0x03B2);theFont.style=staticFontStyle;break;	//beta
	case 0x0D:pMathType=mi;theFont.style=italic;pmt(0x03B3);theFont.style=staticFontStyle;break;	//gamma
	case 0x0E:pMathType=mi;theFont.style=italic;pmt(0x03B4);theFont.style=staticFontStyle;break;	//delta
	case 0x0F:pMathType=mi;theFont.style=italic;pmt(0x03B5);theFont.style=staticFontStyle;break;	//epsilon

	case 0x10:pMathType=mi;theFont.style=italic;pmt(0x03B6);theFont.style=staticFontStyle;break;	//zeta
	case 0x11:pMathType=mi;theFont.style=italic;pmt(0x03B7);theFont.style=staticFontStyle;break;	//eta
	case 0x12:pMathType=mi;theFont.style=italic;pmt(0x03B8);theFont.style=staticFontStyle;break;	//theta
	case 0x13:pMathType=mi;theFont.style=italic;pmt(0x03B9);theFont.style=staticFontStyle;break;	//iota
	case 0x14:pMathType=mi;theFont.style=italic;pmt(0x03BA);theFont.style=staticFontStyle;break;	//kappa
	case 0x15:pMathType=mi;theFont.style=italic;pmt(0x03BB);theFont.style=staticFontStyle;break;	//lambda
	case 0x16:pMathType=mi;theFont.style=italic;pmt(0x03BC);theFont.style=staticFontStyle;break;	//mu
	case 0x17:pMathType=mi;theFont.style=italic;pmt(0x03BD);theFont.style=staticFontStyle;break;	//nu
	case 0x18:pMathType=mi;theFont.style=italic;pmt(0x03BE);theFont.style=staticFontStyle;break;	//xi
	case 0x19:pMathType=mi;theFont.style=italic;pmt(0x03C0);theFont.style=staticFontStyle;break;	//pi
	case 0x1A:pMathType=mi;theFont.style=italic;pmt(0x03C1);theFont.style=staticFontStyle;break;	//ro
	case 0x1B:pMathType=mi;theFont.style=italic;pmt(0x03C3);theFont.style=staticFontStyle;break;	//sigma
	case 0x1C:pMathType=mi;theFont.style=italic;pmt(0x03C4);theFont.style=staticFontStyle;break;	//tau
	case 0x1D:pMathType=mi;theFont.style=italic;pmt(0x03C5);theFont.style=staticFontStyle;break;	//upsilon
	case 0x1E:pMathType=mi;theFont.style=italic;pmt(0x03C6);theFont.style=staticFontStyle;break;	//phi
	case 0x1F:pMathType=mi;theFont.style=italic;pmt(0x03C7);theFont.style=staticFontStyle;break;	//chi

	case 0x20:pMathType=mi;theFont.style=italic;pmt(0x03C8);theFont.style=staticFontStyle;break;	//psi
	case 0x21:pMathType=mi;theFont.style=italic;pmt(0x03C9);theFont.style=staticFontStyle;break;	//omega
	case 0x22:pMathType=mi;theFont.style=italic;pmt(0x025B);theFont.style=staticFontStyle;break;	//latin epsilon
	case 0x23:pMathType=mi;theFont.style=italic;pmt(0x03D1);theFont.style=staticFontStyle;break;	//script theta
	case 0x24:pMathType=mi;theFont.style=italic;pmt(0x03D6);theFont.style=staticFontStyle;break;	//varpi
	case 0x25:pMathType=mi;theFont.style=italic;pmt(0x03F1);theFont.style=staticFontStyle;break;	//varrho
	case 0x26:pMathType=mi;theFont.style=italic;pmt(0x03C2);theFont.style=staticFontStyle;break;	//final sigma
	case 0x27:pMathType=mi;theFont.style=italic;pmt(0x03C6);theFont.style=staticFontStyle;break;	//italic phi
	case 0x28:pMathType=mo;pmt(0x21BC);break;	//left harpoon up
	case 0x29:pMathType=mo;pmt(0x21BD);break;	//left harpoon down
	case 0x2A:pMathType=mo;pmt(0x21C0);break;	//right harpoon up
	case 0x2B:pMathType=mo;pmt(0x21C1);break;	//right harpoon down
	case 0x2C:pMathType=mo;pmt(0x02BF);break;	//left half ring
	case 0x2D:pMathType=mo;pmt(0x02BE);break;	//right half ring
	case 0x2E:pMathType=mo;pmt(0x25B9);break;	//right triangle small
	case 0x2F:pMathType=mo;pmt(0x25C3);break;	//left triangle small

	case 0x30:
	case 0x31:
	case 0x32:
	case 0x33:
	case 0x34:
	case 0x35:
	case 0x36:
	case 0x37:
	case 0x38:
	case 0x39:pMathType=mn;pmt(*temp);break;//digits
	case 0x3A:pMathType=mo;pmt(0x002E);break;//dot
	case 0x3B:pMathType=mo;pmt(0x002C);break;//comma
	case 0x3C://less than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	p("<mo>&lt;</mo>");
		break;
	case 0x3D:pMathType=mo;pmt(0x002F);break;//division
	case 0x3E: //greater than
		if(combiningUnicode==0x0338) { 
			combiningUnicode=0;
			pmt(0x226F);
		}	else	p("<mo>&gt;</mo>");
		break;
	case 0x3F:pMathType=mo;pmt(0x25C6);break;	//star operator

	case 0x40:pMathType=mo;pmt(0x2202);break;	//partial diff

	case 0x5B:pMathType=mo;pmt(0x266D);break;	//music flat
	case 0x5C:pMathType=mo;pmt(0x266E);break;	//music natural
	case 0x5D:pMathType=mo;pmt(0x266F);break;	//music sharp
	case 0x5E:pMathType=mo;pmt(0x203F);break;	//character tie
	case 0x5F:pMathType=mo;pmt(0x2040);break;	//under tie

	case 0x60:pMathType=mo;pmt(0x2113);break;	//ell script

	case 0x7B:pMathType=mi;theFont.style=italic;pmt(0x0131);theFont.style=staticFontStyle;break;	//dotless i
	case 0x7C:pMathType=mi;theFont.style=italic;pmt(0x0237);theFont.style=staticFontStyle;break;	//dotless j
	case 0x7D:pMathType=mo;
		staticFontFamily=theFont.family;
		theFont.family=cursive;
		pmt(0x2118);
		theFont.family=staticFontFamily;
		break;	//script capital P
	case 0x7E:pMathType=mo;pmt(0x20d7);break;	//combining right arrow above, XXX cmmi is spacing though
	case 0x7F:pMathType=mo;pmt(0x2040);break;	//tie
	default:
		pMathType=mi;theFont.style=italic;pmt(*temp);theFont.style=staticFontStyle;
	}
	temp++;
}while(*temp);
return;
}

void fontMapMathItalicA(){
//px[b]mia, tx[b]mia
	unsigned char* temp=(unsigned char*)yytext;
	int staticFontFamily;
	
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x0393);break;//Gamma
	case 0x01:pMathType=mo;pmt(0x0394);break;//Delta
	case 0x02:pMathType=mo;pmt(0x0398);break;//Theta
	case 0x03:pMathType=mo;pmt(0x039B);break;//Lambda
	case 0x04:pMathType=mo;pmt(0x039E);break;//Xi
	case 0x05:pMathType=mo;pmt(0x03A0);break;//Pi
	case 0x06:pMathType=mo;pmt(0x03A3);break;//Sigma
	case 0x07:pMathType=mo;pmt(0x03D2);break;//Upsilon with hook
	case 0x08:pMathType=mo;pmt(0x03A6);break;//Phi
	case 0x09:pMathType=mo;pmt(0x03A8);break;//Psi
	case 0x0A:pMathType=mo;pmt(0x03A9);break;//Omega
	case 0x0B:pMathType=mo;pmt(0x03B1);break;//alpha
	case 0x0C:pMathType=mo;pmt(0x03B2);break;//beta
	case 0x0D:pMathType=mo;pmt(0x03B3);break;//gamma
	case 0x0E:pMathType=mo;pmt(0x03B4);break;//delta
	case 0x0F:pMathType=mo;pmt(0x03B5);break;//epsilon

	case 0x10:pMathType=mo;pmt(0x03B6);break;//zeta
	case 0x11:pMathType=mo;pmt(0x03B7);break;//eta
	case 0x12:pMathType=mo;pmt(0x03B8);break;//theta
	case 0x13:pMathType=mo;pmt(0x03B9);break;//iota
	case 0x14:pMathType=mo;pmt(0x03BA);break;//kappa
	case 0x15:pMathType=mo;pmt(0x03BB);break;//lambda
	case 0x16:pMathType=mo;pmt(0x03BC);break;//mu
	case 0x17:pMathType=mo;pmt(0x03BD);break;//nu
	case 0x18:pMathType=mo;pmt(0x03BE);break;//xi
	case 0x19:pMathType=mo;pmt(0x03C0);break;//pi
	case 0x1A:pMathType=mo;pmt(0x03C1);break;//ro
	case 0x1B:pMathType=mo;pmt(0x03C3);break;//sigma
	case 0x1C:pMathType=mo;pmt(0x03C4);break;//tau
	case 0x1D:pMathType=mo;pmt(0x03C5);break;//upsilon
	case 0x1E:pMathType=mo;pmt(0x03C6);break;//phi
	case 0x1F:pMathType=mo;pmt(0x03C7);break;//chi

	case 0x20:pMathType=mo;pmt(0x03C8);break;//psi
	case 0x21:pMathType=mo;pmt(0x03C9);break;//omega
	case 0x22:pMathType=mo;pmt(0x025B);break;//latin epsilon
	case 0x23:pMathType=mo;pmt(0x03D1);break;//script theta
	case 0x24:pMathType=mo;pmt(0x03D6);break;//varpi
	case 0x25:pMathType=mo;pmt(0x03F1);break;//varrho
	case 0x26:pMathType=mo;pmt(0x03C2);break;//final sigma
	case 0x27:pMathType=mo;pmt(0x03C6);break;//italic phi
	
	//nothing here
	
	case 0x31:pMathType=mi;pmt(0x0261);break;//varg, latin g
	case 0x32:pMathType=mi;pmt(0x0079);break;//\yl, only in tx
	case 0x33:pMathType=mi;pmt(0x0076);break;//\vl, only in tx
	case 0x34:pMathType=mi;pmt(0x0077);break;//\wl, only in tx
	
	//nothing here
	
	case 0x41://pmt(0x1D504);break;//fraktur A
	case 0x42://pmt(0x1D505);break;//fraktur B
	case 0x43://pmt(0x212D);break;//fraktur C
	case 0x44://pmt(0x1D507);break;//fraktur D
	case 0x45://pmt(0x1D508);break;//fraktur E
	case 0x46://pmt(0x1D509);break;//fraktur F
	case 0x47://pmt(0x1D50A);break;//fraktur G
	case 0x48://pmt(0x210C);break;//fraktur H
	case 0x49://pmt(0x2111);break;//fraktur I
	case 0x4A://pmt(0x1D50D);break;//fraktur J
	case 0x4B://pmt(0x1D50E);break;//fraktur K
	case 0x4C://pmt(0x1D50F);break;//fraktur L
	case 0x4D://pmt(0x1D510);break;//fraktur M
	case 0x4E://pmt(0x1D511);break;//fraktur N
	case 0x4F://pmt(0x1D512);break;//fraktur O

	case 0x50://pmt(0x2119);break;//pmt(0x1D513);break;//fraktur P
	case 0x51://pmt(0x211A);break;//pmt(0x1D514);break;//fraktur Q
	case 0x52://pmt(0x211C);break;//fraktur R
	case 0x53://pmt(0x1D516);break;//fraktur S
	case 0x54://pmt(0x1D517);break;//fraktur T
	case 0x55://pmt(0x1D518);break;//fraktur U
	case 0x56://pmt(0x1D519);break;//fraktur V
	case 0x57://pmt(0x1D51A);break;//fraktur W
	case 0x58://pmt(0x1D51B);break;//fraktur X
	case 0x59://pmt(0x1D51C);break;//fraktur Y
	case 0x5A://pmt(0x2128);break;//fraktur Z
		pMathType=mo;staticFontFamily=theFont.family;
		theFont.family=fraktur;pmt(*temp);
		theFont.family=staticFontFamily;
		break;

	//nothing
				
	case 0x61://pmt(0x1D586);break;//fraktur a
	case 0x62://pmt(0x1D587);break;//fraktur b
	case 0x63://pmt(0x1D588);break;//fraktur c
	case 0x64://pmt(0x1D589);break;//fraktur d
	case 0x65://pmt(0x1D58A);break;//fraktur e
	case 0x66://pmt(0x1D58B);break;//fraktur f
	case 0x67://pmt(0x1D58C);break;//fraktur g
	case 0x68://pmt(0x1D58D);break;//fraktur h
	case 0x69://pmt(0x1D58E);break;//fraktur i
	case 0x6A://pmt(0x1D58F);break;//fraktur j
	case 0x6B://pmt(0x1D590);break;//fraktur k
	case 0x6C://pmt(0x1D591);break;//fraktur k
	case 0x6D://pmt(0x1D592);break;//fraktur m
	case 0x6E://pmt(0x1D593);break;//fraktur n
	case 0x6F://pmt(0x1D594);break;//fraktur o

	case 0x70://pmt(0x1D595);break;//fraktur p
	case 0x71://pmt(0x1D596);break;//fraktur q
	case 0x72://pmt(0x1D597);break;//fraktur r
	case 0x73://pmt(0x1D598);break;//fraktur s
	case 0x74://pmt(0x1D599);break;//fraktur t
	case 0x75://pmt(0x1D59A);break;//fraktur u
	case 0x76://pmt(0x1D59B);break;//fraktur v
	case 0x77://pmt(0x1D59C);break;//fraktur w
	case 0x78://pmt(0x1D59D);break;//fraktur x
	case 0x79://pmt(0x1D59E);break;//fraktur y
	case 0x7A://pmt(0x1D59F);break;//fraktur z
		pMathType=mo;staticFontFamily=theFont.family;
		theFont.family=fraktur;pmt(*temp);
		theFont.family=staticFontFamily;
		break;
		
	//nothing
	case 0x7F:pMathType=mo;pmt(0x2040);break;//tie

	//only txmia from here
	//nothing
	case 0x81:
	case 0x82:
	case 0x83:
	case 0x84:
	case 0x85:
	case 0x86:
	case 0x87:
	case 0x88:
	case 0x89:
	case 0x8A:
	case 0x8B:
	case 0x8C:
	case 0x8D:
	case 0x8E:
	case 0x8F:

	case 0x90:
	case 0x91:
	case 0x92:
	case 0x93:
	case 0x94:
	case 0x95:
	case 0x96:
	case 0x97:
	case 0x98:
	case 0x99:
	case 0x9A://pMathType=mo;pmt(*temp-0x20);break;//ds A-Z
		pMathType=mo;staticFontFamily=theFont.family;
		theFont.family=doubleStruck;pmt(*temp-0x20);
		theFont.family=staticFontFamily;
		break;
	
	//nothing

	case 0xAB:pMathType=mo;pmt('k');break;//ds k
	//nothing
	}
	temp++;
}while(*temp);
return;
}




void fontMapMsam(){
//msam, px[b]sya, tx[b]sya, xccam, cmbras

unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x22A1);break;//squared dot
	case 0x01:pMathType=mo;pmt(0x229E);break;//squared plus
	case 0x02:pMathType=mo;pmt(0x22A0);break;//squared times
	case 0x03:pMathType=mo;pmt(0x25A1);break;//white square (d'Alembertian :()
	case 0x04:pMathType=mo;pmt(0x25A0);break;//black square
	case 0x05:pMathType=mo;pmt(0x00B7);break;//center dot
	case 0x06:pMathType=mo;pmt(0x25CA);break;//lozenge
	case 0x07:pMathType=mo;pmt(0x29EB);break;//black lozenge
	case 0x08:pMathType=mo;pmt(0x21BB);break;//circlearrowright
	case 0x09:pMathType=mo;pmt(0x21BA);break;//circlearrowleft
	case 0x0A:pMathType=mo;pmt(0x21CC);break;//rightleftharpoons
	case 0x0B:pMathType=mo;pmt(0x21CB);break;//leftrightharpoons
	case 0x0C:pMathType=mo;pmt(0x229F);break;//squared minus
	case 0x0D:pMathType=mo;	//Vdash
		precomposedNegative(0x22A9,0x22AE);
		break;
	case 0x0E:pMathType=mo;pmt(0x22AA);break;//Vvdash
	case 0x0F:pMathType=mo;	//vDash
		precomposedNegative(0x22A8,0x22AD);
		break;

	case 0x10:pMathType=mo;pmt(0x21A0);break;//twoheadrightarrow
	case 0x11:pMathType=mo;pmt(0x219E);break;//twoheadleftarrow
	case 0x12:pMathType=mo;pmt(0x21C7);break;//left paired arrows
	case 0x13:pMathType=mo;pmt(0x21C9);break;//right paired arrows
	case 0x14:pMathType=mo;pmt(0x21C8);break;//up paired arrows
	case 0x15:pMathType=mo;pmt(0x21CA);break;//down paired arrows
	case 0x16:pMathType=mo;pmt(0x21BE);break;//up harpoon right barb
	case 0x17:pMathType=mo;pmt(0x21C2);break;//down harpoon right barb
	case 0x18:pMathType=mo;pmt(0x21BF);break;//up harpoon left barb
	case 0x19:pMathType=mo;pmt(0x21C3);break;//down harpoon left barb
	case 0x1A:pMathType=mo;pmt(0x21A3);break;//rightarrowtail
	case 0x1B:pMathType=mo;pmt(0x21A2);break;//leftarrowtail
	case 0x1C:pMathType=mo;pmt(0x21C6);break;//left over right arrows
	case 0x1D:pMathType=mo;pmt(0x21C4);break;//right over left arrows
	case 0x1E:pMathType=mo;pmt(0x21B0);break;//uparrow left tip
	case 0x1F:pMathType=mo;pmt(0x21B1);break;//uparrow right tip

	case 0x20:pMathType=mo;pmt(0x21DD);break;//right squiggle arrow
	case 0x21:pMathType=mo;pmt(0x21AD);break;//leftright wave arrow
	case 0x22:pMathType=mo;pmt(0x21AB);break;//left arrow loop
	case 0x23:pMathType=mo;pmt(0x21AC);break;//right arrow loop
	case 0x24:pMathType=mo;pmt(0x2257);break;//ring equal
	case 0x25:pMathType=mo;pmt(0x227F);break;//succeedes equivalent
	case 0x26:pMathType=mo;									//greater equivalent
						precomposedNegative(0x2273,0x2275);
						break;
	case 0x27:pMathType=mo;pmt(0x2267);break;//greater over equal
	case 0x28:pMathType=mo;pmt(0x22B8);break;//multimap
	case 0x29:pMathType=mo;pmt(0x2234);break;//therefore
	case 0x2A:pMathType=mo;pmt(0x2235);break;//because
	case 0x2B:pMathType=mo;pmt(0x2251);break;//geometric equal
	case 0x2C:pMathType=mo;pmt(0x225C);break;//delta equal
	case 0x2D:pMathType=mo;pmt(0x227E);break;//precedes equiv
	case 0x2E:pMathType=mo;									//less equiv
						precomposedNegative(0x2272,0x2274);
						break;
	case 0x2F:pMathType=mo;pmt(0x2AB7);break;//precapprox

	case 0x30:pMathType=mo;pmt(0x22DC);break;//equal less
	case 0x31:pMathType=mo;pmt(0x22DD);break;//equal greater
	case 0x32:pMathType=mo;pmt(0x22DE);break;//equal preceds
	case 0x33:pMathType=mo;pmt(0x22DF);break;//equal succeedes
	case 0x34:pMathType=mo;	//precedes equal
		precomposedNegative(0x227C,0x22E0);
		break;
	case 0x35:pMathType=mo;pmt(0x2266);break;//less over equal
	case 0x36:pMathType=mo;pmt(0x2A7D);break;//leqslant
	case 0x37:pMathType=mo;									//less greater
						precomposedNegative(0x2276,0x2278);
						break;
	case 0x38:pMathType=mo;pmt(0x2035);break;//back prime
	case 0x39:pMathType=mo;pmt(0x2012);break;//figure dash
	case 0x3A:pMathType=mo;pmt(0x2253);break;//image approx
	case 0x3B:pMathType=mo;pmt(0x2252);break;//approx image
	case 0x3C:pMathType=mo;	//succeeds equal
		precomposedNegative(0x227D,0x22E1);
		break;
	case 0x3D:pMathType=mo;pmt(0x2267);break;//greater over equal
	case 0x3E:pMathType=mo;pmt(0x2A7E);break;//greater equal slant
	case 0x3F:pMathType=mo;									//greater less
						precomposedNegative(0x2277,0x2279);
						break;
	case 0x40:pMathType=mo;pmt(0x228F);break;//square subset
	case 0x41:pMathType=mo;pmt(0x2290);break;//square superset
	case 0x42:pMathType=mo;	//normal subgroup
		precomposedNegative(0x22B2,0x22EA);
		break;
	case 0x43:pMathType=mo;	//contains as normal subgroup
		precomposedNegative(0x22B3,0x22EB);
		break;
	case 0x44:pMathType=mo;	//contains as normal subgroup equal
		precomposedNegative(0x22B5,0x22ED);
		break;
	case 0x45:pMathType=mo;	//normal subgroup equal
		precomposedNegative(0x22B4,0x22EC);
		break;
	case 0x46:pMathType=mo;pmt(0x2605);break;//bigstar
	case 0x47:pMathType=mo;pmt(0x226C);break;//between
	case 0x48:pMathType=mo;pmt(0x25BE);break;//black triangle down
	case 0x49:pMathType=mo;pmt(0x25B8);break;//black triangle right
	case 0x4A:pMathType=mo;pmt(0x25C2);break;//black triangle left
	case 0x4B:pMathType=mo;pmt(0x20D7);break;//combining arrow right
	case 0x4C:pMathType=mo;pmt(0x20D6);break;//combining arrow left
	case 0x4D:pMathType=mo;pmt(0x25B5);break;//white triangle up
	case 0x4E:pMathType=mo;pmt(0x25B4);break;//black triangle up
	case 0x4F:pMathType=mo;pmt(0x25BF);break;//white triangle down

	case 0x50:pMathType=mo;pmt(0x2256);break;//ring in equal to
	case 0x51:pMathType=mo;pmt(0x22DA);break;//less equal greater
	case 0x52:pMathType=mo;pmt(0x22DB);break;//greater equal less
	case 0x53:pMathType=mo;pmt(0x2A8B);break;//less eqqual greater
	case 0x54:pMathType=mo;pmt(0x2A8C);break;//greater eqqual less
	case 0x55:pMathType=mo;pmt(0x00A5);break;//yuan
	case 0x56:pMathType=mo;pmt(0x21DB);break;//right triple arrow
	case 0x57:pMathType=mo;pmt(0x21DA);break;//left triple arrow
	case 0x58:pMathType=mo;pmt(0x2713);break;//check mark
	case 0x59:pMathType=mo;pmt(0x22BB);break;//xor
	case 0x5A:pMathType=mo;pmt(0x22BC);break;//nand
	case 0x5B:pMathType=mo;pmt(0x2306);break;//perspective
	case 0x5C:pMathType=mo;pmt(0x2220);break;//angle
	case 0x5D:pMathType=mo;pmt(0x2221);break;//measured angle
	case 0x5E:pMathType=mo;pmt(0x2222);break;//arc angle
	case 0x5F:pMathType=mo;pmt(0x221D);break;//propto

	case 0x60:pMathType=mo;pmt(0x2323);break;//ssmile
	case 0x61:pMathType=mo;pmt(0x2322);break;//sfrown
	case 0x62:pMathType=mo;pmt(0x22D0);break;//double subset
	case 0x63:pMathType=mo;pmt(0x22D1);break;//double superset
	case 0x64:pMathType=mo;pmt(0x22D2);break;//double union
	case 0x65:pMathType=mo;pmt(0x22D3);break;//double intersection
	case 0x66:pMathType=mo;pmt(0x22CF);break;//curly logical and
	case 0x67:pMathType=mo;pmt(0x22CE);break;//curly logical or
	case 0x68:pMathType=mo;pmt(0x22CB);break;//left semidirect product
	case 0x69:pMathType=mo;pmt(0x22CC);break;//right semidirect product
	case 0x6A:pMathType=mo;pmt(0x2AC5);break;//subseteqq
	case 0x6B:pMathType=mo;pmt(0x2AC6);break;//supseteqq
	case 0x6C:pMathType=mo;pmt(0x224F);break;//difference
	case 0x6D:pMathType=mo;pmt(0x224E);break;//geometrical equivalent
	case 0x6E:pMathType=mo;pmt(0x22D8);break;//very much less
	case 0x6F:pMathType=mo;pmt(0x22D9);break;//very much greater

	case 0x70:pMathType=mo;pmt(0x231C);break;//top left corner
	case 0x71:pMathType=mo;pmt(0x231D);break;//top right corner
	case 0x72:pMathType=mo;pmt(0x24C7);break;//circle R
	case 0x73:pMathType=mo;pmt(0x24C8);break;//circle S
	case 0x74:pMathType=mo;pmt(0x22D4);break;//pitchfork
	case 0x75:pMathType=mo;pmt(0x2214);break;//dot plus
	case 0x76:pMathType=mo;pmt(0x223D);break;//reversed tilde
	case 0x77:pMathType=mo;pmt(0x22CD);break;//reversed tilde equal
	case 0x78:pMathType=mo;pmt(0x231E);break;//bottom left corner
	case 0x79:pMathType=mo;pmt(0x231F);break;//bottom right corner
	case 0x7A:pMathType=mo;pmt(0x2720);break;//maltese cross
	case 0x7B:pMathType=mo;pmt(0x2201);break;//complement
	case 0x7C:pMathType=mo;pmt(0x22BA);break;//intercal
	case 0x7D:pMathType=mo;pmt(0x229A);break;//circled ring
	case 0x7E:pMathType=mo;pmt(0x229B);break;//circled asterisk
	case 0x7F:pMathType=mo;pmt(0x229D);break;//circled dash

	}
	temp++;
}while(*temp) ;
return;
}
	

void fontMapMsbm(){
//msbm, px[b]syb, tx[b]syb, xccbm, cmbrbs
int staticFontFamily;
unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x2268);break;//less not equal
	case 0x01:pMathType=mo;pmt(0x2269);break;//greater not equal
	case 0x02:pMathType=mo;pmt(0x2270);break;//not less not equal
	case 0x03:pMathType=mo;pmt(0x2271);break;//not greater not equal
	case 0x04:pMathType=mo;pmt(0x226E);break;//not less
	case 0x05:pMathType=mo;pmt(0x226F);break;//not greater
	case 0x06:pMathType=mo;pmt(0x2280);break;//not precede
	case 0x07:pMathType=mo;pmt(0x2281);break;//not succceed
	case 0x08:pMathType=mo;pmt(0x2268);break;//less than not equal
	case 0x09:pMathType=mo;pmt(0x2269);break;//greater than not equal
	case 0x0A:pMathType=mo;pmt(0x2270);break;//not less not equal
	case 0x0B:pMathType=mo;pmt(0x2271);break;//not greater not equal
	case 0x0C:pMathType=mo;pmt(0x2A87);break;//less not equal
	case 0x0D:pMathType=mo;pmt(0x2A88);break;//greater not equal
	case 0x0E:p("<mo>");p(ul2utf8(0x2AAF));p(ul2utf8(0x0338));p("</mo>");break;//not precedes not equal
	case 0x0F:p("<mo>");p(ul2utf8(0x2AB0));p(ul2utf8(0x0338));p("</mo>");break;//not succeeds not equal

	case 0x10:pMathType=mo;pmt(0x22E7);break;//precedes not equivalent
	case 0x11:pMathType=mo;pmt(0x22E8);break;//succeeds not equivalent
	case 0x12:pMathType=mo;pmt(0x22E6);break;//less not equivalent
	case 0x13:pMathType=mo;pmt(0x22E7);break;//greater not equivalent
	case 0x14:p("<mo>");p(ul2utf8(0x2266));p(ul2utf8(0x0338));p("</mo>");break;//not less not equal
	case 0x15:p("<mo>");p(ul2utf8(0x2267));p(ul2utf8(0x0338));p("</mo>");break;//not greater not equal
	case 0x16:pMathType=mo;pmt(0x2AB5);break;//precedes not equal
	case 0x17:pMathType=mo;pmt(0x2AB6);break;//succeedes not equal
	case 0x18:pMathType=mo;pmt(0x2AB9);break;//precedes not approx
	case 0x19:pMathType=mo;pmt(0x2ABA);break;//succeeds not approx
	case 0x1A:pMathType=mo;pmt(0x2A89);break;//less not approx
	case 0x1B:pMathType=mo;pmt(0x2A8A);break;//greater not approx
	case 0x1C:pMathType=mo;pmt(0x2241);break;//not tilde
	case 0x1D:pMathType=mo;pmt(0x2247);break;//not approximate not equal
	case 0x1E:pMathType=mo;pmt(0x2571);break;//diagup
	case 0x1F:pMathType=mo;pmt(0x2572);break;//diagdown

	case 0x20:p("<mo>");p(ul2utf8(0x228A));p(ul2utf8(0xFE00));p("</mo>");break;//var subset not equal
	case 0x21:p("<mo>");p(ul2utf8(0x228B));p(ul2utf8(0xFE00));p("</mo>");break;//var supset not equal
	case 0x22:p("<mo>");p(ul2utf8(0x2AC5));p(ul2utf8(0x0338));p("</mo>");break;//not subset not eqqual
	case 0x23:p("<mo>");p(ul2utf8(0x2AC6));p(ul2utf8(0x0338));p("</mo>");break;//not superset not eqqual
	case 0x24:pMathType=mo;pmt(0x2ACB);break;//subset not eqqual
	case 0x25:pMathType=mo;pmt(0x2ACC);break;//superset not eqqual
	case 0x26:p("<mo>");p(ul2utf8(0x2ACB));p(ul2utf8(0xFE00));p("</mo>");break;//var subset not eqqual
	case 0x27:p("<mo>");p(ul2utf8(0x2ACC));p(ul2utf8(0xFE00));p("</mo>");break;//var superset not eqqual
	case 0x28:pMathType=mo;pmt(0x228A);break;//subset not equal
	case 0x29:pMathType=mo;pmt(0x228B);break;//superset not equal
	case 0x2A:pMathType=mo;pmt(0x2288);break;//not subset not equal
	case 0x2B:pMathType=mo;pmt(0x2289);break;//not superset not equal
	case 0x2C:pMathType=mo;pmt(0x2226);break;//not parallel
	case 0x2D:pMathType=mo;pmt(0x2224);break;//not divide
	case 0x2E:pMathType=mo;pmt(0x2224);break;//short not divide
	case 0x2F:pMathType=mo;pmt(0x2226);break;//short not parallel

	case 0x30:pMathType=mo;pmt(0x22AC);break;//does not prove
	case 0x31:pMathType=mo;pmt(0x22AE);break;//does not force
	case 0x32:pMathType=mo;pmt(0x22AD);break;//not true
	case 0x33:pMathType=mo;pmt(0x22AF);break;//nVDash
	case 0x34:pMathType=mo;pmt(0x22ED);break;//not triangle right not equal
	case 0x35:pMathType=mo;pmt(0x22EC);break;//not triangle left not equal
	case 0x36:pMathType=mo;pmt(0x22EA);break;//not triangle left
	case 0x37:pMathType=mo;pmt(0x22EC);break;//not triangle right
	case 0x38:pMathType=mo;pmt(0x219A);break;//not left arrow
	case 0x39:pMathType=mo;pmt(0x219B);break;//not right arrow
	case 0x3A:pMathType=mo;pmt(0x21CD);break;//not left double arrow
	case 0x3B:pMathType=mo;pmt(0x21CF);break;//not right double arrow
	case 0x3C:pMathType=mo;pmt(0x21CE);break;//not left right double arrow
	case 0x3D:pMathType=mo;pmt(0x21AE);break;//not left right arrow
	case 0x3E:pMathType=mo;pmt(0x22C7);break;//division times
	case 0x3F:pMathType=mo;pmt(0x2205);break;//var empty set

	case 0x40:pMathType=mo;pmt(0x2204);break;//not exist
	case 0x41:
	case 0x42:
	case 0x43:
	case 0x44:
	case 0x45:
	case 0x46:
	case 0x47:
	case 0x48:
	case 0x49:
	case 0x4A:
	case 0x4B:
	case 0x4C:
	case 0x4D:
	case 0x4E:
	case 0x4F:

	case 0x50:
	case 0x51:
	case 0x52:
	case 0x53:
	case 0x54:
	case 0x55:
	case 0x56:
	case 0x57:
	case 0x58:
	case 0x59:
	case 0x5A:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=doubleStruck;
			pmt(*temp);
			theFont.family=staticFontFamily;
			break;//double A-Z
	case 0x5B:pMathType=mo;pmt('^');break;//
	case 0x5C:pMathType=mo;pmt('^');break;//
	case 0x5D:pMathType=mo;pmt('~');break;//
	case 0x5E:pMathType=mo;pmt('~');break;//
	
	//nothing
	
	case 0x60:pMathType=mo;pmt(0x2132);break;//turned capital F
	case 0x61:pMathType=mo;pmt(0x2141);break;//turned sans-serif capital G

	case 0x66:pMathType=mo;pmt(0x2127);break;//mho
	case 0x67:pMathType=mo;pmt(0x00D0);break;//eth
	case 0x68:pMathType=mo;pmt(0x2242);break;//minus tilde
	case 0x69:pMathType=mo;pmt(0x2136);break;//beth
	case 0x6A:pMathType=mo;pmt(0x2137);break;//gimel
	case 0x6B:pMathType=mo;pmt(0x2138);break;//daleth
	case 0x6C:pMathType=mo;pmt(0x22D6);break;//less dot
	case 0x6D:pMathType=mo;pmt(0x22D7);break;//greater dot
	case 0x6E:pMathType=mo;pmt(0x22C9);break;//left normal factor semidirect product
	case 0x6F:pMathType=mo;pmt(0x2216);break;//right normal factor semidirect product

	case 0x70:pMathType=mo;pmt(0x2223);break;//divides
	case 0x71:pMathType=mo;pmt(0x2225);break;//parallel to
	case 0x72:pMathType=mo;pmt(0x005C);break;//integer divide
	case 0x73:pMathType=mo;								//similar
		precomposedNegative(0x223C, 0x2241);
		break;
	case 0x74:pMathType=mo;									//thickapprox
		precomposedNegative(0x2248, 0x2249);
		break;
	case 0x75:pMathType=mo;pmt(0x224A);break;//approxeq
	case 0x76:pMathType=mo;pmt(0x2AB8);break;//succapprox
	case 0x77:pMathType=mo;pmt(0x2AB7);break;//precapprox
	case 0x78:pMathType=mo;pmt(0x21B6);break;//curve arrow left
	case 0x79:pMathType=mo;pmt(0x21B7);break;//curve arrow right
	case 0x7A:pMathType=mo;pmt(0x03DD);break;//digamma
	case 0x7B:pMathType=mo;pmt(0x03F0);break;//varkappa
	case 0x7C:pMathType=mo;
		staticFontFamily=theFont.family;
		theFont.family=doubleStruck;
		pmt(0x006b);
		theFont.family=staticFontFamily;
		break;//bbbk
	case 0x7D:pMathType=mo;pmt(0x210F);break;//hslash
	case 0x7E:pMathType=mo;pmt(0x210F);break;//hbar
	case 0x7F:pMathType=mo;pmt(0x03F6);break;//backepsilon

	}
	temp++;
}while(*temp) ;
return;
}

void fontMapMathSymbolC(){
//tx[b]syc,px[b]syc
unsigned char* temp=(unsigned char*)yytext;

do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x22A3);break;//left tack
	case 0x01:pMathType=mo;pmt(0x22A7);break;//models
	case 0x02:pMathType=mo;pmt(0x2AE4);break;//vertical bar left double turnstile
	case 0x03:pMathType=mo;pmt(0x22A9);break;//forces
	case 0x04:pMathType=mo;pmt(0x2AE3);break;//double vertical bar left turnstile
	case 0x05:pMathType=mo;pmt(0x22AB);break;//double vertical bar right double turnstile
	case 0x06:pMathType=mo;pmt(0x2AE5);break;//double vertical bar left double turnstile
	case 0x07:pMathType=mo;pmt(0x25CB);break;//white circle
	case 0x08:pMathType=mo;pmt(0x25CF);break;//black circle
	case 0x09:pMathType=mo;pmt(0x2AFD);break;//double solidus, varparallel
	case 0x0A:pMathType=mo;pmt(0x244A);break;//OCR double backslash, nvarparallelinv
	case 0x0B:p("<mo>");p(ul2utf8(0x2AFD));p(ul2utf8(0x0338));p("</mo>");break;//negated double solidus, nvarparallel
	case 0x0C:p("<mo>");p(ul2utf8(0x244A));p(ul2utf8(0x0338));p("</mo>");break;//negated OCR double backslash, nvarparallelinv
	case 0x0D:p("<mo>");p(":");p(ul2utf8(0x2248));p("</mo>");break;//XXX,colon almost equal,\colonapprox
	case 0x0E:p("<mo>");p(":");p(ul2utf8(0x223C));p("</mo>");break;//XXX,colon similar, \colonsim
	case 0x0F:p("<mo>");p("::");p(ul2utf8(0x2248));p("</mo>");break;//XXX,double colon almost equal,\Colonapprox

	case 0x10:p("<mo>");p("::");p(ul2utf8(0x223C));p("</mo>");break;//double colon similar,\Colonsim
	case 0x11:pMathType=mo;pmt(0x2250);break;//approaches the limit,\doteq
	case 0x12:pMathType=mo;pmt(0x27DC);break;//left multimap
	case 0x13:pMathType=mo;pmt(0x29DF);break;//double-ended multimap
	case 0x14:p("<mo>");p(ul2utf8(0x2212));p(ul2utf8(0x2022));p("</mo>");break;//XXX=minus+bullet,\multimapdot
	case 0x15:p("<mo>");p(ul2utf8(0x2022));p(ul2utf8(0x2212));p("</mo>");break;//XXX,\multimapdotinv
	case 0x16:p("<mo>");p(ul2utf8(0x2022));p(ul2utf8(0x2212));p(ul2utf8(0x2022));p("</mo>");break;//XXX,\multimapdotboth
	case 0x17:pMathType=mo;pmt(0x22B6);break;//original of
	case 0x18:pMathType=mo;pmt(0x22B7);break; //image of
	case 0x19:pMathType=mo;pmt(0x22AB);break;//double vertical bar double turnstile right
	case 0x1A:p("<mo>");p("|");p(ul2utf8(0x22AB));p("</mo>");break; //XXX, triple vbar double turnstile right
	case 0x1B:pMathType=mo;pmt(0x2245);break; //\cong
	case 0x1C:pMathType=mo;pmt(0x2AAF);break; //\preceqq
	case 0x1D:pMathType=mo;pmt(0x2AB0);break; //\succeqq
	case 0x1E:p("<mo>");p(ul2utf8(0x227E));p(ul2utf8(0x0338));p("</mo>");break; //\nprecsim
	case 0x1F:p("<mo>");p(ul2utf8(0x227F));p(ul2utf8(0x0338));p("</mo>");break; //\nsuccsim

	case 0x20:pMathType=mo;pmt(0x2274);break;//\nlesssim
	case 0x21:pMathType=mo;pmt(0x2275);break;//\ngtrsim
	case 0x22:p("<mo>");p(ul2utf8(0x2A85));p(ul2utf8(0x0338));p("</mo>");break;//XXX,\nlessapprox
	case 0x23:p("<mo>");p(ul2utf8(0x2A86));p(ul2utf8(0x0338));p("</mo>");break;//XXX,\ngtrapprox
	case 0x24:pMathType=mo;pmt(0x22E0);break;//\npreccurlyeq
	case 0x25:pMathType=mo;pmt(0x22E1);break;//\nsucccurlyeq
	case 0x26:pMathType=mo;pmt(0x2278);break;//\ngtrless
	case 0x27:pMathType=mo;pmt(0x2279);break;//\nlessgtr
	case 0x28:p("<mo>");p(ul2utf8(0x224F));p(ul2utf8(0x0338));p("</mo>");break;//\nbumpeq
	case 0x29:p("<mo>");p(ul2utf8(0x224E));p(ul2utf8(0x0338));p("</mo>");break;//\nBumpeq
	case 0x2A:p("<mo>");p(ul2utf8(0x223D));p(ul2utf8(0x0338));p("</mo>");break;//\nbacksim
	case 0x2B:p("<mo>");p(ul2utf8(0x224C));p(ul2utf8(0x0338));p("</mo>");break;//\nbacksimeq
	case 0x2C:pMathType=mo;pmt(0x2260);break;//\neq
	case 0x2D:pMathType=mo;pmt(0x226D);break;//\nasymp
	case 0x2E:pMathType=mo;pmt(0x2262);break;//\nequiv
	case 0x2F:pMathType=mo;pmt(0x2241);break;//\nsim

	case 0x30:pMathType=mo;pmt(0x2249);break;//\napprox
	case 0x31:pMathType=mo;pmt(0x2284);break;//\nsubset
	case 0x32:pMathType=mo;pmt(0x2285);break;//\nsupset
	case 0x33:p("<mo>");p(ul2utf8(0x226A));p(ul2utf8(0x0338));p("</mo>");break;//\nll
	case 0x34:p("<mo>");p(ul2utf8(0x226B));p(ul2utf8(0x0338));p("</mo>");break;//\ngg
	case 0x35:pMathType=mo;pmt(0x2249);break;//\nthickapprox
	case 0x36:pMathType=mo;pmt(0x224A);break;//\napproxeq
	case 0x37:p("<mo>");p(ul2utf8(0x2AB7));p(ul2utf8(0x0338));p("</mo>");break;//\nprecapprox
	case 0x38:p("<mo>");p(ul2utf8(0x2AB8));p(ul2utf8(0x0338));p("</mo>");break;//\nsuccapprox
	case 0x39:p("<mo>");p(ul2utf8(0x2AB3));p(ul2utf8(0x0338));p("</mo>");break;//\npreceqq
	case 0x3A:p("<mo>");p(ul2utf8(0x2AB4));p(ul2utf8(0x0338));p("</mo>");break;//\nsucceqq
	case 0x3B:pMathType=mo;pmt(0x2244);break;//\nsimeq 
	case 0x3C:pMathType=mo;pMathType=mo;pmt(0x2209);break;//\notin
	case 0x3D:pmt(0x220C);break;//\notni
	case 0x3E:p("<mo>");p(ul2utf8(0x22D0));p(ul2utf8(0x0338));p("</mo>");break;//\nSubset
	case 0x3F:p("<mo>");p(ul2utf8(0x22D1));p(ul2utf8(0x0338));p("</mo>");break;//\nSupset

	case 0x40:pMathType=mo;pmt(0x22E2);break;//\nsqsubseteq
	case 0x41:pMathType=mo;pmt(0x22E3);break;//\nsqsupseteq
	case 0x42:pMathType=mo;pmt(0x2254);break;//\coloneqq
	case 0x43:pMathType=mo;pmt(0x2255);break;//\eqqcolon
	case 0x44:p("<mo>");p(":-");p("</mo>");break;//XXX,\coloneq
	case 0x45:pMathType=mo;pmt(0x2239);break;//\eqcolon
	case 0x46:pMathType=mo;pmt(0x2A74);break;//\Coloneqq
	case 0x47:p("<mo>");p("=::");p("</mo>");break;//XXX,\Eqqcolon

	case 0x48:p("<mo>");p("::-");p("</mo>");break;//\Coloneq
	case 0x49:p("<mo>");p("-::");p("</mo>");break;//\Eqcolon
	case 0x4A:pMathType=mo;pmt(0x297D);break;//XXX, \strictif
	case 0x4B:pMathType=mo;pmt(0x297C);break;//XXX, \strictfi
	case 0x4C:p("<mo>");p(ul2utf8(0x297C));p(ul2utf8(0x297D));p("</mo>");break;//\strictiff
	case 0x4D:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1=frown,\invamp
	case 0x4E:pMathType=mo;pmt(0x27C5);break;//\lbag
	case 0x4F:pMathType=mo;pmt(0x27C6);break;//\rbag
	
	case 0x50:pMathType=mo;pmt(0x27C5);break;//\Lbag
	case 0x51:pMathType=mo;pmt(0x27C6);break;//\Rbag
	case 0x52:pMathType=mo;pmt(0x29C0);break;//\circledless
	case 0x53:pMathType=mo;pmt(0x29C1);break;//\circledgtr
	case 0x54:p("<mo>");p(ul2utf8(0x2227));p(ul2utf8(0x20DD));p("</mo>");break;//\circledwedge
	case 0x55:p("<mo>");p(ul2utf8(0x2228));p(ul2utf8(0x20DD));p("</mo>");break;//\circledvee
	case 0x56:pMathType=mo;pmt(0x29B6);break;//\circledbar
	case 0x57:pMathType=mo;pmt(0x29B8);break;//\circledbslash
	case 0x58:pMathType=mo;pmt(0x22C9);break;//XXX?,\lJoin
	case 0x59:pMathType=mo;pmt(0x22CA);break;//XXX?,\rJoin
	case 0x5A:pMathType=mo;pmt(0x2A1D);break;//\Join
	case 0x5B:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\openJoin
	case 0x5C:pMathType=mo;pmt(0x22C8);break;//\lrtimes
	case 0x5D:pMathType=mo;pmt(0x2A09);break;//\opentimes
	case 0x5E:pMathType=mo;pmt(0x25C7);break;//\Diamond
	case 0x5F:pMathType=mo;pmt(0x25C6);break;//\Diamondblack

	case 0x60:pMathType=mo;pmt(0x22C2);break;//XXX n-ary intersection,\nplus
	case 0x61:p("<mo>");p(ul2utf8(0x228F));p(ul2utf8(0x0338));p("</mo>");break;//\nsqsubset
	case 0x62:p("<mo>");p(ul2utf8(0x2290));p(ul2utf8(0x0338));p("</mo>");break;//\nsqsupset
	case 0x63:pMathType=mo;pmt(0x21E0);break;//\dashleftarrow
	case 0x64:pMathType=mo;pmt(0x21E2);break;//\dashrightarrow
	case 0x65:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\dashleftrightarrow
	case 0x66:pMathType=mo;pmt(0x21DC);break;//\leftsquigarrow
	case 0x67:p("<mo>");p(ul2utf8(0x21A0));p(ul2utf8(0x0338));p("</mo>");break;//\ntwoheadrightarrow
	case 0x68:p("<mo>");p(ul2utf8(0x219E));p(ul2utf8(0x0338));p("</mo>");break;//\ntwoheadleftarrow
	case 0x69:pMathType=mo;pmt(0x29C6);break;//\boxast
	case 0x6A:pMathType=mo;pmt(0x2342);break;//\boxbslash
	case 0x6B:p("<mo>");p("|");p(ul2utf8(0x20DE));p("</mo>");break;//\boxbar
	case 0x6C:pMathType=mo;pmt(0x2341);break;//\boxslash
	case 0x6D:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1=frown,\Wr
	case 0x6E:pMathType=mo;pmt(0x019B);break;//\lambdaslash
	case 0x6F:pMathType=mo;pmt(0x019B);break;//\lambdabar
	
	case 0x70:pMathType=mo;pmt(0x2667);break;//\varclubsuit
	case 0x71:pMathType=mo;pmt(0x2666);break;//\vardiamondsuit
	case 0x72:pMathType=mo;pmt(0x2665);break;//\varheartsuit
	case 0x73:pMathType=mo;pmt(0x2664);break;//\varspadesuit
	case 0x74:pMathType=mo;pmt(0x2B01);break;//\Nearrow
	case 0x75:pMathType=mo;pmt(0x2B02);break;//\Searrow
	case 0x76:pMathType=mo;pmt(0x2B00);break;//\Nwarrow
	case 0x77:pMathType=mo;pmt(0x2B03);break;//\Swarrow
	case 0x78:pMathType=mo;pmt(0x2AEA);break;//\Top
	case 0x79:pMathType=mo;pmt(0x2AEB);break;//\Bot,\Perp
	case 0x7A:pMathType=mo;pmt(0x223C);break;//\leadstoext
	case 0x7B:pMathType=mo;pmt(0x219D);break;//\leadsto
	case 0x7C:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\sqcupplus
	case 0x7D:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\sqcapplus
	case 0x7E:pMathType=mo;pmt(0x301A);break;//\llbracket
	case 0x7F:pMathType=mo;pmt(0x301B);break;//\rrbracket
	
	case 0x80:p("<mo>");p(ul2utf8(0x25A1));p(ul2utf8(0x2192));p("</mo>");break;//\boxright
	case 0x81:p("<mo>");p(ul2utf8(0x2190));p(ul2utf8(0x25A1));p("</mo>");break;//\boxleft
	case 0x82:p("<mo>");p(ul2utf8(0x22A1));p(ul2utf8(0x2192));p("</mo>");break;//\boxdotright
	case 0x83:p("<mo>");p(ul2utf8(0x2190));p(ul2utf8(0x22A1));p("</mo>");break;//\boxdotleft
	case 0x84:p("<mo>");p(ul2utf8(0x22C4));p(ul2utf8(0x2192));p("</mo>");break;//\Diamondright
	case 0x85:p("<mo>");p(ul2utf8(0x2190));p(ul2utf8(0x22C4));p("</mo>");break;//\Diamondleft
	case 0x86:p("<mo>");p(ul2utf8(0x27D0));p(ul2utf8(0x2192));p("</mo>");break;//\Diamonddotright
	case 0x87:p("<mo>");p(ul2utf8(0x2190));p(ul2utf8(0x27D0));p("</mo>");break;//\Diamonddotleft
	case 0x88:p("<mo>");p(ul2utf8(0x25A1));p(ul2utf8(0x21D2));p("</mo>");break;//\boxRight
	case 0x89:p("<mo>");p(ul2utf8(0x21D0));p(ul2utf8(0x25A1));p("</mo>");break;//\boxLeft
	case 0x8A:p("<mo>");p(ul2utf8(0x22A1));p(ul2utf8(0x21D2));p("</mo>");break;//\boxdotRight
	case 0x8B:p("<mo>");p(ul2utf8(0x21D0));p(ul2utf8(0x22A1));p("</mo>");break;//\boxdotLeft
	case 0x8C:p("<mo>");p(ul2utf8(0x22C4));p(ul2utf8(0x21D2));p("</mo>");break;//\DiamondRight
	case 0x8D:p("<mo>");p(ul2utf8(0x21D0));p(ul2utf8(0x22C4));p("</mo>");break;//\DiamondLeft
	case 0x8E:p("<mo>");p(ul2utf8(0x27D0));p(ul2utf8(0x21D2));p("</mo>");break;//\DiamonddotRight
	case 0x8F:p("<mo>");p(ul2utf8(0x21D0));p(ul2utf8(0x27D0));p("</mo>");break;//\DiamonddotLeft

	case 0x90:pMathType=mo;pmt(0x27D0);break;//\Diamonddot
	case 0x91:p("<mo>");p(ul2utf8(0x25CB));p(ul2utf8(0x2192));p("</mo>");break;//\circleright
	case 0x92:p("<mo>");p(ul2utf8(0x2190));p(ul2utf8(0x25CB));p("</mo>");break;//\circleleft
	case 0x93:p("<mo>");p(ul2utf8(0x2299));p(ul2utf8(0x2192));p("</mo>");break;//\circledotright
	case 0x94:p("<mo>");p(ul2utf8(0x2190));p(ul2utf8(0x2299));p("</mo>");break;//\circledotleft
	case 0x95:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\multimapbothvert
	case 0x96:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\multimapdotbothvert
	case 0x97:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\multimapdotbothBvert
	case 0x98:pMathType=mo;pmt(0x2639);break;//XXX not found in Unicode 4.1,\multimapdotbothAvert
	default:pMathType=mo;pmt(*temp);
	}
	temp++;
}while(*temp);
return;
}

void fontMapCmTeX(){
//cmtex
unsigned char* temp=(unsigned char*)yytext;
	do{
		switch(*temp){
		case 0x00:pMathType=mo;pmt(0x00B7);break;//center dot
		case 0x01:pMathType=mo;pmt(0x2193);break;//downwards arrow
		case 0x02:pMathType=mi;pmt(0x0381);break;//alpha
		case 0x03:pMathType=mi;pmt(0x0382);break;//beta
		case 0x04:pMathType=mo;pmt(0x2227);break;//logical and
		case 0x05:pMathType=mo;pmt(0x00AC);break;//not sign
		case 0x06:pMathType=mo;pmt(0x2208);break;//element of
		case 0x07:pMathType=mi;pmt(0x03C0);break;//pi
		case 0x08:pMathType=mi;pmt(0x03BB);break;//lambda
		case 0x09:pMathType=mi;pmt(0x03B3);break;//gamma
		case 0x0A:pMathType=mi;pmt(0x03B4);break;//delta
		case 0x0B:pMathType=mo;pmt(0x2191);break;//upwards arrow
		case 0x0C:pMathType=mo;pmt(0x00B1);break;//plus-minus
		case 0x0D:pMathType=mo;pmt(0x2295);break;//circled plus,\oplus
		case 0x0E:pMathType=mn;pmt(0x221E);break;//infinity
		case 0x0F:pMathType=mo;pmt(0x2202);break;//partial differential

		case 0x10:pMathType=mo;pmt(0x2282);break;//subset of
		case 0x11:pMathType=mo;pmt(0x2283);break;//superset of
		case 0x12:pMathType=mo;pmt(0x2229);break;//intersection
		case 0x13:pMathType=mo;pmt(0x222A);break;//union
		case 0x14:pMathType=mo;pmt(0x2200);break;//for all
		case 0x15:pMathType=mo;pmt(0x2203);break;//there exists
		case 0x16:pMathType=mo;pmt(0x2297);break;//circled times,\otimes
		case 0x17:pMathType=mo;pmt(0x21C6);break;//left arrow over right arrow
		case 0x18:pMathType=mo;pmt(0x2190);break;//left arrow
		case 0x19:pMathType=mo;pmt(0x2192);break;//right arrow
		case 0x1A:pMathType=mo;pmt(0x2260);break;//not equal
		case 0x1B:pMathType=mo;pmt(0x25CA);break;//lozenge
		case 0x1C:pMathType=mo;pmt(0x2264);break;//less than or equal
		case 0x1D:pMathType=mo;pmt(0x2265);break;//greater than or equal
		case 0x1E:pMathType=mo;pmt(0x2261);break;//identical to
		case 0x1F:pMathType=mo;pmt(0x2228);break;//logical or

		case 0x20:break;//XXX:space?,nothing
		case 0x21:pMathType=mo;pmt(*temp);break;//right double quotation mark
		case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
		case 0x23:pMathType=mo;pmt(*temp);break;//sharp
		case 0x24:pMathType=mo;pmt(*temp);break;//$
		case 0x25:pMathType=mo;pmt(*temp);break;//%
		case 0x26:
				if (mathmode && !mathText){
					p("<mo>&amp;</mo>");
				}else 
					p("&amp;");
			break;//ampersand
		case 0x27:pMathType=mo;pmt(*temp);break;//'
		case 0x28:pMathType=mo;pmt(*temp);break;//(
		case 0x29:pMathType=mo;pmt(*temp);break;//)
		case 0x2A:
		case 0x2B:
		case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
		case 0x2D:
		case 0x2E:
		case 0x2F:pMathType=mo;pmt(*temp);break;
		case 0x30:
		case 0x31:
		case 0x32:
		case 0x33:
		case 0x34:
		case 0x35:
		case 0x36:
		case 0x37:
		case 0x38:
		case 0x39:pMathType=mn;pmt(*temp);break;
		case 0x3A:
		case 0x3B:pMathType=mo;pmt(*temp);break;
		case 0x3C:pMathType=mo;pmt(0x2039);break;//angle quotation
		case 0x3D:pMathType=mo;//equal
			precomposedNegative(*temp, 0x2260);
			break;
		case 0x3E:pMathType=mo;pmt(0x203A);break;//angle quotation
		case 0x3F:pMathType=mo;pmt(*temp);break;//question sign
		case 0x40:pMathType=mo;pmt(*temp);break;//at sign

		case 0x5B:pMathType=mo;pmt(*temp);break;//left bracket
		case 0x5C:pMathType=mo;pmt(*temp);break;//left double quotation mark
		case 0x5D:pMathType=mo;pmt(*temp);break;//right bracket
		case 0x5E:pMathType=mo;pmt(*temp);break;//^
		case 0x5F:pMathType=mo;pmt(*temp);break;//dot above

		case 0x60:pMathType=mo;pmt(*temp);break;//`

		case 0x7B:pMathType=mo;pmt(*temp);break;//left brace
		case 0x7C:pMathType=mo;pmt(*temp);break;//vertical bar
		case 0x7D:pMathType=mo;pmt(*temp);break;//right brace
		case 0x7E:pMathType=mo;pmt(*temp);break;//tilde
		case 0x7F:pMathType=mo;pmt(0x222B);break;//integral sign
		default:pMathType=mo;pmt(*temp);
		}
		temp++;
	}while(*temp);
	return;
}


void fontMapLasy(){
unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	//nothing here
	case 0x01:pMathType=mo;pmt(0x22B2);break;//normal subgroup of
	case 0x02:pMathType=mo;pmt(0x22B4);break;//normal subgroup of or equal to
	case 0x03:pMathType=mo;pmt(0x22B3);break;//contains as normal subgroup
	case 0x04:pMathType=mo;pmt(0x22B5);break;//contains as normal subgroup or equal to
	//nothing here
	case 0x28:pMathType=mo;pmt(0x227A);break;//precedes
	case 0x29:pMathType=mo;pmt(0x227B);break;//succeeds
	case 0x2A:pMathType=mo;pmt(0x22CF);break;//curly logical and
	case 0x2B:pMathType=mo;pmt(0x22CE);break;//curly logical or
	//nothing here
	
	case 0x30:pMathType=mo;pmt(0x2127);break;//inverted ohm greek omega
	case 0x31:pMathType=mo;pmt(0x22C8);break;//bowtie
	case 0x32:pMathType=mo;pmt(0x25A1);break;//white square
	case 0x33:pMathType=mo;pmt(0x25C7);break;//white diamond
	//nothing here
	
	case 0x3A:break;//XXX,extension to a squiggle arrow
	case 0x3B:pMathType=mo;pmt(0x21DD);break;//right squiggle arrow
	case 0x3C:pMathType=mo;pmt(0x228F);break;//square image of
	case 0x3D:pMathType=mo;pmt(0x2290);break;//square original of
	}
	temp++;
}while(*temp);
return;
}

void fontMapWasy(){
//wasy[b]
unsigned char* temp=(unsigned char*)yytext;
do{
	switch(*temp){
	case 0x00:pMathType=mo;pmt(0x25B3);break;//up-triangle white
	case 0x01:pMathType=mo;pmt(0x22B2);break;//normal subgroup of
	case 0x02:pMathType=mo;pmt(0x22B4);break;//normal subgroup of or equal to
	case 0x03:pMathType=mo;pmt(0x22B3);break;//contains as normal subgroup
	case 0x04:pMathType=mo;pmt(0x22B5);break;//contains as normal subgroup or equal to
	case 0x05:pMathType=mo;pmt(0x2234);break;//therefore
	case 0x06:pMathType=mo;pmt(0x2315);break;//recorder
	case 0x07:pMathType=mo;pmt(0x260E);break;//black telephone
	case 0x08:pMathType=mo;pmt(0x2713);break;//check mark
	case 0x09:pMathType=mo;pmt(0x27AA);break;//right \pointer
	case 0x0A:pMathType=mo;pmt(0x237E);break;//\bell
	case 0x0B:pMathType=mo;pmt(0x266A);break;//\eighthnote
	case 0x0C:pMathType=mo;pmt(0x2669);break;//\quarternote
	case 0x0D:pMathType=mo;pmt(0x1D15E);break;//\halfnote
	case 0x0E:pMathType=mo;pmt(0x1D15D);break;//\fullnote musical
	case 0x0F:pMathType=mo;pmt(0x266B);break;//\twonotes, beamed eigththnotes
	
	case 0x10:pMathType=mo;pmt(0x25C0);break;//left-triangle black
	case 0x11:pMathType=mo;pmt(0x25B6);break;//right-triangle black
	case 0x12:pMathType=mo;pmt(0x2607);break;//lightning
	case 0x13:pMathType=mo;pmt(0x260A);break;//ascending note
	case 0x14:pMathType=mo;pmt(0x260B);break;//descending note
	case 0x15:pMathType=mo;pmt(0x2349);break;//APL\invdiameter
	case 0x16:pMathType=mo;pmt(0x235F);break;//XXX?,circle star, \APLlog
	case 0x17:pMathType=mo;pmt(0x2648);break;//\vernal, XXX is it \aries?
	case 0x18:pMathType=mo;pmt(0x2310);break;//reversed not, \invneg
	case 0x19:pMathType=mo;pmt(0x2640);break;//\venus
	case 0x1A:pMathType=mo;pmt(0x2642);break;//male sign, \mars
	case 0x1B:pMathType=mo;pmt(0x00A4);break;//\currency
	case 0x1C:pMathType=mo;pmt(0x231A);break;//\clock
	case 0x1D:pMathType=mo;pmt(0x221D);break;//\propto
	case 0x1E:pMathType=mo;pmt(0x2222);break;//\varangle
	case 0x1F:pMathType=mo;pmt(0x2300);break;//\diameter
	
	case 0x20:pMathType=mo;pmt(0x26AB);break;//black circle
	case 0x21:pMathType=mo;pmt(0x27F3);break;//\rightturn
	case 0x22:pMathType=mo;pmt(0x27F2);break;//\leftturn
	case 0x23:pMathType=mo;pmt(0x26AC);break;//white circle
	case 0x24:pMathType=mo;pmt(0x263E);break;//\leftmoon
	case 0x25:pMathType=mo;pmt(0x263D);break;//\rightmoon
	case 0x26:pMathType=mo;pmt(0x2641);break;//\earth
	case 0x27:pMathType=mo;pmt(0x263F);break;//\mercury
	case 0x28:pMathType=mo;pmt(0x2039);break;//left quot angle
	case 0x29:pMathType=mo;pmt(0x203A);break;//right quot angle
	case 0x2A:pMathType=mo;pmt(0x2303);break;//up arrowhead
	case 0x2B:pMathType=mo;pmt(0x2304);break;//down arrowhead
	case 0x2C:pMathType=mo;pmt(0x263A);break;//\whitesmiley
	case 0x2D:pMathType=mo;pmt(0x263B);break;//\blacksmiley
	case 0x2E:pMathType=mo;pmt(0x263C);break;//\sun
	case 0x2F:pMathType=mo;pmt(0x2639);break;//\frownie
	
	case 0x30:pMathType=mo;pmt(0x2127);break;//inverted ohm sign
	case 0x31:pMathType=mo;pmt(0x22C8);break;//\Bowtie
	case 0x32:pMathType=mo;pmt(0x2395);break;//\APLbox
	case 0x33:pMathType=mo;pmt(0x25C7);break;//\Diamond
	case 0x34:pMathType=mo;pmt(0x2612);break;//\XBox
	case 0x35:pMathType=mo;pmt(0x25CA);break;//\lozenge
	case 0x36:pMathType=mo;pmt(0x2720);break;//maltese cross, \kreuz
	case 0x37:pMathType=mo;pmt(0x2394);break;//software function, \hexagon
	case 0x38:pMathType=mo;pmt(0x2639);break;//XXX :( not found in Unicode 4.1,\octagon
	case 0x39:pMathType=mo;pmt(0x232C);break;//XXX?,benzene,\varhexagon
	case 0x3A:pMathType=mo;pmt(0x223C);break;//APL tilde,\APLnot
	case 0x3B:pMathType=mo;pmt(0x219D);break;//rightwards wave arrow
	case 0x3C:pMathType=mo;pmt(0x228F);break;//square image of
	case 0x3D:pMathType=mo;pmt(0x2290);break;//square original of
	case 0x3E:pMathType=mo;pmt(0x2272);break;//less-than or equivalent to
	case 0x3F:pMathType=mo;pmt(0x2273);break;//greater-than or equivalent to
	
	case 0x40:pMathType=mo;pmt(0x224B);break;//triple tilde
	case 0x41:pMathType=mo;pmt(0x2217);break;//XXX,asterisk operator,\hexstar
	case 0x42:pMathType=mo;pmt(0x2217);break;//XXX not in Unicode4.1,asterisk operator,\varhexstar
	case 0x43:pMathType=mo;pmt(0x2721);break;//\davidsstar
	case 0x44:pMathType=mo;pmt(0x2639);break;//XXX :( not found in Unicode 4.1,\pentagon
	case 0x45:pMathType=mo;pmt(0x2639);break;//XXX :( not found in Unicode 4.1,\APLstar
	case 0x46:pMathType=mo;pmt(0x25BD);break;//\APL down, white triangle down 
	case 0x47:pMathType=mo;pmt(0x25D6);break;//left half black circle,\leftcircle
	case 0x48:pMathType=mo;pmt(0x25D7);break;//right half black circle,\rightcircle
	case 0x49:pMathType=mo;pmt(0x25D6);break;//XXX: should be white, left half black circle,\leftcircle
	case 0x4A:pMathType=mo;pmt(0x25D7);break;//XXX: should be white, right half black circle,\rightcircle
	case 0x4B:pMathType=mo;pmt(0x25B2);break;//black up triangle, \UParrow
	case 0x4C:pMathType=mo;pmt(0x25BC);break;//black down triangle, \DOWNarrow
	case 0x4D:
	case 0x4E:
	case 0x4F:break;//nothing

	case 0x50:pMathType=mo;pmt(0x2639);break;//XXX:not found in U4.1,\gluonelement
	case 0x51:pMathType=mo;pmt(0x2639);break;//XXX:not found in U4.1,\gluonbelement
	case 0x52:pMathType=mo;pmt(0x2639);break;//XXX:not found in U4.1,\gluoneelement
	case 0x53:
	case 0x54:break;//nothing
	case 0x55:pMathType=mo;pmt(0x01DD);break;//small letter turned e, \inve
	case 0x56:pMathType=mo;pmt(0x260C);break;//conjunction
	case 0x57:pMathType=mo;pmt(0x260D);break;//opposition
	case 0x58:pMathType=mo;pmt(0x2643);break;//jupiter
	case 0x59:pMathType=mo;pmt(0x2644);break;//saturn
	case 0x5A:pMathType=mo;pmt(0x2645);break;//uranus
	case 0x5B:pMathType=mo;pmt(0x2646);break;//neptune
	case 0x5C:pMathType=mo;pmt(0x2647);break;//pluto
	case 0x5D:pMathType=mo;pmt(0x2649);break;//taurus
	case 0x5E:pMathType=mo;pmt(0x264A);break;//gemini
	case 0x5F:pMathType=mo;pmt(0x264B);break;//cancer

	case 0x60:pMathType=mo;pmt(0x264D);break;//virgo
	case 0x61:pMathType=mo;pmt(0x264E);break;//libra
	case 0x62:pMathType=mo;pmt(0x264F);break;//scorpius
	case 0x63:pMathType=mo;pmt(0x2650);break;//saggitarius
	case 0x64:pMathType=mo;pmt(0x2651);break;//capricorn
	case 0x65:pMathType=mo;pmt(0x2652);break;//aquarius
	case 0x66:pMathType=mo;pmt(0x2653);break;//pisces
	case 0x67:pMathType=mo;pmt(0x00A2);break;//cent sign
	case 0x68:pMathType=mo;pmt(0x2030);break;//\permil
	case 0x69:pMathType=mo;pmt(0x00FE);break;//\thorn
	case 0x6A:pMathType=mo;pmt(0x00DE);break;//\THORN
	case 0x6B:pMathType=mo;pmt(0x00F0);break;//eth, \dh
	case 0x6C:pMathType=mo;pmt(0x0254);break;//\openo
	case 0x6D:pMathType=mo;pmt(0x2639);break;//XXX:not found in U4.1,\ataribox
	case 0x6E:pMathType=mo;pmt(0x2350);break;//\APLuparrowbox
	case 0x6F:pMathType=mo;pmt(0x2357);break;//\APLdownarrowbox

	case 0x70:pMathType=mo;pmt(0x2347);break;//\APLleftarrowbox
	case 0x71:pMathType=mo;pmt(0x2348);break;//\APLrightarrowbox
	case 0x72:pMathType=mo;pmt(0x222B);break;//integral, \int
	case 0x73:pMathType=mo;pmt(0x222C);break;//\iint
	case 0x74:pMathType=mo;pmt(0x222D);break;//\iiint
	case 0x75:pMathType=mo;pmt(0x222E);break;//\oint
	case 0x76:pMathType=mo;pmt(0x222F);break;//\oiint
	case 0x77:pMathType=mo;pmt(0x222B);break;//integral, \int
	case 0x78:pMathType=mo;pmt(0x222C);break;//\iint
	case 0x79:pMathType=mo;pmt(0x222D);break;//\iiint
	case 0x7A:pMathType=mo;pmt(0x222E);break;//\oint
	case 0x7B:pMathType=mo;pmt(0x222F);break;//\oiint
	case 0x7C:pMathType=mo;pmt('|');break;//|
	case 0x7D:pMathType=mo;pmt(0x235E);break;//XXX:?, APL quote,\APLinput
	case 0x7E:pMathType=mo;pmt(0x2395);break;//APL quad,\APLbox
	case 0x7F:pMathType=mo;pmt(0x2639);break;//XXX:not found in U4.1,\APLcomment

	}
	temp++;
}while(*temp);
return;
}

void fontMap7c(){//eufm
unsigned char* temp=(unsigned char*)yytext;
int staticFontFamily;

	do{
		switch(*temp){
		case 0x00:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0076);
			theFont.family=staticFontFamily;
		break;//v, should be pmt(0x1D533),FIXME not sure
		case 0x01:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0064);
			theFont.family=staticFontFamily;
		break;//d, should be pmt(0x1D521),FIXME not sure
		case 0x02:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0066);
			theFont.family=staticFontFamily;
		break;//f, should be pmt(0x1D523),FIXME not sure
		case 0x03:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0066);
			theFont.family=staticFontFamily;
		break;//f, should be pmt(0x1D523),FIXME not sure
		case 0x04:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0067);
			theFont.family=staticFontFamily;
		break;//g, should be pmt(0x1D524),FIXME not sure
		case 0x05:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x006B);
			theFont.family=staticFontFamily;
		break;//k, should be pmt(0x1D528),FIXME not sure
		case 0x06:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0074);
			theFont.family=staticFontFamily;
		break;//t, should be pmt(0x1D531),FIXME not sure
		case 0x07:pMathType=mo;
			staticFontFamily=theFont.family;
			theFont.family=fraktur;
			pmt(0x0075);
			theFont.family=staticFontFamily;
		break;//u, should be pmt(0x1D532),FIXME not sure
		
		//nothing
		
		case 0x12:pMathType=mo;pmt(0x2018);break;//leftquote
		case 0x13:pMathType=mo;pmt(0x2019);break;//rightquote
		
		//nothing
		
		case 0x21:pMathType=mo;pmt(*temp);break;//!
		
		//nothing
		
		case 0x26:
			if (mathmode && !mathText){
				p("<mo>&amp;</mo>");
			}else 
				p("&amp;");
			break;//ampersand
		case 0x27:
			if (mathmode && !mathText){
				p("<mo>&apos;</mo>");
			}else 
				p("&apos;");
			break;//single quote, apostrophe
		case 0x28:pMathType=mo;pmt(*temp);break;//(
		case 0x29:pMathType=mo;pmt(*temp);break;//)
		case 0x2A:
		case 0x2B:
		case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
		case 0x2D:
		case 0x2E:
		case 0x2F:pMathType=mo;pmt(*temp);break;

		case 0x30:
		case 0x31:
		case 0x32:
		case 0x33:
		case 0x34:
		case 0x35:
		case 0x36:
		case 0x37:
		case 0x38:
		case 0x39:pMathType=mn;pmt(*temp);break;
		case 0x3A:
		case 0x3B:pMathType=mo;pmt(*temp);break;//;
		//nothing
		case 0x3D:pMathType=mo; //equal
			precomposedNegative(*temp, 0x2260);
			break;
		//nothing
		case 0x3F:

		case 0x41:
		case 0x42:pMathType=mo;staticFontFamily=theFont.family;
			theFont.family=fraktur;pmt(*temp);
			theFont.family=staticFontFamily;
			break;
		case 0x43:pMathType=mo;pmt(0x212D);break;//fraktur C
		case 0x44:
		case 0x45:
		case 0x46:
		case 0x47:pMathType=mo;staticFontFamily=theFont.family;
			theFont.family=fraktur;pmt(*temp);
			theFont.family=staticFontFamily;
			break;
		case 0x48:pMathType=mo;pmt(0x210C);break;//fraktur H
		case 0x49:pMathType=mo;pmt(0x2111);break;//fraktur I
		case 0x4A:
		case 0x4B:
		case 0x4C:
		case 0x4D:
		case 0x4E:
		case 0x4F:

		case 0x50:
		case 0x51:pMathType=mo;staticFontFamily=theFont.family;
			theFont.family=fraktur;pmt(*temp);
			theFont.family=staticFontFamily;
			break;
		case 0x52:pMathType=mo;pmt(0x211C);break;//fraktur R
		case 0x53:
		case 0x54:
		case 0x55:
		case 0x56:
		case 0x57:
		case 0x58:
		case 0x59:pMathType=mo;staticFontFamily=theFont.family;
			theFont.family=fraktur;pmt(*temp);
			theFont.family=staticFontFamily;
			break;
		case 0x5A:pMathType=mo;pmt(0x2128);break;//fraktur Z

		case 0x5B:pMathType=mo;pmt(*temp);break;//[
		//nothing
		case 0x5D:pMathType=mo;pmt(*temp);break;//]
		case 0x5E:pMathType=mo;pmt(*temp);break;//^
		
		//nothing

		case 0x61:
		case 0x62:
		case 0x63:
		case 0x64:
		case 0x65:
		case 0x66:
		case 0x67:
		case 0x68:
		case 0x69:
		case 0x6A:
		case 0x6B:
		case 0x6C:
		case 0x6D:
		case 0x6E:
		case 0x6F:

		case 0x70:
		case 0x71:
		case 0x72:
		case 0x73:
		case 0x74:
		case 0x75:
		case 0x76:
		case 0x77:
		case 0x78:
		case 0x79:
		case 0x7A:pMathType=mo;staticFontFamily=theFont.family;
			theFont.family=fraktur;pmt(*temp);
			theFont.family=staticFontFamily;
			break;	//pmt(0x1D59F);break;//fraktur a-z
		//nothing
		case 0x7D:pMathType=mo;pmt(0x0022);break;//quotation mark, (XXX)
		//nothing

		}
		temp++;
	}while(*temp) ;
	return;
}

/* mappings to be integrated later

		if (strstr(currentFont,"eurm")){//identical to cmmi, but upright
		do{
			switch(*temp){
			case 0x00:pMathType=mo;pmt(0x0393);break;//Gamma
			case 0x01:pMathType=mo;pmt(0x0394);break;//Delta
			case 0x02:pMathType=mo;pmt(0x0398);break;//Theta
			case 0x03:pMathType=mo;pmt(0x039B);break;//Lambda
			case 0x04:pMathType=mo;pmt(0x039E);break;//Xi
			case 0x05:pMathType=mo;pmt(0x03A0);break;//Pi
			case 0x06:pMathType=mo;pmt(0x03A3);break;//Sigma
			case 0x07:pMathType=mo;pmt(0x03D2);break;//Upsilon with hook
			case 0x08:pMathType=mo;pmt(0x03A6);break;//Phi
			case 0x09:pMathType=mo;pmt(0x03A8);break;//Psi
			case 0x0A:pMathType=mo;pmt(0x03A9);break;//Omega
			case 0x0B:pMathType=mo;pmt(0x03B1);break;//alpha
			case 0x0C:pMathType=mo;pmt(0x03B2);break;//beta
			case 0x0D:pMathType=mo;pmt(0x03B3);break;//gamma
			case 0x0E:pMathType=mo;pmt(0x03B4);break;//delta
			case 0x0F:pMathType=mo;pmt(0x03B5);break;//epsilon

			case 0x10:pMathType=mo;pmt(0x03B6);break;//zeta
			case 0x11:pMathType=mo;pmt(0x03B7);break;//eta
			case 0x12:pMathType=mo;pmt(0x03B8);break;//theta
			case 0x13:pMathType=mo;pmt(0x03B9);break;//iota
			case 0x14:pMathType=mo;pmt(0x03BA);break;//kappa
			case 0x15:pMathType=mo;pmt(0x03BB);break;//lambda
			case 0x16:pMathType=mo;pmt(0x03BC);break;//mu
			case 0x17:pMathType=mo;pmt(0x03BD);break;//nu
			case 0x18:pMathType=mo;pmt(0x03BE);break;//xi
			case 0x19:pMathType=mo;pmt(0x03C0);break;//pi
			case 0x1A:pMathType=mo;pmt(0x03C1);break;//ro
			case 0x1B:pMathType=mo;pmt(0x03C3);break;//sigma
			case 0x1C:pMathType=mo;pmt(0x03C4);break;//tau
			case 0x1D:pMathType=mo;pmt(0x03C5);break;//upsilon
			case 0x1E:pMathType=mo;pmt(0x03C6);break;//phi
			case 0x1F:pMathType=mo;pmt(0x03C7);break;//chi

			case 0x20:pMathType=mo;pmt(0x03C8);break;//psi
			case 0x21:pMathType=mo;pmt(0x03C9);break;//omega
			case 0x22:pMathType=mo;pmt(0x025B);break;//latin epsilon
			case 0x23:pMathType=mo;pmt(0x03D1);break;//script theta
			case 0x24:pMathType=mo;pmt(0x03D6);break;//varpi

			//nothing here

			case 0x30:
			case 0x31:
			case 0x32:
			case 0x33:
			case 0x34:
			case 0x35:
			case 0x36:
			case 0x37:
			case 0x38:
			case 0x39:pMathType=mn;pmt(*temp);break;//digits
			case 0x3A:pMathType=mo;pmt(0x002E);break;//dot
			case 0x3B:pMathType=mo;pmt(0x002C);break;//comma
			case 0x3C://less than
				if(combiningUnicode==0x0338) { 
					combiningUnicode=0;
					pmt(0x226F);
				}	else	p("<mo mathvariant=\"normal\">&lt;</mo>");
				break;
			case 0x3D:pMathType=mo;pmt(0x002F);break;//division
			case 0x3E: //greater than
				if(combiningUnicode==0x0338) { 
					combiningUnicode=0;
					pmt(0x226F);
				}	else	p("<mo mathvariant=\"normal\">&gt;</mo>");
				break;
			//nothing here
			
			case 0x40:pMathType=mo;pmt(0x2202);break;//partial diff

			//nothing here

			case 0x60:pMathType=mo;pmt(0x2113);break;//ell script

			case 0x7B:pMathType=mo;pmt(0x0131);break;//imath
			case 0x7C:pMathType=mo;pmt(0x006A);break;//jmath,pmt(0x0237);break;//jmath
			case 0x7D:pMathType=mos;pmt('P');break;//pMathType=mo;pmt(0x2188);break;//script capital P
			//nothing here
			
			default:pMathType=mo;pmt(*temp);
			}
			temp++;
		}while(*temp);
		return;
	}

	
	if (strstr(currentFont,"wncyr")){//cyrillic
		do{
			switch(*temp){
			case 0x00:pMathType=mo;pmt(0x040A);break;//NJE
			case 0x01:pMathType=mo;pmt(0x0409);break;//LJE
			case 0x02:pMathType=mo;pmt(0x040F);break;//DZHE
			case 0x03:pMathType=mo;pmt(0x042D);break;//E
			case 0x04:pMathType=mo;pmt(0x0406);break;//I
			case 0x05:pMathType=mo;pmt(0x0404);break;//Ukrainian IE
			case 0x06:pMathType=mo;pmt(0x0402);break;//DJE
			case 0x07:pMathType=mo;pmt(0x040B);break;//TSHE
			case 0x08:pMathType=mo;pmt(0x045A);break;//nje
			case 0x09:pMathType=mo;pmt(0x0459);break;//lje
			case 0x0A:pMathType=mo;pmt(0x045F);break;//dzhe
			case 0x0B:pMathType=mo;pmt(0x044D);break;//e
			case 0x0C:pMathType=mo;pmt(0x0456);break;//i
			case 0x0D:pMathType=mo;pmt(0x0454);break;//ukrainian ie
			case 0x0E:pMathType=mo;pmt(0x0452);break;//dje
			case 0x0F:pMathType=mo;pmt(0x045B);break;//tshe

			case 0x10:pMathType=mo;pmt(0x042E);break;//YU
			case 0x11:pMathType=mo;pmt(0x0416);break;//ZHE
			case 0x12:pMathType=mo;pmt(0x0419);break;//short I
			case 0x13:pMathType=mo;pmt(0x0401);break;//IO
			case 0x14:pMathType=mo;pmt(0x0474);break;//IZHITSA
			case 0x15:pMathType=mo;pmt(0x0472);break;//FITA
			case 0x16:pMathType=mo;pmt(0x0405);break;//DZE
			case 0x17:pMathType=mo;pmt(0x042F);break;//YA
			case 0x18:pMathType=mo;pmt(0x044E);break;//yu
			case 0x19:pMathType=mo;pmt(0x0436);break;//zhe
			case 0x1A:pMathType=mo;pmt(0x0439);break;//short i
			case 0x1B:pMathType=mo;pmt(0x0451);break;//io
			case 0x1C:pMathType=mo;pmt(0x0475);break;//izhitsa
			case 0x1D:pMathType=mo;pmt(0x0473);break;//fita
			case 0x1E:pMathType=mo;pmt(0x0455);break;//dze
			case 0x1F:pMathType=mo;pmt(0x044F);break;//ya

			case 0x20:pMathType=mo;pmt(0x00A8);break;//diaeresis
			case 0x21:pMathType=mo;pmt(*temp);break;//!
			case 0x22:pMathType=mo;pmt(0x201D);break;//right double quotation mark
			case 0x23:pMathType=mo;pmt(0x0462);break;//YAT
			case 0x24:pMathType=mo;pmt(0x02D8);break;//breve XXX should be breve1
			case 0x25:pMathType=mo;pmt(*temp);break;//%
			case 0x26:pMathType=mo;pmt(0x00B4);break;//acute 
			case 0x27:pMathType=mo;pmt(0x2019);break;//quoteright
			case 0x28:pMathType=mo;pmt(*temp);break;//(
			case 0x29:pMathType=mo;pmt(*temp);break;//)
			case 0x2A:pMathType=mo;pmt(*temp);break;//ascii multiplication
			case 0x2B:pMathType=mo;pmt(0x0463);break;//yat
			case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
			case 0x2D://-
			case 0x2E://.
			case 0x2F:pMathType=mo;pmt(*temp);break;//slash

			case 0x30:
			case 0x31:
			case 0x32:
			case 0x33:
			case 0x34:
			case 0x35:
			case 0x36:
			case 0x37:
			case 0x38:
			case 0x39:pMathType=mn;pmt(*temp);break;//arabic numerals
			case 0x3A:pMathType=mo;pmt(*temp);break;//:
			case 0x3B:pMathType=mo;pmt(*temp);break;//;
			case 0x3C:pMathType=mo;pmt(0x00AB);break;//guillemet left 
			case 0x3D:pMathType=mo;pmt(0x0131);break;//imath
			case 0x3E:pMathType=mo;pmt(0x00BB);break;//guillemet right 
			case 0x3F:pMathType=mo;pmt(*temp);break;//?

			case 0x40:pMathType=mo;pmt(0x02D8);break;//breve 
			case 0x41:pMathType=mo;pmt(0x0410);break;//A
			case 0x42:pMathType=mo;pmt(0x0411);break;//BE
			case 0x43:pMathType=mo;pmt(0x0426);break;//TSE
			case 0x44:pMathType=mo;pmt(0x0414);break;//DE
			case 0x45:pMathType=mo;pmt(0x0415);break;//IE
			case 0x46:pMathType=mo;pmt(0x0424);break;//EF
			case 0x47:pMathType=mo;pmt(0x0413);break;//GHE
			case 0x48:pMathType=mo;pmt(0x0425);break;//HA
			case 0x49:pMathType=mo;pmt(0x0418);break;//I
			case 0x4A:pMathType=mo;pmt(0x0408);break;//JE
			case 0x4B:pMathType=mo;pmt(0x041A);break;//KA
			case 0x4C:pMathType=mo;pmt(0x041B);break;//EL
			case 0x4D:pMathType=mo;pmt(0x041C);break;//EM
			case 0x4E:pMathType=mo;pmt(0x041D);break;//EN
			case 0x4F:pMathType=mo;pmt(0x041E);break;//O

			case 0x50:pMathType=mo;pmt(0x041F);break;//PE
			case 0x51:pMathType=mo;pmt(0x0427);break;//CHE
			case 0x52:pMathType=mo;pmt(0x0420);break;//ER
			case 0x53:pMathType=mo;pmt(0x0421);break;//ES
			case 0x54:pMathType=mo;pmt(0x0422);break;//TE
			case 0x55:pMathType=mo;pmt(0x0423);break;//U
			case 0x56:pMathType=mo;pmt(0x0412);break;//VE
			case 0x57:pMathType=mo;pmt(0x0429);break;//SHCHA
			case 0x58:pMathType=mo;pmt(0x0428);break;//SHA
			case 0x59:pMathType=mo;pmt(0x042B);break;//YERU
			case 0x5A:pMathType=mo;pmt(0x0417);break;//ZE
			
			case 0x5B:pMathType=mo;pmt(*temp);break;//left bracket
			case 0x5C:pMathType=mo;pmt(0x201C);break;//left double quotation mark
			case 0x5D:pMathType=mo;pmt(*temp);break;//right bracket
			case 0x5E:pMathType=mo;pmt(0x044C);break;//soft sign
			case 0x5F:pMathType=mo;pmt(0x044A);break;//hard sign

			case 0x60:pMathType=mo;pmt(*temp);break;//`
			case 0x61:pMathType=mo;pmt(0x0430);break;//a 
			case 0x62:pMathType=mo;pmt(0x0431);break;//be
			case 0x63:pMathType=mo;pmt(0x0446);break;//tse
			case 0x64:pMathType=mo;pmt(0x0434);break;//de
			case 0x65:pMathType=mo;pmt(0x0435);break;//ie
			case 0x66:pMathType=mo;pmt(0x0444);break;//ef
			case 0x67:pMathType=mo;pmt(0x0433);break;//ghe
			case 0x68:pMathType=mo;pmt(0x0445);break;//ha
			case 0x69:pMathType=mo;pmt(0x0438);break;//i
			case 0x6A:pMathType=mo;pmt(0x0458);break;//je
			case 0x6B:pMathType=mo;pmt(0x043A);break;//ka
			case 0x6C:pMathType=mo;pmt(0x043B);break;//el
			case 0x6D:pMathType=mo;pmt(0x043C);break;//em
			case 0x6E:pMathType=mo;pmt(0x043D);break;//en
			case 0x6F:pMathType=mo;pmt(0x043E);break;//o
			case 0x70:pMathType=mo;pmt(0x043F);break;//pe
			case 0x71:pMathType=mo;pmt(0x0447);break;//che
			case 0x72:pMathType=mo;pmt(0x0440);break;//er
			case 0x73:pMathType=mo;pmt(0x0441);break;//es
			case 0x74:pMathType=mo;pmt(0x0442);break;//te
			case 0x75:pMathType=mo;pmt(0x0443);break;//u
			case 0x76:pMathType=mo;pmt(0x0432);break;//ve
			case 0x77:pMathType=mo;pmt(0x0449);break;//shcha
			case 0x78:pMathType=mo;pmt(0x0448);break;//sha
			case 0x79:pMathType=mo;pmt(0x044B);break;//yeru
			case 0x7A:pMathType=mo;pmt(0x0437);break;//ze
			
			case 0x7B:pMathType=mo;pmt(0x2013);break;//en dash
			case 0x7C:pMathType=mo;pmt(0x2014);break;//em dash
			case 0x7D:pMathType=mo;pmt(0x2116);break;//numero sign
			case 0x7E:pMathType=mo;pmt(0x044C);break;//soft
			case 0x7F:pMathType=mo;pmt(0x044A);break;//hard
			default:pMathType=mo;pmt(*temp);
			}
			temp++;
		}while(*temp);
		return;
	}

	if (strstr(currentFont,"wncyi")){//cyrillic
		do{
			switch(*temp){
			case 0x00:pMathType=mi;pmt(0x040A);break;//NJE
			case 0x01:pMathType=mi;pmt(0x0409);break;//LJE
			case 0x02:pMathType=mi;pmt(0x040F);break;//DZHE
			case 0x03:pMathType=mi;pmt(0x042D);break;//E
			case 0x04:pMathType=mi;pmt(0x0406);break;//I
			case 0x05:pMathType=mi;pmt(0x0404);break;//Ukrainian IE
			case 0x06:pMathType=mi;pmt(0x0402);break;//DJE
			case 0x07:pMathType=mi;pmt(0x040B);break;//TSHE
			case 0x08:pMathType=mi;pmt(0x045A);break;//nje
			case 0x09:pMathType=mi;pmt(0x0459);break;//lje
			case 0x0A:pMathType=mi;pmt(0x045F);break;//dzhe
			case 0x0B:pMathType=mi;pmt(0x044D);break;//e
			case 0x0C:pMathType=mi;pmt(0x0456);break;//i
			case 0x0D:pMathType=mi;pmt(0x0454);break;//ukrainian ie
			case 0x0E:pMathType=mi;pmt(0x0452);break;//dje
			case 0x0F:pMathType=mi;pmt(0x045B);break;//tshe

			case 0x10:pMathType=mi;pmt(0x042E);break;//YU
			case 0x11:pMathType=mi;pmt(0x0416);break;//ZHE
			case 0x12:pMathType=mi;pmt(0x0419);break;//short I
			case 0x13:pMathType=mi;pmt(0x0401);break;//IO
			case 0x14:pMathType=mi;pmt(0x0474);break;//IZHITSA
			case 0x15:pMathType=mi;pmt(0x0472);break;//FITA
			case 0x16:pMathType=mi;pmt(0x0405);break;//DZE
			case 0x17:pMathType=mi;pmt(0x042F);break;//YA
			case 0x18:pMathType=mi;pmt(0x044E);break;//yu
			case 0x19:pMathType=mi;pmt(0x0436);break;//zhe
			case 0x1A:pMathType=mi;pmt(0x0439);break;//short i
			case 0x1B:pMathType=mi;pmt(0x0451);break;//io
			case 0x1C:pMathType=mi;pmt(0x0475);break;//izhitsa
			case 0x1D:pMathType=mi;pmt(0x0473);break;//fita
			case 0x1E:pMathType=mi;pmt(0x0455);break;//dze
			case 0x1F:pMathType=mi;pmt(0x044F);break;//ya

			case 0x20:pMathType=moi;pmt(0x00A8);break;//diaeresis
			case 0x21:pMathType=moi;pmt(*temp);break;//!
			case 0x22:pMathType=moi;pmt(0x201D);break;//right double quotation mark
			case 0x23:pMathType=mi;pmt(0x0462);break;//YAT
			case 0x24:pMathType=moi;pmt(0x02D8);break;//breve XXX should be breve1
			case 0x25:pMathType=moi;pmt(*temp);break;//%
			case 0x26:pMathType=moi;pmt(0x00B4);break;//acute 
			case 0x27:pMathType=moi;pmt(0x2019);break;//quoteright
			case 0x28:pMathType=ldi;pmt(*temp);break;//(
			case 0x29:pMathType=rdi;pmt(*temp);break;//)
			case 0x2A:pMathType=moi;pmt(*temp);break;//ascii multiplication sign
			case 0x2B:pMathType=mi;pmt(0x0463);break;//yat
			case 0x2C:inhibitspace=0;pMathType=moi;pmt(*temp);break;
			case 0x2D://-
			case 0x2E://.
			case 0x2F:pMathType=moi;pmt(*temp);break;//slash

			case 0x30:
			case 0x31:
			case 0x32:
			case 0x33:
			case 0x34:
			case 0x35:
			case 0x36:
			case 0x37:
			case 0x38:
			case 0x39:pMathType=mni;pmt(*temp);break;//arabic numerals
			case 0x3A:pMathType=moi;pmt(*temp);break;//:
			case 0x3B:pMathType=moi;pmt(*temp);break;//;
			case 0x3C:pMathType=moi;pmt(0x00AB);break;//guillemet left 
			case 0x3D:pMathType=moi;pmt(0x0131);break;//imath
			case 0x3E:pMathType=moi;pmt(0x00BB);break;//guillemet right 
			case 0x3F:pMathType=moi;pmt(*temp);break;//?

			case 0x40:pMathType=moi;pmt(0x02D8);break;//breve 
			case 0x41:pMathType=mi;pmt(0x0410);break;//A
			case 0x42:pMathType=mi;pmt(0x0411);break;//BE
			case 0x43:pMathType=mi;pmt(0x0426);break;//TSE
			case 0x44:pMathType=mi;pmt(0x0414);break;//DE
			case 0x45:pMathType=mi;pmt(0x0415);break;//IE
			case 0x46:pMathType=mi;pmt(0x0424);break;//EF
			case 0x47:pMathType=mi;pmt(0x0413);break;//GHE
			case 0x48:pMathType=mi;pmt(0x0425);break;//HA
			case 0x49:pMathType=mi;pmt(0x0418);break;//I
			case 0x4A:pMathType=mi;pmt(0x0408);break;//JE
			case 0x4B:pMathType=mi;pmt(0x041A);break;//KA
			case 0x4C:pMathType=mi;pmt(0x041B);break;//EL
			case 0x4D:pMathType=mi;pmt(0x041C);break;//EM
			case 0x4E:pMathType=mi;pmt(0x041D);break;//EN
			case 0x4F:pMathType=mi;pmt(0x041E);break;//O

			case 0x50:pMathType=mi;pmt(0x041F);break;//PE
			case 0x51:pMathType=mi;pmt(0x0427);break;//CHE
			case 0x52:pMathType=mi;pmt(0x0420);break;//ER
			case 0x53:pMathType=mi;pmt(0x0421);break;//ES
			case 0x54:pMathType=mi;pmt(0x0422);break;//TE
			case 0x55:pMathType=mi;pmt(0x0423);break;//U
			case 0x56:pMathType=mi;pmt(0x0412);break;//VE
			case 0x57:pMathType=mi;pmt(0x0429);break;//SHCHA
			case 0x58:pMathType=mi;pmt(0x0428);break;//SHA
			case 0x59:pMathType=mi;pmt(0x042B);break;//YERU
			case 0x5A:pMathType=mi;pmt(0x0417);break;//ZE
			
			case 0x5B:pMathType=ldi;pmt(*temp);break;//left bracket
			case 0x5C:pMathType=ldi;pmt(0x201C);break;//left double quotation mark
			case 0x5D:pMathType=rdi;pmt(*temp);break;//right bracket
			case 0x5E:pMathType=moi;pmt(0x044C);break;//soft sign
			case 0x5F:pMathType=moi;pmt(0x044A);break;//hard sign

			case 0x60:pMathType=moi;pmt(*temp);break;//`
			case 0x61:pMathType=mi;pmt(0x0430);break;//a 
			case 0x62:pMathType=mi;pmt(0x0431);break;//be
			case 0x63:pMathType=mi;pmt(0x0446);break;//tse
			case 0x64:pMathType=mi;pmt(0x0434);break;//de
			case 0x65:pMathType=mi;pmt(0x0435);break;//ie
			case 0x66:pMathType=mi;pmt(0x0444);break;//ef
			case 0x67:pMathType=mi;pmt(0x0433);break;//ghe
			case 0x68:pMathType=mi;pmt(0x0445);break;//ha
			case 0x69:pMathType=mi;pmt(0x0438);break;//i
			case 0x6A:pMathType=mi;pmt(0x0458);break;//je
			case 0x6B:pMathType=mi;pmt(0x043A);break;//ka
			case 0x6C:pMathType=mi;pmt(0x043B);break;//el
			case 0x6D:pMathType=mi;pmt(0x043C);break;//em
			case 0x6E:pMathType=mi;pmt(0x043D);break;//en
			case 0x6F:pMathType=mi;pmt(0x043E);break;//o
			case 0x70:pMathType=mi;pmt(0x043F);break;//pe
			case 0x71:pMathType=mi;pmt(0x0447);break;//che
			case 0x72:pMathType=mi;pmt(0x0440);break;//er
			case 0x73:pMathType=mi;pmt(0x0441);break;//es
			case 0x74:pMathType=mi;pmt(0x0442);break;//te
			case 0x75:pMathType=mi;pmt(0x0443);break;//u
			case 0x76:pMathType=mi;pmt(0x0432);break;//ve
			case 0x77:pMathType=mi;pmt(0x0449);break;//shcha
			case 0x78:pMathType=mi;pmt(0x0448);break;//sha
			case 0x79:pMathType=mi;pmt(0x044B);break;//yeru
			case 0x7A:pMathType=mi;pmt(0x0437);break;//ze
			
			case 0x7B:pMathType=moi;pmt(0x2013);break;//en dash
			case 0x7C:pMathType=moi;pmt(0x2014);break;//em dash
			case 0x7D:pMathType=moi;pmt(0x2116);break;//numero sign
			case 0x7E:pMathType=moi;pmt(0x044C);break;//soft
			case 0x7F:pMathType=moi;pmt(0x044A);break;//hard
			default:pMathType=mi;pmt(*temp);
			}
			temp++;
		}while(*temp);
		return;
	}
			
	if (strstr(currentFont,"eusm")){
		do{
			switch(*temp){
			case 0x00:pMathType=mo;pmt('-');break;//-
			//nothing
			case 0x18:pMathType=mo;pmt(0x223C);break;//\sim
			//nothing
			case 0x3A:pMathType=mo;pmt(0x00AC);break;//\neg
			//nothing
			case 0x3C:pMathType=mo;pmt(0x211C);break;//real part
			case 0x3D:pMathType=mo;pmt(0x2111);break;//image part
			//nothing
			case 0x40:pMathType=mo;pmt(0x2135);break;//\aleph transfinite
			case 0x41:
			case 0x42:
			case 0x43:
			case 0x44:
			case 0x45:
			case 0x46:
			case 0x47:
			case 0x48:
			case 0x49:
			case 0x4A:
			case 0x4B:
			case 0x4C:
			case 0x4D:
			case 0x4E:
			case 0x4F:
			
			case 0x50:
			case 0x51:
			case 0x52:
			case 0x53:
			case 0x54:
			case 0x55:
			case 0x56:
			case 0x57:
			case 0x58:
			case 0x59:
			case 0x5A:pMathType=mos;pmt(*temp);break;//A-Z script, straight
			//nothing
			case 0x5E:pMathType=mos;pmt(0x2227);break;//and
			case 0x5F:pMathType=mos;pmt(0x2228);break;//or
			
			//nothing
			case 0x66:pMathType=lds;pmt('{');break;//{
			case 0x67:pMathType=rds;pmt('}');break;//}
			//nothing
			case 0x6A:pMathType=mos;pmt('|');break;//
			//nothing
			case 0x6E:pMathType=mos;pmt('\\');break;//
			//nothing
			case 0x78:pMathType=mos;pmt(0x00A7);break;//section sign
			
			}
			temp++;
		}while(*temp);
		return;
	}

	if (strstr(currentFont,"euex")){
		do{
			switch(*temp){
			//nothing
			case 0x08:pMathType=ld;pmt('{');break;//
			case 0x09:pMathType=rd;pmt('}');break;//
			case 0x0A:pMathType=ld;pmt('{');break;//
			case 0x0B:pMathType=rd;pmt('}');break;//
			case 0x0C:pMathType=ld;pmt('{');break;//
			case 0x0D:pMathType=rd;pmt('}');break;//
			case 0x0E:pMathType=ld;pmt('{');break;//
			case 0x0F:pMathType=rd;pmt('}');break;//
			//nothing
			case 0x18:pMathType=mo;pmt(0x21BC);break;//left harpoon barb up
			case 0x19:pMathType=mo;pmt(0x21BD);break;//left harpoon barb down
			case 0x1A:pMathType=mo;pmt(0x21C0);break;//right harpoon barb up
			case 0x1B:pMathType=mo;pmt(0x21C1);break;//right harpoon barb down
			//nothing
			case 0x20:pMathType=mo;pmt(0x2190);break;//left arrow
			case 0x21:pMathType=mo;pmt(0x2192);break;//right arrow
			case 0x22:pMathType=mo;pmt(0x2191);break;//up arrow
			case 0x23:pMathType=mo;pmt(0x2193);break;//down arrow
			case 0x24:pMathType=mo;pmt(0x2194);break;//left right arrow
			case 0x25:pMathType=mo;pmt(0x2197);break;//N-E arrow
			case 0x26:pMathType=mo;pmt(0x2198);break;//S-E arrow
			//nothing
			case 0x28:pMathType=mo;pmt(0x21D0);break;//left double arrow
			case 0x29:pMathType=mo;pmt(0x21D2);break;//right double arrow
			case 0x2A:pMathType=mo;pmt(0x21D1);break;//up double arrow
			case 0x2B:pMathType=mo;pmt(0x21D3);break;//down double arrow
			case 0x2C:pMathType=mo;pmt(0x21D4);break;//left right double arrow
			case 0x2D:pMathType=mo;pmt(0x2196);break;//N-W arrow
			case 0x2E:pMathType=mo;pmt(0x2199);break;//S-W arrow
			//nothing
			case 0x31:pMathType=mo;pmt(0x221E);break;//infinity
			
			case 0x38:pMathType=ld;pmt('{');break;//infinity
			//XXX, let the extensions out and mark only the margins
			//XXX, scaling is done by the mathplayer
			case 0x3B:pMathType=rd;pmt('{');break;//infinity
			
			//nothing
			
			case 0x48:
			case 0x49:pMathType=mo;pmt(0x222E);break;//\oint
			//nothing
			
			case 0x50:pMathType=mo;pmt(0x2211);break;//sum
			case 0x51:pMathType=mo;pmt(0x220F);break;//product
			case 0x52:pMathType=mo;pmt(0x222B);break;//\int
			//nothing
			case 0x58:pMathType=mo;pmt(0x2211);break;//sum
			case 0x59:pMathType=mo;pmt(0x220F);break;//product
			case 0x5A:pMathType=mo;pmt(0x222B);break;//\int
			//nothing
			case 0x60:
			case 0x61:pMathType=mo;pmt(0x220F);break;//n-ary coproduct
			//nothing
			//nothing
			case 0x6C:pMathType=mo;pmt(0x2195);break;//up down arrow
			case 0x6D:pMathType=mo;pmt(0x21D5);break;//up down double arrow
			
			//nothing, XXX, brace extensions, let the player do it
			
			}
			temp++;
		}while(*temp);
		return;
	}
		
	if (strstr(currentFont,"rsfs")){
		do{
			switch(*temp){
			
			case 0x7F:pMathType=mo;pmt(0x2040);break;//tie
			
			default: pMathType=mis;pmt('Z');break;//pMathType=mi;pmt(0x1D4B5);break;//A-Z script; 
			}
			temp++;
		}while(*temp);
		return;
	}
	
		
	if (strstr(currentFont,"lassdc")){
		do{
			switch(*temp){
			case 0x00:pMathType=mobss;pmt(0x0060);break;//grave accent
			case 0x01:pMathType=mobss;pmt(0x00B4);break;//acute accent
			case 0x02:pMathType=mobss;pmt(0x005E);break;//hat
			case 0x03:pMathType=mobss;pmt(0x007E);break;//tilde
			case 0x04:pMathType=mobss;pmt(0x0308);break;//XXX, it is combining, should be put in combineAccent
			case 0x05:pMathType=mobss;pmt(0x02DD);break;//double acute accent
			case 0x06:pMathType=mobss;pmt(0x02DA);break;//ring above
			case 0x07:pMathType=mobss;pmt(0x02C7);break;//caron, hacek
			case 0x08:pMathType=mobss;pmt(0x02D8);break;//breve
			case 0x09:pMathType=mobss;pmt(0x00AF);break;//macron
			case 0x0A:pMathType=mobss;pmt(0x02D9);break;//dot above
			case 0x0B:pMathType=mobss;pmt(0x00B8);break;//cedilla
			case 0x0C:pMathType=mobss;pmt(0x02DB);break;//ogonek
			case 0x0D:pMathType=mobss;pmt(0x201A);break;//single low quot-mark
			case 0x0E:pMathType=mobss;pmt(0x2329);break;//left angle
			case 0x0F:pMathType=mobss;pmt(0x232A);break;//right angle
			

			case 0x10:pMathType=ldbss;pmt(0x201C);break;//left double quotation mark
			case 0x11:pMathType=ldbss;pmt(0x201D);break;//right double quotation mark
			case 0x12:pMathType=mobss;pmt(0x0311);break;//frown, combining inverted breve
			case 0x13:pMathType=mobss;pmt(0x030F);break;//combining double breve
			case 0x14:pMathType=mobss;pmt(0x0306);break;//combining breve, XXX should be cyrillic breve
			case 0x15:pMathType=mobss;pmt(0x2013);break;//en dash
			case 0x16:pMathType=mobss;pmt(0x2014);break;//em dash
			case 0x17:pMathType=mobss;pmt(0xE003F);break;//XXX, error mark: I chose TAG question mark
			case 0x18:pMathType=mobss;pmt('0');break;//XXX, pmzero???
			case 0x19:pMathType=mobss;pmt(0x0131);break;//imath
			case 0x1A:pMathType=mobss;pmt(0x006A);break;//jmath,pmt(0x0237);break;//jmath
			case 0x1B:pMathType=mobss;pmt('f');pMathType=mo;pmt('f');break;//p(ul2utf8(0xFB00));break;//ligature ff
			case 0x1C:pMathType=mobss;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB01));break;//ligature fi
			case 0x1D:pMathType=mobss;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB02));break;//ligature fl
			case 0x1E:pMathType=mobss;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('i');break;//p(ul2utf8(0xFB03));break;//ligature ffi
			case 0x1F:pMathType=mobss;pmt('f');pMathType=mo;pmt('f');pMathType=mo;pmt('l');break;//p(ul2utf8(0xFB04));break;//ligature ffl

			case 0x20:pMathType=mobss;pmt(0x2423);break;//graphic for space
			case 0x21:pMathType=mobss;pmt(*temp);break;//!
			case 0x22:pMathType=mobss;pmt(0x201D);break;//right double quotation mark
			case 0x23:
			case 0x24:
			case 0x25:pMathType=mobss;pmt(*temp);break;
			case 0x26:
				if (mathmode && !mathText){
					p("<mo mathvariant=\"bold-sans-serif\">&amp;</mo>");
				}else 
					p("&amp;");
				break;//ampersand
			case 0x27:pMathType=mobss;pmt(0x2019);break;//quoteright
			case 0x28:pMathType=ldbss;pmt(*temp);break;//(
			case 0x29:pMathType=rdbss;pmt(*temp);break;//)
			case 0x2A:
			case 0x2B:
			case 0x2C:inhibitspace=0;pMathType=mo;pmt(*temp);break;
			case 0x2D:
			case 0x2E:
			case 0x2F:pMathType=mobss;pmt(*temp);break;

			case 0x30:
			case 0x31:
			case 0x32:
			case 0x33:
			case 0x34:
			case 0x35:
			case 0x36:
			case 0x37:
			case 0x38:
			case 0x39:pMathType=mnbss;pmt(*temp);break;
			case 0x3A:pMathType=mobss;pmt(*temp);break;//:
			case 0x3B:pMathType=mobss;pmt(*temp);break;//;
			case 0x3C://less than
				if(combiningUnicode==0x0338) { 
					combiningUnicode=0;
					pmt(0x226F);
				}	else	p("<mo mathvariant=\"bold-sans-serif\">&lt;</mo>");
				break;
			case 0x3D:pMathType=mobss;pmt(0x002F);break;//division
			case 0x3E: //greater than
				if(combiningUnicode==0x0338) { 
					combiningUnicode=0;
					pmt(0x226F);
				}	else	p("<mo mathvariant=\"bold-sans-serif\">&gt;</mo>");
				break;
			case 0x3F:pMathType=mobss;pmt(*temp);break;//?

			case 0x40:pMathType=mobss;pmt(*temp);break;//@

			case 0x5B:pMathType=ldbss;pmt(*temp);break;//[
			case 0x5C:pMathType=mobss;pmt(*temp);break;//backslash
			case 0x5D:pMathType=rdbss;pmt(*temp);break;//]
			
			case 0x5E:pMathType=mobss;pmt(*temp);break;//^
			case 0x5F:pMathType=mobss;pmt(*temp);break;//_
			case 0x60:pMathType=mobss;pmt(*temp);break;//`
			case 0x61:
			case 0x7A:break;//ascii small letters

			case 0x7B:pMathType=ldbss;pmt(*temp);break;//left brace
			case 0x7C:pMathType=mobss;pmt(*temp);break;//vertical bar
			case 0x7D:pMathType=rdbss;pmt(*temp);break;//right brace
			case 0x7E:pMathType=mobss;pmt(*temp);break;//tilde
			case 0x7F:pMathType=mobss;pmt(0x2012);break;//figure dash
			
			//cyrillic
			case 0x80:pMathType=mobss;pmt(0x0490);break;//GHE with upturn
			case 0x81:pMathType=mobss;pmt(0x0492);break;//GHE with stroke
			case 0x82:pMathType=mobss;pmt(0x0494);break;//GHE with midhook
			case 0x83:pMathType=mobss;pmt(0x040B);break;//TSHE
			case 0x84:pMathType=mobss;pmt(0x04BA);break;//SHHA
			case 0x85:pMathType=mobss;pmt(0x0496);break;//ZHE with descender
			case 0x86:pMathType=mobss;pmt(0x0498);break;//ZE with descender
			case 0x87:pMathType=mobss;pmt(0x0409);break;//LJE
			case 0x88:pMathType=mobss;pmt(0x0407);break;//YI
			case 0x89:pMathType=mobss;pmt(0x049A);break;//KA with descender
			case 0x8A:pMathType=mobss;pmt(0x04A1);break;//KA bashkir
			case 0x8B:pMathType=mobss;pmt(0x049C);break;//KA with vertical stroke
			case 0x8C:pMathType=mobss;pmt(0x04D4);break;//ligature A IE
			case 0x8D:pMathType=mobss;pmt(0x04A2);break;//EN with descender
			case 0x8E:pMathType=mobss;pmt(0x04A4);break;//ligature EN GHE
			case 0x8F:pMathType=mobss;pmt(0x0405);break;//DZE

			case 0x90:pMathType=mobss;pmt(0x0472);break;//FITA
			case 0x91:pMathType=mobss;pmt(0x04AA);break;//ES with descendent
			case 0x92:pMathType=mobss;pmt(0x040E);break;//short U
			case 0x93:pMathType=mobss;pmt(0x04AE);break;//straight U
			case 0x94:pMathType=mobss;pmt(0x04B0);break;//straight U with stroke
			case 0x95:pMathType=mobss;pmt(0x04B2);break;//HA with descender
			case 0x96:pMathType=mobss;pmt(0x040F);break;//DZHE
			case 0x97:pMathType=mobss;pmt(0x04B8);break;//CHE with vertical stroke
			case 0x98:pMathType=mobss;pmt(0x04B6);break;//CHE with descender
			case 0x99:pMathType=mobss;pmt(0x0404);break;//ukrainian IE
			case 0x9A:pMathType=mobss;pmt(0x04D8);break;//SCHWA
			case 0x9B:pMathType=mobss;pmt(0x040A);break;//NJE
			case 0x9C:pMathType=mobss;pmt(0x0451);break;//IO
			case 0x9D:pMathType=mobss;pmt(0x2116);break;//numero sign
			case 0x9E:pMathType=mobss;pmt(0x00A4);break;//currency sign
			case 0x9F:pMathType=mobss;pmt(0x00A7);break;//section sign

			case 0xA0:pMathType=mobss;pmt(0x0491);break;//ghe with upturn
			case 0xA1:pMathType=mobss;pmt(0x0493);break;//ghe with stroke
			case 0xA2:pMathType=mobss;pmt(0x0495);break;//ghe with midhook
			case 0xA3:pMathType=mobss;pmt(0x045B);break;//tshe
			case 0xA4:pMathType=mobss;pmt(0x04BB);break;//shha
			case 0xA5:pMathType=mobss;pmt(0x0497);break;//zhe with descender
			case 0xA6:pMathType=mobss;pmt(0x0499);break;//ze with descender
			case 0xA7:pMathType=mobss;pmt(0x0459);break;//lje
			case 0xA8:pMathType=mobss;pmt(0x0457);break;//yi
			case 0xA9:pMathType=mobss;pmt(0x0498);break;//ka with descender
			case 0xAA:pMathType=mobss;pmt(0x04A1);break;//ka bashkir
			case 0xAB:pMathType=mobss;pmt(0x049D);break;//ka with vertical stroke
			case 0xAC:pMathType=mobss;pmt(0x04D5);break;//ligature A IE
			case 0xAD:pMathType=mobss;pmt(0x04A3);break;//en with descender
			case 0xAE:pMathType=mobss;pmt(0x04A5);break;//ligature en ghe
			case 0xAF:pMathType=mobss;pmt(0x0455);break;//dze
			
			case 0xB0:pMathType=mobss;pmt(0x0473);break;//fita
			case 0xB1:pMathType=mobss;pmt(0x04AB);break;//es with descendent
			case 0xB2:pMathType=mobss;pmt(0x045E);break;//short u
			case 0xB3:pMathType=mobss;pmt(0x04AF);break;//straight u
			case 0xB4:pMathType=mobss;pmt(0x04B1);break;//straight u with stroke
			case 0xB5:pMathType=mobss;pmt(0x04B3);break;//ha with descender
			case 0xB6:pMathType=mobss;pmt(0x045F);break;//dzhe
			case 0xB7:pMathType=mobss;pmt(0x04B9);break;//che with vertical stroke
			case 0xB8:pMathType=mobss;pmt(0x04B7);break;//che with descender
			case 0xB9:pMathType=mobss;pmt(0x0454);break;//ukrainian IE
			case 0xBA:pMathType=mobss;pmt(0x04D9);break;//schwa
			case 0xBB:pMathType=mobss;pmt(0x045A);break;//nje
			case 0xBC:pMathType=mobss;pmt(0x0451);break;//io
			case 0xBD:pMathType=moss;pmt(0x201E);break;//low double comma quot-mark
			case 0xBE:pMathType=moss;pmt(0x00AB);break;//guillemet left 
			case 0xBF:pMathType=mobss;pmt(0x00BB);break;//guillemet right

			case 0xC0:pMathType=mobss;pmt(0x0410);break;//A
			case 0xC1:pMathType=mobss;pmt(0x0411);break;//BE
			case 0xC2:pMathType=mobss;pmt(0x0412);break;//VE
			case 0xC3:pMathType=mobss;pmt(0x0413);break;//GHE
			case 0xC4:pMathType=mobss;pmt(0x0414);break;//DE
			case 0xC5:pMathType=mobss;pmt(0x0415);break;//IE
			case 0xC6:pMathType=mobss;pmt(0x0416);break;//ZHE
			case 0xC7:pMathType=mobss;pmt(0x0417);break;//ZE
			case 0xC8:pMathType=mobss;pmt(0x0418);break;//I
			case 0xC9:pMathType=mobss;pmt(0x0419);break;//short I
			case 0xCA:pMathType=mobss;pmt(0x041A);break;//KA
			case 0xCB:pMathType=mobss;pmt(0x041B);break;//EL
			case 0xCC:pMathType=mobss;pmt(0x041C);break;//EM
			case 0xCD:pMathType=mobss;pmt(0x041D);break;//EN
			case 0xCE:pMathType=mobss;pmt(0x041E);break;//O
			case 0xCF:pMathType=mobss;pmt(0x041F);break;//PE

			case 0xD0:pMathType=mobss;pmt(0x0420);break;//ER
			case 0xD1:pMathType=mobss;pmt(0x0421);break;//ES
			case 0xD2:pMathType=mobss;pmt(0x0422);break;//TE
			case 0xD3:pMathType=mobss;pmt(0x0423);break;//U
			case 0xD4:pMathType=mobss;pmt(0x0424);break;//EF
			case 0xD5:pMathType=mobss;pmt(0x0425);break;//HA
			case 0xD6:pMathType=mobss;pmt(0x0426);break;//TSE
			case 0xD7:pMathType=mobss;pmt(0x0427);break;//CHE
			case 0xD8:pMathType=mobss;pmt(0x0428);break;//SHA
			case 0xD9:pMathType=mobss;pmt(0x0429);break;//SHCHA
			case 0xDA:pMathType=mobss;pmt(0x042A);break;//HARD sign
			case 0xDB:pMathType=mobss;pmt(0x042B);break;//YERU
			case 0xDC:pMathType=mobss;pmt(0x042C);break;//SOFT sign
			case 0xDD:pMathType=mobss;pmt(0x042D);break;//E
			case 0xDE:pMathType=mobss;pmt(0x042E);break;//YU
			case 0xDF:pMathType=mobss;pmt(0x042F);break;//YA
			
			case 0xE0:pMathType=mobss;pmt(0x0430);break;//a
			case 0xE1:pMathType=mobss;pmt(0x0431);break;//be
			case 0xE2:pMathType=mobss;pmt(0x0432);break;//ve
			case 0xE3:pMathType=mobss;pmt(0x0433);break;//ghe
			case 0xE4:pMathType=mobss;pmt(0x0434);break;//de
			case 0xE5:pMathType=mobss;pmt(0x0435);break;//ie
			case 0xE6:pMathType=mobss;pmt(0x0436);break;//zhe
			case 0xE7:pMathType=mobss;pmt(0x0437);break;//ze
			case 0xE8:pMathType=mobss;pmt(0x0438);break;//i
			case 0xE9:pMathType=mobss;pmt(0x0439);break;//short i
			case 0xEA:pMathType=mobss;pmt(0x043A);break;//ka
			case 0xEB:pMathType=mobss;pmt(0x043B);break;//el
			case 0xEC:pMathType=mobss;pmt(0x043C);break;//em
			case 0xED:pMathType=mobss;pmt(0x043D);break;//en
			case 0xEE:pMathType=mobss;pmt(0x043E);break;//o
			case 0xEF:pMathType=mobss;pmt(0x043F);break;//pe

			case 0xF0:pMathType=mobss;pmt(0x0440);break;//er
			case 0xF1:pMathType=mobss;pmt(0x0441);break;//es
			case 0xF2:pMathType=mobss;pmt(0x0442);break;//te
			case 0xF3:pMathType=mobss;pmt(0x0443);break;//u
			case 0xF4:pMathType=mobss;pmt(0x0444);break;//ef
			case 0xF5:pMathType=mobss;pmt(0x0445);break;//ha
			case 0xF6:pMathType=mobss;pmt(0x0446);break;//tse
			case 0xF7:pMathType=mobss;pmt(0x0447);break;//che
			case 0xF8:pMathType=mobss;pmt(0x0448);break;//sha
			case 0xF9:pMathType=mobss;pmt(0x0449);break;//shcha
			case 0xFA:pMathType=mobss;pmt(0x044A);break;//hard sign
			case 0xFB:pMathType=mobss;pmt(0x044B);break;//yeru
			case 0xFC:pMathType=mobss;pmt(0x044C);break;//soft sign
			case 0xFD:pMathType=mobss;pmt(0x044D);break;//e
			case 0xFE:pMathType=mobss;pmt(0x044E);break;//yu
			case 0xFF:pMathType=mobss;pmt(0x044F);break;//ya
			
			default:pMathType=mobss;pmt(*temp);
			}
			temp++;
		}while(*temp);
		return;
	}


*/

char* ul2utf8(unsigned int unicode){
	unsigned int mask=0x3F;
	unsigned char u1,u2=0x80,u3=0x80,u4=0x80,u5=0x80,u6=0x80;
	static char s[7];
	if (unicode>=0x04000000) u1=126;
		else if (unicode>=0x00200000) u1=62;
			else if (unicode>=0x00010000) u1=30;
				else if (unicode>=0x00000800) u1=14;
					else if (unicode>=0x00000080) u1=6;
						else u1=0;
	switch(u1){
		case 0:
			u1=unicode;
			sprintf(s,"%c",u1);
			break;
		case 6:
			u2+=unicode & mask;
			u1=(u1<<5)+(unicode>>6 & mask>>1);
			sprintf(s,"%c%c",u1,u2);
			break;
		case 14:
			u3+=unicode & mask;
			u2+=unicode>>6 & mask;
			u1=(u1<<4)+(unicode>>12 & mask>>2);
			sprintf(s,"%c%c%c",u1,u2,u3);
			break;
		case 30:
			u4+=unicode & mask;
			u3+=unicode>>6 & mask;
			u2+=unicode>>12 & mask;
			u1=(u1<<3)+(unicode>>18 & mask>>3);
			sprintf(s,"%c%c%c%c",u1,u2,u3,u4);
			break;
		case 62:
			u5+=unicode & mask;
			u4+=unicode>>6 & mask;
			u3+=unicode>>12 & mask;
			u2+=unicode>>18 & mask;
			u1=(u1<<2)+(unicode>>24 & mask>>4);
			sprintf(s,"%c%c%c%c%c",u1,u2,u3,u4,u5);
			break;
		case 126:
			u6+=unicode & mask;
			u5+=unicode>>6 & mask;
			u4+=unicode>>12 & mask;
			u3+=unicode>>18 & mask;
			u2+=unicode>>24 & mask;
			u1=(u1<<1)+(unicode>>30 & mask>>5);
			sprintf(s,"%c%c%c%c%c%c",u1,u2,u3,u4,u5,u6);
			break;
	}
	return s;
}


void pmt(unsigned int unicode){
	if (mathmode && !mathText && !mathOp){
		if (unicode!=blockthis) blockthis=0xFFFF;
		else return;
		switch(pMathType){
		case mi:
			switch(theFont.family){
			case serif:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo>");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mi>");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mi mathvariant=\"bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//serif
			case sans:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-sans-serif\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mi mathvariant=\"sans-serif-italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mi mathvariant=\"sans-serif-bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//sans
			case monospace:
				switch (theFont.style){
				case upright:
					p("<mo mathvariant=\"monospace\">");
				break;	//upright
				case italic: 
				case oblique:	
					p("<mi mathvariant=\"monospace\">");
				break;	//italic
				}
			break;	//monospace
			case cursive:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"script\">");
					break;	//normalWeight
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-script\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mi mathvariant=\"script\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mi mathvariant=\"bold-script\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//cursive
			case doubleStruck:
				switch (theFont.style){
				case upright:
					p("<mo mathvariant=\"double-struck\">");
				break;	//upright
				case italic: 
				case oblique:	
					p("<mi mathvariant=\"double-struck\">");
				break;	//italic
				}
			break;	//doubleStruck
			case fraktur:	
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"fraktur\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-fraktur\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mi mathvariant=\"fraktur\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mi mathvariant=\"bold-fraktur\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//fraktur
			case fantasy:	//ignore
			break;
			}
		break;	//mi
		case mo:
			switch(theFont.family){
			case serif:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo>");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//serif
			case sans:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-sans-serif\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif-italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"sans-serif-bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//sans
			case monospace:
					p("<mo mathvariant=\"monospace\">");//XXX, wha', no italic here?
			break;	//monospace
			case cursive:
				switch (theFont.weight){
				case hairline: 
				case extraLight:
				case light: 
				case book: 
				case normalWeight: 
				case medium:
					p("<mo mathvariant=\"script\">");
				break;	//normal
				case demiBold:
				case semiBold:
				case bold: 
				case extraBold: 
				case heavy: 
				case black: 
				case ultraBlack:
				case poster:
					p("<mo mathvariant=\"bold-script\">");
				break;	//bold
				}
			break;	//cursive
			case doubleStruck:
				p("<mo mathvariant=\"double-struck\">");
			break;	//doubleStruck
			case fraktur:	
				switch (theFont.weight){
				case hairline: 
				case extraLight:
				case light: 
				case book: 
				case normalWeight: 
				case medium:
					p("<mo mathvariant=\"fraktur\">");
				break;	//normal
				case demiBold:
				case semiBold:
				case bold: 
				case extraBold: 
				case heavy: 
				case black: 
				case ultraBlack:
				case poster:
					p("<mo mathvariant=\"bold-fraktur\">");
				break;	//bold
				}
			break;	//fraktur
			case fantasy:	//ignore
			break;
			}
		break;	//mo
		case mn:
			fixDigits();//XXX needs fixing itself :), currently ignores number formatting
			break;
		case ld:
		case ld_b:
			if(!mDelimiter) p("<mrow>");
			switch(theFont.family){
			case serif:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo>");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//serif
			case sans:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-sans-serif\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif-italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"sans-serif-bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//sans
			case monospace:
					p("<mo mathvariant=\"monospace\">");//XXX, wha', no italic here?
			break;	//monospace
			case cursive:
				switch (theFont.weight){
				case hairline: 
				case extraLight:
				case light: 
				case book: 
				case normalWeight: 
				case medium:
					p("<mo mathvariant=\"script\">");
				break;	//normal
				case demiBold:
				case semiBold:
				case bold: 
				case extraBold: 
				case heavy: 
				case black: 
				case ultraBlack:
				case poster:
					p("<mo mathvariant=\"bold-script\">");
				break;	//bold
				}
			break;	//cursive
			case doubleStruck:
				p("<mo mathvariant=\"double-struck\">");
			break;	//doubleStruck
			case fraktur:	
				switch (theFont.weight){
				case hairline: 
				case extraLight:
				case light: 
				case book: 
				case normalWeight: 
				case medium:
					p("<mo mathvariant=\"fraktur\">");
				break;	//normal
				case demiBold:
				case semiBold:
				case bold: 
				case extraBold: 
				case heavy: 
				case black: 
				case ultraBlack:
				case poster:
					p("<mo mathvariant=\"bold-fraktur\">");
				break;	//bold
				}
			break;	//fraktur
			case fantasy:	//ignore
			break;
			}
		break;//ld,ld_b
		case rd:	
		case rd_b:
			if(!mDelimiter) p("</mrow>");
			switch(theFont.family){
			case serif:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo>");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//serif
			case sans:
				switch (theFont.style){
				case upright:
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"bold-sans-serif\">");
					break;	//bold
					}
				break;	//upright
				case italic: 
				case oblique:	
					switch (theFont.weight){
					case hairline: 
					case extraLight:
					case light: 
					case book: 
					case normalWeight: 
					case medium:
						p("<mo mathvariant=\"sans-serif-italic\">");
					break;	//normal
					case demiBold:
					case semiBold:
					case bold: 
					case extraBold: 
					case heavy: 
					case black: 
					case ultraBlack:
					case poster:
						p("<mo mathvariant=\"sans-serif-bold-italic\">");
					break;	//bold
					}
				break;	//italic
				}
			break;	//sans
			case monospace:
					p("<mo mathvariant=\"monospace\">");//XXX, wha', no italic here?
			break;	//monospace
			case cursive:
				switch (theFont.weight){
				case hairline: 
				case extraLight:
				case light: 
				case book: 
				case normalWeight: 
				case medium:
					p("<mo mathvariant=\"script\">");
				break;	//normal
				case demiBold:
				case semiBold:
				case bold: 
				case extraBold: 
				case heavy: 
				case black: 
				case ultraBlack:
				case poster:
					p("<mo mathvariant=\"bold-script\">");
				break;	//bold
				}
			break;	//cursive
			case doubleStruck:
				p("<mo mathvariant=\"double-struck\">");
			break;	//doubleStruck
			case fraktur:	
				switch (theFont.weight){
				case hairline: 
				case extraLight:
				case light: 
				case book: 
				case normalWeight: 
				case medium:
					p("<mo mathvariant=\"fraktur\">");
				break;	//normal
				case demiBold:
				case semiBold:
				case bold: 
				case extraBold: 
				case heavy: 
				case black: 
				case ultraBlack:
				case poster:
					p("<mo mathvariant=\"bold-fraktur\">");
				break;	//bold
				}
			break;	//fraktur
			case fantasy:	//ignore
			break;
			}
		break;	//rd,rd_b
		case ld_x:
		case rd_x:
		case ld_e:
		case rd_e:
		break;
	}

		p(ul2utf8(unicode));
		if (combiningUnicode) {
			p(ul2utf8(combiningUnicode));
			combiningUnicode=0;
		}

		switch(pMathType){
			case mi:
				switch (theFont.style){
				case upright:
					p("</mo>");
				break;	//upright
				case italic: 
				case oblique:	
					p("</mi>");
				break;	//italic
				}
			break;	//mi
			case mo:
				p("</mo>");
			break;
			case mn:
				p("</mn>");
			break;
			case ld:
			case ld_e:
				p("</mo>"); 
				if(!mDelimiter) p("<mrow>");
				Wraps[depth]++;
			break;
			case rd:
			case rd_e:
				p("</mo>");
				if(!mDelimiter) p("</mrow>");
//				if (Wraps[depth]==0)
//					die("right delimiter consumed too early\n");
				Wraps[depth]--;
			break;
			case ld_b:
			case rd_b:
			case ld_x:
			case rd_x:
			break;
		}
	}else {
		p(ul2utf8(unicode));
		if (combiningUnicode) {
			contractTextAccent();			
			combiningUnicode=0;
		}
	}
	return;
}

void saveAccent(char accent){
	//if (strstr(theFont.name,"cmr")|| strstr(theFont.name,"cmbx")|| strstr(theFont.name,"pplr")|| strstr(theFont.name,"cmcsc")){
	if (theFont.map==fontMap7t){
			switch(accent){
			case 0x12:combiningUnicode=0x0300;break;//grave accent
			case 0x13:combiningUnicode=0x0301;break;//acute accent
			case 0x14:combiningUnicode=0x030C;break;//caron, hacek
			case 0x15:combiningUnicode=0x0306;break;//breve
			case 0x16:combiningUnicode=0x0304;break;//macron
			case 0x17:combiningUnicode=0x030A;break;//ring above
			case 0x18:combiningUnicode=0x0327;break;//cedilla below 
			case 0x20:combiningUnicode=0x0337;break;//short solidus overlay
			case 0x5E:combiningUnicode=0x0302;break;//circumflex
			case 0x5F:combiningUnicode=0x0307;break;//dot above
			case 0x63:combiningUnicode=0x0063;break;//special case 'c' from copyright
			case 0x7D:combiningUnicode=0x030B;break;//long hungarian umlaut, combining double acute accent
			case 0x7E:combiningUnicode=0x0342;break;//tilde
			case 0x7F:combiningUnicode=0x0308;break;//diaeresis
			}
	}
	if (theFont.map==fontMapMathItalic){
		switch(accent){
			case 0x7F:combiningUnicode=0x2040;break;//tie
		}
	}
	return;
}

void saveAccentUnder(char accent){
	if (theFont.map==fontMap7t){
			switch(accent){
			case 0x16:combiningUnicode=0x0331;break;//macron below
			case 0x18:combiningUnicode=0x0327;break;//cedilla below
			case 0x2E:combiningUnicode=0x0323;break;//dot below
			}
	}
	return;
}

void InferContent(){
	char*from,utf8Operator[100];

	//divide
	from=doc_math;
	do{
	from=content(from,">/<","<apply><divide/><ci>","</ci></apply>");
	}while(from);

	//plus
	from=doc_math;
	do{
	from=content(from,">+<","<apply><plus/><ci>","</ci></apply>");
	}while(from);

	//minus
	from=doc_math;
	strcpy(utf8Operator,">");
	strcat(utf8Operator,ul2utf8(0x2212));
	strcat(utf8Operator,"<");
	do{
	from=content(from,utf8Operator,"<apply><minus/><ci>","</ci></apply>");
	}while(from);
	
	//begin relations 
	//equal
	from=doc_math;
	do{
	from=content(from,">=<","<apply><eq/><ci>","</ci></apply>");
	}while(from);
	
	//not equal
	from=doc_math;
	strcpy(utf8Operator,">");
	strcat(utf8Operator,ul2utf8(0x2260));
	strcat(utf8Operator,"<");
	do{
	from=content(from,utf8Operator,"<apply><neq/><ci>","</ci></apply>");
	}while(from);
	
	//greater than
	from=doc_math;
	do{
	from=content(from,">&gt;<","<apply><gt/><ci>","</ci></apply>");
	}while(from);

	//less than
	from=doc_math;
	do{
	from=content(from,">&lt;<","<apply><lt/><ci>","</ci></apply>");
	}while(from);
	
	//greater than or equal
	from=doc_math;
	strcpy(utf8Operator,">");
	strcat(utf8Operator,ul2utf8(0x2265));
	strcat(utf8Operator,"<");
	do{
	from=content(from,utf8Operator,"<apply><geq/><ci>","</ci></apply>");
	}while(from);
	
	//less than or equal
	from=doc_math;
	strcpy(utf8Operator,">");
	strcat(utf8Operator,ul2utf8(0x2264));
	strcat(utf8Operator,"<");
	do{
	from=content(from,utf8Operator,"<apply><leq/><ci>","</ci></apply>");
	}while(from);
	
	//equivalent
	from=doc_math;
	strcpy(utf8Operator,">");
	strcat(utf8Operator,ul2utf8(0x224D));
	strcat(utf8Operator,"<");
	do{
	from=content(from,utf8Operator,"<apply><equivalent/><ci>","</ci></apply>");
	}while(from);
	
	//approx
	from=doc_math;
	strcpy(utf8Operator,">");
	strcat(utf8Operator,ul2utf8(0x224A));
	strcat(utf8Operator,"<");
	do{
	from=content(from,utf8Operator,"<apply><approx/><ci>","</ci></apply>");
	}while(from);
	
	//end relations 
}

char* content(char*from,char*what, char*bas, char*eas){
	/* look for 'what' in 'from',
	find the previous argument and insert 'bas', then '</ci><ci>',
	then find the next argument and insert and 'eas'
	*/

	char *temp,*tail,*lock,*check;
	temp=lock=check=strstr(from,what);
	if (temp==NULL) return NULL;

	//ensure we're not at the end of a container
	check=strstr(++check,">");
	if (check==strstr(check,"><")){
		if (IsMMLContainerEnd(++check)) return ++lock;
	}else
		return ++lock;

	//ensure we're not at the beginning of a container
	while(*temp--!='<'){if (temp==from) return(++lock);};
	while(*temp--!='<'){if (temp==from) return(++lock);};
	if (IsMMLContainerStart(++temp)) return ++lock;

	lock=strstr(temp,what);
	lock=strstr(++lock,">");
	tail=(char*)malloc(strlen(++lock)+1);
	strcpy(tail,lock);
	lock=strstr(temp,"><");
	*++lock=0;
	lock=(char*)malloc(strlen(temp)+1);
	strcpy(lock,"<");
	strcat(lock,temp+2);
	temp=MatchTagLeft(temp,lock);
	free(lock);
	Insert(temp,bas);
	strcat(temp,"</ci><ci>");
	lock=strrchr(temp,0);
	strcat(temp,tail);
	free(tail);

	//'lock' points now to the beginning of the second argument
	temp=lock;
	temp=MatchTagRight(strstr(temp,"<"));
	Insert(temp,eas);
	return ++lock;
}

void beginSuperScript(){
	char*temp=strrchr(doc_math,0),*tail,*lock;
	lock=temp;
	//go to last closing tag
	while (strstr(temp,"</")!=temp) {
		if (temp==doc_math) {
			if (mathOp){	//a decorated operator
				Insert(temp,"<msup><mrow>");
				p("</mo></mrow><mrow><mo>");
			}else	//the author used $^
				Insert(temp,"<msup><mrow><mi> </mi></mrow><mrow>");
			return; 
		}
		if (strstr(temp,"<mrow")==temp || strstr(temp,"<mtd")==temp) {
			temp=strstr(temp,">");temp++;
			Insert(temp,"<msup><mrow><mi> </mi></mrow><mrow>");
			return; //the author used {}^ 
		}
		temp--;
	}
	
	
	if ((tail=strstr(temp," RD "))){
		temp=SkipBracketsLeft(tail);
	}else{
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,"<");
		strcat(tail,strstr(temp,"/")+1);
		*strstr(tail,">")=0;
		temp=MatchTagLeft(temp,tail);
		free(tail);
	}
	
	if (hbrace && temp==strstr(temp,"<munder")){
		Insert(temp,"<munder accentunder=\"true\">");
		p("<mrow>");
	}else{
		if (hbrace && temp==strstr(temp,"<mover")){
			Insert(temp,"<mover accent=\"true\">");
			p("<mrow>");
		}else{
				Insert(temp,"<msup><mrow>");
				p("</mrow><mrow>");
		}
	}
	if (mathOp) p("<mo>");
}

void beginSubScript(){
	char*temp=strrchr(doc_math,0),*tail,*lock;
	while (strstr(temp,"</")!=temp) {
		if (temp==doc_math) {
			if (mathOp){	//a decorated operator
				Insert(temp,"<msub><mrow>");
				p("</mo></mrow><mrow><mo>");
			}else	//the author used $_
				Insert(temp,"<msub><mrow><mi> </mi></mrow><mrow>");
			return; 
		}
		if (strstr(temp,"<mrow")==temp || strstr(temp,"<mtd")==temp) {
			temp=strstr(temp,">");temp++;
			Insert(temp,"<msub><mrow><mi> </mi></mrow><mrow>");
			return; //the author used {}_ 
		}
		temp--;
	}
	
	if ((tail=strstr(temp," RD "))){
		temp=SkipBracketsLeft(tail);
	}else{
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,"<");
		strcat(tail,strstr(temp,"/")+1);
		*strstr(tail,">")=0;
		lock=temp=MatchTagLeft(temp,tail);
		free(tail);
	}
	
	if (temp==strstr(temp,"<msup")){
		lock=MatchTagRight(temp);
		while (lock!=strstr(lock,"</")) lock--;
		*lock=0;
		temp++;temp++;
		Insert(temp,"sub");//make it a <msubsup> tag
		p("<mrow>");
	}else{
		if (hbrace && temp==strstr(temp,"<munder")){
			Insert(temp,"<munder accentunder=\"true\">");
			p("<mrow>");
		}else{
			if (hbrace && temp==strstr(temp,"<mover")){
				Insert(temp,"<mover accent=\"true\">");
				p("<mrow>");
			}else{
					Insert(temp,"<msub><mrow>");
					p("</mrow><mrow>");
			}
		}
	}
	if (mathOp) p("<mo>");
}

void endSubScript(){
	char*temp=strrchr(doc_math,0),*tail,*lock;
	if (mathOp) p("</mo>");
	p("</mrow>");
	
	temp=MatchTagLeft(temp,"<mrow");

	while (strstr(temp,"</mrow")!=temp) {
		if (temp!=doc_math) temp--;
		else die("error: can't reach first argument of 'subscript'\n");
	}
	temp=MatchTagLeft(temp,"<mrow");

	if (temp!=doc_math) {
		temp--;
		while (strstr(temp,"<")!=temp) temp--;
	}
	if (temp==strstr(temp,"</mrow>")){
		temp=MatchTagLeft(temp,"<mrow");
		if (temp!=doc_math) temp--;
		while (strstr(temp,"<")!=temp) {
			if (temp!=doc_math) temp--;
			else die("error: can't delimit first argument of 'subscript'\n");
		}
	}

	if (temp==strstr(temp,"<msubsup")){
		temp=strstr(temp,"<mrow>");
		temp=MatchTagRight(temp);
		lock=temp;
		temp=MatchTagRight(temp);
		tail=(char*)malloc(strlen(temp)+1);
		strcpy(tail,temp);
		*temp=0;
		Insert(lock,tail);
		free(tail);
		p("</msubsup>");
	}
	else
		if (temp==strstr(temp,"<munder")) p("</munder>");
		else {
			if (temp==strstr(temp,"<mover")) p("</mover>");
			else	p("</msub>");
		}
		
	if (mathOp) decorated=1;
}


void endSuperScript()
{
	char*temp=strrchr(doc_math,0);
	if (mathOp) p("</mo>");
	p("</mrow>");
	
	temp=MatchTagLeft(temp,"<mrow");

	while (strstr(temp,"</mrow")!=temp) {
		if (temp!=doc_math) temp--;
		else die("error:\n can't reach first argument of 'superscript'\n");
	}
	temp=MatchTagLeft(temp,"<mrow");

	if (temp!=doc_math) {
		temp--;
		while (strstr(temp,"<")!=temp) temp--;
	}
	if (temp==strstr(temp,"</mrow>")){
		temp=MatchTagLeft(temp,"<mrow");
		if (temp!=doc_math) temp--;
		while (strstr(temp,"<")!=temp) {
			if (temp!=doc_math) temp--;
			else die("error:\n can't delimit first argument of 'superscript'\n");
		}
	}
	
	if (temp==strstr(temp,"<munder")) p("</munder>");
	else {
		if (temp==strstr(temp,"<mover")) p("</mover>");
		else	p("</msup>");
	}
	
	if (mathOp) decorated=1;
}

void endMAccent(){
	char*temp=strrchr(doc_math,0),*tail;
	while (strstr(temp,"</mrow")!=temp) temp--;
	temp=MatchTagLeft(temp,"<mrow");
	tail=(char*)malloc(strlen(temp)+1);
	strcpy(tail,temp);*temp=0;
	while (strstr(temp,"</mrow")!=temp) {
		if (temp!=doc_math) temp--;
		else die("error in MAccent\n");
	}
	temp=MatchTagLeft(temp,"<mrow");
	Insert(temp,tail);
	free(tail);
}

void fixDigits(){
	char*temp=strrchr(doc_math,0);
	char dsep='.';
	//if there are previous digits don't put any <mn
	if (temp==doc_math){p("<mn>");return ;}
	while(*temp!='<'){
		temp--;
		if (temp==doc_math){p("<mn>");return ;}
	}
	if (temp==strstr(temp,"</mn>")) {
		*temp=0;return;
	}
	//if noninteger, unwrap the separator
	if (temp==strstr(temp,"</mo>")) {
		temp--;
		if (*temp=='.'){ //noninteger number, XXX localize separator
			dsep=*temp;
			temp=MatchTagLeft(temp,"<mo");
			temp--;
			if (temp==doc_math){p("<mn>");return ;}
			while(*temp!='<'){
				temp--;
				if (temp==doc_math){p("<mn>");return ;}
			}
		}
		if (temp==strstr(temp,"</mn")) {
			*temp++=dsep;
			*temp=0;
			return;			
		}
	}
	p("<mn>");
}

void precomposedNegative(unsigned int single, unsigned int composed){
//choose the precomposed negated operators where available
		if(combiningUnicode==0x0338) { 
				combiningUnicode=0;
				pmt(composed);
			}
		else	pmt(single);
}

void contractTextAccent(){
//mapping a character-accent combining pair into a single
//unicode character, if the accented character 
//is already available in the Unicode spec

	unsigned char*temp=(unsigned char*)strrchr(doc_text,0);
	unsigned char test=*(--temp);
	switch (test){
		case 'a':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xE0));//a with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xE1));//a with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01CE));//a with caron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x0103));//a with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x0101));//a with macron
				break;
				case 0x030A:
					*temp=0;
					p(ul2utf8(0x00E5));//a with ring above
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xE2));//a with circumflex
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0227));//a with dot above
				break;
				case 0x0342:
					*temp=0;
					p(ul2utf8(0x00E3));//a with tilde
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00E4));//a with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'A':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xC0));//A with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xC1));//A with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01CD));//A with caron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x0102));//A with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x0100));//A with macron
				break;
				case 0x030A:
					*temp=0;
					p(ul2utf8(0x00C5));//A with ring above
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xC2));//A with circumflex
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0226));//A with dot above
				break;
				case 0x0342:
					*temp=0;
					p(ul2utf8(0x00C3));//A with tilde
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00C4));//A with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'e':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xE8));//a with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xE9));//e with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x011B));//e with caron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x0115));//e with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x0113));//e with macron
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xEA));//e with circumflex
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0117));//e with dot above
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0xEB));//e with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'E':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xC8));//E with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xC9));//E with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x011A));//E with caron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x0114));//E with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x0112));//E with macron
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xCA));//E with circumflex
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0116));//E with dot above
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00CB));//E with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 177://the dotless i case
			temp--;
			if (*(unsigned char*)temp==196){
				switch (combiningUnicode){
					case 0x0300:
						*temp=0;
						p(ul2utf8(0xEC));//i with grave
					break;
					case 0x0301:
						*temp=0;
						p(ul2utf8(0xED));//i with acute
					break;
					case 0x0302:
						*temp=0;
						p(ul2utf8(0xEE));//i with circumflex
					break;
					case 0x0304:
						*temp=0;
						p(ul2utf8(0x012B));//i with macron
					break;
					case 0x0306:
						*temp=0;
						p(ul2utf8(0x012D));//i with breve
					break;
					case 0x0307:
						*temp=0;
						p(ul2utf8(0x0131));//i with_out_ dot above
					break;
					case 0x0308:
						*temp=0;
						p(ul2utf8(0x00EF));//i with diaeresis
					break;
					case 0x030C:
						*temp=0;
						p(ul2utf8(0x01D0));//i with caron
					break;
					case 0x0342:
						*temp=0;
						p(ul2utf8(0x0129));//i with tilde
					break;
					default:
						p(ul2utf8(combiningUnicode)); //leave them combined 
				};
			}
			break;
		case 'I':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xCC));//I with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xCD));//I with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xCE));//I with circumflex
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x012A));//I with macron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x012C));//I with breve
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0130));//I with dot above
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01CF));//I with caron
				break;
				case 0x0342:
					*temp=0;
					p(ul2utf8(0x0129));//I with tilde
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00CF));//I with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'o':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xF2));//o with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xF3));//o with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xF4));//o with circumflex
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x014F));//o with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x014D));//o with macron
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x022F));//o with dot above
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00F6));//o with diaeresis
				break;
				case 0x030B:
					*temp=0;
					p(ul2utf8(0x0151));//o with Hungarian umlaut
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01D2));//o with caron
				break;
				case 0x0342:
					*temp=0;
					p(ul2utf8(0x00F5));//o with tilde
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'O':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xD2));//O with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xD3));//O with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xD4));//O with circumflex
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x014C));//O with macron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x014E));//O with breve
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x022E));//O with dot above
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00D6));//O with diaeresis
				break;
				case 0x030B:
					*temp=0;
					p(ul2utf8(0x0150));//O with Hungarian umlaut
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01D1));//O with caron
				break;
				case 0x0342:
					*temp=0;
					p(ul2utf8(0x00D5));//O with tilde
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'u':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xF9));//u with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xFA));//u with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01D4));//u with caron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x016D));//u with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x016B));//u with macron
				break;
				case 0x030A:
					*temp=0;
					p(ul2utf8(0x016F));//u with ring above
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xFB));//u with circumflex
				break;
				case 0x030B:
					*temp=0;
					p(ul2utf8(0x0171));//u with Hungarian umlaut
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00FC));//u with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'U':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0xD9));//u with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0xDA));//u with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x01D3));//u with caron
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x016C));//u with breve
				break;
				case 0x0304:
					*temp=0;
					p(ul2utf8(0x016A));//u with macron
				break;
				case 0x030A:
					*temp=0;
					p(ul2utf8(0x016E));//u with ring above
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0xDB));//u with circumflex
				break;
				case 0x030B:
					*temp=0;
					p(ul2utf8(0x0170));//u with Hungarian umlaut
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0xDC));//u with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'c':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0107));//c with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x109));//c with circumflex
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x010B));//c with dot above
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x010D));//c with caron
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'C':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0106));//C with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x108));//C with circumflex
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x010A));//C with dot above
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x010C));//C with caron
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'd':
			switch (combiningUnicode){
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x010F));//d with caron
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'D':
			switch (combiningUnicode){
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x010E));//D with caron
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'g':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x011D));//g with circumflex
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x011F));//g with breve
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0121));//g with dot above
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0122));//g with cedilla
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'G':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x011C));//G with circumflex
				break;
				case 0x0306:
					*temp=0;
					p(ul2utf8(0x011D));//G with breve
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x0120));//G with dot above
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0122));//G with cedilla
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'h':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x0125));//h with circumflex
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'H':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x0124));//H with circumflex
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'k':
			switch (combiningUnicode){
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0137));//l with cedilla
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'K':
			switch (combiningUnicode){
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0136));//L with cedilla
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'l':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x013A));//l with acute
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x013C));//l with cedilla
				break;
				case 0x0337:
					*temp=0;
					p(ul2utf8(0x0142));//l with stroke
					inhibitspace=1;
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'L':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0139));//L with acute
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x013B));//L with cedilla
				break;
				case 0x0337:
					*temp=0;
					p(ul2utf8(0x0141));//L with stroke
					inhibitspace=1;
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'n':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0x01F9));//n with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0144));//n with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0148));//n with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0146));//n with cedilla
				break;
				case 0x0303:
					*temp=0;
					p(ul2utf8(0x00F1));//n with tilde
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'N':
			switch (combiningUnicode){
				case 0x0300:
					*temp=0;
					p(ul2utf8(0x01F8));//N with grave
				break;
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0143));//N with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0147));//N with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0145));//N with cedilla
				break;
				case 0x0342:
					*temp=0;
					p(ul2utf8(0x00D1));//n with tilde
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'r':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0155));//r with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0159));//r with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0157));//r with cedilla
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'R':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0154));//R with acute
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0158));//R with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0156));//R with cedilla
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 's':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x15B));//s with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x15D));//s with circumflex
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0161));//s with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x015F));//S with cedilla
					//p(ul2utf8(0x0219));//S with comma
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'S':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x15A));//S with acute
				break;
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x15C));//S with circumflex
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0160));//S with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x015E));//S with cedilla
					//p(ul2utf8(0x0218));//S with comma
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 't':
			switch (combiningUnicode){
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0165));//t with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0163));//t with cedilla 
					//p(ul2utf8(0x021B));//t with comma
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'T':
			switch (combiningUnicode){
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x0164));//T with caron
				break;
				case 0x0327:
					*temp=0;
					p(ul2utf8(0x0162));//T with cedilla
					//p(ul2utf8(0x021A));//T with comma
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'w':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x0175));//w with circumflex
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'W':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x0174));//w with circumflex
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'y':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x0177));//y with circumflex
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x00FF));//y with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'Y':
			switch (combiningUnicode){
				case 0x0302:
					*temp=0;
					p(ul2utf8(0x0176));//Y with circumflex
				break;
				case 0x0308:
					*temp=0;
					p(ul2utf8(0x0178));//Y with diaeresis
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'z':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x017A));//z with acute
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x017C));//z with dot above
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x017E));//z with caron
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 'Z':
			switch (combiningUnicode){
				case 0x0301:
					*temp=0;
					p(ul2utf8(0x0179));//Z with acute
				break;
				case 0x0307:
					*temp=0;
					p(ul2utf8(0x017B));//z with dot above
				break;
				case 0x030C:
					*temp=0;
					p(ul2utf8(0x017D));//z with caron
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		case 0x01://holder for big circle in cmsy, this is for the copyright symbol
			switch (combiningUnicode){//this should be 'c'
				case 'c':
					*temp=0;
					p(ul2utf8(0x00A9));//copyright sign
				break;
				default:
					p(ul2utf8(combiningUnicode)); //leave them combined 
			};
			break;
		default:
			p(ul2utf8(combiningUnicode)); //leave them combined 
	}
	combiningUnicode=0;
}

void AddPHint(int start){
	char* temp;
	if (!fakesp){strcat(doc_text," ");fakesp=1;}
	if (!pHints || (mathmode && !mathText)) return;
	if (start){
		strcat(doc_text,"<ph f=\""); strcat(doc_text,theFont.name);strcat(doc_text,"\">");
		pHint++;	//allow nested elements containing phints
	}	else{
		if (pHint){
			temp=strrchr(doc_text,0);
			if (temp!=doc_text){
				temp--;
				if (temp!=doc_text && *temp=='>'){
					do{
						temp--;
					}while(temp!=doc_text && *temp!='<');
					
					if (temp==strstr(temp,"<ph ")) {
						*temp=0;
						pHint--;
						return;
					}
				}
			}
			strcat(doc_text,"</ph>");pHint--;
		}
	}
}

void printFigureFileName(){
	char*filename=(char*)malloc(strlen(yytext)+1), *temp;
	temp=strstr(yytext," figFileName: ")+strlen(" figFileName: ");
	if (temp==NULL) die("\nin epsffile, expected ' figFileName: '\n");
	strcpy(filename,temp);
	temp=strrchr(filename,'.');
	if (temp) 
		*temp=0;
	else
		*strstr(filename," :figFileName ")=0;
	AddPHint(0);
	p("<source>");
	p(filename);
	p("</source>");
	free(filename);
	AddPHint(1);
}

void printEPSFigureFileName(){
	char*filename=(char*)malloc(strlen(yytext)+1), *temp;
	temp=strstr(yytext,"file=")+strlen("file=");
	if (temp==NULL) die("\nin epsfig, expected 'file='\n");
	strcpy(filename,temp);
	temp=strrchr(filename,'.');
	if (temp) 
		*temp=0;
	else
		*strstr(filename," :epsfigFileName ")=0;
	AddPHint(0);
	p("<source>");
	p(filename);
	p("</source>");
	AddPHint(1);
	free(filename);
}

void printRef(){
	char*ref=(char*)malloc(strlen(yytext)+1), *temp;
	char s[5]="";
	strcpy(ref,strstr(yytext,"@")+1);
	*strrchr(ref,'@')=0;
	temp=ref;
	p("<sref>");
	while(*temp){
		switch (*temp){
		case '<':
			strcpy(s,"&lt;");
			break;
		case '>':
			strcpy(s,"&gt;");
			break;
		default:
			*s=*temp;
			s[1]=0;
		}
		p(s);
		temp++;
	}	
	p("</sref>");
	free(ref);
}

void printId(){
	char*label=(char*)malloc(strlen(yytext)+1), *temp;
	char s[5]="";
	strcpy(label,strstr(yytext,"@")+1);
	*strrchr(label,'@')=0;
	temp=label;
	p("<id>");
	while(*temp){
		switch (*temp){
		case '<':
			strcpy(s,"&lt;");
			break;
		case '>':
			strcpy(s,"&gt;");
			break;
		default:
			*s=*temp;
			s[1]=0;
		}
		p(s);
		temp++;
	}	
	p("</id>");
	free(label);
}

void printOption(){
	char*option;
	if (!mathmode){
		option=(char*)malloc(strlen(yytext)+1);
		strcpy(option,strstr(yytext,":")+1);
		*strrchr(option,':')=0;
		p("<option>");
		p(option);
		p("</option>");
		free(option);
	}
}

void printFType(){
	char*type=(char*)malloc(strlen(yytext)+1);
	strcpy(type,strstr(yytext,":")+1);
	*strrchr(type,':')=0;
	p("<type>");
	p(type);
	p("</type>");
	free(type);
}


void printAbsLang(){
	char*label=(char*)malloc(strlen(yytext)+1);
	strcpy(label,strstr(yytext,"@")+1);
	*strrchr(label,'@')=0;
		AddPHint(0);
		p("<language type=\"");
		p(label);
		p("\"/>");
		AddPHint(1);
	free(label);
}

void printBkgColor(){
	char*label=(char*)malloc(strlen(yytext)+1);
	strcpy(label,strstr(yytext,"@")+1);
	*strrchr(label,'@')=0;
	AddPHint(0);
	p("<background color=\"");
	p(label);
	p("\"/>");
	AddPHint(1);
	free(label);
}

void printEnvType(){
	char*type=(char*)malloc(strlen(yytext)+1);
	strcpy(type,strstr(yytext,"@")+1);
	*strrchr(type,'@')=0;
	p("<type>");
	p(type);
	p("</type>");
	free(type);
}

void printSectType(){
	char*ref=(char*)malloc(strlen(yytext)+1);
	strcpy(ref,strstr(yytext,":")+1);
	*strrchr(ref,':')=0;
	p("<type>");
	p(ref);
	p("</type>");
	free(ref);
}

void printCiteSRef(){
	char* peek,*temp,*ref;
	int commas=0;
	peek=yytext;
	while((peek=strchr(peek,','))){
		commas++;peek++;
	}
	ref=(char*)malloc(strlen(yytext)+commas*strlen("</sref><sref>")+1);
	p("<sref>");
	peek=strchr(yytext,'@')+1;
	temp=ref;
	while (*peek!='@'){
		if (*peek==' '){ 
			peek++; continue;
		}
		if (*peek==','){
			strcpy(temp,"</sref><sref>");
			temp=strrchr(temp,0);
		}else
			*temp++=*peek;
		peek++;
	}
	*temp=0;
	p(ref);
	p("</sref>");
	free(ref);
}

void wrap(int open){
//pops/inserts phantom parentheses to fix the 
//well-formedness of math spread over cells
int i;
char* temp;
//fprintf (stderr,"%d,%s\n",open, doc_math);
	if (open>0){
		for (i=0;i<Wraps[depth];i++)
			p("<mrow><mrow>");
		return;
	}
	if (open==0){
		for (i=0;i<Wraps[depth];i++)
			p("</mrow></mrow>");
		return;
	}
	if (open<0){
		if ((temp=strstr(doc_math,"<mtd"))){
			temp=strchr(temp,'>'); temp++;
			Insert(temp,"<mrow><mrow>");
		}else
			Insert(doc_math,"<mrow><mrow>");
		return;
	}
}
