/*
Hermes seed utility version 0.9.10, 2006-08-01
author Romeo Anghelache http://romeo.roua.org
released under GNU GPL
*/

#ifdef WIN32
#include <windows.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int beginWrap (const char*what);
int endWrap (int toPost);
void escapeLine (char upto);
void skip ();
void die (char*reason);
static FILE*in, *out;

/* wrapping the regions where \over is active with \left. and \right.
e.g. ${a+b\over c}$ becomes ${\left.a+b\over c\right.}$
*/
int main (int argc, char **argv){
	char fnin[FILENAME_MAX],fnout[FILENAME_MAX],c,s[100],*peek, *stest;
	int i,result,seeded=0,post=0,cpin,cpout;
	long unbalanced[20];
	
	if (argc<2) {
		printf("error: no file argument given, quitting\n");
		exit(EXIT_FAILURE);
	}
	strcpy(fnin,argv[argc-1]);
	strcpy(fnout,fnin);
	peek=strrchr(fnout,'.');
	if (peek)
		*peek=0;
	strcat(fnout,".s.tex");
	in=fopen(fnin,"rb");
	if (in==NULL) {
		perror(fnin);
		exit(EXIT_FAILURE);
	}
	out=fopen(fnout,"wb+");
	if (out==NULL) {
		perror(fnout);
		exit(EXIT_FAILURE);
	}
	printf("Reading from:\t%s,\nWriting to:\t%s\n",fnin,fnout);
	
	do{
		result=fscanf(in,"%c",&c);
		if (result==EOF) break;
		
		if (c=='\\'){
			fseek(in,-1,SEEK_CUR);
			stest="\\renewcommand";
			fgets(s,strlen(stest)+2,in);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				fputs(s,out);
				do{
						fscanf(in,"%c",&c);
						fputc(c,out);
				} while(c!='}');
				continue;
			} 
			fseek(in,-strlen(s),SEEK_CUR);
			stest="\\over";
			fgets(s,strlen(stest)+2,in);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				fseek(in,-1,SEEK_CUR);
				post+=beginWrap(stest);
				unbalanced[post-1]=0;
				*s=0;
				continue;
			} 
			fseek(in,-strlen(s),SEEK_CUR);
			stest="\\choose";
			fgets(s,strlen(stest)+2,in);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				fseek(in,-1,SEEK_CUR);
				post+=beginWrap(stest);
				unbalanced[post-1]=0;
				*s=0;
				continue;
			} 
			fseek(in,-strlen(s),SEEK_CUR);
			stest="\\atop";
			fgets(s,strlen(stest)+2,in);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				fseek(in,-1,SEEK_CUR);
				post+=beginWrap(stest);
				unbalanced[post-1]=0;
				*s=0;
				continue;
			} 
			fseek(in,-strlen(s),SEEK_CUR);
			if (post){
					post-=endWrap(post);
					*s=0;
					continue;
			}
			if (!seeded){
				stest="\\DeclareMathOperator";				
				fgets(s,strlen(stest)+1,in);
				if (strlen(s)>=strlen(stest) && strcmp(s,stest)==0)
				{
					fputs("\\input dlt\n",out);
					fputs(s,out);
					seeded=1;
					continue;
				}
				fseek(in,-strlen(s),SEEK_CUR);				
				stest="\\begin{document}";				
				fgets(s,strlen(stest)+1,in);
				if (strlen(s)>=strlen(stest) && strcmp(s,stest)==0)
				{
					fputs("\\input dlt\n",out);
					fputs(s,out);
					seeded=1;
					continue;
				}
				fseek(in,-strlen(s),SEEK_CUR);				
				stest="\\input dlt";				
				fgets(s,strlen(stest)+1,in);
				if (strlen(s)>=strlen(stest) && strcmp(s,stest)==0)
				{
					fputs(s,out);
					seeded=1;
					continue;
				}
				fseek(in,-strlen(s),SEEK_CUR);				
			}
			fseek(in,1,SEEK_CUR);
			*s=0;
		}
			
		if (post){
			if (c=='$'){
					do{
						post--;
						fputs("\\right.",out);
					}while(post);
					fputc(c,out);
					continue;
			}
			if (c=='{'){
					unbalanced[post-1]++;
					fputc(c,out);
					continue;
			}
			if (c=='}'){
				if (unbalanced[post-1]>0){
					for (i=1;i<=post;i++){
						unbalanced[i-1]--;
					}
				}
				else	{
					post--;
					for (i=1;i<=post;i++){
						unbalanced[i-1]--;
					}
					fputs("\\right.",out);
					if (post<0){
						die("error: unbalanced '}'s\n");
						break;
					}

				}
				fputc(c,out);
				continue;
			}
		}
		
		fputc(c,out);
		if (c=='%')
			escapeLine('\n');
	}while (1);
	
	return fclose(in)+fclose(out);
}

int endWrap (int toPost){
	int result, posted=0;
	char s[100],*stest;
	stest="\\end";
	fgets(s,strlen(stest)+2,in);
	if (strlen(s)>=strlen(stest) \
		&& strstr(s,stest)==s )
	{
		if (isalpha (s[strlen(stest)])==0){
			do{
				toPost--;
				posted++;
				fputs("\\right.",out);
				fputs(s,out);
			}while(toPost);
				return posted;
		}	
	}
	fseek(in,-strlen(s),SEEK_CUR);
	stest="\\label";
	fgets(s,strlen(stest)+2,in);
	if (strlen(s)>=strlen(stest) \
		&& strstr(s,stest)==s )
	{
		if (isalpha (s[strlen(stest)])==0){
			do{
				toPost--;
				posted++;
				fputs("\\right.",out);
				fputs(s,out);
			}while(toPost);
				return posted;
		}	
	}
	fseek(in,-strlen(s),SEEK_CUR);
	result=fscanf(in,"%6[\\left]",s);
	if (strstr(s,"\\left")==s){
		fputs(s,out);
		return posted=0;
	}
	fputs(s,out);
	return posted=0;
}

int beginWrap (const char* what){
	long posout,final,unbalanced=1;
	int result,post=0,escape=0;
	char c, s[100],*tail;

	final=ftell(out);
	do{
		fseek(out,-1,SEEK_CUR);
		result=fscanf(out,"%c",&c);
		fseek(out,-1,SEEK_CUR);
		if (c=='}') unbalanced++;
		if (c=='{' && unbalanced) {
			if (unbalanced==1) {
				fseek(out,1,SEEK_CUR);
				break;
			}
			unbalanced--;
		}
		if (c=='#') escape=1;
		if (c=='$') {
			if (unbalanced==1) {
				fseek(out,1,SEEK_CUR);
				break;
			}
		}
		if (c=='\\'){
			char *stest="\\begin";
			fgets(s,strlen(stest)+2,out);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				fseek(out,-1,SEEK_CUR);
				skip();
				break;
			}	
			fseek(out,-strlen(s),SEEK_CUR);
			stest="\\label";
			fgets(s,strlen(stest)+2,out);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				fseek(out,-1,SEEK_CUR);
				skip();
				break;
			}	
			else
					fseek(out,-strlen(s),SEEK_CUR);
			stest="\\buildrel";
			fgets(s,strlen(stest)+2,out);
			if (strlen(s)>=strlen(stest) \
				&& strstr(s,stest)==s \
				&& isalpha (s[strlen(stest)])==0)
			{
				escape=1;
			}
			fseek(out,-strlen(s),SEEK_CUR);
		}
		if (escape){
			result=fseek(out,final,SEEK_SET);	
			fputs(what,out);
			return post=0;
		}
	}while(unbalanced);
	
	posout=ftell(out);
	tail=(char*)malloc(final-posout+1);
	fread(tail,1,final-posout,out);
	tail[final-posout]=0;
	fseek(out,posout-final,SEEK_CUR);
	fputs("\\left.",out);
	fputs(tail,out);
	free(tail);
	fputs(what, out);
	post++;
	return post;
}

void escapeLine(char upto){
	char c;
	int	result=fscanf(in,"%c",&c);
	if (result==EOF) return;
	while(c!=upto && result!=EOF){
		fputc(c,out);
		result=fscanf(in,"%c",&c);
		if (result==EOF) return;
	}
	fseek(in,-1,SEEK_CUR);
	return;
}

void skip(){
	int unbalanced=0;
	char c;
	do{
		fscanf(out,"%c",&c);
		switch(c){
			case '{':
				unbalanced++;
				break;
			case '}':
				unbalanced--;
				break;
			default:;
		}
	}	while (c!='}' || unbalanced);
}

void die(char* reason){
	printf("%s\n",reason);
	fclose(in);
	fclose(out);
	exit(EXIT_FAILURE);
}
